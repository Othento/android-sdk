@file:Suppress("FunctionNaming", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.progressSemantics
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion

/** Spec §5 — `KycLoaderSize`. Source: `apps/sdk/.../kyc-loader.scss:18-26`. */
@Immutable
internal enum class KycLoaderSize(
    val dimension: Dp,
    val strokeWidth: Dp,
) {
    Sm(20.dp, 2.dp),
    Md(32.dp, 2.5.dp),
    Lg(48.dp, 3.dp),
}

/** Spec §5 — `KycLoaderTone`. Source: `apps/sdk/.../kyc-loader.scss:28-36`. */
@Immutable
internal enum class KycLoaderTone { Primary, Neutral, Inverse }

/**
 * Indeterminate spinner. Faithful port of `apps/sdk/.../kyc-loader/`.
 *
 * - Default: a 270° arc (web's `border-top-color: transparent` on a full
 *   circle is geometrically equivalent) rotated 0 → 360° over 1600 ms with
 *   **ease-in-out** per `motion-arc-loop`.
 * - Reduced motion: rotation halts; the arc opacity-pulses 1 ↔ 0.4 over the
 *   same 1600 ms (`kyc-reduced-pulse` per `motion.scss:73-75`).
 */
@Composable
internal fun KycLoader(
    modifier: Modifier = Modifier,
    size: KycLoaderSize = KycLoaderSize.Md,
    tone: KycLoaderTone = KycLoaderTone.Primary,
    contentDescription: String = "Loading",
) {
    val color = colorFor(tone)
    val motion = LocalOthentoMotion.current
    val transition = rememberInfiniteTransition(label = "kyc-loader-transition")

    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = if (motion.reducedMotion) 0f else 360f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(durationMillis = motion.durationLoopMs, easing = motion.easeInOut),
                repeatMode = RepeatMode.Restart,
            ),
        label = "kyc-loader-angle",
    )
    val pulseAlpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (motion.reducedMotion) ReducedPulseMin else 1f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(durationMillis = motion.durationLoopMs, easing = motion.easeInOut),
                repeatMode = RepeatMode.Reverse,
            ),
        label = "kyc-loader-pulse",
    )

    Canvas(
        modifier =
            modifier
                .size(size.dimension)
                .rotate(rotation)
                .alpha(if (motion.reducedMotion) pulseAlpha else 1f)
                .progressSemantics()
                .semantics {
                    this.contentDescription = contentDescription
                    this.liveRegion = LiveRegionMode.Polite
                },
    ) {
        val stroke = size.strokeWidth.toPx()
        val arcSize =
            Size(
                width = this.size.width - stroke,
                height = this.size.height - stroke,
            )
        val topLeft = Offset(stroke / 2f, stroke / 2f)
        drawArc(
            color = color,
            startAngle = ArcStartDeg,
            sweepAngle = ArcSweepDeg,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = stroke),
        )
    }
}

@Composable
private fun colorFor(tone: KycLoaderTone): Color {
    val colors = LocalOthentoColors.current
    return when (tone) {
        KycLoaderTone.Primary -> colors.primary
        KycLoaderTone.Neutral -> colors.textMuted
        KycLoaderTone.Inverse -> Color.White
    }
}

private const val ArcStartDeg = -90f
private const val ArcSweepDeg = 270f
private const val ReducedPulseMin = 0.4f
