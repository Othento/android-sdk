package com.othento.core.internal.data.model

/**
 * Domain model for a single piece of evidence the active step needs.
 *
 * Per [docs/spec/09-data-models.md §2.2]. The OTP-specific fields are
 * present only on OTP challenges and are absent on document/selfie/liveness.
 *
 * [corporateEmailOnly] gates the email-OTP destination: when `true` the
 * email step accepts only corporate (non public/free) domains. Defaults
 * to `false` so it is a no-op for every non-email challenge.
 */
internal data class Challenge(
    val challengeType: ChallengeType,
    val challengeStatus: ChallengeStatus,
    val otpExpiresAt: String?,
    val otpSize: Int?,
    val otpAlphanumeric: Boolean?,
    val corporateEmailOnly: Boolean = false,
)
