@file:Suppress("MagicNumber", "LongMethod")

package com.othento.core.internal.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Hand-drawn [ImageVector]s for every inline SVG referenced by Phase-2
 * primitives. Path data follows the spec's wireframes and Lucide's public SVG
 * source ([scan-face](https://lucide.dev/icons/scan-face),
 * [user-check](https://lucide.dev/icons/user-check)).
 *
 * Icons are stroke-based with `Color.Black` so consumers can tint via
 * `ColorFilter.tint(color)` or `Icon(tint = color)`.
 */
internal object OthentoIcons {
    private val Stroke = SolidColor(Color.Black)

    /** Checkmark polyline. Used by KycStatusIcon `check`, KycStepList past-step. */
    val Check: ImageVector =
        builder("Check") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(20f, 6f)
                lineTo(9f, 17f)
                lineTo(4f, 12f)
            }
        }

    /** Two crossed lines. Used by KycStatusIcon `cross`. */
    val Cross: ImageVector =
        builder("Cross") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(18f, 6f)
                lineTo(6f, 18f)
                moveTo(6f, 6f)
                lineTo(18f, 18f)
            }
        }

    /** Circle with hour/minute hands. Used by KycStatusIcon `clock`. */
    val Clock: ImageVector =
        builder("Clock") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addCircle(12f, 12f, 10f)
                moveTo(12f, 6f)
                lineTo(12f, 12f)
                lineTo(16f, 14f)
            }
        }

    /** Circle with center exclamation. Used by KycStatusIcon `exclamation`. */
    val Exclamation: ImageVector =
        builder("Exclamation") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
            ) {
                addCircle(12f, 12f, 10f)
                moveTo(12f, 8f)
                lineTo(12f, 13f)
                moveTo(12f, 16f)
                lineTo(12.01f, 16f)
            }
        }

    /** ⓘ info circle. Used by KycTipList `list` variant. */
    val Info: ImageVector =
        builder("Info") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
            ) {
                addCircle(12f, 12f, 10f)
                moveTo(12f, 16f)
                lineTo(12f, 12f)
                moveTo(12f, 8f)
                lineTo(12.01f, 8f)
            }
        }

    /** ID-card glyph. Used by KycStepList `step_id_verification`. */
    val IdCard: ImageVector =
        builder("IdCard") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addRoundedRect(2f, 5f, 20f, 14f, 2.5f)
                addCircle(8.5f, 11f, 2f)
                moveTo(14f, 10f)
                lineTo(18f, 10f)
                moveTo(14f, 13.5f)
                lineTo(17f, 13.5f)
            }
        }

    /**
     * Passport-cover glyph — portrait rounded rect with a centered photo
     * circle and a caption bar near the bottom. Mirrors the web SDK's
     * inline SVG in `document-select-screen.html` lines 74-78.
     */
    val Passport: ImageVector =
        builder("Passport") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.5f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addRoundedRect(4f, 2f, 16f, 20f, 2f)
                addCircle(12f, 10f, 3f)
                moveTo(8f, 18f)
                lineTo(16f, 18f)
            }
        }

    /** Smartphone glyph. Used by KycStepList `step_phone_verification`. */
    val Smartphone: ImageVector =
        builder("Smartphone") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addRoundedRect(5f, 2f, 14f, 20f, 2.5f)
                moveTo(12f, 18f)
                lineTo(12.01f, 18f)
            }
        }

    /** Envelope glyph. Used by KycStepList `step_email_verification`. */
    val Envelope: ImageVector =
        builder("Envelope") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addRoundedRect(2f, 4f, 20f, 16f, 2.5f)
                moveTo(2f, 7f)
                lineTo(12f, 13f)
                lineTo(22f, 7f)
            }
        }

    /** Lucide `scan-face`. Used by KycStepList `step_liveness_check`. */
    val ScanFace: ImageVector =
        builder("ScanFace") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                // corner brackets
                moveTo(3f, 7f)
                lineTo(3f, 5f)
                arcTo(2f, 2f, 0f, false, true, 5f, 3f)
                lineTo(7f, 3f)
                moveTo(17f, 3f)
                lineTo(19f, 3f)
                arcTo(2f, 2f, 0f, false, true, 21f, 5f)
                lineTo(21f, 7f)
                moveTo(21f, 17f)
                lineTo(21f, 19f)
                arcTo(2f, 2f, 0f, false, true, 19f, 21f)
                lineTo(17f, 21f)
                moveTo(7f, 21f)
                lineTo(5f, 21f)
                arcTo(2f, 2f, 0f, false, true, 3f, 19f)
                lineTo(3f, 17f)
                // eyes + smile
                moveTo(8f, 14f)
                curveTo(8.5f, 15f, 10f, 16f, 12f, 16f)
                curveTo(14f, 16f, 15.5f, 15f, 16f, 14f)
                moveTo(9f, 9f)
                lineTo(9.01f, 9f)
                moveTo(15f, 9f)
                lineTo(15.01f, 9f)
            }
        }

    /** Lucide `user-check`. Used by KycStepList `step_face_match`. */
    val UserCheck: ImageVector =
        builder("UserCheck") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                // body curve
                moveTo(16f, 21f)
                lineTo(16f, 19f)
                arcTo(4f, 4f, 0f, false, false, 12f, 15f)
                lineTo(5f, 15f)
                arcTo(4f, 4f, 0f, false, false, 1f, 19f)
                lineTo(1f, 21f)
                // head circle
                addCircle(8.5f, 7f, 4f)
                // checkmark
                moveTo(17f, 11f)
                lineTo(19f, 13f)
                lineTo(23f, 9f)
            }
        }

    /** Chevron right. Used by KycStepList `compact` separator. */
    val ChevronRight: ImageVector =
        builder("ChevronRight") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2.5f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(9f, 6f)
                lineTo(15f, 12f)
                lineTo(9f, 18f)
            }
        }

    /**
     * Lock-shield. Used by the Phase-4 trust footer
     * ([docs/spec/06-screens/20-shared.md] §SdkLayout).
     *
     * Shape: a 14×14 padlock — rounded rectangle body with a U-shaped shackle.
     */
    val Lock: ImageVector =
        builder("Lock") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                // Body: 5,11 → 19,11 → 19,21 → 5,21 (closed rounded rect approximation).
                moveTo(5f, 11f)
                lineTo(19f, 11f)
                lineTo(19f, 21f)
                lineTo(5f, 21f)
                close()
                // Shackle arc from (8,11) up over (12,5) and back down to (16,11).
                moveTo(8f, 11f)
                lineTo(8f, 7f)
                arcTo(4f, 4f, 0f, false, true, 16f, 7f)
                lineTo(16f, 11f)
            }
        }

    /** Chevron down. Used by [com.othento.core.internal.ui.components.KycDropdown]. */
    val ChevronDown: ImageVector =
        builder("ChevronDown") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(6f, 9f)
                lineTo(12f, 15f)
                lineTo(18f, 9f)
            }
        }

    /** Arrow left. Used by `Change document` link in CaptureFallbackScreen. */
    val ArrowLeft: ImageVector =
        builder("ArrowLeft") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(19f, 12f)
                lineTo(5f, 12f)
                moveTo(12f, 19f)
                lineTo(5f, 12f)
                lineTo(12f, 5f)
            }
        }

    /**
     * Picture placeholder (rect + sun + mountain) per web's
     * `apps/sdk/.../capture/capture-screen.html` line 27 inline SVG.
     */
    val Picture: ImageVector =
        builder("Picture") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.5f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addRoundedRect(3f, 3f, 18f, 18f, 2f)
                addCircle(8.5f, 8.5f, 1.5f)
                moveTo(21f, 15f)
                lineTo(16f, 10f)
                lineTo(5f, 21f)
            }
        }

    /** Upload arrow (cloud-out shape) used by the upload-button glyph. */
    val UploadArrow: ImageVector =
        builder("UploadArrow") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(21f, 15f)
                lineTo(21f, 19f)
                arcTo(2f, 2f, 0f, false, true, 19f, 21f)
                lineTo(5f, 21f)
                arcTo(2f, 2f, 0f, false, true, 3f, 19f)
                lineTo(3f, 15f)
                moveTo(17f, 8f)
                lineTo(12f, 3f)
                lineTo(7f, 8f)
                moveTo(12f, 3f)
                lineTo(12f, 15f)
            }
        }

    /**
     * Sun glyph — circle + 8 rays — used as the "bright lighting" tip-card
     * icon (web `kyc-intro-sheet.html` line 154-158).
     */
    val Sun: ImageVector =
        builder("Sun") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addCircle(12f, 12f, 4f)
                moveTo(12f, 2f)
                lineTo(12f, 4f)
                moveTo(12f, 20f)
                lineTo(12f, 22f)
                moveTo(4.93f, 4.93f)
                lineTo(6.34f, 6.34f)
                moveTo(17.66f, 17.66f)
                lineTo(19.07f, 19.07f)
                moveTo(2f, 12f)
                lineTo(4f, 12f)
                moveTo(20f, 12f)
                lineTo(22f, 12f)
                moveTo(6.34f, 17.66f)
                lineTo(4.93f, 19.07f)
                moveTo(19.07f, 4.93f)
                lineTo(17.66f, 6.34f)
            }
        }

    /**
     * Four corner brackets enclosing nothing — used as the "all four corners
     * visible" tip icon (web `kyc-intro-sheet.html` line 159-163).
     */
    val FourCorners: ImageVector =
        builder("FourCorners") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(4f, 8f)
                lineTo(4f, 5f)
                arcTo(1f, 1f, 0f, false, true, 5f, 4f)
                lineTo(8f, 4f)
                moveTo(16f, 4f)
                lineTo(19f, 4f)
                arcTo(1f, 1f, 0f, false, true, 20f, 5f)
                lineTo(20f, 8f)
                moveTo(20f, 16f)
                lineTo(20f, 19f)
                arcTo(1f, 1f, 0f, false, true, 19f, 20f)
                lineTo(16f, 20f)
                moveTo(8f, 20f)
                lineTo(5f, 20f)
                arcTo(1f, 1f, 0f, false, true, 4f, 19f)
                lineTo(4f, 16f)
            }
        }

    /**
     * Square with crosshair lines — used as the "no glare" tip icon
     * (web `kyc-intro-sheet.html` line 164-168).
     */
    val Glare: ImageVector =
        builder("Glare") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(10f, 2f)
                lineTo(14f, 2f)
                lineTo(14f, 6f)
                moveTo(22f, 10f)
                lineTo(22f, 14f)
                lineTo(18f, 14f)
                moveTo(14f, 22f)
                lineTo(10f, 22f)
                lineTo(10f, 18f)
                moveTo(2f, 14f)
                lineTo(2f, 10f)
                lineTo(6f, 10f)
                addRoundedRect(7f, 7f, 10f, 10f, 1f)
            }
        }

    /**
     * Rectangle with diagonal cross — used as the "real document, no
     * screens" tip icon (web `kyc-intro-sheet.html` line 169-173).
     */
    val NoScreen: ImageVector =
        builder("NoScreen") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addRoundedRect(3f, 5f, 18f, 14f, 2f)
                moveTo(3f, 5f)
                lineTo(21f, 19f)
                moveTo(21f, 5f)
                lineTo(3f, 19f)
            }
        }

    /** Camera body — used by the camera-capture shutter button (Phase 6). */
    val Camera: ImageVector =
        builder("Camera") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                // Body — closed roundedrect with a notch top-center.
                moveTo(2f, 8f)
                arcTo(2f, 2f, 0f, false, true, 4f, 6f)
                lineTo(8f, 6f)
                lineTo(10f, 3f)
                lineTo(14f, 3f)
                lineTo(16f, 6f)
                lineTo(20f, 6f)
                arcTo(2f, 2f, 0f, false, true, 22f, 8f)
                lineTo(22f, 19f)
                arcTo(2f, 2f, 0f, false, true, 20f, 21f)
                lineTo(4f, 21f)
                arcTo(2f, 2f, 0f, false, true, 2f, 19f)
                close()
                addCircle(12f, 13f, 4f)
            }
        }

    /**
     * Camera body with a diagonal slash. Used by the camera permission-denied
     * / unavailable error UI. The "no camera" web SVG is in
     * `apps/sdk/.../camera-capture-screen.html` line 207-210 (Phase 6).
     */
    val CameraSlash: ImageVector =
        builder("CameraSlash") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(2f, 8f)
                arcTo(2f, 2f, 0f, false, true, 4f, 6f)
                lineTo(8f, 6f)
                lineTo(10f, 3f)
                lineTo(14f, 3f)
                lineTo(16f, 6f)
                lineTo(20f, 6f)
                arcTo(2f, 2f, 0f, false, true, 22f, 8f)
                lineTo(22f, 19f)
                arcTo(2f, 2f, 0f, false, true, 20f, 21f)
                lineTo(4f, 21f)
                arcTo(2f, 2f, 0f, false, true, 2f, 19f)
                close()
                addCircle(12f, 13f, 4f)
                moveTo(2f, 2f)
                lineTo(22f, 22f)
            }
        }

    /** Lightning bolt — torch on. Spec §05-capture #5 flash button. */
    val Bolt: ImageVector =
        builder("Bolt") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(13f, 2f)
                lineTo(3f, 14f)
                lineTo(12f, 14f)
                lineTo(11f, 22f)
                lineTo(21f, 10f)
                lineTo(12f, 10f)
                close()
            }
        }

    /** Lightning bolt with cancel slash — torch off. */
    val BoltOff: ImageVector =
        builder("BoltOff") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(13f, 2f)
                lineTo(3f, 14f)
                lineTo(12f, 14f)
                lineTo(11f, 22f)
                lineTo(21f, 10f)
                lineTo(12f, 10f)
                close()
                moveTo(2f, 22f)
                lineTo(22f, 2f)
            }
        }

    /** Circle with inner circle — "face the camera" tip icon (web `face`). */
    val Face: ImageVector =
        builder("Face") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addCircle(12f, 12f, 9f)
                addCircle(12f, 12f, 3f)
            }
        }

    /** Glasses — "remove glasses" tip icon (web `glasses`). */
    val Glasses: ImageVector =
        builder("Glasses") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addCircle(7f, 15f, 3f)
                addCircle(17f, 15f, 3f)
                moveTo(10f, 15f)
                lineTo(14f, 15f)
                moveTo(3f, 10f)
                lineTo(5f, 7f)
                lineTo(9f, 7f)
                moveTo(21f, 10f)
                lineTo(19f, 7f)
                lineTo(15f, 7f)
            }
        }

    /** Neutral expression smiley — "neutral expression" tip icon (web `neutral`). */
    val Neutral: ImageVector =
        builder("Neutral") {
            path(
                stroke = Stroke,
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                addCircle(12f, 12f, 10f)
                moveTo(9f, 10f)
                lineTo(9.01f, 10f)
                moveTo(15f, 10f)
                lineTo(15.01f, 10f)
                moveTo(8f, 15f)
                lineTo(16f, 15f)
            }
        }

    /** Warning triangle. Used by KycSandboxBanner. */
    val WarningTriangle: ImageVector =
        builder("WarningTriangle") {
            path(
                stroke = Stroke,
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(12f, 3f)
                lineTo(22f, 20f)
                lineTo(2f, 20f)
                close()
                moveTo(12f, 9f)
                lineTo(12f, 13f)
                moveTo(12f, 17f)
                lineTo(12.01f, 17f)
            }
        }

    private fun builder(
        name: String,
        block: ImageVector.Builder.() -> Unit,
    ): ImageVector =
        ImageVector
            .Builder(
                name = name,
                defaultWidth = 24.dp,
                defaultHeight = 24.dp,
                viewportWidth = 24f,
                viewportHeight = 24f,
            ).apply(block)
            .build()
}

/**
 * Adds a circle as a path segment. Compose's [path] DSL has no `addCircle`, so
 * we approximate via four quarter arcs.
 */
private fun androidx.compose.ui.graphics.vector.PathBuilder.addCircle(
    cx: Float,
    cy: Float,
    r: Float,
) {
    moveTo(cx + r, cy)
    arcTo(r, r, 0f, false, true, cx, cy + r)
    arcTo(r, r, 0f, false, true, cx - r, cy)
    arcTo(r, r, 0f, false, true, cx, cy - r)
    arcTo(r, r, 0f, false, true, cx + r, cy)
}

/**
 * Adds a rounded rectangle with all four corners radius [r]. Compose's [path]
 * DSL has no `addRoundedRect`, so we draw the perimeter explicitly.
 */
private fun androidx.compose.ui.graphics.vector.PathBuilder.addRoundedRect(
    x: Float,
    y: Float,
    width: Float,
    height: Float,
    r: Float,
) {
    val right = x + width
    val bottom = y + height
    moveTo(x + r, y)
    lineTo(right - r, y)
    arcTo(r, r, 0f, false, true, right, y + r)
    lineTo(right, bottom - r)
    arcTo(r, r, 0f, false, true, right - r, bottom)
    lineTo(x + r, bottom)
    arcTo(r, r, 0f, false, true, x, bottom - r)
    lineTo(x, y + r)
    arcTo(r, r, 0f, false, true, x + r, y)
    close()
}
