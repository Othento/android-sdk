@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Phase 9 — email destination input. Single-line text field with
 * regex-driven validation matching the web SDK's
 * `EmailDestinationInput` (spec [docs/spec/06-screens/10-otp-email.md]).
 *
 * The input itself is dumb — it pushes the trimmed raw value through
 * [onValueChange] and renders the [errorMessage] passed in. Validation
 * lives in [EmailValidator] so the OTP screen can compute it once and
 * pass the message + valid flag to both the input and the Send button.
 */
@Composable
internal fun EmailDestinationInput(
    raw: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    errorMessage: String? = null,
    disabled: Boolean = false,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val isError = errorMessage != null
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (disabled) colors.bgHover else colors.bgBase)
                    .border(
                        width = 1.dp,
                        color = if (isError) colors.error else colors.border,
                        shape = RoundedCornerShape(8.dp),
                    ).padding(horizontal = 14.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            BasicTextField(
                value = raw,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                enabled = !disabled,
                singleLine = true,
                textStyle = typography.body.copy(color = colors.textPrimary),
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                    ),
                cursorBrush = SolidColor(colors.primary),
                decorationBox = { inner ->
                    if (raw.isEmpty()) {
                        Text(text = "you@company.com", style = typography.body, color = colors.textMuted)
                    }
                    inner()
                },
            )
        }
        if (isError) {
            Text(
                text = errorMessage.orEmpty(),
                style = typography.caption,
                color = colors.error,
            )
        }
    }
}
