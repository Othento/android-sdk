package com.othento.core.internal

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModelProvider
import com.othento.core.internal.flow.OthentoFlowViewModel
import com.othento.core.internal.ui.screens.OthentoFlowHost
import com.othento.core.internal.ui.theme.OthentoTheme
import com.othento.core.api.OthentoCancelReason

/**
 * Compose-driven host Activity. Reads the [SdkBus] token from its Intent,
 * constructs an [OthentoFlowViewModel], and renders [OthentoFlowHost].
 *
 * Two cancel paths route here:
 * 1. **Hardware back / gesture** — the back-press callback signals the
 *    ViewModel which fires `onCancelled(BackButton)` on the host listener.
 * 2. **Host destroy** — `OthentoSDK.destroy()` is forwarded through
 *    [SdkBus.signalCancel]; the registered canceller below fires
 *    `onCancelled(HostDestroy)` and finishes the Activity.
 */
internal class OthentoActivity : ComponentActivity() {
    private var token: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val incomingToken = intent.getStringExtra(SdkBus.EXTRA_TOKEN)
        val busSession = incomingToken?.let { SdkBus.get(it) }
        if (incomingToken == null || busSession == null) {
            // Either the Intent was hand-constructed (no token) or the host
            // process was restored from death and the bus map was wiped.
            // There's no recovery — finish quietly so the host's launcher
            // Activity stays in a sane state.
            finish()
            return
        }
        token = incomingToken

        val viewModel =
            ViewModelProvider(
                this,
                OthentoFlowViewModel.Factory(
                    config = busSession.config,
                    listener = busSession.listener,
                    fixture = busSession.fixture,
                    contentResolver = applicationContext.contentResolver,
                    appContext = applicationContext,
                ),
            )[OthentoFlowViewModel::class.java]

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    viewModel.onUserCancel(OthentoCancelReason.BackButton)
                    finish()
                }
            },
        )

        SdkBus.registerCanceller(incomingToken) { reason ->
            viewModel.onUserCancel(reason)
            finish()
        }

        // Pin the View-tree to LTR so RTL device locales (e.g. Arabic) don't
        // mirror AndroidView interop — most importantly the CameraX PreviewView,
        // which lives in the View hierarchy and ignores Compose's LocalLayoutDirection.
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_LTR

        setContent {
            OthentoTheme {
                OthentoFlowHost(
                    viewModel = viewModel,
                    onReturnToApp = { finish() },
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Burn the bus entry only on real teardown — `isFinishing` distinguishes
        // user dismissal / terminal exit from a configuration-change recreation.
        if (isFinishing) {
            token?.let { SdkBus.remove(it) }
        }
    }
}
