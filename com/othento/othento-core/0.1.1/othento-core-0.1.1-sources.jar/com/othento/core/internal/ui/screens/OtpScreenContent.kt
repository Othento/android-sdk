@file:Suppress(
    "FunctionNaming",
    "TopLevelPropertyNaming",
    "MagicNumber",
    "LongMethod",
    "LongParameterList",
    "TooManyFunctions",
    "MaxLineLength",
    "CyclomaticComplexMethod",
)

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.othento.core.internal.data.model.OtpChannel
import com.othento.core.internal.flow.OtpUiState
import com.othento.core.internal.flow.OtpVerifyErrorKind
import com.othento.core.internal.ui.components.EmailDestinationInput
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.components.KycNotice
import com.othento.core.internal.ui.components.KycNoticeTone
import com.othento.core.internal.ui.components.KycOtpInput
import com.othento.core.internal.ui.components.KycOtpInputState
import com.othento.core.internal.ui.components.KycResultDialog
import com.othento.core.internal.ui.components.KycResultDialogTone
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.components.PhoneDestinationInput
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.screens.common.StepProgress
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Pure-render OTP screen. Phase 9. Renders both phone and email
 * variants — only chrome copy + destination input differ. Mirrors the
 * web's `apps/sdk/.../otp/otp-screen.ts` shape.
 *
 * Hosted in [OtpScreen]; this composable takes:
 * - [otp]: the [OtpUiState] from the FlowCoordinator.
 * - [destinationDraft]: local-to-screen scratchpad for the destination
 *   input that sits *outside* the FlowUiState (the user types many
 *   characters before tapping Send; pushing every keystroke through
 *   the ViewModel would needlessly recompose the whole tree).
 * - [destinationCountry]: only used when [otp.channel] is
 *   [OtpChannel.Phone]; the ISO-2 code currently picked.
 * - [destinationError]: pre-computed from the validator; null when the
 *   field is empty or valid.
 * - [destinationValid]: drives the Send button enable state.
 * - callbacks for every user action (typing, country change, send,
 *   verify, change-destination, dialog actions, skip-notice).
 */
@Composable
internal fun OtpScreenContent(
    otp: OtpUiState,
    destinationDraft: String,
    destinationCountry: String,
    destinationError: String?,
    destinationValid: Boolean,
    code: String,
    stepProgress: StepProgress,
    onDestinationDraftChange: (String) -> Unit,
    onDestinationCountryChange: (String) -> Unit,
    onCodeChange: (String) -> Unit,
    onSendClick: () -> Unit,
    onVerifyClick: () -> Unit,
    onChangeDestination: () -> Unit,
    onCancelEdit: () -> Unit,
    onDialogPrimary: () -> Unit,
    onDialogDismiss: () -> Unit,
    onAcknowledgeSkipNotice: () -> Unit,
) {
    val isPhone = otp.channel == OtpChannel.Phone
    val title = if (isPhone) "Phone verification" else "Email verification"
    val subtitle = if (isPhone) "We'll text you a verification code" else "We'll email you a verification code"

    KycScreen(
        zone = KycScreenZone.Guided,
        title = title,
        subtitle = subtitle,
        stepLabel = stepProgress.label,
        totalSegments = stepProgress.total,
        activeSegment = stepProgress.currentIndex,
        body = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                if (otp.editing) {
                    DestinationState(
                        otp = otp,
                        destinationDraft = destinationDraft,
                        destinationCountry = destinationCountry,
                        destinationError = destinationError,
                        destinationValid = destinationValid,
                        onDestinationDraftChange = onDestinationDraftChange,
                        onDestinationCountryChange = onDestinationCountryChange,
                        onSendClick = onSendClick,
                        onCancelEdit = onCancelEdit,
                    )
                } else {
                    CodeEntryState(
                        otp = otp,
                        code = code,
                        onCodeChange = onCodeChange,
                        onVerifyClick = onVerifyClick,
                        onChangeDestination = onChangeDestination,
                        onResendClick = onSendClick,
                    )
                }
            }
        },
    )

    when (otp.verifyErrorKind) {
        OtpVerifyErrorKind.Expired ->
            KycResultDialog(
                icon = OthentoIcons.Clock,
                iconContentDescription = "Code expired",
                title = "Code expired",
                body = "The verification code is no longer valid. Send a new one and we'll deliver it again.",
                primaryLabel = "Send new code",
                onPrimary = onDialogPrimary,
                onDismiss = onDialogDismiss,
                tone = KycResultDialogTone.Primary,
                secondaryLabel = "Dismiss",
                onSecondary = onDialogDismiss,
            )
        OtpVerifyErrorKind.Invalid ->
            KycResultDialog(
                icon = OthentoIcons.WarningTriangle,
                iconContentDescription = "Incorrect code",
                title = "Incorrect code",
                body = "That code doesn't match. Double-check and try again.",
                primaryLabel = "Try again",
                onPrimary = onDialogPrimary,
                onDismiss = onDialogDismiss,
                tone = KycResultDialogTone.Error,
            )
        null -> Unit
    }

    otp.skipNotice?.let { notice ->
        KycResultDialog(
            icon = OthentoIcons.WarningTriangle,
            iconContentDescription = "Verification skipped",
            title = "Verification skipped",
            body = notice.message,
            primaryLabel = "Continue",
            onPrimary = onAcknowledgeSkipNotice,
            onDismiss = onAcknowledgeSkipNotice,
            tone = KycResultDialogTone.Warning,
        )
    }
}

@Composable
private fun DestinationState(
    otp: OtpUiState,
    destinationDraft: String,
    destinationCountry: String,
    destinationError: String?,
    destinationValid: Boolean,
    onDestinationDraftChange: (String) -> Unit,
    onDestinationCountryChange: (String) -> Unit,
    onSendClick: () -> Unit,
    onCancelEdit: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val isPhone = otp.channel == OtpChannel.Phone
    val resending = otp.lastContact != null
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        IllustrationCircle(icon = if (isPhone) OthentoIcons.Smartphone else OthentoIcons.Envelope)
        Text(
            text = if (isPhone) "Verify your phone number" else "Verify your email address",
            style = typography.titleH3,
            color = colors.textPrimary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text =
                when {
                    resending && isPhone -> "Enter the new number you want the code sent to."
                    resending -> "Enter the new email you want the code sent to."
                    isPhone -> "We'll send a one-time code via SMS to verify your number."
                    else -> "We'll send a one-time code to verify your email address."
                },
            style = typography.body,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().widthIn(max = 340.dp),
        )

        Text(
            text = if (isPhone) "Phone number" else "Email address",
            style = typography.inputLabel,
            color = colors.textPrimary,
        )
        if (isPhone) {
            PhoneDestinationInput(
                raw = destinationDraft,
                countryCode = destinationCountry,
                onRawChange = onDestinationDraftChange,
                onCountryChange = onDestinationCountryChange,
                disabled = otp.sendInFlight,
                errorMessage = destinationError?.takeIf { destinationDraft.isNotEmpty() },
            )
        } else {
            EmailDestinationInput(
                raw = destinationDraft,
                onValueChange = onDestinationDraftChange,
                disabled = otp.sendInFlight,
                errorMessage = destinationError?.takeIf { destinationDraft.isNotEmpty() },
            )
        }

        otp.sendError?.let { notice ->
            KycNotice(title = notice.title, description = notice.description, tone = KycNoticeTone.Error)
        }

        val sendLabel =
            when {
                otp.sendInFlight -> "Sending..."
                resending -> "Resend code"
                else -> "Send code"
            }
        KycButton(
            label = sendLabel,
            onClick = onSendClick,
            variant = KycButtonVariant.Primary,
            enabled = destinationValid && !otp.sendInFlight,
            loading = otp.sendInFlight,
            fullWidth = true,
        )
        if (resending) {
            KycButton(
                label = "Cancel",
                onClick = onCancelEdit,
                variant = KycButtonVariant.Ghost,
                enabled = !otp.sendInFlight,
                fullWidth = true,
            )
        }

        SecurityNote()
    }
}

@Composable
private fun CodeEntryState(
    otp: OtpUiState,
    code: String,
    onCodeChange: (String) -> Unit,
    onVerifyClick: () -> Unit,
    onChangeDestination: () -> Unit,
    onResendClick: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val isPhone = otp.channel == OtpChannel.Phone
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        IllustrationCircle(icon = if (isPhone) OthentoIcons.Smartphone else OthentoIcons.Envelope)
        Text(
            text = if (isPhone) "Check your messages" else "Check your inbox",
            style = typography.titleH3,
            color = colors.textPrimary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text = "We sent a ${otp.codeLength}-digit code to",
            style = typography.body,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )

        ContactBadge(
            contact = otp.lastContact ?: "—",
            isPhone = isPhone,
            onChange = onChangeDestination,
            disabled = otp.verifyInFlight || otp.sendInFlight,
        )

        KycOtpInput(
            code = code,
            onCodeChange = onCodeChange,
            length = otp.codeLength,
            alphanumeric = otp.alphanumeric,
            disabled = otp.verifyInFlight,
            state = if (otp.verifyError != null) KycOtpInputState.Error else KycOtpInputState.Default,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Didn't receive it?",
                style = typography.caption,
                color = colors.textSecondary,
            )
            ResendButton(
                state = otp,
                onClick = onResendClick,
            )
        }

        // Send error (e.g. a failed resend) — kept visible on the code screen
        // too, mirroring the web SDK's otp-screen.html.
        otp.sendError?.let { notice ->
            KycNotice(title = notice.title, description = notice.description, tone = KycNoticeTone.Error)
        }

        if (otp.verifyError != null && otp.verifyErrorKind == null) {
            KycNotice(description = otp.verifyError, tone = KycNoticeTone.Error)
        }

        KycButton(
            label = if (otp.verifyInFlight) "Verifying..." else "Verify",
            onClick = onVerifyClick,
            variant = KycButtonVariant.Primary,
            enabled = code.length == otp.codeLength && code.all { it != ' ' } && !otp.verifyInFlight,
            loading = otp.verifyInFlight,
            fullWidth = true,
        )

        Text(
            text =
                if (isPhone) {
                    "Standard message rates may apply. Make sure the number can receive SMS."
                } else {
                    "Check your spam or junk folder if you don't see the email."
                },
            style = typography.caption,
            color = colors.textMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().widthIn(max = 300.dp),
        )
    }
}

@Composable
private fun IllustrationCircle(icon: ImageVector) {
    val colors = LocalOthentoColors.current
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier =
                Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(colors.primaryBg),
            contentAlignment = Alignment.Center,
        ) {
            KycIcon(
                imageVector = icon,
                contentDescription = null,
                sizeDp = 40.dp,
                tint = colors.primary,
            )
        }
    }
}

@Composable
private fun ContactBadge(
    contact: String,
    isPhone: Boolean,
    onChange: () -> Unit,
    disabled: Boolean,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(
                    androidx.compose.foundation.shape
                        .RoundedCornerShape(12.dp),
                ).background(colors.bgHover)
                .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = contact,
            style = typography.body.copy(fontWeight = FontWeight.W700),
            color = colors.textPrimary,
        )
        Text(
            text = if (isPhone) "Change phone number" else "Change email",
            style = typography.caption.copy(fontWeight = FontWeight.W700),
            color = if (disabled) colors.textMuted else colors.primary,
            modifier =
                Modifier
                    .clickable(enabled = !disabled, onClick = onChange)
                    .padding(4.dp),
        )
    }
}

@Composable
private fun ResendButton(
    state: OtpUiState,
    onClick: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val label =
        when {
            state.sendInFlight -> "Sending…"
            state.canResend -> "Resend code"
            else -> "Resend in ${state.cooldownRemainingSec}s"
        }
    val enabled = state.canResend && !state.sendInFlight
    Text(
        text = label,
        style = typography.caption.copy(fontWeight = FontWeight.W600),
        color = if (enabled) colors.primary else colors.textMuted,
        modifier =
            Modifier
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

@Composable
private fun SecurityNote() {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(
                    androidx.compose.foundation.shape
                        .RoundedCornerShape(8.dp),
                ).background(colors.bgHover)
                .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        KycIcon(
            imageVector = OthentoIcons.Lock,
            contentDescription = null,
            sizeDp = 14.dp,
            tint = colors.primary,
        )
        Text(
            text = "Your information is encrypted and secure",
            style = typography.caption,
            color = colors.textMuted,
        )
        Spacer(Modifier.height(0.dp))
    }
}
