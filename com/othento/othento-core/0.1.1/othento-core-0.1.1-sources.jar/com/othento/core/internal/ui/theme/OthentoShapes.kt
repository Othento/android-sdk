package com.othento.core.internal.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * Border-radius tokens per [docs/spec/04-design-system.md] §4.
 */
@Immutable
internal data class OthentoShapes(
    val sm: Shape = RoundedCornerShape(4.dp),
    val md: Shape = RoundedCornerShape(8.dp),
    val lg: Shape = RoundedCornerShape(12.dp),
    val xl: Shape = RoundedCornerShape(16.dp),
    val full: Shape = RoundedCornerShape(percent = 50),
    /** Bottom-sheet panels: 20 dp top corners, 0 dp bottom. */
    val sheet: Shape =
        RoundedCornerShape(
            topStart = 20.dp,
            topEnd = 20.dp,
            bottomStart = 0.dp,
            bottomEnd = 0.dp,
        ),
) {
    companion object {
        val Default: OthentoShapes = OthentoShapes()
    }
}

internal val LocalOthentoShapes =
    staticCompositionLocalOf<OthentoShapes> {
        error("OthentoShapes not provided. Wrap content in OthentoTheme { … }.")
    }
