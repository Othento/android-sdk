package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass
import com.othento.core.internal.data.model.ActiveStepStatus

/**
 * Wire shape for an entry in the flat `steps[]` listing.
 *
 * Mirrors [docs/spec/09-data-models.md §2.1]. `configuration` is typed as
 * `any` on the wire — Moshi parses it into a JSON map; per-step shape
 * (e.g. OTP step) is decoded by the relevant phase's flow code.
 *
 * **Spec deviation**: the spec types this as the narrower `StepStatus`
 * (Pending / InProgress / Completed / Failed), but the dev backend
 * actually returns the wider `ActiveStepStatus` here too — `AwaitingEvidence`
 * was observed on `steps[0]` after `initiate`. We use the wider enum so
 * the parser tolerates whichever value the backend ships. Logged as P9
 * in `docs/spec/99-open-questions.md`.
 */
@JsonClass(generateAdapter = true)
internal data class StepDto(
    val attemptStepId: String,
    val configuration: Map<String, Any?>? = null,
    val stepCode: String,
    val stepName: String,
    // Defensive: dev backend has been observed to omit `order` on some
    // post-confirm responses (especially two-side documents where
    // `currentStep` is the source of truth and `steps[]` is just a
    // listing). Defaulting to null keeps the parse robust.
    val order: Int? = null,
    val status: ActiveStepStatus,
)
