@file:Suppress(
    "FunctionNaming",
    "TopLevelPropertyNaming",
    "MagicNumber",
    "LongMethod",
    "LongParameterList",
    "TooManyFunctions",
    "MaxLineLength",
    // Reason: this file owns the full selfie-capture screen (runtime composable
    // + every state's pure-render variant + supporting helpers). Splitting into
    // multiple files fragments the state-to-render mapping that's the whole
    // value of co-locating these. Suppressions mirror the camera-capture screen.
)

package com.othento.core.internal.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.othento.core.internal.capture.CameraReadyState
import com.othento.core.internal.capture.CameraSelectorKind
import com.othento.core.internal.capture.CameraSession
import com.othento.core.internal.capture.PermissionStatus
import com.othento.core.internal.capture.SelfieConfig
import com.othento.core.internal.capture.SelfieDetectionPipeline
import com.othento.core.internal.capture.SelfieDetectionState
import com.othento.core.internal.capture.SelfieFrameAnalyzer
import com.othento.core.internal.capture.SelfieKind
import com.othento.core.internal.capture.detection.ValidationIssue
import com.othento.core.internal.capture.detection.ValidationWarning
import com.othento.core.internal.capture.detection.face.FaceDetectorClient
import com.othento.core.internal.capture.detection.face.SelfieHint
import com.othento.core.internal.capture.rememberCameraPermissionState
import com.othento.core.internal.capture.video.RollingVideoRecorder
import com.othento.core.internal.ui.components.BlurredCaptureBackground
import com.othento.core.internal.ui.components.CapturedVideoPreview
import com.othento.core.internal.ui.components.IntroTipCard
import com.othento.core.internal.ui.components.lastVideoFrame
import com.othento.core.internal.ui.components.CaptureReviewSheet
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.components.KycIntroSheet
import com.othento.core.internal.ui.components.KycLoader
import com.othento.core.internal.ui.components.KycLoaderSize
import com.othento.core.internal.ui.components.OvalRoiOverlay
import com.othento.core.internal.ui.components.PlacementGuideKind
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Phase 7 selfie / face-match capture surface. Spec
 * [docs/spec/06-screens/08-selfie-capture.md].
 *
 * Owns the runtime side: front-camera bind via [CameraSession] +
 * [CameraSelectorKind.Front], ML Kit face detection via [FaceDetectorClient]
 * driven by [SelfieFrameAnalyzer], stability gating via
 * [SelfieDetectionPipeline], rolling video buffer via [RollingVideoRecorder],
 * preview-then-confirm.
 *
 * Pure rendering lives in [SelfieCaptureScreenContent] so Paparazzi snapshot
 * tests cover every state.
 */
@Composable
@Suppress("CyclomaticComplexMethod")
internal fun SelfieCaptureScreen(
    kind: SelfieKind,
    onCapturedFile: (Uri, Boolean) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val cameraSession = remember { CameraSession(context) }
    val faceClient = remember { FaceDetectorClient(minFaceSize = SelfieConfig.MIN_FACE_SIZE_HINT) }
    val bindAttempt = remember { mutableIntStateOf(0) }
    // Pipeline + analyzer are keyed on bindAttempt so a retake gets a fresh
    // capture-delay window. Critically: do NOT use a `mutableStateOf` for the
    // start-time and write to it inside the bind effect — that path triggers
    // a recomposition that creates a new pipeline AFTER the analyzer was
    // already bound to the old one, leaving the screen observing a state
    // flow no frames are flowing into.
    val pipeline =
        remember(bindAttempt.intValue) {
            SelfieDetectionPipeline(cameraStartedAt = System.currentTimeMillis())
        }
    val analyzer =
        remember(pipeline) {
            SelfieFrameAnalyzer(pipeline = pipeline, client = faceClient)
        }
    val videoBuffer =
        remember(kind) {
            val prefix = if (kind == SelfieKind.Liveness) "liveness" else "selfie"
            RollingVideoRecorder(context = context, flowPrefix = prefix)
        }

    DisposableEffect(Unit) {
        onDispose {
            videoBuffer.reset()
            faceClient.release()
            cameraSession.shutdown()
        }
    }

    val permissionState =
        rememberCameraPermissionState(
            onSettingsRequested = { openSelfieAppSettings(context) },
        )

    var cameraReady by remember { mutableStateOf(CameraReadyState.Loading) }
    var captureReady by remember { mutableStateOf(false) }
    var capturedUri by remember { mutableStateOf<Uri?>(null) }
    var previewWarnings by remember { mutableStateOf(emptyList<ValidationWarning>()) }
    var validating by remember { mutableStateOf(false) }
    var captureJob by remember { mutableStateOf<Job?>(null) }
    var timedOut by remember { mutableStateOf(false) }
    var wasAutoCapture by remember { mutableStateOf(false) }
    // Auto-capture closes the camera and shows a blurred frozen frame behind
    // the upload sheet while the clip uploads. `uploadFrame` is the last frame
    // of the captured clip; `uploading` swaps the live HUD for that backdrop.
    var uploading by remember { mutableStateOf(false) }
    var uploadFrame by remember { mutableStateOf<ImageBitmap?>(null) }

    val introVisible = remember { mutableStateOf(true) }
    val previewView =
        remember {
            PreviewView(context).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
                implementationMode = PreviewView.ImplementationMode.PERFORMANCE
            }
        }

    LaunchedEffect(permissionState.status) {
        cameraReady =
            when (permissionState.status) {
                PermissionStatus.Granted -> cameraReady
                PermissionStatus.Denied -> CameraReadyState.PermissionDenied
                PermissionStatus.PermanentlyDenied -> CameraReadyState.PermissionPermanentlyDenied
                PermissionStatus.Unknown -> CameraReadyState.Loading
            }
    }

    LaunchedEffect(introVisible.value) {
        if (!introVisible.value && permissionState.status != PermissionStatus.Granted) {
            permissionState.request()
        }
    }

    // Pause auto-detection while the intro sheet is open. Reopening intro
    // mid-session via the ⓘ button must also halt the stability counter so
    // we don't auto-capture the instant the sheet closes again. Keyed on
    // `pipeline` too so a retake (which rebuilds the pipeline) inherits
    // the current paused state.
    LaunchedEffect(pipeline, introVisible.value) {
        pipeline.setPaused(introVisible.value)
        if (introVisible.value) timedOut = false
    }

    // Bind front camera + ImageAnalysis (face) + VideoCapture.
    // Same single-effect pattern as CameraCaptureScreen so retake works
    // through bindAttempt without restating the lifecycle dance. Each retake
    // resets the rolling recorder before re-binding so no orphaned MediaCodec
    // surfaces linger across bind attempts.
    LaunchedEffect(permissionState.status, bindAttempt.intValue) {
        if (permissionState.status != PermissionStatus.Granted) return@LaunchedEffect
        cameraReady = CameraReadyState.Loading
        captureReady = false
        timedOut = false
        previewWarnings = emptyList()
        videoBuffer.reset()

        val videoUseCase = videoBuffer.buildUseCase()
        val bindResult =
            cameraSession.bind(
                lifecycleOwner = lifecycleOwner,
                previewView = previewView,
                analyzer = analyzer,
                selector = CameraSelectorKind.Front,
                extraUseCase = videoUseCase,
            )
        when (bindResult) {
            is CameraSession.BindResult.Bound -> {
                cameraReady = CameraReadyState.Active
                videoBuffer.start()
                delay(SELFIE_CAPTURE_READY_DELAY_MS)
                captureReady = true
            }
            is CameraSession.BindResult.Failed -> {
                cameraReady = CameraReadyState.Unavailable
            }
        }
    }

    // Camera-timeout watchdog — if no successful detection within
    // SelfieConfig.CAMERA_TIMEOUT_MS, flip to the timeout error state.
    // Keyed on `introVisible` so the 45 s window restarts each time the
    // user dismisses the intro sheet (initial open or mid-session reopen);
    // the timer must not run behind the intro.
    LaunchedEffect(cameraReady, capturedUri, introVisible.value) {
        if (cameraReady != CameraReadyState.Active) return@LaunchedEffect
        if (capturedUri != null) return@LaunchedEffect
        if (introVisible.value) return@LaunchedEffect
        delay(SelfieConfig.CAMERA_TIMEOUT_MS)
        if (capturedUri == null) {
            timedOut = true
        }
    }

    // Post-capture face check for manual captures — sample video frames
    // and verify at least one contains a face. Auto-capture already passed
    // the pipeline's face gate so it skips this.
    LaunchedEffect(capturedUri) {
        val uri = capturedUri ?: run {
            validating = false
            previewWarnings = emptyList()
            return@LaunchedEffect
        }
        if (wasAutoCapture) {
            validating = false
            previewWarnings = emptyList()
            return@LaunchedEffect
        }
        validating = true
        previewWarnings = emptyList()
        val warnings = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            runCatching {
                val retriever = android.media.MediaMetadataRetriever()
                try {
                    retriever.setDataSource(uri.path)
                    val durationMs = retriever.extractMetadata(
                        android.media.MediaMetadataRetriever.METADATA_KEY_DURATION,
                    )?.toLongOrNull() ?: 0L
                    val durationUs = durationMs * 1_000L
                    val count = SELFIE_POST_CAPTURE_SAMPLES
                    val stepUs = if (durationUs > 0 && count > 1) durationUs / (count - 1) else 0L
                    val checker = FaceDetectorClient(minFaceSize = 0.25f)
                    try {
                        for (i in 0 until count) {
                            val timeUs = if (count > 1) i * stepUs else 0L
                            val frame = retriever.getFrameAtTime(
                                timeUs,
                                android.media.MediaMetadataRetriever.OPTION_CLOSEST,
                            ) ?: continue
                            val input = com.google.mlkit.vision.common.InputImage.fromBitmap(frame, 0)
                            val faces = checker.detectOnce(input)
                            frame.recycle()
                            if (faces.isNotEmpty()) return@runCatching emptyList()
                        }
                        listOf(
                            ValidationWarning(
                                issue = ValidationIssue.NoCard,
                                message = "We could not detect a face in this capture. Please retake your selfie ensuring your face is clearly visible and centered in the frame.",
                            ),
                        )
                    } finally {
                        checker.release()
                    }
                } finally {
                    runCatching { retriever.release() }
                }
            }.getOrElse { emptyList() }
        }
        validating = false
        previewWarnings = warnings
    }

    // Auto-capture trigger — observe pipeline state.
    val detectionState by pipeline.state.collectAsState()
    LaunchedEffect(detectionState) {
        if (capturedUri != null) return@LaunchedEffect // in preview — don't re-capture
        if (detectionState !is SelfieDetectionState.ReadyToCapture) return@LaunchedEffect
        if (!captureReady) return@LaunchedEffect
        if (captureJob != null) return@LaunchedEffect
        pipeline.markCaptured()
        wasAutoCapture = true
        captureJob =
            scope.launch {
                val uri =
                    runCatching {
                        withTimeoutOrNull(SELFIE_CAPTURE_WATCHDOG_MS) { videoBuffer.stopAndTrim() }
                    }.getOrNull()?.let { Uri.fromFile(it) }
                if (uri != null) {
                    // Auto-capture already passed the face gate — skip the review
                    // step and upload directly. Freeze on a blurred last frame and
                    // close the camera so the upload sheet sits over a calm
                    // backdrop, not the live viewport.
                    uploadFrame = lastVideoFrame(uri)
                    uploading = true
                    cameraSession.unbind()
                    onCapturedFile(uri, false)
                } else {
                    // Trim failed — fall back to retake.
                    pipeline.reset()
                    videoBuffer.reset()
                    captureReady = false
                    bindAttempt.intValue++
                }
                captureJob = null
            }
    }

    val capturedPreview: (@Composable () -> Unit)? =
        capturedUri?.let { uri ->
            { CapturedVideoPreview(uri = uri) }
        }

    val state =
        SelfieCaptureUiState(
            cameraReady = cameraReady,
            detectionState = detectionState,
            captureReady = captureReady,
            isPreviewing = capturedUri != null,
            timedOut = timedOut,
            previewWarnings = previewWarnings,
            validating = validating,
        )
    val callbacks =
        SelfieCaptureCallbacks(
            onShutter = {
                if (capturedUri != null) return@SelfieCaptureCallbacks
                if (!captureReady || captureJob != null) return@SelfieCaptureCallbacks
                if (detectionState is SelfieDetectionState.CaptureBlocked) return@SelfieCaptureCallbacks
                pipeline.markCaptured()
                wasAutoCapture = false
                captureJob =
                    scope.launch {
                        fireCapture(videoBuffer = videoBuffer) { uri ->
                            if (uri != null) {
                                capturedUri = uri
                            } else {
                                // Trim failed — fall back to retake.
                                pipeline.reset()
                                videoBuffer.reset()
                                captureReady = false
                                bindAttempt.intValue++
                            }
                        }
                        captureJob = null
                    }
            },
            onShowIntro = { introVisible.value = true },
            onTryAgain = {
                when (cameraReady) {
                    CameraReadyState.PermissionDenied,
                    CameraReadyState.PermissionPermanentlyDenied,
                    -> permissionState.request()
                    CameraReadyState.Unavailable -> bindAttempt.intValue++
                    else -> Unit
                }
            },
            onRetake = {
                capturedUri = null
                previewWarnings = emptyList()
                validating = false
                captureReady = false
                timedOut = false
                wasAutoCapture = false
                pipeline.reset()
                bindAttempt.intValue++
            },
            onConfirmCapture = {
                val uri = capturedUri ?: return@SelfieCaptureCallbacks
                onCapturedFile(uri, !wasAutoCapture)
            },
            onOpenAppSettings = { openSelfieAppSettings(context) },
        )

    Box(modifier = Modifier.fillMaxSize()) {
        if (uploading) {
            // Camera is closed; show the blurred frozen frame. The host layers
            // the UploadProgressSheet on top while the clip uploads.
            BlurredCaptureBackground(frame = uploadFrame, modifier = Modifier.fillMaxSize())
            return@Box
        }
        SelfieCaptureScreenContent(
            state = state,
            callbacks = callbacks,
            kind = kind,
            previewSurface = {
                AndroidView(
                    factory = { previewView },
                    modifier = Modifier.fillMaxSize().background(Color.Black),
                )
            },
            capturedPreview = capturedPreview,
        )

        if (introVisible.value) {
            val intro = selfieIntroFor(kind)
            KycIntroSheet(
                illustration =
                    when (kind) {
                        SelfieKind.Liveness -> PlacementGuideKind.Liveness
                        SelfieKind.FaceMatch -> PlacementGuideKind.Selfie
                    },
                title = intro.title,
                subtitle = intro.subtitle,
                eyebrow = intro.eyebrow,
                tipCards =
                    when (kind) {
                        SelfieKind.FaceMatch -> faceMatchIntroTipCards()
                        SelfieKind.Liveness -> livenessIntroTipCards()
                    },
                buttonLabel = intro.buttonLabel,
                onContinue = { introVisible.value = false },
            )
        }
    }
}

private data class SelfieIntroCopy(
    val eyebrow: String,
    val title: String,
    val subtitle: String,
    val buttonLabel: String,
)

private fun selfieIntroFor(kind: SelfieKind): SelfieIntroCopy =
    when (kind) {
        SelfieKind.FaceMatch ->
            SelfieIntroCopy(
                eyebrow = "Face match · Selfie",
                title = "Now a quick selfie.",
                subtitle = "We'll match your face to the photo on your ID. Takes 2 seconds.",
                buttonLabel = "Start selfie",
            )
        SelfieKind.Liveness ->
            SelfieIntroCopy(
                eyebrow = "Liveness",
                title = "Quick liveness check.",
                subtitle = "Just look at the camera. We’ll confirm you’re really here — no action needed.",
                buttonLabel = "Continue",
            )
    }

// ──────────────────────────────────────── Pure-render content ─────────────────────────────────────

internal data class SelfieCaptureUiState(
    val cameraReady: CameraReadyState,
    val detectionState: SelfieDetectionState,
    val captureReady: Boolean,
    val isPreviewing: Boolean,
    val timedOut: Boolean = false,
    val previewWarnings: List<ValidationWarning> = emptyList(),
    val validating: Boolean = false,
) {
    val statusHint: SelfieHint?
        get() = (detectionState as? SelfieDetectionState.Searching)?.hint

    val warningText: String?
        get() {
            val warning =
                when (val s = detectionState) {
                    is SelfieDetectionState.Searching -> s.warning
                    is SelfieDetectionState.Holding -> s.warning
                    else -> null
                }
            return warning?.text
        }

    val captureProgress: Float
        get() =
            when (val s = detectionState) {
                is SelfieDetectionState.Holding -> s.progress
                is SelfieDetectionState.ReadyToCapture -> 1f
                else -> 0f
            }

    val statusText: String
        get() =
            when {
                isPreviewing -> "Looks good"
                detectionState is SelfieDetectionState.ReadyToCapture -> "Hold steady..."
                detectionState is SelfieDetectionState.Holding -> {
                    // Countdown — same shape as the ID screen / web SDK:
                    // "Hold steady... Xs" with X derived from how much
                    // of `captureProgress` (0..1) is left, scaled across
                    // the configured 1.3 s hold target.
                    val remainingMs = (SELFIE_HOLD_TARGET_MS * (1f - captureProgress)).toLong()
                    val remainingSec = ((remainingMs + SELFIE_PILL_ROUND_UP_MS) / 1_000L).coerceAtLeast(1L)
                    "Hold steady... ${remainingSec}s"
                }
                detectionState is SelfieDetectionState.Searching && statusHint != null -> statusHint!!.text
                detectionState is SelfieDetectionState.CaptureBlocked -> "Position your face in the oval"
                else -> "Position your face in the oval"
            }
}

private const val SELFIE_HOLD_TARGET_MS: Float = 1_400f
private const val SELFIE_PILL_ROUND_UP_MS: Long = 999L

internal data class SelfieCaptureCallbacks(
    val onShutter: () -> Unit,
    val onShowIntro: () -> Unit,
    val onTryAgain: () -> Unit,
    val onRetake: () -> Unit,
    val onConfirmCapture: () -> Unit,
    val onOpenAppSettings: () -> Unit,
)

@Composable
internal fun SelfieCaptureScreenContent(
    state: SelfieCaptureUiState,
    callbacks: SelfieCaptureCallbacks,
    kind: SelfieKind = SelfieKind.FaceMatch,
    previewSurface: @Composable () -> Unit = { Box(Modifier.fillMaxSize().background(Color.Black)) },
    capturedPreview: (@Composable () -> Unit)? = null,
) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        when {
            state.cameraReady == CameraReadyState.Loading -> SelfieCameraLoading()
            state.cameraReady == CameraReadyState.PermissionDenied ->
                SelfiePermissionError(
                    permanentlyDenied = false,
                    onTryAgain = callbacks.onTryAgain,
                    onOpenSettings = callbacks.onOpenAppSettings,
                )
            state.cameraReady == CameraReadyState.PermissionPermanentlyDenied ->
                SelfiePermissionError(
                    permanentlyDenied = true,
                    onTryAgain = callbacks.onTryAgain,
                    onOpenSettings = callbacks.onOpenAppSettings,
                )
            state.cameraReady == CameraReadyState.Unavailable -> SelfieCameraUnavailable(onTryAgain = callbacks.onTryAgain)
            state.timedOut -> SelfieTimeout(onTryAgain = callbacks.onRetake)
            state.isPreviewing && capturedPreview != null ->
                SelfiePreviewState(
                    capturedPreview = capturedPreview,
                    isValidating = state.validating,
                    warnings = state.previewWarnings,
                    onRetake = callbacks.onRetake,
                    onConfirm = callbacks.onConfirmCapture,
                )
            else ->
                SelfieActiveHud(
                    state = state,
                    callbacks = callbacks,
                    kind = kind,
                    previewSurface = previewSurface,
                )
        }
    }
}

// ──────────────────────────────────────── State composables ───────────────────────────────────────

@Composable
private fun SelfieCameraLoading() {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            KycLoader(size = KycLoaderSize.Lg)
            Spacer(Modifier.height(16.dp))
            Text(
                text = "Preparing camera...",
                style = LocalOthentoTypography.current.body,
                color = Color.White,
            )
        }
    }
}

@Composable
private fun SelfiePermissionError(
    permanentlyDenied: Boolean,
    onTryAgain: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    SelfieErrorPanel(
        title = "Camera access required",
        body = "Allow camera access to verify your identity with a selfie.",
        primaryLabel = if (permanentlyDenied) "Open settings" else "Try again",
        onPrimary = if (permanentlyDenied) onOpenSettings else onTryAgain,
    )
}

@Composable
private fun SelfieCameraUnavailable(onTryAgain: () -> Unit) {
    SelfieErrorPanel(
        title = "No camera detected",
        body = "We couldn't open the front camera on this device. Please try again.",
        primaryLabel = "Try again",
        onPrimary = onTryAgain,
    )
}

@Composable
private fun SelfieTimeout(onTryAgain: () -> Unit) {
    SelfieErrorPanel(
        title = "No face detected",
        body = "We couldn't detect your face in time. Please try again and position your face in the oval.",
        primaryLabel = "Try again",
        onPrimary = onTryAgain,
    )
}

@Composable
private fun SelfieErrorPanel(
    title: String,
    body: String,
    primaryLabel: String,
    onPrimary: () -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = title,
                style = LocalOthentoTypography.current.titleH3.copy(fontWeight = FontWeight.W700),
                color = Color.White,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = body,
                style = LocalOthentoTypography.current.body,
                color = Color.White.copy(alpha = 0.75f),
            )
            Spacer(Modifier.height(20.dp))
            KycButton(label = primaryLabel, onClick = onPrimary, variant = KycButtonVariant.Primary)
        }
    }
}

@Composable
private fun SelfieActiveHud(
    state: SelfieCaptureUiState,
    callbacks: SelfieCaptureCallbacks,
    kind: SelfieKind,
    previewSurface: @Composable () -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        previewSurface()
        OvalRoiOverlay(modifier = Modifier.fillMaxSize())

        val isHolding = state.detectionState is SelfieDetectionState.Holding
        if (isHolding) {
            SelfieScanLine(modifier = Modifier.fillMaxSize())
        }

        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars),
        ) {
            SelfieTopChrome(kind = kind, onTipsTap = callbacks.onShowIntro)
            Spacer(Modifier.height(8.dp))
            SelfieStatusPill(
                text = state.statusText,
                isHolding =
                    state.detectionState is SelfieDetectionState.Holding ||
                        state.detectionState is SelfieDetectionState.ReadyToCapture,
            )
            Spacer(Modifier.weight(1f))
            state.warningText?.let { warningText ->
                SelfieWarningBubble(
                    text = warningText,
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
            }
            SelfieCaptureRow(
                progress = state.captureProgress,
                enabled =
                    state.captureReady &&
                        state.detectionState !is SelfieDetectionState.CaptureBlocked,
                visible = state.captureReady,
                onShutter = callbacks.onShutter,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SelfieScanLine(modifier: Modifier = Modifier) {
    val primary = LocalOthentoColors.current.primary
    val transition = rememberInfiniteTransition(label = "selfie-scan")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = SELFIE_SCAN_HALF_MS, easing = EaseInOut),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "selfie-scan-progress",
    )
    val scanAlpha = 0.3f + 0.7f * progress

    Canvas(modifier = modifier) {
        val ovalW = size.width * SelfieConfig.ROI_WIDTH_RATIO
        val ovalH = ovalW * SelfieConfig.ROI_HEIGHT_TO_WIDTH_RATIO
        val ovalLeft = (size.width - ovalW) / 2f
        val ovalTop = (size.height - ovalH) / 2f
        val ovalRect = Rect(ovalLeft, ovalTop, ovalLeft + ovalW, ovalTop + ovalH)
        val ovalPath = Path().apply { addOval(ovalRect) }

        clipPath(ovalPath) {
            val scanTop = ovalTop + ovalH * 0.15f
            val scanBottom = ovalTop + ovalH * 0.75f
            val y = scanTop + (scanBottom - scanTop) * progress
            val lineLeft = ovalLeft + ovalW * 0.1f
            val lineW = ovalW * 0.8f
            val lineH = SELFIE_SCAN_LINE_H.toPx()
            val glowH = 8.dp.toPx()

            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        primary.copy(alpha = 0.3f),
                        primary.copy(alpha = 0.3f),
                        Color.Transparent,
                    ),
                    startX = lineLeft,
                    endX = lineLeft + lineW,
                ),
                topLeft = Offset(lineLeft, y - glowH / 2f),
                size = Size(lineW, glowH),
                alpha = scanAlpha,
            )

            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        primary,
                        primary,
                        Color.Transparent,
                    ),
                    startX = lineLeft,
                    endX = lineLeft + lineW,
                ),
                topLeft = Offset(lineLeft, y - lineH / 2f),
                size = Size(lineW, lineH),
                alpha = scanAlpha,
            )
        }
    }
}

private const val SELFIE_SCAN_HALF_MS: Int = 1_000
private val SELFIE_SCAN_LINE_H = 2.dp

@Composable
private fun SelfieTopChrome(
    kind: SelfieKind,
    onTipsTap: () -> Unit,
) {
    val pillText =
        when (kind) {
            SelfieKind.FaceMatch -> "Face match · Selfie"
            SelfieKind.Liveness -> "Liveness"
        }
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 12.dp).height(36.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SelfieChromePill(text = pillText, modifier = Modifier.weight(1f))
        SelfieChromeButton(
            icon = OthentoIcons.Info,
            contentDescription = "Show tips",
            onClick = onTipsTap,
        )
    }
}

@Composable
private fun SelfieChromeButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
) {
    Box(
        modifier =
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f))
                .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        KycIcon(
            imageVector = icon,
            contentDescription = contentDescription,
            sizeDp = 16.dp,
            tint = Color.White,
        )
    }
}

@Composable
private fun SelfieChromePill(
    text: String,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier =
            modifier
                .height(36.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White.copy(alpha = 0.12f))
                .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            style = LocalOthentoTypography.current.caption.copy(fontWeight = FontWeight.W600),
            color = Color.White,
        )
    }
}

@Composable
private fun SelfieStatusPill(
    text: String,
    isHolding: Boolean,
) {
    val bg =
        if (isHolding) {
            LocalOthentoColors.current.primary.copy(alpha = 0.85f)
        } else {
            Color.White.copy(alpha = 0.15f)
        }
    val dotColor = if (isHolding) Color.White else AmberDot
    Box(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            modifier =
                Modifier
                    .wrapContentSize()
                    .clip(RoundedCornerShape(999.dp))
                    .background(bg)
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(dotColor))
            Text(
                text = text,
                style = LocalOthentoTypography.current.caption.copy(fontWeight = FontWeight.W600),
                color = Color.White,
            )
        }
    }
}

@Composable
private fun SelfieWarningBubble(
    text: String,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Row(
            modifier =
                Modifier
                    .wrapContentSize()
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(AmberDot))
            Text(
                text = text,
                style = LocalOthentoTypography.current.caption.copy(fontWeight = FontWeight.W600),
                color = AmberDot,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun SelfieCaptureRow(
    progress: Float,
    enabled: Boolean,
    visible: Boolean,
    onShutter: () -> Unit,
) {
    val ringColor = LocalOthentoColors.current.primary
    val targetProgress = progress.coerceIn(0f, 1f)
    val displayed by animateFloatAsState(
        targetValue = targetProgress,
        animationSpec = if (targetProgress == 0f) snap() else tween(
            durationMillis = 200,
            easing = LinearEasing,
        ),
        label = "selfie-ring",
    )
    val appearAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(durationMillis = 350),
        label = "selfie-row-alpha",
    )
    val appearSlide by animateFloatAsState(
        targetValue = if (visible) 0f else 12f,
        animationSpec = tween(durationMillis = 350),
        label = "selfie-row-slide",
    )
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .graphicsLayer(alpha = appearAlpha, translationY = appearSlide),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier =
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f))
                    .clickable(enabled = enabled, onClick = onShutter),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val stroke = SELFIE_RING_STROKE.toPx()
                val inset = stroke / 2f
                val topLeft = Offset(inset, inset)
                val arcSize = androidx.compose.ui.geometry.Size(
                    size.width - stroke,
                    size.height - stroke,
                )
                drawArc(
                    color = ringColor.copy(alpha = 0.30f),
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
                if (displayed > 0f) {
                    drawArc(
                        color = ringColor.copy(alpha = 0.95f),
                        startAngle = -90f,
                        sweepAngle = 360f * displayed,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Round),
                    )
                }
            }
            KycIcon(
                imageVector = OthentoIcons.Camera,
                contentDescription = "Capture",
                sizeDp = 28.dp,
                tint = Color.White,
            )
        }
    }
}

private val SELFIE_RING_STROKE = 4.dp

@Composable
private fun SelfiePreviewState(
    capturedPreview: @Composable () -> Unit,
    isValidating: Boolean,
    warnings: List<ValidationWarning>,
    onRetake: () -> Unit,
    onConfirm: () -> Unit,
) {
    CaptureReviewSheet(
        title = "Review your selfie",
        subtitle = "Make sure your face is clearly visible",
        validationText = "Checking face quality…",
        capturedPreview = capturedPreview,
        isValidating = isValidating,
        warnings = warnings,
        onRetake = onRetake,
        onConfirm = onConfirm,
    )
}

// ──────────────────────────────────────── Side-effect helpers ─────────────────────────────────────

private suspend fun fireCapture(
    videoBuffer: RollingVideoRecorder,
    onResult: (Uri?) -> Unit,
) {
    val trimmed =
        runCatching {
            withTimeoutOrNull(SELFIE_CAPTURE_WATCHDOG_MS) {
                videoBuffer.stopAndTrim()
            }
        }.getOrNull()
    onResult(trimmed?.let { Uri.fromFile(it) })
}

private fun openSelfieAppSettings(context: Context) {
    val intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    runCatching { context.startActivity(intent) }
}

private fun faceMatchIntroTipCards(): List<IntroTipCard> =
    listOf(
        IntroTipCard(
            label = "Face the camera",
            detail = "Look straight ahead",
            icon = OthentoIcons.Face,
        ),
        IntroTipCard(
            label = "Good lighting",
            detail = "Avoid strong backlight",
            icon = OthentoIcons.Sun,
        ),
        IntroTipCard(
            label = "Remove glasses",
            detail = "Hats and masks too",
            icon = OthentoIcons.Glasses,
        ),
        IntroTipCard(
            label = "Neutral expression",
            detail = "Keep still, don’t smile",
            icon = OthentoIcons.Neutral,
        ),
    )

private fun livenessIntroTipCards(): List<IntroTipCard> =
    listOf(
        IntroTipCard(
            label = "Look at the camera",
            detail = "Stay natural",
            icon = OthentoIcons.Face,
        ),
        IntroTipCard(
            label = "Stay in frame",
            detail = "Face centered in oval",
            icon = OthentoIcons.FourCorners,
        ),
        IntroTipCard(
            label = "Good lighting",
            detail = "Avoid strong backlight",
            icon = OthentoIcons.Sun,
        ),
        IntroTipCard(
            label = "Remove glasses",
            detail = "Hats and masks too",
            icon = OthentoIcons.Glasses,
        ),
    )

private val AmberDot: Color = Color(0xFFFBBF24)

// 2 s of buffered footage before the shutter unlocks. RollingVideoRecorder
// needs ≥ a second of scratch before the trim can produce a valid clip;
// tapping the shutter earlier gets a 0-byte trim → null → retake fallback
// fires instead of a real capture (the user perceives this as a missed
// click that requires tapping twice). Mirrors CAPTURE_READY_DELAY_MS on
// the ID capture screen — same buffer, same constraint.
private const val SELFIE_CAPTURE_READY_DELAY_MS: Long = 2_000L
private const val SELFIE_CAPTURE_WATCHDOG_MS: Long = 5_000L
private const val SELFIE_POST_CAPTURE_SAMPLES: Int = 5
