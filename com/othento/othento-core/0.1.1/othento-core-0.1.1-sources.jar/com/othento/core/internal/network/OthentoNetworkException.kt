package com.othento.core.internal.network

import com.othento.core.api.OthentoError

/**
 * Internal exception type wrapping a domain [OthentoError] together with a
 * pre-localised display message.
 *
 * Repository methods throw this on failure; the SDK's public callbacks
 * unwrap it into `(error, displayMessage)` for the host. Lives in the
 * internal package because hosts should never `catch` this directly —
 * they receive the unwrapped pair via [com.othento.core.api.OthentoSDKListener].
 */
internal class OthentoNetworkException(
    val error: OthentoError,
    val displayMessage: String,
    cause: Throwable? = null,
) : RuntimeException("[${error.code}] $displayMessage", cause)
