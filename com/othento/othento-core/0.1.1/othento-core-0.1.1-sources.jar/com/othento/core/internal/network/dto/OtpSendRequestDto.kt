package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass

/**
 * Wire body for `POST /api/v1/SessionToken/session/otp/send`.
 *
 * Mirrors [docs/spec/09-data-models.md §3.8]. Used by Phase 9; defined now
 * for DTO completeness.
 */
@JsonClass(generateAdapter = true)
internal data class OtpSendRequestDto(
    val attemptStepId: String,
    val contact: String,
)
