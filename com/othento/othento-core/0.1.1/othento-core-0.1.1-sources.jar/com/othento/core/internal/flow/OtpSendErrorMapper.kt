package com.othento.core.internal.flow

/**
 * Builds the inline notice shown when an OTP send is rejected. Faithful port
 * of the web SDK's `OtpFlowController.resolveSendNotice`
 * (`apps/sdk/src/app/pages/verify/otp-flow-controller.service.ts`).
 *
 * The repository already extracts the concrete field-level reason — e.g. the
 * `request.Contact` → "Corporate email required" validation error — into the
 * raw [com.othento.core.internal.data.OtpSendResult.Failure.displayMessage].
 * This layer only decides how to present it:
 *
 * - For the corporate-email-only policy we keep the backend reason as a bold
 *   [OtpNotice.title] and add guidance so the user understands that personal
 *   providers are blocked and what to enter instead.
 * - Every other failure is shown verbatim (description only), so the
 *   corporate hint never misleads on an unrelated error.
 */
internal object OtpSendErrorMapper {
    /**
     * Matches the backend's corporate/business-email policy rejection. Kept
     * deliberately broad — and gated on a match — so any other contact-field
     * error still surfaces its own message verbatim.
     */
    private val corporateEmailHintRe =
        Regex("corporate|business|organization|company", RegexOption.IGNORE_CASE)

    private const val CORPORATE_GUIDANCE: String =
        "Personal email providers (Gmail, Yahoo, Outlook, etc.) aren't accepted. " +
            "Please use your work or organization email address."

    fun resolveNotice(message: String): OtpNotice =
        if (corporateEmailHintRe.containsMatchIn(message)) {
            OtpNotice(title = message, description = CORPORATE_GUIDANCE)
        } else {
            OtpNotice(description = message)
        }
}
