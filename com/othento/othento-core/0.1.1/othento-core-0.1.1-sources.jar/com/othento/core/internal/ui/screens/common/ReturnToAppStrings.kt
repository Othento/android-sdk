package com.othento.core.internal.ui.screens.common

/**
 * Shared label for the explicit "close the SDK" CTA on every terminal /
 * error screen. The SDK never auto-finishes the host Activity — the user
 * tapping this CTA is the one and only path back to the host app.
 */
internal const val RETURN_TO_APP_LABEL: String = "Return to app"
