package com.othento.core.internal.capture.detection.passport

import android.graphics.Rect
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.othento.core.internal.capture.CaptureConfig
import com.othento.core.internal.capture.detection.face.FaceDetectorClient
import com.othento.core.internal.capture.detection.smartcropper.YuvToBitmap

/**
 * Passport photo gate. Verifies that an ML-Kit-detected face box lies in
 * the ICAO-correct upper-left quadrant of the passport cutout, sized
 * appropriately. Single-flight via [FaceDetectorClient]; latest result
 * cached in [snapshot].
 *
 * Defaults are derived from the web SDK capture.config.ts faceDetection block.
 *
 * Phase 7: ML Kit lifecycle delegated to [FaceDetectorClient] so the
 * selfie loop can share the same wrapper.
 */
internal class PassportPhotoGate(
    private val minFaceWidthRatio: Float = DEFAULT_MIN_FACE_WIDTH_RATIO,
    private val maxFaceWidthRatio: Float = DEFAULT_MAX_FACE_WIDTH_RATIO,
    private val maxFaceCenterX: Float = DEFAULT_MAX_FACE_CENTER_X,
    private val maxFaceCenterY: Float = DEFAULT_MAX_FACE_CENTER_Y,
    private val faceEdgeMargin: Float = CaptureConfig.FACE_EDGE_MARGIN,
) {
    private val client = FaceDetectorClient(minFaceSize = MIN_FACE_SIZE_HINT)

    @Volatile
    private var lastPassAtMs: Long = 0L

    data class Snapshot(
        val passed: Boolean = false,
    )

    fun schedule(
        image: ImageProxy,
        cutout: Rect,
    ) {
        // Full-frame fallback: when the screen can't supply a cutout
        // (no layout pass yet, or the analyzer fired before the cutout
        // overlay measured itself) the rect is empty. We scan the
        // entire sensor frame and fall back to "any face present" —
        // MRZ remains the strong signal in this mode, so a false
        // positive on the face gate alone can't trigger auto-capture.
        val isFullFrame =
            cutout.isEmpty ||
                (cutout.width() >= image.width && cutout.height() >= image.height)

        // Pass the full cutout (not the upper-65% sub-crop). The
        // sub-crop was a perf/precision optimization in the web SDK but
        // computing it correctly across rotations is fiddly: in image
        // coords, "top 65% of upright" is different per rotation
        // (right 65% along x for 90° CW, left 65% along x for 270° CW,
        // bottom 65% for 180°). ML Kit Face only fires on faces — it
        // ignores text — so passing the full cutout to the recognizer
        // produces the same passport-photo face match as a correctly
        // rotated sub-crop, at the cost of a slightly larger bitmap.
        val photoCutout = if (isFullFrame) null else cutout

        // Convert YUV → ARGB Bitmap synchronously. The bitmap survives the
        // analyzer's image.close() call.
        val bitmap = YuvToBitmap.convert(image, cutoutInImageCoords = photoCutout) ?: return
        val rotation = image.imageInfo.rotationDegrees
        val input = InputImage.fromBitmap(bitmap, rotation)
        val bitmapWidth = bitmap.width
        val bitmapHeight = bitmap.height
        // ML Kit Face returns boundingBox in *rotated* (upright) coords —
        // for rotation 90/270 the upright image's width/height are
        // swapped relative to the bitmap. Pass the upright dims to the
        // geometry validator so widthRatio / centerX / centerY are
        // computed against the same axes the thresholds were tuned for.
        val rotatedToUpright = rotation == QUARTER_TURN_DEG || rotation == THREE_QUARTER_TURN_DEG
        val uprightWidth = if (rotatedToUpright) bitmapHeight else bitmapWidth
        val uprightHeight = if (rotatedToUpright) bitmapWidth else bitmapHeight
        client.scheduleLatest(input) { faces, error ->
            bitmap.recycle()
            if (error != null || faces == null) {
                return@scheduleLatest
            }
            val face = faces.firstOrNull()?.boundingBox
            val passed =
                when {
                    face == null -> false
                    isFullFrame -> true
                    else ->
                        PassportPhotoGeometry.validate(
                            faceBox = face,
                            cutoutWidth = uprightWidth,
                            cutoutHeight = uprightHeight,
                            minFaceWidthRatio = minFaceWidthRatio,
                            maxFaceWidthRatio = maxFaceWidthRatio,
                            maxFaceCenterX = maxFaceCenterX,
                            maxFaceCenterY = maxFaceCenterY,
                            faceEdgeMargin = faceEdgeMargin,
                        )
                }
            if (passed) {
                lastPassAtMs = System.currentTimeMillis()
            }
        }
    }

    fun snapshot(): Snapshot {
        val age = System.currentTimeMillis() - lastPassAtMs
        return Snapshot(passed = lastPassAtMs > 0L && age < PASS_GRACE_MS)
    }

    fun release() {
        client.release()
    }

    private companion object {
        /** Once the face gate passes, keep it open for this long even if
         *  subsequent ML Kit scans temporarily fail. Matches MRZ's grace
         *  window — prevents hold-timer resets from transient detection gaps. */
        const val PASS_GRACE_MS: Long = 3_000L

        // Source: web SDK capture.config.ts faceDetection block (mobile defaults).
        const val DEFAULT_MIN_FACE_WIDTH_RATIO: Float = 0.08f
        const val DEFAULT_MAX_FACE_WIDTH_RATIO: Float = 0.38f
        const val DEFAULT_MAX_FACE_CENTER_X: Float = 0.42f
        const val DEFAULT_MAX_FACE_CENTER_Y: Float = 0.70f
        const val MIN_FACE_SIZE_HINT: Float = 0.15f
        const val QUARTER_TURN_DEG: Int = 90
        const val THREE_QUARTER_TURN_DEG: Int = 270
    }
}

/**
 * Pure geometry validator — testable without ML Kit.
 *
 * Mirrors [validateFaceGeometry] from the web SDK's mrz-detector.service.ts.
 * `widthRatio = faceWidth / cutoutWidth` must lie in `[min, max]`.
 * `centerX, centerY` (each in 0..1) must be ≤ their `max*` thresholds —
 * i.e., face is left-of-center and upper-of-center, the ICAO photo position.
 * `faceEdgeMargin` (default 0 = no check) enforces that `leftRatio ≥ margin`
 * and `rightRatio ≤ 1 − margin`, rejecting faces clipped at the frame edge.
 */
internal object PassportPhotoGeometry {
    /**
     * Validates ICAO face geometry within a passport cutout.
     *
     * Suppression reasons:
     * - LongParameterList: eight distinct geometric thresholds; grouping into a
     *   config object would push complexity into callers. Tests pass each
     *   threshold individually for clarity.
     * - ReturnCount: three early-exit degenerate guards (empty face / empty
     *   cutout / out-of-range width ratio) plus the normal boolean return.
     *   Collapsing into a single expression would hide the guard intent.
     */
    @Suppress("LongParameterList", "ReturnCount")
    fun validate(
        faceBox: Rect,
        cutoutWidth: Int,
        cutoutHeight: Int,
        minFaceWidthRatio: Float,
        maxFaceWidthRatio: Float,
        maxFaceCenterX: Float,
        maxFaceCenterY: Float,
        faceEdgeMargin: Float = 0f,
    ): Boolean {
        if (faceBox.width() <= 0 || faceBox.height() <= 0) return false
        if (cutoutWidth <= 0 || cutoutHeight <= 0) return false

        val widthRatio = faceBox.width().toFloat() / cutoutWidth
        if (widthRatio < minFaceWidthRatio || widthRatio > maxFaceWidthRatio) return false

        val centerX = (faceBox.left + faceBox.width() / 2f) / cutoutWidth
        val centerY = (faceBox.top + faceBox.height() / 2f) / cutoutHeight
        val leftRatio = faceBox.left.toFloat() / cutoutWidth
        val rightRatio = (faceBox.left + faceBox.width()).toFloat() / cutoutWidth
        return centerX <= maxFaceCenterX &&
            centerY <= maxFaceCenterY &&
            leftRatio >= faceEdgeMargin &&
            rightRatio <= 1f - faceEdgeMargin
    }
}
