@file:Suppress(
    "FunctionNaming",
    "TopLevelPropertyNaming",
    "MagicNumber",
    "LongParameterList",
    "LongMethod",
    // Reason: the bottom-sheet composable assembles a linear stack of pre-camera
    // sections (eyebrow, animated illustration, title, subtitle, tip-grid,
    // button). Splitting fragments the spec mapping in
    // `apps/sdk/src/app/components/ui/kyc-intro-sheet/kyc-intro-sheet.scss`.
)

package com.othento.core.internal.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Pre-camera tips sheet. Compose port of the web's
 * `apps/sdk/src/app/components/ui/kyc-intro-sheet/kyc-intro-sheet.ts`
 * + `.scss`.
 *
 * Visual structure (matches the web's bottom-sheet layout):
 * - Full-screen darkened backdrop.
 * - Panel **anchored to the bottom**, with rounded top corners only,
 *   slide-up entry animation.
 * - Eyebrow (mono, primary) + animated demo illustration (floating card
 *   inside a dashed primary frame) + title + subtitle + 4-card tip grid +
 *   "Scan Document" CTA.
 *
 * V8c — bottom-sheet styling, slide-up entry, animated demo card, and the
 * web's per-tip-card icons (light / corners / glare / no-screen) all
 * landed in this revision. Reduced-motion respects the system flag via
 * [LocalOthentoMotion].
 */
@Composable
internal fun KycIntroSheet(
    illustration: PlacementGuideKind,
    title: String,
    subtitle: String,
    eyebrow: String,
    tipCards: List<IntroTipCard>,
    buttonLabel: String,
    onContinue: () -> Unit,
    visible: Boolean = true,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val backdropInteraction = remember { MutableInteractionSource() }

    Box(
        modifier =
            Modifier
                .fillMaxSize(),
        contentAlignment = Alignment.BottomCenter,
    ) {
        // Backdrop.
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(animationSpec = tween(durationMillis = 300)),
            exit = fadeOut(animationSpec = tween(durationMillis = 240)),
            modifier = Modifier.fillMaxSize(),
        ) {
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .background(BackdropColor)
                        .clickable(
                            interactionSource = backdropInteraction,
                            indication = null,
                            // Tap on backdrop is a no-op — matches web behaviour
                            // (web doesn't dismiss intro on backdrop tap; user
                            // must tap the CTA).
                            onClick = {},
                        ),
            )
        }

        // Bottom-anchored panel with slide-up animation.
        AnimatedVisibility(
            visible = visible,
            enter =
                slideInVertically(
                    initialOffsetY = { it },
                    animationSpec =
                        tween(
                            durationMillis = 400,
                            easing = LinearOutSlowInEasing,
                        ),
                ) + fadeIn(animationSpec = tween(durationMillis = 250)),
            exit =
                slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = tween(durationMillis = 240),
                ) + fadeOut(animationSpec = tween(durationMillis = 180)),
        ) {
            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .heightIn(max = PanelMaxHeight)
                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .background(colors.bgBase)
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .verticalScroll(rememberScrollState())
                        .padding(
                            PaddingValues(
                                horizontal = PanelInnerHorizontal,
                                vertical = PanelInnerVertical,
                            ),
                        )
                        // Tap inside panel must NOT propagate to backdrop.
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {},
                        ),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (eyebrow.isNotBlank()) {
                    Text(
                        text = eyebrow.uppercase(),
                        style =
                            typography.microEyebrow.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.W600,
                                fontSize = 11.sp,
                                letterSpacing = 0.5.sp,
                            ),
                        color = colors.primary,
                    )
                    Spacer(Modifier.height(6.dp))
                }
                IntroIllustration(kind = illustration)
                Spacer(Modifier.height(16.dp))
                Text(
                    text = title,
                    style = typography.titleH3.copy(fontSize = 20.sp, fontWeight = FontWeight.W700),
                    color = colors.textPrimary,
                    textAlign = TextAlign.Center,
                )
                if (subtitle.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = subtitle,
                        style = typography.bodySm,
                        color = colors.textSecondary,
                        textAlign = TextAlign.Center,
                    )
                }
                if (tipCards.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    TipCardGrid(cards = tipCards)
                }
                Spacer(Modifier.height(20.dp))
                KycButton(
                    onClick = onContinue,
                    label = buttonLabel,
                    variant = KycButtonVariant.Primary,
                    size = KycButtonSize.Lg,
                    fullWidth = true,
                )
            }
        }
    }
}

// --- Animated demo illustration ----------------------------------------

/**
 * Compose port of `kyc-intro-sheet.scss` `.intro-sheet__demo` — a 140-dp
 * tall canvas with a primary-tinted gradient background, a dashed
 * primary-bordered frame in the middle, and an animated card that floats
 * left/right with a slight rotation (web `intro-demo-float` keyframe at
 * 5.4 s loop).
 */
@Composable
@Suppress(
    "CyclomaticComplexMethod",
)
private fun IntroIllustration(kind: PlacementGuideKind) {
    when (kind) {
        PlacementGuideKind.Selfie,
        PlacementGuideKind.Liveness,
        -> SelfieIntroIllustration(isLiveness = kind == PlacementGuideKind.Liveness)
        else -> DocumentIntroIllustration(kind = kind)
    }
}

@Composable
private fun DocumentIntroIllustration(kind: PlacementGuideKind) {
    val colors = LocalOthentoColors.current
    val motion = LocalOthentoMotion.current

    val transition = rememberInfiniteTransition(label = "intro-demo")
    val animProgress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(durationMillis = 5_400, easing = LinearOutSlowInEasing),
                repeatMode = RepeatMode.Restart,
            ),
        label = "intro-demo-progress",
    )
    val effectiveProgress = if (motion.reducedMotion) 0.5f else animProgress

    val phase = effectiveProgress * 4f
    val dxDp =
        when {
            phase < 1f -> -10f + 10f * phase
            phase < 2f -> 10f * (phase - 1f)
            phase < 3f -> 10f - 10f * (phase - 2f)
            else -> -10f * (phase - 3f)
        }
    val rotDeg =
        when {
            phase < 1f -> -2f + 2f * phase
            phase < 2f -> 2f * (phase - 1f)
            phase < 3f -> 2f - 2f * (phase - 2f)
            else -> -2f * (phase - 3f)
        }

    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(colors.primaryBg)
                .border(width = 1.dp, color = colors.border, shape = RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center,
    ) {
        DashedRectFrame(color = colors.primary.copy(alpha = 0.35f))

        Box(
            modifier =
                Modifier
                    .offset(x = if (motion.reducedMotion) 0.dp else dxDp.dp)
                    .let { base ->
                        if (motion.reducedMotion) base else base.rotate(rotDeg)
                    },
            contentAlignment = Alignment.Center,
        ) {
            DemoCard(kind = kind)
        }

        Box(
            modifier = Modifier.fillMaxSize().padding(bottom = 10.dp),
            contentAlignment = Alignment.BottomCenter,
        ) {
            DemoLabel(
                text =
                    when (kind) {
                        PlacementGuideKind.IdCardBack -> "Flip to the back"
                        else -> "Align inside frame"
                    },
            )
        }
    }
}

@Composable
@Suppress("CyclomaticComplexMethod", "LongMethod")
private fun SelfieIntroIllustration(isLiveness: Boolean) {
    val colors = LocalOthentoColors.current
    val motion = LocalOthentoMotion.current

    val transition = rememberInfiniteTransition(label = "selfie-intro")

    // Breath float: subtle vertical translate + scale (web `intro-selfie-float` 4.2s)
    val breathProgress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(durationMillis = 4_200, easing = LinearOutSlowInEasing),
                repeatMode = RepeatMode.Reverse,
            ),
        label = "selfie-breath",
    )

    // Pulse ring: expanding oval (web `intro-selfie-pulse` 2.6s / 2.4s liveness)
    val pulseDuration = if (isLiveness) 2_400 else 2_600
    val pulseProgress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(durationMillis = pulseDuration, easing = LinearOutSlowInEasing),
                repeatMode = RepeatMode.Restart,
            ),
        label = "selfie-pulse",
    )

    // Second pulse ring for liveness, offset by ~half cycle
    val pulse2Progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec =
            infiniteRepeatable(
                animation =
                    tween(
                        durationMillis = pulseDuration,
                        delayMillis = 1_200,
                        easing = LinearOutSlowInEasing,
                    ),
                repeatMode = RepeatMode.Restart,
            ),
        label = "selfie-pulse-2",
    )

    // Scan line: sweeps vertically (web `intro-selfie-scan` 2.4s)
    val scanProgress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(durationMillis = 2_400, easing = LinearOutSlowInEasing),
                repeatMode = RepeatMode.Restart,
            ),
        label = "selfie-scan",
    )

    // Corner bracket pulse (selfie only, web `intro-selfie-corner-pulse` 2.4s)
    val cornerAlpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.85f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(durationMillis = 2_400, easing = LinearOutSlowInEasing),
                repeatMode = RepeatMode.Reverse,
            ),
        label = "selfie-corner",
    )

    val breathDy = if (motion.reducedMotion) 0f else -3f * breathProgress
    val breathScale = if (motion.reducedMotion) 1f else 1f + 0.02f * breathProgress

    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(14.dp))
                .border(width = 1.dp, color = colors.border, shape = RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center,
    ) {
        // Radial gradient background (web: radial-gradient at 50% 45%)
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush =
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(colors.primaryBg, Color.Transparent),
                        center =
                            androidx.compose.ui.geometry.Offset(
                                size.width * 0.5f,
                                size.height * 0.45f,
                            ),
                        radius = size.width * 0.7f,
                    ),
            )
        }

        // Pulse ring(s)
        if (!motion.reducedMotion) {
            PulseRing(colors.primary, pulseProgress)
            if (isLiveness) {
                PulseRing(colors.primary, pulse2Progress)
            }
        } else {
            PulseRingStatic(colors.primary, alpha = 0.3f)
            if (isLiveness) {
                PulseRingStatic(colors.primary, alpha = 0.3f)
            }
        }

        // Dashed oval frame (web: 100x120 dp, border-radius 50%/45%)
        DashedOvalFrame(color = colors.primary.copy(alpha = 0.35f))

        // Scan line
        if (!motion.reducedMotion) {
            ScanLine(colors.primary, scanProgress)
        } else {
            ScanLineStatic(colors.primary)
        }

        // Corner brackets (selfie only)
        if (!isLiveness) {
            CornerBrackets(
                color = colors.primary,
                alpha = if (motion.reducedMotion) 0.5f else cornerAlpha,
            )
        }

        // Face silhouette with breath animation
        Box(
            modifier =
                Modifier
                    .offset(y = breathDy.dp)
                    .graphicsLayer(scaleX = breathScale, scaleY = breathScale),
            contentAlignment = Alignment.Center,
        ) {
            FaceSilhouette(primaryColor = colors.primary)
        }

        // Demo label
        Box(
            modifier = Modifier.fillMaxSize().padding(bottom = 10.dp),
            contentAlignment = Alignment.BottomCenter,
        ) {
            DemoLabel(
                text = if (isLiveness) "Just look at the camera" else "Center your face",
            )
        }
    }
}

@Composable
private fun PulseRing(color: Color, progress: Float) {
    val scale = 0.85f + 0.3f * progress
    val alpha = if (progress < 0.7f) 0.6f * (1f - progress / 0.7f) else 0f
    Canvas(
        modifier =
            Modifier
                .size(width = 100.dp, height = 120.dp)
                .graphicsLayer(scaleX = scale, scaleY = scale, alpha = alpha),
    ) {
        drawOval(
            color = color,
            topLeft = androidx.compose.ui.geometry.Offset.Zero,
            size = size,
            style =
                androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()),
        )
    }
}

@Composable
private fun PulseRingStatic(color: Color, alpha: Float) {
    Canvas(
        modifier =
            Modifier
                .size(width = 100.dp, height = 120.dp)
                .graphicsLayer(alpha = alpha),
    ) {
        drawOval(
            color = color,
            topLeft = androidx.compose.ui.geometry.Offset.Zero,
            size = size,
            style =
                androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()),
        )
    }
}

@Composable
private fun DashedOvalFrame(color: Color) {
    Canvas(modifier = Modifier.size(width = 100.dp, height = 120.dp)) {
        val strokePx = 2.dp.toPx()
        val dashPx = 6.dp.toPx()
        val gapPx = 4.dp.toPx()
        drawOval(
            color = color,
            topLeft =
                androidx.compose.ui.geometry.Offset(strokePx / 2f, strokePx / 2f),
            size =
                androidx.compose.ui.geometry.Size(
                    width = size.width - strokePx,
                    height = size.height - strokePx,
                ),
            style =
                androidx.compose.ui.graphics.drawscope.Stroke(
                    width = strokePx,
                    pathEffect =
                        androidx.compose.ui.graphics.PathEffect.dashPathEffect(
                            floatArrayOf(dashPx, gapPx),
                            0f,
                        ),
                ),
        )
    }
}

@Composable
private fun ScanLine(color: Color, progress: Float) {
    val scanAlpha =
        when {
            progress < 0.15f -> progress / 0.15f * 0.85f
            progress < 0.85f -> 0.85f
            else -> 0.85f * (1f - (progress - 0.85f) / 0.15f)
        }
    val yOffset = (-60f + 120f * progress).dp
    Box(
        modifier =
            Modifier
                .offset(y = yOffset)
                .size(width = 104.dp, height = 2.dp)
                .graphicsLayer(alpha = scanAlpha)
                .background(
                    brush =
                        androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors =
                                listOf(
                                    Color.Transparent,
                                    color,
                                    color,
                                    Color.Transparent,
                                ),
                            startX = 0f,
                            endX = Float.POSITIVE_INFINITY,
                        ),
                    shape = RoundedCornerShape(1.dp),
                ),
    )
}

@Composable
private fun ScanLineStatic(color: Color) {
    Box(
        modifier =
            Modifier
                .size(width = 104.dp, height = 2.dp)
                .graphicsLayer(alpha = 0.4f)
                .background(
                    brush =
                        androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors =
                                listOf(
                                    Color.Transparent,
                                    color,
                                    color,
                                    Color.Transparent,
                                ),
                            startX = 0f,
                            endX = Float.POSITIVE_INFINITY,
                        ),
                    shape = RoundedCornerShape(1.dp),
                ),
    )
}

@Composable
private fun CornerBrackets(color: Color, alpha: Float) {
    Canvas(
        modifier =
            Modifier
                .size(width = 112.dp, height = 124.dp)
                .graphicsLayer(alpha = alpha),
    ) {
        val strokePx = 2.dp.toPx()
        val armPx = 14.dp.toPx()
        val cornerR = 3.dp.toPx()
        val bracketColor = color
        val stroke =
            androidx.compose.ui.graphics.drawscope.Stroke(
                width = strokePx,
                cap = androidx.compose.ui.graphics.StrokeCap.Round,
            )

        // TL: down arm + right arm
        drawLine(bracketColor, androidx.compose.ui.geometry.Offset(0f, armPx), androidx.compose.ui.geometry.Offset(0f, cornerR), stroke.width)
        drawLine(bracketColor, androidx.compose.ui.geometry.Offset(cornerR, 0f), androidx.compose.ui.geometry.Offset(armPx, 0f), stroke.width)

        // TR
        drawLine(bracketColor, androidx.compose.ui.geometry.Offset(size.width, armPx), androidx.compose.ui.geometry.Offset(size.width, cornerR), stroke.width)
        drawLine(bracketColor, androidx.compose.ui.geometry.Offset(size.width - cornerR, 0f), androidx.compose.ui.geometry.Offset(size.width - armPx, 0f), stroke.width)

        // BL
        drawLine(bracketColor, androidx.compose.ui.geometry.Offset(0f, size.height - armPx), androidx.compose.ui.geometry.Offset(0f, size.height - cornerR), stroke.width)
        drawLine(bracketColor, androidx.compose.ui.geometry.Offset(cornerR, size.height), androidx.compose.ui.geometry.Offset(armPx, size.height), stroke.width)

        // BR
        drawLine(bracketColor, androidx.compose.ui.geometry.Offset(size.width, size.height - armPx), androidx.compose.ui.geometry.Offset(size.width, size.height - cornerR), stroke.width)
        drawLine(bracketColor, androidx.compose.ui.geometry.Offset(size.width - cornerR, size.height), androidx.compose.ui.geometry.Offset(size.width - armPx, size.height), stroke.width)
    }
}

@Composable
private fun FaceSilhouette(primaryColor: Color) {
    Canvas(modifier = Modifier.size(width = 64.dp, height = 80.dp)) {
        val w = size.width
        val h = size.height
        val sx = w / 96f
        val sy = h / 120f
        val path =
            androidx.compose.ui.graphics.Path().apply {
                moveTo(48f * sx, 12f * sy)
                cubicTo(62f * sx, 12f * sy, 72f * sx, 24f * sy, 72f * sx, 40f * sy)
                cubicTo(72f * sx, 52f * sy, 66f * sx, 62f * sy, 58f * sx, 68f * sy)
                lineTo(58f * sx, 74f * sy)
                cubicTo(78f * sx, 77f * sy, 90f * sx, 92f * sy, 90f * sx, 120f * sy)
                lineTo(6f * sx, 120f * sy)
                cubicTo(6f * sx, 92f * sy, 18f * sx, 77f * sy, 38f * sx, 74f * sy)
                lineTo(38f * sx, 68f * sy)
                cubicTo(30f * sx, 62f * sy, 24f * sx, 52f * sy, 24f * sx, 40f * sy)
                cubicTo(24f * sx, 24f * sy, 34f * sx, 12f * sy, 48f * sx, 12f * sy)
                close()
            }
        drawPath(
            path = path,
            brush =
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    colors =
                        listOf(
                            primaryColor.copy(alpha = 0.22f),
                            primaryColor.copy(alpha = 0.06f),
                        ),
                ),
        )
        drawPath(
            path = path,
            color = primaryColor,
            style =
                androidx.compose.ui.graphics.drawscope.Stroke(
                    width = 1.6f * ((sx + sy) / 2f),
                    join = androidx.compose.ui.graphics.StrokeJoin.Round,
                ),
        )
    }
}

@Composable
private fun DashedRectFrame(color: Color) {
    Canvas(
        modifier = Modifier.size(width = 170.dp, height = 105.dp),
    ) {
        val strokePx = 2.dp.toPx()
        val dashPx = 6.dp.toPx()
        val gapPx = 4.dp.toPx()
        drawRoundRect(
            color = color,
            topLeft =
                androidx.compose.ui.geometry
                    .Offset(strokePx / 2f, strokePx / 2f),
            size =
                androidx.compose.ui.geometry.Size(
                    width = size.width - strokePx,
                    height = size.height - strokePx,
                ),
            cornerRadius =
                androidx.compose.ui.geometry
                    .CornerRadius(10.dp.toPx(), 10.dp.toPx()),
            style =
                androidx.compose.ui.graphics.drawscope.Stroke(
                    width = strokePx,
                    pathEffect =
                        androidx.compose.ui.graphics.PathEffect.dashPathEffect(
                            floatArrayOf(dashPx, gapPx),
                            0f,
                        ),
                ),
        )
    }
}

@Composable
private fun DemoCard(kind: PlacementGuideKind) {
    val colors = LocalOthentoColors.current
    Box(
        modifier =
            Modifier
                .size(width = 150.dp, height = 90.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(colors.bgBase)
                .border(width = 1.dp, color = colors.border.copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp)),
    ) {
        when (kind) {
            PlacementGuideKind.IdCardBack -> DemoCardBack()
            else -> DemoCardFront()
        }
    }
}

@Composable
private fun DemoCardFront() {
    val colors = LocalOthentoColors.current
    Row(
        modifier = Modifier.fillMaxSize().padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // Photo box.
        Box(
            modifier =
                Modifier
                    .size(width = 38.dp, height = 52.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(colors.primaryBg),
        )
        // Lines.
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            DemoLine(widthFraction = 0.7f, color = colors.bgHover)
            DemoLine(widthFraction = 0.5f, color = colors.bgHover)
            DemoLine(widthFraction = 0.6f, color = colors.bgHover)
            Spacer(Modifier.height(2.dp))
            DemoLine(widthFraction = 0.9f, color = colors.primaryBg, height = 4.dp)
            DemoLine(widthFraction = 0.85f, color = colors.primaryBg, height = 4.dp)
        }
    }
}

@Composable
private fun DemoCardBack() {
    val colors = LocalOthentoColors.current
    Column(modifier = Modifier.fillMaxSize()) {
        // Magnetic stripe.
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(16.dp)
                    .background(colors.textPrimary.copy(alpha = 0.18f)),
        )
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            DemoLine(widthFraction = 0.9f, color = colors.bgHover)
            DemoLine(widthFraction = 0.7f, color = colors.bgHover)
            DemoLine(widthFraction = 0.8f, color = colors.bgHover)
            DemoLine(widthFraction = 0.5f, color = colors.bgHover)
        }
    }
}

@Composable
private fun DemoLine(
    widthFraction: Float,
    color: Color,
    height: androidx.compose.ui.unit.Dp = 5.dp,
) {
    Box(
        modifier =
            Modifier
                .fillMaxWidth(widthFraction)
                .height(height)
                .clip(RoundedCornerShape(2.dp))
                .background(color),
    )
}

@Composable
private fun DemoLabel(text: String) {
    val colors = LocalOthentoColors.current
    Box(
        modifier =
            Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(colors.textPrimary)
                .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(
            text = text,
            color = colors.bgBase,
            fontSize = 10.sp,
            fontWeight = FontWeight.W600,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.3.sp,
        )
    }
}

// --- Tip cards ---------------------------------------------------------

@Composable
private fun TipCardGrid(cards: List<IntroTipCard>) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        cards.chunked(2).forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                pair.forEach { card ->
                    Box(modifier = Modifier.weight(1f)) {
                        TipCardCell(card = card)
                    }
                }
                if (pair.size == 1) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun TipCardCell(card: IntroTipCard) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(colors.bgBase)
                .border(width = 1.dp, color = colors.border, shape = RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Box(
            modifier =
                Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(colors.primaryBg),
            contentAlignment = Alignment.Center,
        ) {
            KycIcon(
                imageVector = card.icon,
                contentDescription = null,
                sizeDp = 15.dp,
                tint = colors.primary,
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = card.label,
            style = typography.caption.copy(fontWeight = FontWeight.W600),
            color = colors.textPrimary,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = card.detail,
            style = typography.caption.copy(fontSize = 10.sp),
            color = colors.textMuted,
        )
    }
}

internal data class IntroTipCard(
    val label: String,
    val detail: String,
    val icon: ImageVector = OthentoIcons.Info,
)

private val PanelMaxHeight = 700.dp
private val PanelInnerHorizontal = 20.dp
private val PanelInnerVertical = 24.dp
private val BackdropColor = Color(0xC7000000)
