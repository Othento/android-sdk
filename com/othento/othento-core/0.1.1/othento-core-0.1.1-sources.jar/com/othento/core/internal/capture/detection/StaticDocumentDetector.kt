package com.othento.core.internal.capture.detection

import android.graphics.Bitmap
import android.graphics.PointF

/**
 * Test seam over `SmartCropper.scan(Bitmap)`. The validator depends on this
 * interface so unit tests can drive corner outcomes with a fake. `fun interface`
 * so tests can pass a SAM lambda directly.
 */
internal fun interface StaticDocumentDetector {
    /** Returns 4 corner points, or null if no quad is confidently detected. */
    fun scan(bitmap: Bitmap): List<PointF>?
}
