package com.othento.core.internal.flow

import com.othento.core.internal.data.model.OtpChannel
import com.othento.core.internal.data.model.Session

/**
 * Screen-facing state for the OTP screens (phone + email). Owned by
 * [FlowCoordinator] and rebuilt on each tick of the cooldown timer.
 *
 * Fields mirror the visible elements of [docs/spec/06-screens/09-otp-phone.md]
 * §"States" — the screen is a thin renderer over this shape.
 */
internal data class OtpUiState(
    /** Phone vs email — drives the destination input + chrome copy. */
    val channel: OtpChannel,
    /**
     * `true` while the user is editing the destination contact (initial
     * state, or after tapping "Change phone/email"). `false` once a send
     * has succeeded — flips to the code-entry layout.
     */
    val editing: Boolean,
    val sendInFlight: Boolean = false,
    val verifyInFlight: Boolean = false,
    /**
     * Inline error below "Send code" (network / non-{410,422} HTTP). Carries
     * an optional bold [OtpNotice.title] plus the body so policy rejections
     * (e.g. corporate-email-only) can show the backend reason *and* guidance.
     */
    val sendError: OtpNotice? = null,
    /**
     * Inline error below "Verify". `null` when one of the two dialog
     * kinds ([verifyErrorKind]) is the active surface — the dialog
     * supersedes the inline notice.
     */
    val verifyError: String? = null,
    /** Distinguishes the two dialog cases the spec calls out (§10.5). */
    val verifyErrorKind: OtpVerifyErrorKind? = null,
    /** Skip-notice sheet payload. Pending session committed on Continue. */
    val skipNotice: SkipNotice? = null,
    val cooldownRemainingSec: Int = 0,
    val isExpired: Boolean = false,
    val canResend: Boolean = true,
    /** Most recently sent contact — restores destination on edit-cancel. */
    val lastContact: String? = null,
    val codeLength: Int = DEFAULT_OTP_LENGTH,
    val alphanumeric: Boolean = false,
    /**
     * Email channel only: when `true` the destination input rejects public
     * / free email domains, accepting corporate addresses only. Driven by
     * the active challenge's `corporateEmailOnly` flag. Always `false` for
     * the phone channel.
     */
    val corporateEmailOnly: Boolean = false,
) {
    data class SkipNotice(
        val pendingSession: Session,
        val message: String,
    )

    companion object {
        const val DEFAULT_OTP_LENGTH: Int = 6
    }
}

/**
 * Inline send-failure notice. Mirrors the web SDK's `OtpNotice`
 * (`apps/sdk/.../models/session.model.ts`): an optional bold [title] (the
 * concrete backend reason) over a [description] body. When [title] is null
 * the notice renders as a single line, identical to the previous behaviour.
 */
internal data class OtpNotice(
    val description: String,
    val title: String? = null,
)

/** Spec §10.5 — verify error dialog discriminator. */
internal enum class OtpVerifyErrorKind {
    /** HTTP 410 — show the "Code expired" dialog with "Send new code" CTA. */
    Expired,

    /** HTTP 422 — show the "Incorrect code" dialog with "Try again" CTA. */
    Invalid,
}
