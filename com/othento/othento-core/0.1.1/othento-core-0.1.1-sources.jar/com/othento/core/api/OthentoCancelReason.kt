package com.othento.core.api

/**
 * Reason the SDK fired [OthentoSDKListener.onCancelled].
 *
 * Mirrors the cross-platform contract's `CancelReason`. The first two
 * values are the cross-platform set every implementation emits; the
 * remaining values are Android-additive (no collision with the
 * cross-platform values or with iOS/Web additions).
 *
 * Wire format: PascalCase Kotlin constants serialize to the matching
 * PascalCase JSON string — the cross-platform contract uses kebab-case
 * on the wire (`"host-destroy"`, `"sdk-internal"`, `"back-button"`), and
 * the SDK maps to those strings via the `wireValue` property when
 * forwarding to analytics / webhook payloads.
 */
public enum class OthentoCancelReason(
    public val wireValue: String,
) {
    /** Host called [OthentoSDK.destroy] before a terminal event. */
    HostDestroy("host-destroy"),

    /** The SDK's own UI cancelled the session (e.g. an in-flow Cancel CTA). */
    SdkInternal("sdk-internal"),

    /** System back button or back gesture. Android-only. */
    BackButton("back-button"),
}
