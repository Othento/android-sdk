package com.othento.core.internal.capture.video

import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.io.File
import java.nio.ByteBuffer

/**
 * Trims an MP4 to the last [windowMs] of footage by copying samples from
 * the latest sync (key) frame whose presentation-time is at or before
 * `durationUs - windowMs * 1000`. No re-encode — straight extractor →
 * muxer pass-through.
 *
 * If the scratch is shorter than [windowMs] the whole file is copied.
 * Returns `false` (and best-effort deletes the partial output) on any
 * failure: missing video track, unreadable source, muxer error.
 *
 * Audio is not handled — the recorder writes video-only.
 *
 * Reference design: docs/superpowers/specs/2026-05-02-rolling-video-capture-design.md
 */
internal object VideoTrim {
    private const val TAG = "VideoTrim"
    private const val SAMPLE_BUFFER_BYTES: Int = 1024 * 1024 // 1 MiB

    /**
     * Pure cutoff math. Returns the presentation-time (microseconds) at
     * which the trimmed clip should start. Internal for unit testing —
     * production callers go through [trim].
     */
    internal fun computeCutoffUs(
        durationUs: Long,
        windowMs: Long,
    ): Long {
        if (durationUs <= 0L) return 0L
        val windowUs = windowMs * 1_000L
        if (windowUs <= 0L) return durationUs
        if (windowUs >= durationUs) return 0L
        return durationUs - windowUs
    }

    /**
     * Trim [input] into [output]. Returns `true` on success. On failure
     * the partial [output] is best-effort deleted and `false` is
     * returned; the caller is expected to surface a retake hint.
     */
    fun trim(
        input: File,
        output: File,
        windowMs: Long,
    ): Boolean {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(input.absolutePath)
            val videoTrack = findVideoTrackIndex(extractor)
            if (videoTrack < 0) {
                Log.w(TAG, "No video track in ${input.name}")
                return false
            }
            extractor.selectTrack(videoTrack)
            val format = extractor.getTrackFormat(videoTrack)
            val durationUs =
                if (format.containsKey(MediaFormat.KEY_DURATION)) {
                    format.getLong(MediaFormat.KEY_DURATION)
                } else {
                    -1L
                }
            val cutoffUs = computeCutoffUs(durationUs, windowMs)

            extractor.seekTo(cutoffUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val firstSampleUs = extractor.sampleTime
            if (firstSampleUs < 0L) {
                Log.w(TAG, "No sample at/before cutoff for ${input.name}")
                return false
            }

            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outTrack = muxer.addTrack(format)
            muxer.start()

            val buffer = ByteBuffer.allocate(SAMPLE_BUFFER_BYTES)
            val info = android.media.MediaCodec.BufferInfo()
            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                info.offset = 0
                info.size = sampleSize
                info.presentationTimeUs = (extractor.sampleTime - firstSampleUs).coerceAtLeast(0L)
                info.flags = mapExtractorFlags(extractor.sampleFlags)
                muxer.writeSampleData(outTrack, buffer, info)
                extractor.advance()
            }
            return true
        } catch (t: Throwable) {
            Log.w(TAG, "Trim failed for ${input.name}: ${t.message}")
            runCatching { output.delete() }
            return false
        } finally {
            runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun findVideoTrackIndex(extractor: MediaExtractor): Int {
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/")) return i
        }
        return -1
    }

    /** MediaExtractor sample flags don't directly match BufferInfo flags; map sync-only. */
    private fun mapExtractorFlags(extractorFlags: Int): Int {
        var out = 0
        if (extractorFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
            out = out or android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME
        }
        return out
    }
}
