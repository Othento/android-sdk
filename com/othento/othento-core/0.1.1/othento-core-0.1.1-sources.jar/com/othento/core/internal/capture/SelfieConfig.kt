package com.othento.core.internal.capture

/**
 * Selfie-screen tunables — single source of truth for the Phase 7 face-match
 * capture loop. Values mirror the web SDK's `selfie.config.ts`
 * (`apps/sdk/src/app/pages/verify/screens/selfie-capture/selfie.config.ts`)
 * mobile branch; spec [docs/spec/11-business-logic-and-validation.md] §7 / §9.
 *
 * Only the mobile ("base") column is ported. The web's desktop overrides
 * (`inputSize=416`, `scoreThreshold=0.3`, etc.) don't apply on phones.
 */
internal object SelfieConfig {
    // ──────────────────────────────────────── Face detection cadence ──────────────────────────────

    /**
     * Minimum-face-size hint passed to ML Kit. The web uses face-api's
     * `inputSize=224`; ML Kit takes a fractional minimum face size instead
     * (proportion of the shorter image edge). 0.15 keeps detection robust
     * for ICAO photo-style selfies that fill the oval.
     */
    const val MIN_FACE_SIZE_HINT: Float = 0.15f

    /** Detector loop cadence — ~5 fps. Same as web's selfie config. */
    const val DETECTION_INTERVAL_MS: Long = 200L

    // ──────────────────────────────────────── Oval ROI geometry ───────────────────────────────────

    /** Oval width as a fraction of the container width. */
    const val ROI_WIDTH_RATIO: Float = 0.65f

    /** Oval is taller than wide — `height = width × this`. */
    const val ROI_HEIGHT_TO_WIDTH_RATIO: Float = 1.3f

    // ──────────────────────────────────────── Auto-capture ────────────────────────────────────────

    /**
     * Block auto + manual capture for this long after the camera turns on,
     * so the rolling video buffer has at least 2 s of footage.
     */
    const val CAPTURE_DELAY_MS: Long = 2_000L

    /** Stable face-in-ROI duration before auto-capture fires. */
    const val AUTO_CAPTURE_DURATION_MS: Long = 1_400L

    /**
     * Tolerance fraction — missed-frame count above
     * `ceil(durationMs * toleranceRatio / detectionIntervalMs)` resets the
     * stability counter. Quality issues bypass the tolerance and reset
     * immediately.
     */
    const val AUTO_CAPTURE_TOLERANCE_RATIO: Float = 0.3f

    /** Sticky-message floor — hint strings persist this long to avoid flicker. */
    const val MESSAGE_MIN_DURATION_MS: Long = 1_500L

    // ──────────────────────────────────────── Geometric gates ─────────────────────────────────────

    /** Face area / oval area — too small below this. */
    const val FILL_PERCENTAGE_MIN: Float = 0.62f

    /** Face area / oval area — too large above this. */
    const val FILL_PERCENTAGE_MAX: Float = 1.4f

    /**
     * Distance from face center to oval center, normalised by the oval
     * radii (`sqrt((dx/rx)² + (dy/ry)²)`). Face must be ≤ this to pass the
     * "face in oval" check.
     */
    const val MAX_CENTER_OFFSET: Float = 0.38f

    // ──────────────────────────────────────── Brightness gates ────────────────────────────────────

    /** Mean luminance over the face bounding box; too dark below. */
    const val FACE_BRIGHTNESS_MIN: Int = 70

    /** Mean luminance over the face bounding box; too bright above. */
    const val FACE_BRIGHTNESS_MAX: Int = 230

    // ──────────────────────────────────────── Capture timeout ─────────────────────────────────────

    /**
     * Selfie camera timeout — same 45 s window as document capture
     * (`selfie.config.ts:50-55`). Beyond this, the screen flips to the
     * "We couldn't detect your face in time" timeout state.
     */
    const val CAMERA_TIMEOUT_MS: Long = 45_000L
}
