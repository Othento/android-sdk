@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.theme

import android.provider.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

/**
 * The single Compose entry point for every SDK screen. Provides the design-token
 * CompositionLocals ([LocalOthentoColors], [LocalOthentoTypography], [LocalOthentoSpacing],
 * [LocalOthentoShapes], [LocalOthentoElevation], [LocalOthentoMotion]) and a thin
 * [MaterialTheme] beneath them so any incidental Material 3 surface (e.g.
 * indication ripple) inherits consistent tints.
 */
@Composable
internal fun OthentoTheme(
    reducedMotion: Boolean = rememberReducedMotion(),
    content: @Composable () -> Unit,
) {
    val colors = remember { OthentoColors.Light }
    val typography = remember { OthentoTypography.default() }
    val spacing = remember { OthentoSpacing.Default }
    val shapes = remember { OthentoShapes.Default }
    val elevation = remember { OthentoElevation.Default }
    val motion =
        remember(reducedMotion) { OthentoMotion.Default.copy(reducedMotion = reducedMotion) }

    val materialColorScheme =
        remember(colors) {
            lightColorScheme(
                primary = colors.primary,
                onPrimary = Color.White,
                background = colors.bgBase,
                onBackground = colors.textPrimary,
                surface = colors.bgBase,
                onSurface = colors.textPrimary,
                error = colors.error,
                onError = Color.White,
            )
        }

    // The SDK is designed LTR-only. Force Compose layout direction so an Arabic
    // (or any RTL) device locale can't mirror our screens. The host Activity
    // also pins the View-tree direction for AndroidView interop (CameraX preview).
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Ltr,
        LocalOthentoColors provides colors,
        LocalOthentoTypography provides typography,
        LocalOthentoSpacing provides spacing,
        LocalOthentoShapes provides shapes,
        LocalOthentoElevation provides elevation,
        LocalOthentoMotion provides motion,
    ) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            content = content,
        )
    }
}

/**
 * Reads `Settings.Global.TRANSITION_ANIMATION_SCALE` and `ANIMATOR_DURATION_SCALE`
 * once per composition. Both at zero ⇒ user has reduced motion enabled.
 *
 * The flags are static for the lifetime of an Activity; if the user toggles them
 * the SDK Activity will be recreated, so the next composition picks up the
 * change automatically.
 */
@Composable
internal fun rememberReducedMotion(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        val resolver = context.contentResolver
        val transition =
            Settings.Global.getFloat(
                resolver,
                Settings.Global.TRANSITION_ANIMATION_SCALE,
                1f,
            )
        val animator =
            Settings.Global.getFloat(
                resolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1f,
            )
        transition == 0f && animator == 0f
    }
}

