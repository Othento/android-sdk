@file:Suppress(
    "MagicNumber",
    "ReturnCount",
    // Reason: V27 corner smoother. The literal `4` is the mandated quad
    // corner count (TL/TR/BR/BL per spec §1.3); `3` is the 0-based upper
    // bound of the same 4-slot range — not arbitrary tuning values.
    // `ReturnCount`: two early-exit guards (null corners + single-frame
    // buffer) plus the normal return; extracting them would obscure the
    // buffer-lifecycle logic.
)

package com.othento.core.internal.capture.detection

import android.graphics.PointF
import com.othento.core.internal.capture.CaptureConfig
import java.util.ArrayDeque

/**
 * Per-corner median smoother for detected document quads — V27.
 *
 * Backstory: V26 ships the OpenCV `scanic` port at frame-rate. Even when
 * the algorithm finds the card every frame, Canny is grain-sensitive
 * enough that corner positions shift ±5–15 px between consecutive
 * frames. At 5 fps detection that reads as visible jitter on the L-shape
 * corner brackets.
 *
 * This smoother holds the last [CaptureConfig.CORNER_SMOOTHING_FRAMES]
 * detections and emits a quad whose 4 corners are the per-corner median
 * (separately for X and Y) across the buffer. Median (not mean / EMA)
 * because a single bad frame's contour produces one anomalous quad —
 * median ignores outliers; mean would drag toward them.
 *
 * **Buffer lifecycle:**
 * - On a detection (corners non-null): if more than
 *   [CaptureConfig.CORNER_SMOOTHING_RESET_MS] has elapsed since the
 *   last input, clear the buffer first (user moved the card; old
 *   quads aren't representative). Add the new quad. Emit median.
 * - On a miss (corners null): if the gap exceeded RESET_MS, clear the
 *   buffer. Emit null either way (no detection → no brackets).
 *
 * **What the smoother does NOT touch:** `meetsThreshold` /
 * `coverageRatio` / hint — those are unsmoothed in the calling
 * pipeline, so auto-capture stability still depends on actual
 * frame-to-frame detection consistency, not "any detection at all".
 *
 * Not thread-safe. Caller (`DetectionPipeline.submit`) only invokes
 * this from its launched coroutine, single-flighted by CameraX's
 * `STRATEGY_KEEP_ONLY_LATEST`.
 */
internal class CornerSmoother(
    private val maxFrames: Int = CaptureConfig.CORNER_SMOOTHING_FRAMES,
    private val resetMs: Long = CaptureConfig.CORNER_SMOOTHING_RESET_MS,
) {
    private val buffer: ArrayDeque<List<PointF>> = ArrayDeque(maxFrames)
    private var lastInputMs: Long = Long.MIN_VALUE / 2

    /**
     * Drop the smoothing buffer immediately. Called by [DetectionPipeline.reset]
     * on Retake so the smoother doesn't leak captured-frame corners into the
     * post-retake detection window.
     */
    fun clear() {
        buffer.clear()
        lastInputMs = Long.MIN_VALUE / 2
    }

    /**
     * Submit one frame's detection quad (or null on miss). Returns
     * the smoothed quad to draw, or null if no detection.
     */
    fun smooth(
        corners: List<PointF>?,
        nowMs: Long,
    ): List<PointF>? {
        if (lastInputMs != Long.MIN_VALUE / 2 && (nowMs - lastInputMs) > resetMs) {
            buffer.clear()
        }
        lastInputMs = nowMs

        if (corners == null) return null

        // Spec invariant — every quad has exactly 4 corners sorted TL/TR/BR/BL.
        require(corners.size == 4) { "expected 4 corners, got ${corners.size}" }

        if (buffer.size >= maxFrames) {
            buffer.removeFirst()
        }
        buffer.addLast(corners)

        if (buffer.size == 1) return buffer.first()
        return medianQuad(buffer.toList())
    }

    /**
     * Compute the per-corner median across [quads]. For each of the 4
     * corner slots (TL=0, TR=1, BR=2, BL=3), take the median X and
     * median Y independently.
     */
    private fun medianQuad(quads: List<List<PointF>>): List<PointF> {
        val result = ArrayList<PointF>(4)
        for (slot in 0..3) {
            val xs = quads.map { it[slot].x }.sorted()
            val ys = quads.map { it[slot].y }.sorted()
            // Lower-middle for even-sized lists; for our N ≤ 3 this
            // means: 1 → [0]; 2 → [0]; 3 → [1].
            val mx = xs[(xs.size - 1) / 2]
            val my = ys[(ys.size - 1) / 2]
            result.add(PointF(mx, my))
        }
        return result
    }
}
