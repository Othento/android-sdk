@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Trust row that anchors every Phase-4 screen. Faithful port of the web
 * SDK's `.sdk-footer__trust` ([docs/spec/06-screens/20-shared.md] §SdkLayout):
 *
 * - 12-dp lock icon + "Encrypted & secure"
 * - 3-dp outline-circle separator
 * - "SECURED BY" microlabel (uppercase, `--color-text-disabled`)
 * - 18-dp brand logo placeholder + brand name
 *
 * Phase 4 renders the brand-logo slot as a primary-tinted square (Phase 11
 * adds the URL → bitmap pipeline; logged as Q4 in `99-open-questions.md`).
 *
 * Padding follows the spec: `12 dp` vertical, `24 dp` horizontal, plus
 * `WindowInsets.navigationBars.asPaddingValues().bottom` for safe-area.
 */
@Composable
internal fun OthentoTrustFooter(
    brandName: String,
    modifier: Modifier = Modifier,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val safeBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    Box(
        modifier =
            modifier
                .fillMaxWidth()
                .background(colors.bgBase)
                .padding(horizontal = TrustFooterHorizontal, vertical = TrustFooterVertical)
                .padding(bottom = safeBottom),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(TrustGap),
        ) {
            KycIcon(
                imageVector = OthentoIcons.Lock,
                contentDescription = null,
                sizeDp = LockIconSize,
                tint = colors.textSecondary,
            )
            Text(
                text = "Encrypted & secure",
                style = typography.caption.copy(fontSize = 11.sp),
                color = colors.textSecondary,
            )
            // 3 dp outline circle separator.
            Box(
                modifier =
                    Modifier
                        .size(SeparatorSize)
                        .clip(CircleShape)
                        .border(width = 1.dp, color = colors.textDisabled, shape = CircleShape),
            )
            Text(
                text = "SECURED BY",
                style = typography.microEyebrow.copy(fontSize = 10.sp),
                color = colors.textDisabled,
            )
            Box(
                modifier =
                    Modifier
                        .size(BrandLogoSize)
                        .clip(RoundedCornerShape(4.dp))
                        .background(colors.primaryBg),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = brandName.take(1).uppercase(),
                    style = typography.caption.copy(fontWeight = FontWeight.W700, fontSize = 11.sp),
                    color = colors.primary,
                )
            }
            Text(
                text = brandName,
                style = typography.caption.copy(fontWeight = FontWeight.W600, fontSize = 12.sp),
                color = colors.textMuted,
            )
        }
    }
}

private val TrustFooterVertical = 12.dp
private val TrustFooterHorizontal = 24.dp
private val TrustGap = 6.dp
private val LockIconSize = 12.dp
private val SeparatorSize = 3.dp
private val BrandLogoSize = 18.dp
