@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber", "MatchingDeclarationName", "LongMethod")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * A single dropdown option. [leading] is rendered before the label (used for
 * country flags); [id] is the stable handle the parent receives on select.
 */
@Immutable
internal data class KycDropdownOption(
    val id: String,
    val label: String,
    val leading: (@Composable () -> Unit)? = null,
)

/**
 * Modal-style dropdown matching the web SDK's `.doc-select__dropdown-*`
 * pattern ([apps/sdk/.../document-select-screen.scss:91-99]). Trigger button
 * with optional leading + chevron; the menu renders as a [Popup] overlay
 * directly below the trigger so it floats over the rest of the screen
 * instead of pushing content down. Tapping outside the menu (popup's
 * built-in `dismissOnClickOutside`) or selecting an option closes it.
 *
 * Phase 5 only ships the country picker, but the primitive is internal so
 * Phase 11 can reuse it for the locale switcher (R5 in `99-open-questions.md`).
 */
@Composable
@Suppress("LongParameterList")
internal fun KycDropdown(
    selectedId: String?,
    options: List<KycDropdownOption>,
    onSelect: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val shapes = LocalOthentoShapes.current
    val motion = LocalOthentoMotion.current
    val density = LocalDensity.current
    var open by rememberSaveable { mutableStateOf(false) }
    var triggerWidthPx by remember { mutableStateOf(0) }
    var triggerHeightPx by remember { mutableStateOf(0) }
    val selected = remember(selectedId, options) { options.firstOrNull { it.id == selectedId } }
    val chevronRotation by animateFloatAsState(
        targetValue = if (open) 180f else 0f,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-dropdown-chevron",
    )

    Box(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned {
                        triggerWidthPx = it.size.width
                        triggerHeightPx = it.size.height
                    }.clip(shapes.md)
                    .border(
                        width = TriggerBorderWidth,
                        color = if (open) colors.primary else colors.border,
                        shape = shapes.md,
                    ).background(colors.bgBase)
                    .clickable { open = !open }
                    .padding(horizontal = TriggerHorizontal, vertical = TriggerVertical),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    if (selected != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(LeadingGap),
                        ) {
                            selected.leading?.invoke()
                            Text(
                                text = selected.label,
                                style = typography.body,
                                color = colors.textPrimary,
                            )
                        }
                    } else {
                        Text(
                            text = placeholder,
                            style = typography.body,
                            color = colors.textMuted,
                        )
                    }
                }
                KycIcon(
                    imageVector = OthentoIcons.ChevronDown,
                    contentDescription = null,
                    sizeDp = ChevronSize,
                    tint = colors.textSecondary,
                    modifier = Modifier.rotate(chevronRotation),
                )
            }
        }
        if (open && triggerWidthPx > 0) {
            // Popup floats above the screen content so a long country list
            // can scroll inside the menu without pushing the rest of the
            // page off-screen. The offset positions the popup just below
            // the trigger; the menu width matches the trigger.
            val triggerWidthDp = with(density) { triggerWidthPx.toDp() }
            val offsetY = triggerHeightPx + with(density) { MenuTopGap.toPx().toInt() }
            Popup(
                offset = IntOffset(0, offsetY),
                onDismissRequest = { open = false },
                properties =
                    PopupProperties(
                        focusable = true,
                        dismissOnBackPress = true,
                        dismissOnClickOutside = true,
                    ),
            ) {
                DropdownMenu(
                    options = options,
                    selectedId = selectedId,
                    width = triggerWidthDp,
                    onSelect = {
                        open = false
                        onSelect(it)
                    },
                )
            }
        }
    }
}

@Composable
private fun DropdownMenu(
    options: List<KycDropdownOption>,
    selectedId: String?,
    width: Dp,
    onSelect: (String) -> Unit,
) {
    val colors = LocalOthentoColors.current
    val shapes = LocalOthentoShapes.current
    val typography = LocalOthentoTypography.current
    Box(
        modifier =
            Modifier
                .width(width)
                .shadow(elevation = MenuElevation, shape = shapes.md)
                .clip(shapes.md)
                .background(colors.bgBase)
                .border(width = TriggerBorderWidth, color = colors.border, shape = shapes.md)
                .heightIn(max = MenuMaxHeight),
    ) {
        LazyColumn(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(MenuPadding),
        ) {
            items(items = options, key = { it.id }) { option ->
                val selected = option.id == selectedId
                Row(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(OptionRadius))
                            .background(if (selected) colors.primaryBg else Color.Transparent)
                            .clickable { onSelect(option.id) }
                            .padding(horizontal = OptionHorizontal, vertical = OptionVertical),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(LeadingGap),
                ) {
                    option.leading?.invoke()
                    Text(
                        text = option.label,
                        style = typography.body,
                        color = if (selected) colors.primary else colors.textPrimary,
                        modifier = Modifier.weight(1f),
                    )
                    if (selected) {
                        KycIcon(
                            imageVector = OthentoIcons.Check,
                            contentDescription = null,
                            sizeDp = CheckSize,
                            tint = colors.primary,
                        )
                    }
                }
            }
        }
    }
}

private val TriggerHorizontal = 14.dp
private val TriggerVertical = 12.dp
private val TriggerBorderWidth: Dp = 1.5.dp
private val LeadingGap = 10.dp
private val ChevronSize = 16.dp
private val MenuTopGap = 4.dp
private val MenuMaxHeight = 280.dp
private val MenuPadding = 4.dp
private val MenuElevation = 12.dp
private val OptionRadius = 6.dp
private val OptionHorizontal = 12.dp
private val OptionVertical = 10.dp
private val CheckSize = 16.dp
