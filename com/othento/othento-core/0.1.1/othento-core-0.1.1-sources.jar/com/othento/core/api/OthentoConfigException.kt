package com.othento.core.api

/**
 * Thrown by [OthentoConfig.Builder.build] when the supplied configuration is
 * incomplete or malformed. Synchronous by design — config errors are
 * programmer mistakes and the cross-platform contract requires them to
 * fail fast at construction, not via [OthentoSDKListener.onError].
 */
public class OthentoConfigException(
    public val error: OthentoError,
    message: String,
) : RuntimeException(message)
