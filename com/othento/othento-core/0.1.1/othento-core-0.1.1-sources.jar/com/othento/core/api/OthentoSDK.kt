package com.othento.core.api

import android.app.Activity
import android.content.Intent
import com.othento.core.internal.OthentoActivity
import com.othento.core.internal.SdkBus
import java.util.UUID

/**
 * Public, imperative entry point for the Othento SDK.
 *
 * The host constructs an `OthentoSDK` with a built [OthentoConfig] + an
 * [OthentoSDKListener], then calls [start] to take over the foreground until a
 * terminal status, an error, or a cancel is reported back through the
 * listener. [destroy] tears the flow down on demand and fires
 * [OthentoSDKListener.onCancelled] with [OthentoCancelReason.HostDestroy] when
 * called before a terminal event.
 *
 * Lifecycle (mirrors the cross-platform contract):
 * - [start] may be called at most once per instance.
 * - Exactly one of [OthentoSDKListener.onCompleted] /
 *   [OthentoSDKListener.onCancelled] / [OthentoSDKListener.onError] fires per
 *   session.
 * - [destroy] is a safe no-op after a terminal event.
 *
 * Only one instance may run at a time. Calling [start] while another
 * instance is still running throws [OthentoConfigException] with
 * [OthentoError.ConfigInvalid].
 *
 * Listener callbacks are dispatched on the Android main thread, asynchronously
 * (the SDK never calls a listener method synchronously inside [start]).
 */
public class OthentoSDK(
    private val activity: Activity,
    private val config: OthentoConfig,
    private val listener: OthentoSDKListener,
) {
    private val token: String = UUID.randomUUID().toString()

    @Volatile
    private var started: Boolean = false

    @Volatile
    private var terminated: Boolean = false

    /**
     * Begins the verification flow. Throws [OthentoConfigException] when
     * called twice on the same instance, or when another `OthentoSDK`
     * instance is already running. Both failures carry
     * [OthentoError.ConfigInvalid] so the host needs only one catch.
     *
     * The single-instance slot is released as soon as a terminal listener
     * event fires, so launching a fresh `OthentoSDK` from inside `onError` /
     * `onCompleted` is supported.
     */
    public fun start() {
        if (started) {
            throw OthentoConfigException(
                OthentoError.ConfigInvalid(START_TWICE_MESSAGE),
                START_TWICE_MESSAGE,
            )
        }
        if (terminated) return
        val fixture = pendingFixture.also { pendingFixture = null }
        if (!SdkBus.tryStart(token = token, config = config, listener = listener, fixture = fixture)) {
            throw OthentoConfigException(
                OthentoError.ConfigInvalid(ANOTHER_INSTANCE_RUNNING_MESSAGE),
                ANOTHER_INSTANCE_RUNNING_MESSAGE,
            )
        }
        started = true
        val intent = Intent(activity, OthentoActivity::class.java).putExtra(SdkBus.EXTRA_TOKEN, token)
        activity.startActivity(intent)
    }

    /**
     * Tears the SDK down. If called before a terminal event the listener
     * receives `onCancelled(HostDestroy)`; if called after, this is a safe
     * no-op.
     */
    public fun destroy() {
        if (terminated) return
        terminated = true
        if (started) {
            SdkBus.signalCancel(token, OthentoCancelReason.HostDestroy)
        }
    }

    public companion object {
        @Volatile
        private var pendingFixture: OthentoFixtureScenario? = null

        private const val ANOTHER_INSTANCE_RUNNING_MESSAGE =
            "Another OthentoSDK instance is already running. Call destroy() on it first."

        private const val START_TWICE_MESSAGE =
            "OthentoSDK.start() called twice on the same instance."

        /**
         * Convenience helper: constructs an `OthentoSDK` and calls [start] in
         * one go. Equivalent to `OthentoSDK(activity, config, listener).start()`.
         */
        public fun launch(
            activity: Activity,
            config: OthentoConfig,
            listener: OthentoSDKListener,
        ): OthentoSDK =
            OthentoSDK(activity, config, listener).also { it.start() }

        /**
         * Test-only hook that selects which fixture scenario the next [start]
         * call should resolve to. `internal`, so it is **not** part of the
         * published public API — production hosts cannot reach it. Consumed by
         * the next launch and reset to `null` afterwards so it cannot leak
         * across launches. Used by the SDK's own unit/snapshot tests.
         */
        internal fun setFixtureScenario(scenario: OthentoFixtureScenario) {
            pendingFixture = scenario
        }

        /** Clears any prior [setFixtureScenario] selection. `internal` — test-only. */
        internal fun clearFixtureScenario() {
            pendingFixture = null
        }
    }
}
