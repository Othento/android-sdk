package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass

/**
 * Wire shape for an entry in the documents-list response.
 *
 * Mirrors [docs/spec/09-data-models.md §2.4]. Used by the document-select
 * screen in Phase 5; defined now so DTO+mapper layers don't need a Phase-5
 * patch.
 */
@JsonClass(generateAdapter = true)
internal data class AcceptedDocumentDto(
    val documentId: String,
    val countryCode: String? = null,
    val countryName: String,
    val countryIcon: String,
    val typeName: String,
    val widthMm: Double?,
    val heightMm: Double?,
    val requireBothSides: Boolean,
)
