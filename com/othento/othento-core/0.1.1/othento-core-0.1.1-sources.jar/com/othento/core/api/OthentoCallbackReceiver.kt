package com.othento.core.api

/**
 * Selects which registered backend webhook the Othento platform invokes when
 * a session reaches a terminal state.
 *
 * Mirrors `CallbackReceiver` from the web SDK contract
 * (docs/spec/02-public-api.md §1, session.model.ts:149). Forwarded into the
 * session-create request body and never invoked client-side.
 */
public enum class OthentoCallbackReceiver {
    Initiator,
    Completer,
    Both,
}
