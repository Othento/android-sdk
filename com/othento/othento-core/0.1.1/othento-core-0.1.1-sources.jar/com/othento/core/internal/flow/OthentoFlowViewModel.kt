package com.othento.core.internal.flow

import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.othento.core.internal.capture.detection.DocKind
import com.othento.core.internal.capture.detection.SmartCropperStaticDetector
import com.othento.core.internal.capture.detection.StaticDocumentValidator
import com.othento.core.internal.capture.detection.docKind
import com.othento.core.internal.data.SessionRepositoryFactory
import com.othento.core.internal.fixtures.FixtureSessionSource
import com.othento.core.internal.ui.screens.Side
import com.othento.core.internal.util.ImageInfo
import com.othento.core.internal.util.UriBitmapDecoder
import com.othento.core.api.OthentoCancelReason
import com.othento.core.api.OthentoConfig
import com.othento.core.api.OthentoFixtureScenario
import com.othento.core.api.OthentoSDKListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Component-scoped ViewModel that wires a [FlowCoordinator] into the
 * Activity's lifecycle ([docs/spec/08-state-management.md] §1.2).
 *
 * Survives configuration changes — the coordinator's resolve / upload /
 * polling work runs on `viewModelScope` so cancellation flows through on
 * Activity finish but **not** on rotation.
 *
 * Phase 5 changes:
 * - The factory accepts a [ContentResolver] so the upload pipeline can
 *   stream from a `Uri`.
 * - When [Factory.fixture] is `null`, the factory builds a
 *   [RepositorySessionSource] (real network) instead of a fixture-driven
 *   one. The fixture path remains as a regression hook (R1).
 * - The ViewModel owns Job tracking for upload + polling so the user's
 *   "back press" + "poll retry" cancel cleanly without races.
 */
@Suppress(
    "TooManyFunctions",
    // Reason: each public action method (begin, retry, country, doc, confirm,
    // change, retake, poll-retry, file, cancel) is a single line that
    // delegates to the coordinator. Splitting them up to satisfy the threshold
    // would obscure the 1:1 mapping the Compose host depends on.
)
internal class OthentoFlowViewModel(
    private val coordinator: FlowCoordinator,
    private val contentResolver: ContentResolver,
    private val staticDocumentValidator: StaticDocumentValidator,
    // OthentoConfig.closeOnComplete — when true the host wants the SDK to
    // auto-dismiss on any terminal screen rather than leaving it up. Read by
    // OthentoFlowHost; the listener's terminal event still fires first.
    val closeOnComplete: Boolean = false,
) : ViewModel() {
    val state: StateFlow<FlowUiState> = coordinator.state

    private var inflightJob: Job? = null
    private var validationJob: Job? = null

    init {
        // Tracking the resolve job lets `onUserCancel` actively cancel an
        // in-flight `createSession` round-trip rather than waiting for
        // viewModelScope to wind down on Activity finish — the latter
        // could let `applyResolved` / `applyFailure` fire listener events
        // *after* `onCancelled`, breaking the spec §16 ordering invariant.
        inflightJob = viewModelScope.launch { coordinator.resolve() }
    }

    /**
     * Cancels the running flow with the supplied [reason]. Triggered by the
     * hardware back press (`BackButton`), by `OthentoSDK.destroy()`
     * (`HostDestroy`), or by an in-flow SDK-side cancel CTA (`SdkInternal`).
     *
     * Order matters: cancel any in-flight resolve / upload / poll first,
     * then fire the coordinator's cancel which emits `onCancelled`. Without
     * the cancel-then-emit order, a network resolve completing in the same
     * millisecond as the back-press could fire `onSessionCreated` AFTER
     * `onCancelled`.
     */
    fun onUserCancel(reason: OthentoCancelReason) {
        validationJob?.cancel()
        inflightJob?.cancel()
        coordinator.cancel(reason)
    }

    fun onUserBeginVerification() {
        startInflight { coordinator.beginVerification() }
    }

    fun onUserRetryFailed() {
        startInflight { coordinator.retryFailed() }
    }

    fun onUserCountrySelected(countryName: String) = coordinator.onUserCountrySelected(countryName)

    fun onUserDocumentSelected(documentId: String) = coordinator.onUserDocumentSelected(documentId)

    fun onUserConfirmDocument() = coordinator.onUserConfirmDocument()

    fun onUserChangeDocument() = coordinator.onUserChangeDocument()

    fun onUserRetake() = coordinator.onUserRetake()

    fun onUserSwitchToFallback() = coordinator.onUserSwitchToFallback()

    fun onUserStayOnCamera() = coordinator.onUserStayOnCamera()

    fun onUserPollRetry() {
        startInflight { coordinator.pollRetry() }
    }

    // ---- Phase 9 OTP --------------------------------------------------

    fun onUserSendOtp(contact: String) {
        startInflight { coordinator.sendOtp(contact) }
    }

    fun onUserVerifyOtp(code: String) {
        startInflight { coordinator.verifyOtp(code) }
    }

    fun onUserEditOtpDestination() = coordinator.onUserEditOtpDestination()

    fun onUserCancelOtpEdit() = coordinator.onUserCancelOtpEdit()

    fun onUserDismissOtpDialog() = coordinator.onUserDismissOtpDialog()

    fun onUserOtpDialogPrimary() {
        startInflight { coordinator.onUserOtpDialogPrimary() }
    }

    fun onUserAcknowledgeOtpSkipNotice() {
        startInflight { coordinator.onUserAcknowledgeOtpSkipNotice() }
    }

    fun onUserTickOtpCooldown() = coordinator.tickOtpCooldown()

    /**
     * The Compose `CaptureFallbackScreen` calls this when the user selects a
     * media item. The ViewModel resolves the [Uri] into [ImageInfo.Resolved]
     * (size, MIME, file name) here so the coordinator stays
     * Android-Context-free and easier to test.
     *
     * Rather than uploading immediately, this sets the pending-capture slot
     * and kicks off background validation. The user then confirms or retakes
     * on the preview screen before the upload is actually initiated.
     */
    @Suppress(
        "ReturnCount",
        // Reason: three returns are the three distinct guard conditions
        // (unresolvable URI, oversized file, wrong screen state) before the
        // happy-path. Collapsing them into a single nested-if tree would hurt
        // readability. The labeled return@launch inside the coroutine is a
        // fourth exit that detekt also counts; extracting the lambda body to a
        // named function would obscure the single-file flow.
    )
    fun onUserFileCaptured(uri: Uri, isManualCapture: Boolean = false) {
        val info = ImageInfo.resolve(uri, contentResolver)
        if (info == null) {
            coordinator.onFileUnreadable()
            return
        }
        if (info.sizeBytes > ImageInfo.MAX_UPLOAD_SIZE_BYTES) {
            coordinator.onOversizedFile()
            return
        }
        if (coordinator.state.value.screenState == ScreenState.SelfieCapture ||
            info.mimeType == VIDEO_MP4_MIME
        ) {
            startInflight { coordinator.uploadAndAdvance(uri, info, isManualCapture) }
            return
        }

        val side = currentSide() ?: return
        val docKind =
            coordinator.state.value.pendingDocument
                ?.docKind() ?: DocKind.Id

        coordinator.setPendingCapture(uri, info, side, docKind, isManualCapture)

        validationJob?.cancel()
        validationJob =
            viewModelScope.launch(Dispatchers.Default) {
                val bitmap = UriBitmapDecoder.decode(uri, contentResolver)
                if (bitmap == null) {
                    // Decode failed after metadata succeeded — treat as unreadable.
                    withContext(Dispatchers.Main) {
                        coordinator.clearPendingCapture()
                        coordinator.onFileUnreadable()
                    }
                    return@launch
                }
                val result =
                    try {
                        staticDocumentValidator.validate(bitmap, docKind)
                    } finally {
                        bitmap.recycle()
                    }
                withContext(Dispatchers.Main) {
                    coordinator.updatePendingCaptureWarnings(result.warnings)
                }
            }
    }

    fun onUserConfirmCapture() {
        val pc = coordinator.state.value.pendingCapture ?: return
        validationJob?.cancel()
        coordinator.clearPendingCapture()
        startInflight { coordinator.uploadAndAdvance(pc.uri, pc.imageInfo, pc.isManualCapture) }
    }

    fun onUserRetakeCapture() {
        validationJob?.cancel()
        coordinator.clearPendingCapture()
    }

    /**
     * Launches a long-running coordinator action under [viewModelScope] and
     * cancels any prior in-flight job — guards against e.g. a user
     * double-tapping Begin during a slow document fetch, or tapping Try
     * Again on Processing while polling is still running.
     */
    private fun startInflight(block: suspend () -> Unit) {
        inflightJob?.cancel()
        inflightJob = viewModelScope.launch { block() }
    }

    private fun currentSide(): Side? =
        when (coordinator.state.value.screenState) {
            ScreenState.CaptureFront -> Side.Front
            ScreenState.CaptureBack -> Side.Back
            else -> null
        }

    companion object {
        private const val VIDEO_MP4_MIME = "video/mp4"
    }

    class Factory(
        private val config: OthentoConfig,
        private val listener: OthentoSDKListener,
        private val fixture: OthentoFixtureScenario?,
        private val contentResolver: ContentResolver,
        private val appContext: android.content.Context? = null,
    ) : androidx.lifecycle.ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            require(modelClass.isAssignableFrom(OthentoFlowViewModel::class.java)) {
                "Unknown ViewModel: ${modelClass.name}"
            }
            val stack = SessionRepositoryFactory.create(config, contentResolver, appContext)
            val sessionSource =
                if (fixture != null) {
                    FixtureSessionSource(fixture)
                } else {
                    RepositorySessionSource(stack.sessionRepository)
                }
            val coordinator =
                FlowCoordinator(
                    config = config,
                    listener = listener,
                    sessionSource = sessionSource,
                    // Main.immediate keeps listener-callback ordering deterministic
                    // (matches Phase-1's MockFlowController choice and avoids the
                    // cancel-vs-terminal race the Phase-1 code-review caught).
                    stepDispatcher = Dispatchers.Main.immediate,
                    documentRepository = stack.documentRepository,
                    uploadRepository = stack.uploadRepository,
                    pollingDriver = PollingDriver(stack.sessionRepository),
                    otpRepository = stack.otpRepository,
                    sessionRepository = stack.sessionRepository,
                )
            val staticValidator =
                StaticDocumentValidator(
                    detector = SmartCropperStaticDetector(),
                )
            return OthentoFlowViewModel(
                coordinator,
                contentResolver,
                staticValidator,
                closeOnComplete = config.closeOnComplete,
            ) as T
        }
    }
}
