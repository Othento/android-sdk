package com.othento.core.internal.data.model

/**
 * Type of evidence the active step's challenge expects from the client.
 *
 * Mirrors [docs/spec/09-data-models.md §1.6]. `Selfie` and `LivenessVideo`
 * are alternatives — whichever the backend marks `AwaitingUpload` is the
 * one the selfie/liveness uploader uses (Phase 7+).
 */
internal enum class ChallengeType {
    DocumentFront,
    DocumentBack,
    Selfie,
    LivenessVideo,
    EmailOtp,
    PhoneOtp,
}
