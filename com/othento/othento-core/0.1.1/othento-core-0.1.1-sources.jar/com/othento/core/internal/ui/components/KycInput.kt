@file:Suppress("FunctionNaming", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/** Spec §4 — `KycInputState`. */
@Immutable
internal enum class KycInputState { Default, Error, Success }

/** Spec §4 — `inputType`. */
@Immutable
internal enum class KycInputType { Text, Email, Tel, Number }

/**
 * Single-line text input. Faithful port of `apps/sdk/.../kyc-input/`:
 *
 * - 44 dp field, 14 dp horizontal padding, 1 dp `--color-border`, `--radius-md`.
 * - `:focus` paints a 3 dp **outer** halo (`box-shadow 0 0 0 3px <tone-bg>`)
 *   that bleeds beyond the field bounds — implemented via [drawBehind] at
 *   negative offsets so the halo extends past the field's clipped rect.
 * - `Error` / `Success` state shifts both the border and focus-halo colors:
 *   error → `error` border + `error-bg` halo, success → `success` + `success-bg`.
 * - Disabled: opacity 0.5, `bg-hover` background, no caret.
 * - Border + halo color transitions over `motion-fast` ease-out.
 *
 * Spec sources: `kyc-input.scss:16-71`.
 */
@Composable
@Suppress("LongParameterList", "LongMethod", "CyclomaticComplexMethod")
internal fun KycInput(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    state: KycInputState = KycInputState.Default,
    label: String? = null,
    placeholder: String = "",
    helperText: String? = null,
    errorText: String? = null,
    disabled: Boolean = false,
    inputType: KycInputType = KycInputType.Text,
) {
    val colors = LocalOthentoColors.current
    val shapes = LocalOthentoShapes.current
    val typography = LocalOthentoTypography.current
    val motion = LocalOthentoMotion.current
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    val targetBorder =
        when {
            disabled -> colors.border
            state == KycInputState.Error -> colors.error
            state == KycInputState.Success -> colors.success
            isFocused -> colors.primary
            else -> colors.border
        }
    val haloColor =
        when (state) {
            KycInputState.Error -> colors.errorBg
            KycInputState.Success -> colors.successBg
            KycInputState.Default -> colors.primaryBg
        }
    val borderColor by animateColorAsState(
        targetValue = targetBorder,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-input-border",
    )
    val haloAlpha by animateColorAsState(
        targetValue = if (isFocused && !disabled) haloColor else Color.Transparent,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-input-halo",
    )

    val backgroundColor = if (disabled) colors.bgHover else colors.bgBase
    val keyboardType =
        when (inputType) {
            KycInputType.Text -> KeyboardType.Text
            KycInputType.Email -> KeyboardType.Email
            KycInputType.Tel -> KeyboardType.Phone
            KycInputType.Number -> KeyboardType.Number
        }
    val accessibilityLabel = listOfNotNull(label, errorText.takeIf { state == KycInputState.Error }).joinToString(", ")

    Column(
        modifier =
            modifier
                .fillMaxWidth()
                .semantics(mergeDescendants = true) {
                    if (accessibilityLabel.isNotBlank()) contentDescription = accessibilityLabel
                    if (state == KycInputState.Error) liveRegion = LiveRegionMode.Polite
                },
        verticalArrangement = Arrangement.spacedBy(InputColumnGap),
    ) {
        if (!label.isNullOrBlank()) {
            Text(
                text = label,
                style = typography.inputLabel,
                color = colors.textPrimary,
            )
        }
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(InputHeight)
                    .alpha(if (disabled) DisabledAlpha else 1f)
                    .drawBehind {
                        if (haloAlpha != Color.Transparent) {
                            val r = MdRadiusDp.toPx()
                            val w = FocusGlowWidthDp.toPx()
                            drawRoundRect(
                                color = haloAlpha,
                                topLeft = Offset(-w, -w),
                                size = Size(size.width + 2f * w, size.height + 2f * w),
                                cornerRadius = CornerRadius(r + w, r + w),
                            )
                        }
                    }.clip(shapes.md)
                    .background(backgroundColor)
                    .border(width = 1.dp, color = borderColor, shape = shapes.md)
                    .padding(horizontal = InputHorizontalPadding),
            contentAlignment = Alignment.CenterStart,
        ) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                enabled = !disabled,
                singleLine = true,
                textStyle = typography.body.copy(color = colors.textPrimary),
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                cursorBrush = SolidColor(colors.primary),
                interactionSource = interactionSource,
                decorationBox = { inner ->
                    if (value.isEmpty() && placeholder.isNotEmpty()) {
                        Text(
                            text = placeholder,
                            style = typography.body,
                            color = colors.textMuted,
                        )
                    }
                    inner()
                },
            )
        }
        when {
            state == KycInputState.Error && !errorText.isNullOrBlank() ->
                Text(text = errorText, style = typography.caption, color = colors.errorText)
            !helperText.isNullOrBlank() ->
                Text(text = helperText, style = typography.caption, color = colors.textSecondary)
            else -> Unit
        }
    }
}

private val InputHeight = 44.dp
private val InputHorizontalPadding = 14.dp
private val InputColumnGap = 6.dp
private val FocusGlowWidthDp = 3.dp
private val MdRadiusDp = 8.dp
private const val DisabledAlpha = 0.5f
