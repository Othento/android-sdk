package com.othento.core.internal.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Elevation tokens per [docs/spec/04-design-system.md] §5.
 *
 * The spec defines shadows as web `box-shadow` triples (offset / blur /
 * color-with-alpha). Compose's `Modifier.shadow(elevation: Dp, …)` synthesises
 * a shadow from a single elevation value plus ambient/spot light. Phase 2
 * approximates each spec shadow with the closest Compose elevation. Pixel-exact
 * fidelity vs. the web build is not guaranteed — see open question U6.
 */
@Immutable
internal data class OthentoElevation(
    val level0: Dp = 0.dp,
    /** `0 1px 2px rgba(15,23,42,0.04)` — `kyc-card --resting`, `kyc-button --secondary`. */
    val level1: Dp = 1.dp,
    /** `0 4px 12px rgba(15,23,42,0.08)` — `kyc-card --emphasized`, CTA hover lift. */
    val level2: Dp = 4.dp,
    /** `0 12px 32px rgba(15,23,42,0.12)` — full-screen dialogs. */
    val level3: Dp = 12.dp,
    /** Primary-tinted CTA glow used by `kyc-button --primary`. */
    val cta: Dp = 4.dp,
) {
    companion object {
        val Default: OthentoElevation = OthentoElevation()
    }
}

internal val LocalOthentoElevation =
    staticCompositionLocalOf<OthentoElevation> {
        error("OthentoElevation not provided. Wrap content in OthentoTheme { … }.")
    }
