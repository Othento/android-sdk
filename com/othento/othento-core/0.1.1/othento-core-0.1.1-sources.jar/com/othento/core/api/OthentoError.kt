package com.othento.core.api

/**
 * Typed errors surfaced by the SDK.
 *
 * Cases mirror the cross-platform contract's `ErrorCode` enum — the [code]
 * string is the canonical wire identifier and is stable across web / iOS /
 * android. Subtype shape is Kotlin-idiomatic (sealed class with associated
 * data); fields like `httpStatus` / `stage` are exposed on the subclasses
 * where they make sense rather than as a uniform base.
 */
public sealed class OthentoError(
    public val code: String,
) {
    /** Required field missing or malformed (not covered by a more specific `missing_*` code). */
    public data class ConfigInvalid(
        val message: String,
    ) : OthentoError("config_invalid")

    public object MissingApiKey : OthentoError("missing_api_key")

    public object MissingWorkflow : OthentoError("missing_workflow")

    public object MissingClientData : OthentoError("missing_client_data")

    public object Cancelled : OthentoError("cancelled")

    public data class MockScenarioFailure(
        val message: String,
    ) : OthentoError("mock_scenario_failure")

    /**
     * The session id is unknown to the backend, or not accessible from this
     * device. Maps to HTTP 404. The status is always `404` by construction
     * so it isn't carried as a field.
     */
    public object SessionNotFound : OthentoError("session_not_found")

    /**
     * Network unreachable: connection refused, DNS failure, TLS error, no
     * connectivity, or a request body that failed to send.
     */
    public data class Network(
        val cause: Throwable?,
    ) : OthentoError("network")

    /**
     * A create-session call failed for a reason that is not a clean 404.
     * Wraps the underlying error code so callers can branch (e.g. retry).
     */
    public data class CreateFailed(
        val httpStatus: Int?,
        val cause: Throwable?,
    ) : OthentoError("create_failed")

    /** The documents-list call failed. */
    public data class DocumentsFailed(
        val httpStatus: Int?,
        val cause: Throwable?,
    ) : OthentoError("documents_failed")

    /** Document `initiate` call failed. */
    public data class InitiateFailed(
        val httpStatus: Int?,
        val cause: Throwable?,
    ) : OthentoError("initiate_failed")

    /**
     * Upload pipeline failed at any stage (`upload-url` GET, S3 PUT, or
     * `confirm-upload` POST). [stage] tags the failed step for telemetry.
     */
    public data class UploadFailed(
        val stage: UploadStage,
        val httpStatus: Int?,
        val cause: Throwable?,
    ) : OthentoError("upload_failed")

    /** Polling loop emitted a transport failure. */
    public data class PollFailed(
        val httpStatus: Int?,
        val cause: Throwable?,
    ) : OthentoError("poll_failed")

    /** Host picked an oversized file on the upload-fallback screen (>10 MB). */
    public object FileTooLarge : OthentoError("file_too_large")

    public data class Unknown(
        val message: String,
    ) : OthentoError("unknown")

    /** Stage of the upload pipeline that triggered an [UploadFailed]. */
    public enum class UploadStage {
        UploadUrl,
        S3Put,
        ConfirmUpload,
    }
}
