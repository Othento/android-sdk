package com.othento.core.internal.util

import android.content.ContentResolver
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/**
 * Pure helper that resolves the metadata Phase 5's upload pipeline needs from
 * a [Uri] returned by `PickVisualMedia`:
 *
 * - **MIME type** for the `Content-Type` of the S3 PUT and the
 *   `confirmUpload` body.
 * - **File size** for the 10 MB cap check
 *   ([docs/spec/11-business-logic-and-validation.md] §12) and as the
 *   denominator for the [com.othento.core.internal.network.ProgressRequestBody]
 *   percent calculation.
 * - **Display name** sent verbatim to the backend in `FileName` query +
 *   `confirmUpload` body so the wire shape matches `S3UploadService`.
 *
 * Wraps `ContentResolver` calls in a tiny seam so the upload-repository tests
 * can pass a fake without faking all of `ContentResolver`.
 */
internal object ImageInfo {
    /**
     * Inspects [uri] via [resolver] and returns a [Resolved] tuple, or
     * `null` if anything's missing — callers surface an inline
     * "couldn't read file" error in that case (rare; the picker generally
     * produces well-formed `content://` URIs).
     *
     * Default file name is "upload.jpg" if the resolver returns no display
     * name; the dev backend ignores the filename's extension as long as the
     * `Content-Type` matches.
     */
    @Suppress("ReturnCount") // Three early-outs (no MIME / cursor null / size missing); each is a real null-check.
    fun resolve(
        uri: Uri,
        resolver: ContentResolver,
    ): Resolved? {
        // All capture paths now return file:// URIs — JPEG stills and MP4
        // clips alike. The MP4 scratch file is produced by
        // [com.othento.core.internal.capture.video.RollingVideoRecorder.stopAndTrim]
        // and the file:// path is constructed in each capture screen before
        // being passed here. ContentResolver.getType() returns null for
        // plain file:// URIs and the OpenableColumns query returns no rows —
        // so the picker-oriented path below silently fails. Fall through to
        // a File-API resolve and pick the MIME from the extension.
        if (uri.scheme == ContentResolver.SCHEME_FILE) {
            val path = uri.path ?: return null
            val file = File(path)
            if (!file.isFile) return null
            return Resolved(
                mimeType = mimeFromExtension(file.name),
                fileName = file.name.ifBlank { DEFAULT_DISPLAY_NAME },
                sizeBytes = file.length(),
            )
        }

        val mime = resolver.getType(uri) ?: return null
        var displayName = DEFAULT_DISPLAY_NAME
        var size: Long? = null
        val cursor: Cursor? =
            resolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null,
            )
        cursor?.use { c ->
            if (c.moveToFirst()) {
                val nameIndex = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0 && !c.isNull(nameIndex)) {
                    displayName = c.getString(nameIndex) ?: DEFAULT_DISPLAY_NAME
                }
                val sizeIndex = c.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex >= 0 && !c.isNull(sizeIndex)) {
                    size = c.getLong(sizeIndex)
                }
            }
        }
        val resolvedSize = size ?: return null
        return Resolved(mimeType = mime, fileName = displayName, sizeBytes = resolvedSize)
    }

    /** Resolved metadata for an upload candidate. */
    data class Resolved(
        val mimeType: String,
        val fileName: String,
        val sizeBytes: Long,
    )

    /** Hard cap from spec [11-business-logic-and-validation.md] §12. */
    const val MAX_UPLOAD_SIZE_BYTES: Long = 10L * 1024L * 1024L

    private const val DEFAULT_DISPLAY_NAME: String = "upload.jpg"

    private const val CAMERA_JPEG_MIME: String = "image/jpeg"
    private const val LIVENESS_MP4_MIME: String = "video/mp4"

    private fun mimeFromExtension(fileName: String): String {
        val ext = fileName.substringAfterLast('.', missingDelimiterValue = "").lowercase()
        return when (ext) {
            "mp4", "m4v" -> LIVENESS_MP4_MIME
            else -> CAMERA_JPEG_MIME
        }
    }
}
