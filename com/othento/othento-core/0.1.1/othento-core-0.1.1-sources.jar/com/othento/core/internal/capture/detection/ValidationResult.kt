@file:Suppress(
    "MaxLineLength",
    // Reason: User-facing warning messages are intentionally verbatim from the web SDK
    // (document-validation.service.ts::WARNING_MESSAGES) for cross-platform UX parity.
)

package com.othento.core.internal.capture.detection

import com.othento.core.internal.data.model.AcceptedDocument

/**
 * On-device validation issue catalogue. Mirrors the web SDK's
 * `document-validation.service.ts` ValidationIssue type.
 */
internal enum class ValidationIssue {
    TooDark,
    TooBright,
    Blurry,
    Glare,
    NoCard,
}

/** Doc-type discriminator for the static validator. */
internal enum class DocKind {
    Id,
    Passport,
}

internal data class ValidationWarning(
    val issue: ValidationIssue,
    val message: String,
)

internal data class ValidationResult(
    val valid: Boolean,
    val issues: List<ValidationIssue>,
    val warnings: List<ValidationWarning>,
) {
    companion object {
        val Clean: ValidationResult = ValidationResult(valid = true, issues = emptyList(), warnings = emptyList())
    }
}

/**
 * User-facing warning copy — verbatim from the web SDK's WARNING_MESSAGES.
 */
internal object ValidationMessages {
    fun forIssue(issue: ValidationIssue): String =
        when (issue) {
            ValidationIssue.TooDark ->
                "The image appears too dark. Please verify it is readable before continuing."
            ValidationIssue.TooBright ->
                "The image appears too bright. Please verify it is readable before continuing."
            ValidationIssue.Blurry ->
                "The image appears blurry. Please verify it is readable before continuing."
            ValidationIssue.Glare ->
                "Glare was detected on the document. Please verify all details are readable before continuing."
            ValidationIssue.NoCard ->
                "No document detected in this capture. Please retake ensuring the full document is clearly visible in the frame."
        }
}

/**
 * Same heuristic as the web SDK's `upload-sheet.ts::isPassport` — case-insensitive
 * substring check on the document's typeName.
 */
internal fun AcceptedDocument.docKind(): DocKind = if (typeName.contains("passport", ignoreCase = true)) DocKind.Passport else DocKind.Id
