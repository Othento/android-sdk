package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass

/**
 * Wire shape of the backend's retry metadata, nested under
 * [TokenSessionResponseDto.reinitInfo] on a `Failed` + `canReinitiate`
 * response. Mirrors the web SDK's `ReinitInfo` interface.
 *
 * [stepsToRetry] defaults to empty and [failureReason] to null so a partial
 * payload (or a backend that omits a field) parses cleanly — matching the
 * defensive defaults already used for [TokenSessionResponseDto.steps].
 */
@JsonClass(generateAdapter = true)
internal data class ReinitInfoDto(
    val attemptsRemaining: Int,
    val failureReason: String? = null,
    val stepsToRetry: List<ReinitStepDto> = emptyList(),
)

/**
 * Wire shape of a single [ReinitInfoDto.stepsToRetry] entry — the web's
 * `Pick<Step, 'stepCode' | 'stepName' | 'order'>`. `order` is nullable
 * because the dev backend omits it on some step rows (see [StepDto]).
 */
@JsonClass(generateAdapter = true)
internal data class ReinitStepDto(
    val stepCode: String,
    val stepName: String,
    val order: Int? = null,
)
