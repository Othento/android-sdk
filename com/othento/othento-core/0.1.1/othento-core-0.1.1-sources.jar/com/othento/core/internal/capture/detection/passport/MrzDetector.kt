package com.othento.core.internal.capture.detection.passport

import android.graphics.Rect
import android.graphics.RectF
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.othento.core.internal.capture.CaptureConfig
import com.othento.core.internal.capture.detection.smartcropper.YuvToBitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

/**
 * MRZ band detector. Runs ML Kit Text Recognition (Latin script v2) at a
 * throttled cadence (driven by [FrameAnalyzer]); scans every detected line
 * against [MrzMatcher].
 *
 * Single-flight: while one recognition is in flight, [schedule] is a no-op.
 * Result is cached in [snapshot] so [DetectionPipeline] can read it on its
 * next tick without blocking.
 */
internal class MrzDetector {
    private val recognizer: TextRecognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val running = AtomicBoolean(false)

    /** Coherent (timestamp, framing) pair so [snapshot] reads both with a
     *  single volatile read — avoids a torn read pairing a fresh match time
     *  with a stale framing. */
    private data class MatchState(val matchAtMs: Long, val framing: MrzFraming)

    /**
     * Wall-clock timestamp of the most recent successful match, or 0 if no
     * match has ever been seen. [snapshot] returns matched=true while
     * `now - matchState.matchAtMs < MATCH_GRACE_MS` — a rolling-window smoother
     * over the inherently noisy ML Kit OCR. Recognition can flicker
     * frame-to-frame on a static scene (autofocus, auto-exposure, JPEG
     * round-trip jitter all change the bitmap enough to flip OCR
     * confidence), so a single failed scan after a successful one
     * shouldn't kick the pipeline out of the MRZ gate. The window is
     * generous enough to span the polygon-stability counter (~500ms at
     * 10 fps) plus reasonable settle time.
     */
    @Volatile
    private var matchState: MatchState = MatchState(0L, MrzFraming.Ok)

    /**
     * Per-scan diagnostic surface for the debug overlay. Format (single line,
     * compact):
     *   `ocr=N | L=<len> c=<chev> '<preview>' | ...`
     *
     * Where `ocr` is total raw OCR-line count from ML Kit, then for the top
     * three cleaned lines (longest first, after stripping anything outside
     * `[A-Z0-9<]`) we report length, chevron count, and a truncated preview
     * of the cleaned content. `(failed)` on ML Kit failure, `(empty)` if no
     * text was recognized.
     */
    private val _debugInfo = MutableStateFlow("(no scan yet)")
    val debugInfo: StateFlow<String> = _debugInfo.asStateFlow()

    data class Snapshot(
        val matched: Boolean = false,
        val framing: MrzFraming = MrzFraming.Ok,
    )

    fun schedule(image: ImageProxy, cutoutFraction: RectF) {
        if (running.getAndSet(true)) return
        // Convert YUV → ARGB Bitmap synchronously. The bitmap is independent of the
        // ImageProxy's underlying buffer — it survives the analyzer's image.close()
        // call. ML Kit's async task can safely read from the bitmap after the proxy
        // is closed.
        //
        // Note the explicit OCR_MAX_DIMENSION = 2048 here: the default 1024 cap
        // (set for SmartCropper safety) downsamples a 1920×1080 sensor frame to
        // 960×540 before OCR — at that size MRZ characters are ~6px tall, below
        // ML Kit Latin v2's reliable threshold. 2048 keeps the frame at native
        // resolution where the band is ~12-15px tall and recognition is
        // dramatically more reliable.
        val bitmap = YuvToBitmap.convert(image, cutoutInImageCoords = null, maxDimension = OCR_MAX_DIMENSION)
        if (bitmap == null) {
            running.set(false)
            return
        }
        val rotation = image.imageInfo.rotationDegrees
        val input = InputImage.fromBitmap(bitmap, rotation)
        recognizer
            .process(input)
            .addOnSuccessListener { txt ->
                // ML Kit groups text into TextBlocks → Lines. Three independent
                // signals to detect MRZ — any one matching opens the gate:
                //   - chevronCount    (matches when OCR reads `<` correctly)
                //   - longestRun      (matches when OCR misreads `<` as a
                //                      single substitute char like `K` / `c`)
                //   - matchesLayout   (matches by line bounding-box aspect
                //                      ratio — character-content-independent;
                //                      catches the band as long as ML Kit
                //                      recognises it as text at all)
                // For chevron / run we feed BOTH per-line and per-block-concat
                // candidates — per-line catches the normal case; per-block-
                // concat catches the case where ML Kit fragments one 44-char
                // MRZ line into multiple internal Lines within the same Block.
                val mlLines = txt.textBlocks.flatMap { b -> b.lines }
                val perLine = mlLines.map { it.text }
                val perBlock = txt.textBlocks.map { b -> b.lines.joinToString(" ") { it.text } }
                val candidates = (perLine + perBlock).distinct()
                val lineBounds = mlLines.mapNotNull { it.boundingBox }

                val matched =
                    MrzMatcher.matches(candidates) || MrzMatcher.matchesLayout(lineBounds)
                if (matched) {
                    matchState = MatchState(
                        matchAtMs = System.currentTimeMillis(),
                        framing = computeFraming(lineBounds, cutoutFraction, rotation, bitmap.width, bitmap.height),
                    )
                }
                // Debug overlay shows the latest classified framing even when the
                // matched grace window has lapsed (snapshot() resolves to Ok then).
                val debugState = matchState
                _debugInfo.value =
                    formatDebug(candidates, txt.textBlocks.size, lineBounds, debugState.matchAtMs) +
                        " frm=${debugState.framing}"
            }.addOnFailureListener { e ->
                _debugInfo.value = "(failed: ${e.javaClass.simpleName})"
            }.addOnCompleteListener {
                bitmap.recycle()
                running.set(false)
            }
    }

    /**
     * Classify passport framing from the MRZ line boxes. ML Kit returns boxes
     * in *upright* coords — for 90°/270° the upright width is the bitmap's
     * height (same rule [PassportPhotoGate] uses). Normalizes the union MRZ
     * extent to image fractions and compares it to the cutout fractions.
     * The cutout fractions are view-normalized (relative to the preview viewport)
     * while the MRZ extent is normalized by the bitmap's upright width; CameraX
     * keeps the preview and analysis upright aspect ratios consistent, so the
     * X-axis fractions share one space.
     */
    private fun computeFraming(
        lineBounds: List<Rect>,
        cutoutFraction: RectF,
        rotation: Int,
        bitmapWidth: Int,
        bitmapHeight: Int,
    ): MrzFraming {
        if (cutoutFraction.isEmpty) return MrzFraming.Ok
        val rotatedToUpright = rotation == QUARTER_TURN_DEG || rotation == THREE_QUARTER_TURN_DEG
        val uprightWidth = if (rotatedToUpright) bitmapHeight else bitmapWidth
        if (uprightWidth <= 0) return MrzFraming.Ok
        val lines = lineBounds.map { MrzLineBox(it.left, it.right, it.height()) }
        val extent = mrzExtentPx(lines, CaptureConfig.MRZ_EXTENT_MIN_ASPECT) ?: return MrzFraming.Ok
        val mrzLeftFrac = extent.first.toFloat() / uprightWidth
        val mrzRightFrac = extent.second.toFloat() / uprightWidth
        return classifyMrzFraming(
            mrzLeftFrac = mrzLeftFrac,
            mrzRightFrac = mrzRightFrac,
            cutoutLeftFrac = cutoutFraction.left,
            cutoutRightFrac = cutoutFraction.right,
            sideMarginMin = CaptureConfig.MRZ_SIDE_MARGIN_MIN,
            minWidthCoverage = CaptureConfig.MIN_MRZ_WIDTH_COVERAGE,
        )
    }

    fun snapshot(): Snapshot {
        val state = matchState
        val ageMs = System.currentTimeMillis() - state.matchAtMs
        val matched = state.matchAtMs > 0L && ageMs < MATCH_GRACE_MS
        return Snapshot(matched = matched, framing = if (matched) state.framing else MrzFraming.Ok)
    }

    fun release() {
        recognizer.close()
    }

    private companion object {
        private const val PREVIEW_LEN = 12
        private const val TOP_LINES = 3
        private const val QUARTER_TURN_DEG: Int = 90
        private const val THREE_QUARTER_TURN_DEG: Int = 270

        /** Rolling window: a successful scan keeps the gate open for this long even if subsequent scans drop it. */
        private const val MATCH_GRACE_MS = 3_000L

        /** Native sensor dimension for OCR — keeps the MRZ band at full resolution for ML Kit. */
        private const val OCR_MAX_DIMENSION = 2_048

        /** Conversion factor from milliseconds to seconds for the debug-string formatter. */
        private const val MS_PER_SECOND: Double = 1_000.0

        private val MRZ_CHARSET: Set<Char> = (('A'..'Z') + ('0'..'9')).toSet() + '<'

        fun formatDebug(
            candidates: List<String>,
            blockCount: Int,
            lineBounds: List<Rect>,
            matchAtMs: Long,
        ): String {
            val matchTag =
                if (matchAtMs == 0L) {
                    "—"
                } else {
                    val ageS = (System.currentTimeMillis() - matchAtMs) / MS_PER_SECOND
                    val graceS = MATCH_GRACE_MS / MS_PER_SECOND
                    if (ageS < graceS) "✓${"%.1f".format(ageS)}s" else "${"%.1f".format(ageS)}s"
                }
            val maxAspect = MrzMatcher.longestLineAspect(lineBounds)
            val aspTag = "asp=${"%.1f".format(maxAspect)}"
            if (candidates.isEmpty()) return "match=$matchTag $aspTag ocr=0 (empty)"
            val totalChev = MrzMatcher.chevronCount(candidates)
            val maxRun = MrzMatcher.longestRun(candidates)
            val cleaned =
                candidates
                    .map { it.uppercase().filter { c -> c in MRZ_CHARSET } }
                    .filter { it.isNotEmpty() }
                    .sortedByDescending { it.length }
                    .take(TOP_LINES)
            return buildString {
                append("match=$matchTag blk=$blockCount chev=$totalChev run=$maxRun $aspTag")
                cleaned.forEach { line ->
                    val chev = line.count { it == '<' }
                    val preview = line.take(PREVIEW_LEN)
                    append(" | L=${line.length} c=$chev '$preview'")
                }
            }
        }
    }
}

/**
 * "MRZ-like text present" matcher. The mobile SDK's job is to *trigger
 * auto-capture* — the captured JPEG goes to the backend for authoritative
 * ICAO parsing and check-digit verification. We only need a "this looks like
 * a passport" signal, which is much more permissive.
 *
 * Three independent signals, OR-combined — any one matching opens the gate:
 *
 *   1. **Chevron count ≥ [MIN_CHEVRONS]** ([chevronCount]). Real MRZ carries
 *      ≥ 20 chevrons (TD3 ≈ 28–60, TD2 ≈ 20–30, TD1 ≈ 33–45). Catches the
 *      case where ML Kit reads `<` correctly — or as `«` (the most common
 *      misread of `<<` against the OCR-B font).
 *
 *   2. **Longest char-repetition run ≥ [MIN_RUN]** ([longestRun]). Catches
 *      the case where ML Kit consistently misreads `<` as some other single
 *      character (typically `K`, `c`, `^`, `(`). The chevron count drops to
 *      near zero in that case, but the *run length* of whatever character it
 *      substitutes is preserved — a line of 14 trailing `<` becomes 14
 *      trailing `K`, and 14-in-a-row of any character is essentially never
 *      seen in printed Latin text.
 *
 *   3. **Line bounding-box aspect ratio ≥ [MIN_LINE_ASPECT]** ([matchesLayout]).
 *      Character-content-independent: triggers whenever ML Kit recognises
 *      the band as text *at all*, regardless of what characters it thinks
 *      are in it. A real MRZ row is 30–44 monospace characters wide by ~1
 *      character tall, giving bounding-box aspect ratios of 30:1 to 50:1.
 *      Normal printed passport text (printed name, DOB, labels) is set in a
 *      larger font and rarely exceeds 15:1 even for long lines, so the MRZ
 *      band's extreme aspect ratio is essentially unique to it. This is
 *      the strongest signal because it survives any character misread.
 *
 * Why not strict TD1/TD2/TD3 line-length validation: ML Kit Latin v2 is
 * reliable at *finding* text but imperfect at preserving OCR-B's exact
 * char-boundaries — line lengths drift, clusters split, punctuation gets
 * inserted. Strict checks reject most real captures while loose-pattern
 * detection has near-zero false-positive risk against normal documents
 * (printed Latin text essentially never contains chevrons or 6+ repeated
 * characters or 25:1-aspect lines).
 */
internal object MrzMatcher {
    fun matches(lines: List<String>): Boolean = chevronCount(lines) >= MIN_CHEVRONS || longestRun(lines) >= MIN_RUN

    /** Layout-only check (signal #3). Pass `true` if any OCR line is MRZ-aspect-ratio long. */
    fun matchesLayout(bounds: List<Rect>): Boolean = longestLineAspect(bounds) >= MIN_LINE_ASPECT

    /** Total chevron-or-guillemet count across all OCR lines. Surfaced for the debug overlay. */
    fun chevronCount(lines: List<String>): Int = lines.sumOf { line -> line.count { it == '<' || it == '«' } }

    /**
     * Longest run of identical alphanumeric / chevron characters across all
     * input lines. Whitespace and punctuation are stripped first so that
     * spaces interpolated by ML Kit between MRZ chars don't break the run.
     */
    fun longestRun(lines: List<String>): Int = lines.maxOfOrNull { longestRunInLine(it) } ?: 0

    /** Largest aspect ratio (long/short side) across all line bounding boxes. */
    fun longestLineAspect(bounds: List<Rect>): Float = bounds.maxOfOrNull { lineAspect(it) } ?: 0f

    private fun lineAspect(rect: Rect): Float {
        val w = rect.width()
        val h = rect.height()
        if (w <= 0 || h <= 0) return 0f
        return max(w, h).toFloat() / min(w, h).toFloat()
    }

    private fun longestRunInLine(line: String): Int {
        val cleaned = line.uppercase().filter { it.isLetterOrDigit() || it == '<' || it == '«' }
        if (cleaned.isEmpty()) return 0
        var maxRun = 1
        var current = 1
        for (i in 1 until cleaned.length) {
            if (cleaned[i] == cleaned[i - 1]) {
                current++
                if (current > maxRun) maxRun = current
            } else {
                current = 1
            }
        }
        return maxRun
    }

    private const val MIN_CHEVRONS: Int = 6
    private const val MIN_RUN: Int = 6
    private const val MIN_LINE_ASPECT: Float = 25f
}
