@file:Suppress("ReturnCount")

package com.othento.core.internal.capture.detection

import android.graphics.Bitmap
import android.graphics.PointF
import com.othento.core.internal.capture.detection.smartcropper.PolygonGeometry
import me.pqpo.smartcropperlib.SmartCropper

/**
 * SmartCropper-backed static detector. Mirrors the corner-handling rules
 * from [com.othento.core.internal.capture.detection.smartcropper.SmartCropperDocumentDetector]:
 *
 * - SmartCropper returns `Point[4]` with potentially-null elements when it
 *   can't find a confident quad. Filter nulls.
 * - Quads with < 4 valid corners are treated as no-detection.
 * - Degenerate quads (near-zero area) are rejected.
 *
 * Caller is responsible for calling [SmartCropper.buildImageDetector] once
 * per process before this impl is constructed.
 */
internal class SmartCropperStaticDetector : StaticDocumentDetector {
    override fun scan(bitmap: Bitmap): List<PointF>? {
        val raw = runCatching { SmartCropper.scan(bitmap) }.getOrNull() ?: return null

        @Suppress("UNCHECKED_CAST")
        val nonNull = (raw as Array<android.graphics.Point?>).filterNotNull()
        if (nonNull.size != EXPECTED_CORNER_COUNT) return null
        val points = nonNull.map { PointF(it.x.toFloat(), it.y.toFloat()) }
        return if (PolygonGeometry.isDegenerate(points)) null else points
    }

    private companion object {
        /** Expected number of corner points returned by SmartCropper.scan. */
        const val EXPECTED_CORNER_COUNT: Int = 4
    }
}
