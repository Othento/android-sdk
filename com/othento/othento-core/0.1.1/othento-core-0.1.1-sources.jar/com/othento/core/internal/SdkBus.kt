package com.othento.core.internal

import android.os.Handler
import android.os.Looper
import com.othento.core.api.OthentoCancelReason
import com.othento.core.api.OthentoConfig
import com.othento.core.api.OthentoFixtureScenario
import com.othento.core.api.OthentoSDKListener
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference

/**
 * Per-launch hand-off between [com.othento.core.api.OthentoSDK] and
 * [OthentoActivity], plus the single-instance guard for the SDK.
 *
 * Activities can't carry function references through Intent extras, so each
 * [com.othento.core.api.OthentoSDK.start] call mints a token, registers
 * the payload here under that token, and puts the token on the launching
 * intent. [tryStart] additionally claims the (process-wide) single
 * running-instance slot atomically — concurrent starts cannot both succeed.
 *
 * Three independent concerns:
 * 1. **Slot reservation** — at most one running instance at a time. The
 *    slot is released either by [markTerminated] (after a terminal listener
 *    event fires, so the host can immediately launch a fresh instance from
 *    its own callback) or by [remove] (Activity teardown).
 * 2. **Cancel routing** — `destroy()` calls [signalCancel]; the bus posts
 *    the call onto the main thread and either invokes the registered
 *    canceller or queues the reason until the Activity's `onCreate`
 *    finishes setup. The queued path closes the destroy-before-onCreate
 *    race that previously caused the cancel signal to be silently lost.
 * 3. **Session payload** — the resolved config / listener / fixture, looked
 *    up by token in [OthentoActivity.onCreate].
 */
internal object SdkBus {
    const val EXTRA_TOKEN: String = "com.othento.core.LAUNCH_TOKEN"

    private val sessions = ConcurrentHashMap<String, Session>()
    private val cancellers = ConcurrentHashMap<String, (OthentoCancelReason) -> Unit>()
    private val pendingCancels = ConcurrentHashMap<String, OthentoCancelReason>()
    private val activeToken = AtomicReference<String?>(null)
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * Atomically reserves the single running-instance slot for [token] and
     * stores the session payload. Returns `false` when another instance
     * already holds the slot — caller should surface this as a config error.
     *
     * The host listener is wrapped with [TerminalAwareListener] so the slot
     * is auto-released on the first terminal event (`onCompleted` /
     * `onError` / `onCancelled`), even before the Activity's onDestroy
     * runs — that's what unblocks back-to-back launches from inside the
     * host's terminal callback.
     */
    fun tryStart(
        token: String,
        config: OthentoConfig,
        listener: OthentoSDKListener,
        fixture: OthentoFixtureScenario?,
    ): Boolean {
        if (!activeToken.compareAndSet(null, token)) return false
        sessions[token] =
            Session(
                config = config,
                listener = TerminalAwareListener(listener, token),
                fixture = fixture,
            )
        return true
    }

    fun get(token: String): Session? = sessions[token]

    /** Full teardown — Activity onDestroy. Idempotent. */
    fun remove(token: String) {
        sessions.remove(token)
        cancellers.remove(token)
        pendingCancels.remove(token)
        activeToken.compareAndSet(token, null)
    }

    /**
     * Releases the single-instance slot and the session payload, but
     * leaves the canceller installed so a late `destroy()` can still
     * route through and finish the Activity. Called from
     * [TerminalAwareListener] on terminal listener events.
     */
    fun markTerminated(token: String) {
        sessions.remove(token)
        activeToken.compareAndSet(token, null)
    }

    /**
     * Registers the Activity's per-token cancel callback. If a host
     * `destroy()` arrived before the Activity finished setup, the queued
     * reason is delivered now (posted to main).
     */
    fun registerCanceller(
        token: String,
        canceller: (OthentoCancelReason) -> Unit,
    ) {
        cancellers[token] = canceller
        val pending = pendingCancels.remove(token)
        if (pending != null) {
            mainHandler.post { canceller(pending) }
        }
    }

    fun unregisterCanceller(token: String) {
        cancellers.remove(token)
    }

    /**
     * Routes a host-issued [com.othento.core.api.OthentoSDK.destroy]
     * onto the main thread. Safe to call from any thread.
     *
     * If the Activity has already registered a canceller, it is invoked
     * on the main looper. Otherwise — Activity hasn't finished `onCreate`
     * yet — the reason is queued and replayed when `registerCanceller`
     * fires. After a terminal event has freed the bus entry, this is a
     * no-op.
     */
    fun signalCancel(
        token: String,
        reason: OthentoCancelReason,
    ) {
        mainHandler.post {
            val canceller = cancellers[token]
            when {
                canceller != null -> canceller(reason)
                sessions.containsKey(token) -> pendingCancels[token] = reason
                else -> Unit // Already terminated — nothing to cancel.
            }
        }
    }

    data class Session(
        val config: OthentoConfig,
        val listener: OthentoSDKListener,
        val fixture: OthentoFixtureScenario?,
    )
}
