package com.othento.core.internal.capture

import android.graphics.PointF

/**
 * V30 detection state machine. Drives the HUD overlay and the auto-capture
 * trigger. State transitions are managed by [DetectionPipeline].
 */
internal sealed class DetectionState {
    object Idle : DetectionState()

    /**
     * No qualifying detection in the current frame. [lastCorners] is the
     * most recent successful detection within the miss-tolerance window —
     * used so the HUD doesn't blink when a single frame drops.
     */
    data class Searching(
        val lastCorners: List<PointF>?,
    ) : DetectionState()

    /** Stable detection, [framesHeld] of [DetectionConfig.stabilityFramesRequired]. */
    data class Holding(
        val corners: List<PointF>,
        val framesHeld: Int,
    ) : DetectionState()

    /** All gates pass and the stability window is full. The screen may now fire auto-capture. */
    data class ReadyToCapture(
        val corners: List<PointF>,
    ) : DetectionState()

    /** Capture fired — pipeline has stopped emitting. */
    data class Captured(
        val corners: List<PointF>,
    ) : DetectionState()
}
