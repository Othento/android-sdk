@file:Suppress("FunctionNaming", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/** Spec §15 — `TipItem`. */
@Immutable
internal data class KycTipItem(
    val text: String,
    val detail: String? = null,
)

/** Spec §15 — `KycTipList` variant. Source: `apps/sdk/.../kyc-tip-list.scss`. */
@Immutable
internal enum class KycTipListVariant { List, Strip }

/**
 * Bullet list of "do this / avoid that" tips. Faithful port of
 * `apps/sdk/.../kyc-tip-list/`.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun KycTipList(
    items: List<KycTipItem>,
    modifier: Modifier = Modifier,
    variant: KycTipListVariant = KycTipListVariant.List,
) {
    when (variant) {
        KycTipListVariant.List -> ListVariant(items, modifier)
        KycTipListVariant.Strip -> StripVariant(items, modifier)
    }
}

@Composable
private fun ListVariant(
    items: List<KycTipItem>,
    modifier: Modifier,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (item in items) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Top,
            ) {
                // icon: margin-top: 1px per scss:22
                Box(modifier = Modifier.padding(top = 1.dp)) {
                    KycIcon(
                        imageVector = OthentoIcons.Info,
                        contentDescription = null,
                        size = KycIconSize.Sm,
                        tint = colors.textMuted,
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = item.text,
                        style = typography.caption,
                        color = colors.textSecondary,
                    )
                    item.detail?.takeIf { it.isNotBlank() }?.let { detail ->
                        Text(
                            text = detail,
                            style = typography.caption.copy(fontSize = DetailSizeSp),
                            color = colors.textMuted,
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StripVariant(
    items: List<KycTipItem>,
    modifier: Modifier,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    FlowRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        for (item in items) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier =
                        Modifier
                            .size(StripDotSize)
                            .clip(CircleShape)
                            .background(colors.primary.copy(alpha = StripDotAlpha)),
                )
                // chip text per scss:53-63: font-base (sans) / 11 / 500 / 0.1 px letter-spacing
                Text(
                    text = item.text,
                    style =
                        typography.caption.copy(
                            fontSize = StripLabelSizeSp,
                            fontWeight = FontWeight.W500,
                            letterSpacing = StripLetterSpacing,
                        ),
                    color = colors.textSecondary,
                )
            }
        }
    }
}

private val StripDotSize = 5.dp
private val StripLabelSizeSp = 11.sp
private val DetailSizeSp = 11.sp
private val StripLetterSpacing = 0.1.sp
private const val StripDotAlpha = 0.75f
