@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.othento.core.internal.ui.components.KycSandboxBanner
import com.othento.core.internal.ui.theme.LocalOthentoColors

/**
 * Equivalent of the web SDK's `SdkLayout` ([docs/spec/06-screens/20-shared.md]
 * §SdkLayout). Wraps every Phase-4 screen with:
 *
 * - the page-bg coloring (`--color-bg-layout`),
 * - the screen body (weight 1 — fills the remaining vertical space),
 * - an optional sandbox banner anchored just above the trust row,
 * - the trust footer.
 *
 * The web layout's "card" max-width / multi-shadow chrome is desktop-only —
 * Android renders edge-to-edge so the host card frame is omitted. Capture
 * screens (Phase 6+) will host themselves via an immersive variant that
 * suppresses footer + sandbox banner.
 */
@Composable
internal fun OthentoSdkScaffold(
    isSandbox: Boolean,
    brandName: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Column(
        modifier =
            modifier
                .fillMaxSize()
                .background(colors.bgLayout)
                .padding(top = statusBarPadding),
    ) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(colors.bgBase),
        ) {
            content()
        }
        if (isSandbox) {
            KycSandboxBanner(modifier = Modifier.fillMaxWidth())
        }
        OthentoTrustFooter(brandName = brandName, modifier = Modifier.fillMaxWidth())
    }
}
