@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber", "LongMethod", "LongParameterList")

package com.othento.core.internal.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.provider.Settings
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.othento.core.internal.capture.CameraReadyState
import com.othento.core.internal.capture.CameraSession
import com.othento.core.internal.capture.CaptureConfig
import com.othento.core.internal.capture.DetectionConfig
import com.othento.core.internal.capture.DetectionPipeline
import com.othento.core.internal.capture.DetectionState
import com.othento.core.internal.capture.FrameAnalyzer
import com.othento.core.internal.capture.PermissionStatus
import com.othento.core.internal.capture.detection.passport.MrzDetector
import com.othento.core.internal.capture.detection.passport.PassportPhotoGate
import com.othento.core.internal.capture.detection.smartcropper.SmartCropperDocumentDetector
import com.othento.core.internal.capture.rememberCameraPermissionState
import com.othento.core.internal.capture.video.RollingVideoRecorder
import com.othento.core.internal.capture.detection.DocKind
import com.othento.core.internal.capture.detection.SmartCropperStaticDetector
import com.othento.core.internal.capture.detection.StaticDocumentValidator
import com.othento.core.internal.capture.detection.StaticPassportValidator
import com.othento.core.internal.capture.detection.ValidationIssue
import com.othento.core.internal.capture.detection.ValidationResult
import com.othento.core.internal.capture.detection.ValidationWarning
import com.othento.core.internal.capture.detection.docKind
import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.flow.PendingCapture
import com.othento.core.internal.ui.components.BlurredCaptureBackground
import com.othento.core.internal.ui.components.CapturedVideoPreview
import com.othento.core.internal.ui.components.IntroTipCard
import com.othento.core.internal.ui.components.KycCameraUploadSheet
import com.othento.core.internal.ui.components.KycIntroSheet
import com.othento.core.internal.ui.components.PlacementGuideKind
import com.othento.core.internal.ui.components.SideKind
import com.othento.core.internal.ui.components.lastVideoFrame
import com.othento.core.internal.ui.icons.OthentoIcons
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Camera-driven capture screen for the front / back side of an ID
 * document. Spec [docs/spec/06-screens/05-capture.md] §"Layout".
 *
 * Owns the runtime side of capture: permission flow, CameraX binding,
 * placement-guide schedule, rolling video buffer, and the preview-then-confirm
 * step. Pure rendering lives in [CameraCaptureScreenContent] so Paparazzi
 * snapshots can exercise every state without a real camera.
 *
 * V30: binds a [DetectionPipeline] backed by [SmartCropperDocumentDetector];
 * auto-capture fires when the pipeline reaches [DetectionState.ReadyToCapture].
 * The manual shutter button remains as a fallback on all screens.
 * Tapping "Retake" rebinds the camera; tapping "Use this clip" forwards
 * the MP4 to the upload pipeline.
 */
@Composable
@Suppress(
    "CyclomaticComplexMethod",
    // Reason: this composable owns the entire capture-screen runtime loop
    // (permission flow, CameraX bind, manual capture, callbacks). Splitting
    // into nested composables fragments the lifecycle-effect coupling and
    // makes the dataflow harder to follow.
)
internal fun CameraCaptureScreen(
    side: Side,
    pendingDocument: AcceptedDocument?,
    enableFallback: Boolean,
    pendingCapture: PendingCapture?,
    onChangeDocument: () -> Unit,
    onCapturedFile: (Uri, Boolean) -> Unit,
    onSwitchToFallback: () -> Unit,
    onPickFile: () -> Unit,
    onRetakePickedFile: () -> Unit,
    onConfirmPickedFile: () -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val cameraSession = remember { CameraSession(context) }
    val videoBuffer =
        remember(side) {
            val prefix = if (side == Side.Back) "back" else "front"
            RollingVideoRecorder(context = context, flowPrefix = prefix)
        }

    // V30 detection pipeline — one per screen instance. Config is keyed on
    // `side` so the pipeline recreates if the host transitions Front→Back.
    val detectionConfig =
        remember(side, pendingDocument) {
            when {
                pendingDocument.isPassport() -> DetectionConfig.forPassport()
                side == Side.Back -> DetectionConfig.forIdBack()
                else -> DetectionConfig.forIdFront()
            }
        }
    val pipeline =
        remember(detectionConfig) {
            DetectionPipeline(
                detector = SmartCropperDocumentDetector(context),
                config = detectionConfig,
                mrz = if (detectionConfig.requireMrz) MrzDetector() else null,
                faceGate = if (detectionConfig.requireFaceGate) PassportPhotoGate() else null,
            )
        }
    LaunchedEffect(pipeline) { pipeline.initializeDetector() }
    DisposableEffect(pipeline) { onDispose { pipeline.release() } }

    // View-normalized cutout fractions (0..1) of the on-screen camera
    // viewport. Updated from CameraCaptureScreenContent via
    // onCutoutBoundsChanged; the analyzer converts these per-frame to the
    // ImageProxy's native (unrotated) coord system using
    // image.imageInfo.rotationDegrees. Decouples detection from any
    // preview/analysis resolution mismatch CameraX may introduce when
    // VideoCapture joins the bind.
    val cutoutFraction = remember { mutableStateOf(android.graphics.RectF()) }

    val frameAnalyzer =
        remember(pipeline) {
            FrameAnalyzer(
                pipeline = pipeline,
                cutoutFractionProvider = { cutoutFraction.value },
                mrz = pipeline.mrzOrNull(),
                faceGate = pipeline.faceGateOrNull(),
            )
        }

    val permissionState =
        rememberCameraPermissionState(
            onSettingsRequested = { openAppSettings(context) },
        )

    var cameraReady by remember { mutableStateOf(CameraReadyState.Loading) }
    var torchAvailable by remember { mutableStateOf(false) }
    var torchOn by remember { mutableStateOf(false) }
    var captureReady by remember { mutableStateOf(false) }
    var showGuide by remember { mutableStateOf(false) }
    var capturedUri by remember { mutableStateOf<Uri?>(null) }
    var captureJob by remember { mutableStateOf<Job?>(null) }
    val bindAttempt = remember { mutableIntStateOf(0) }
    var timedOut by remember { mutableStateOf(false) }
    var wasAutoCapture by remember { mutableStateOf(false) }
    var previewValidating by remember { mutableStateOf(false) }
    var previewWarnings by remember { mutableStateOf(emptyList<ValidationWarning>()) }
    // Auto-capture closes the camera and shows a blurred frozen frame behind
    // the upload sheet while the clip uploads. `uploadFrame` is the last frame
    // of the captured clip; `uploading` swaps the live HUD for that backdrop.
    var uploading by remember { mutableStateOf(false) }
    var uploadFrame by remember { mutableStateOf<ImageBitmap?>(null) }

    val isPassport = pendingDocument.isPassport()
    val staticValidator = remember { StaticDocumentValidator(detector = SmartCropperStaticDetector()) }
    val passportValidator = remember { if (isPassport) StaticPassportValidator() else null }
    DisposableEffect(passportValidator) { onDispose { passportValidator?.release() } }
    LaunchedEffect(capturedUri) {
        val uri = capturedUri ?: run {
            previewValidating = false
            previewWarnings = emptyList()
            return@LaunchedEffect
        }
        if (wasAutoCapture) {
            previewValidating = false
            previewWarnings = emptyList()
            return@LaunchedEffect
        }
        previewValidating = true
        previewWarnings = emptyList()
        val docKind = if (isPassport) DocKind.Passport else DocKind.Id
        val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            runCatching {
                val retriever = android.media.MediaMetadataRetriever()
                try {
                    retriever.setDataSource(uri.path)
                    val durationMs = retriever.extractMetadata(
                        android.media.MediaMetadataRetriever.METADATA_KEY_DURATION
                    )?.toLongOrNull() ?: 0L
                    val durationUs = durationMs * 1_000L
                    val count = POST_CAPTURE_SAMPLE_COUNT
                    val stepUs = if (durationUs > 0 && count > 1) {
                        durationUs / (count - 1)
                    } else 0L
                    var bestResult: ValidationResult? = null
                    for (i in 0 until count) {
                        val timeUs = if (count > 1) i * stepUs else 0L
                        val frame = retriever.getFrameAtTime(
                            timeUs,
                            android.media.MediaMetadataRetriever.OPTION_CLOSEST,
                        ) ?: continue
                        val r = if (passportValidator != null) {
                            passportValidator.validate(frame)
                        } else {
                            staticValidator.validate(frame, docKind)
                        }
                        frame.recycle()
                        if (!r.issues.contains(ValidationIssue.NoCard)) {
                            bestResult = r
                            break
                        }
                        if (bestResult == null) bestResult = r
                    }
                    bestResult
                } finally {
                    runCatching { retriever.release() }
                }
            }.getOrNull()
        }
        previewValidating = false
        previewWarnings = result?.warnings ?: emptyList()
    }

    // Pre-camera intro sheet (web `showIntro` is hardcoded true). First
    // paint shows the sheet; user taps Continue to dismiss + (if needed)
    // request camera permission. The ⓘ button re-opens it later.
    val introVisible = remember { mutableStateOf(true) }
    // Camera-screen upload bottom-sheet (web `<ekyc-sdk-upload-sheet>`).
    val uploadSheetOpen = remember { mutableStateOf(false) }

    // Re-show intro when the host transitions front → back. Without this
    // the same `CameraCaptureScreen` composable is re-invoked with `side
    // = Back` but `remember`'d state keeps its prior value because the
    // position-in-tree hasn't changed.
    LaunchedEffect(side) {
        introVisible.value = true
        uploadSheetOpen.value = false
        capturedUri = null
        timedOut = false
        // The auto-capture upload backdrop is local `remember` state, and the
        // host reuses this same composable node for Front→Back (only `side`
        // changes). Without clearing it here, a front clip that auto-captured
        // and uploaded leaves `uploading = true`, so the Box short-circuits to
        // BlurredCaptureBackground forever and the user is stranded on the
        // frozen blurred front frame instead of seeing the back-side camera.
        uploading = false
        uploadFrame = null
        if (cameraReady == CameraReadyState.Active) {
            // Force a clean rebind so the shutter / placement guide all
            // reset for the new side.
            bindAttempt.intValue++
        }
    }

    // No `BackHandler` — let hardware back fall through to the Activity's
    // OnBackPressedCallback (cancel + finish). Spec line 63 says the
    // *on-screen* back button (front side only) goes to DocumentSelect,
    // not cancel; that's wired through `onChangeDocument`.
    val previewView =
        remember {
            PreviewView(context).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
                implementationMode = PreviewView.ImplementationMode.PERFORMANCE
            }
        }

    LaunchedEffect(permissionState.status) {
        cameraReady =
            when (permissionState.status) {
                PermissionStatus.Granted -> cameraReady // bind effect will flip to Active.
                PermissionStatus.Denied -> CameraReadyState.PermissionDenied
                PermissionStatus.PermanentlyDenied -> CameraReadyState.PermissionPermanentlyDenied
                PermissionStatus.Unknown -> CameraReadyState.Loading
            }
    }

    // Defer the permission prompt until the user dismisses the intro
    // sheet — matches the web's gated camera-init behaviour.
    LaunchedEffect(introVisible.value) {
        if (!introVisible.value && permissionState.status != PermissionStatus.Granted) {
            permissionState.request()
        }
    }

    // Pause auto-detection while the intro sheet is open (re-openable mid-session
    // via the ⓘ button). Without this, frames keep advancing the stability
    // counter behind the sheet and auto-capture fires the moment it's dismissed.
    // Keyed on `pipeline` too so a freshly-rebuilt pipeline (Front→Back side
    // switch recreates `detectionConfig`) inherits the current paused state.
    LaunchedEffect(pipeline, introVisible.value) {
        pipeline.setPaused(introVisible.value)
        if (introVisible.value) timedOut = false
    }

    // Capture-window watchdog — if the user hasn't captured (manual or auto)
    // within CaptureConfig.CAMERA_TIMEOUT_MS, flip to the timeout state.
    // Keyed on `introVisible` so the window restarts each time the intro is
    // dismissed (initial open or mid-session reopen) — the timer must not
    // run behind the sheet. Also paused while previewing a captured clip.
    LaunchedEffect(cameraReady, capturedUri, introVisible.value) {
        if (cameraReady != CameraReadyState.Active) return@LaunchedEffect
        if (capturedUri != null) return@LaunchedEffect
        if (introVisible.value) return@LaunchedEffect
        delay(CaptureConfig.CAMERA_TIMEOUT_MS)
        if (capturedUri == null && !introVisible.value) {
            timedOut = true
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer =
            LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    permissionState.refresh()
                    if (permissionState.status == PermissionStatus.Granted) {
                        // Always force a clean rebind on resume — even when
                        // cameraReady is still Active, CameraX has finalized
                        // the active Recording during ON_PAUSE and the
                        // pipeline's `_holdingStartedAtMs` may be ages-old.
                        // Without this, the first frame after unlock sees
                        // elapsed >> HOLD_TARGET_MS, instantly emits
                        // ReadyToCapture, fires auto-capture, and stalls in
                        // `awaitFinalize` because the recording is already
                        // dead.
                        bindAttempt.intValue++
                    }
                }
            }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Bind + captureReady cycle are folded into one effect, keyed on
    // bindAttempt so Retake (which reuses an already-Active camera via
    // CameraSession's cached provider on Dispatchers.Main.immediate) still
    // re-runs the cycle. Splitting the captureReady delay into a separate
    // effect keyed on `cameraReady` doesn't work for that case: the
    // Loading → Active transition happens in a single synchronous batch and
    // Compose collapses it to a no-change snapshot, so a key-on-cameraReady
    // effect never re-fires after Retake and the CaptureRow's alpha stays
    // at 0. The 500ms delay still gives the preview surface time to settle
    // before the shutter is enabled.
    LaunchedEffect(permissionState.status, bindAttempt.intValue) {
        if (permissionState.status != PermissionStatus.Granted) return@LaunchedEffect
        cameraReady = CameraReadyState.Loading
        captureReady = false
        // Reset the pipeline so a stale Holding window from before
        // an unlock/retake doesn't trigger an instant ReadyToCapture
        // on the first post-bind frame.
        pipeline.reset()
        videoBuffer.reset()

        val videoUseCase = videoBuffer.buildUseCase()
        when (
            val result =
                cameraSession.bind(
                    lifecycleOwner = lifecycleOwner,
                    previewView = previewView,
                    analyzer = frameAnalyzer,
                    extraUseCase = videoUseCase,
                    previewTargetResolution =
                        android.util.Size(
                            CaptureConfig.PREVIEW_TARGET_WIDTH,
                            CaptureConfig.PREVIEW_TARGET_HEIGHT,
                        ),
                )
        ) {
            is CameraSession.BindResult.Bound -> {
                torchAvailable = result.hasFlashUnit
                torchOn = false
                cameraReady = CameraReadyState.Active
                videoBuffer.start()
                delay(CAPTURE_READY_DELAY_MS)
                captureReady = true
            }
            is CameraSession.BindResult.Failed -> {
                cameraReady = CameraReadyState.Unavailable
            }
        }
    }

    // Placement guide schedule: visible for an introductory window after
    // the camera binds, then dismissed (spec §05-capture #3).
    LaunchedEffect(cameraReady) {
        if (cameraReady != CameraReadyState.Active) {
            showGuide = false
            return@LaunchedEffect
        }
        showGuide = true
        delay(GUIDE_DURATION_MS)
        showGuide = false
    }

    DisposableEffect(Unit) {
        onDispose {
            videoBuffer.reset()
            cameraSession.shutdown()
        }
    }

    // No matrix mapping — cutoutFraction is computed directly from the
    // view-pixel rect and the previewView's on-screen dimensions in
    // onCutoutBoundsChanged. The analyzer projects fractions to image
    // coords per-frame, which is resolution- and rotation-independent.

    // V30 auto-capture: observe pipeline state; when ReadyToCapture is
    // reached, mark captured and fire the same handler as the manual shutter.
    val detectionState by pipeline.state.collectAsState()
    LaunchedEffect(detectionState, captureReady) {
        if (capturedUri != null) return@LaunchedEffect // in preview — don't re-capture
        if (detectionState !is DetectionState.ReadyToCapture) return@LaunchedEffect
        if (!captureReady) return@LaunchedEffect
        if (captureJob != null) return@LaunchedEffect
        pipeline.markCaptured()
        wasAutoCapture = true
        captureJob =
            scope.launch {
                val uri =
                    withTimeoutOrNull(CAPTURE_WATCHDOG_MS) {
                        videoBuffer.stopAndTrim()?.let { Uri.fromFile(it) }
                    }
                if (uri != null) {
                    // Auto-capture already cleared every detection gate — skip the
                    // review step and upload the clip directly. Freeze on a
                    // blurred last frame and close the camera so the upload sheet
                    // sits over a calm backdrop, not the live viewport.
                    uploadFrame = lastVideoFrame(uri)
                    uploading = true
                    cameraSession.unbind()
                    onCapturedFile(uri, false)
                } else {
                    // Trim failed (no keyframe, finalize error, etc.) — fall back
                    // to the retake path: reset pipeline + bump bindAttempt so the
                    // bind effect tears down and rebuilds a fresh recorder.
                    pipeline.reset()
                    videoBuffer.reset()
                    captureReady = false
                    bindAttempt.intValue++
                }
                captureJob = null
            }
    }

    val capturedPreview: (@Composable () -> Unit)? =
        capturedUri?.let { uri ->
            { CapturedVideoPreview(uri = uri) }
        }

    val frameDims by frameAnalyzer.lastFrameDims.collectAsState()
    var cutoutScreenRect by remember { mutableStateOf<android.graphics.Rect?>(null) }
    val pipelineHint by pipeline.hint.collectAsState()
    val pipelineWarning by pipeline.warning.collectAsState()
    val captureProgress by pipeline.holdProgress.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        if (uploading) {
            // Camera is closed; show the blurred frozen frame. The host layers
            // the UploadProgressSheet on top while the clip uploads.
            BlurredCaptureBackground(frame = uploadFrame, modifier = Modifier.fillMaxSize())
            return@Box
        }
        CameraCaptureScreenContent(
            state =
                CameraCaptureUiState(
                    cameraReady = cameraReady,
                    torchAvailable = torchAvailable,
                    torchOn = torchOn,
                    showGuide = showGuide,
                    captureReady = captureReady,
                    isPreviewing = capturedUri != null,
                    detectionState = detectionState,
                    frameDims = frameDims,
                    cutoutScreenRect = cutoutScreenRect,
                    captureProgress = captureProgress,
                    hint = pipelineHint,
                    warning = pipelineWarning,
                    timedOut = timedOut,
                    previewValidating = previewValidating,
                    previewWarnings = previewWarnings,
                ),
            side = side,
            pendingDocument = pendingDocument,
            enableFallback = enableFallback,
            onCutoutBoundsChanged = { viewRect ->
                // Cache the on-screen cutout rect for the polygon overlay's
                // inside/outside color split.
                cutoutScreenRect = viewRect
                // Compute view-normalized fractions of the previewView. The
                // analyzer projects these to image coords per-frame, so the
                // mapping survives any preview/analysis resolution mismatch
                // and any rotation CameraX may apply.
                val vw = previewView.width.toFloat()
                val vh = previewView.height.toFloat()
                if (vw > 0f && vh > 0f) {
                    cutoutFraction.value =
                        android.graphics.RectF(
                            (viewRect.left / vw).coerceIn(0f, 1f),
                            (viewRect.top / vh).coerceIn(0f, 1f),
                            (viewRect.right / vw).coerceIn(0f, 1f),
                            (viewRect.bottom / vh).coerceIn(0f, 1f),
                        )
                }
            },
            callbacks =
                CameraCaptureCallbacks(
                    onBack = onChangeDocument,
                    onShutter = {
                        if (capturedUri != null) return@CameraCaptureCallbacks
                        if (!captureReady) return@CameraCaptureCallbacks
                        if (captureJob != null) return@CameraCaptureCallbacks
                        wasAutoCapture = false
                        captureJob =
                            scope.launch {
                                val uri =
                                    withTimeoutOrNull(CAPTURE_WATCHDOG_MS) {
                                        videoBuffer.stopAndTrim()?.let { Uri.fromFile(it) }
                                    }
                                if (uri != null) {
                                    capturedUri = uri
                                } else {
                                    // Trim failed (no keyframe, finalize error, etc.) — fall back
                                    // to the retake path: reset pipeline + bump bindAttempt so the
                                    // bind effect tears down and rebuilds a fresh recorder.
                                    pipeline.reset()
                                    videoBuffer.reset()
                                    captureReady = false
                                    bindAttempt.intValue++
                                }
                                captureJob = null
                            }
                    },
                    onTryAgain = {
                        when (cameraReady) {
                            CameraReadyState.PermissionDenied,
                            CameraReadyState.PermissionPermanentlyDenied,
                            -> permissionState.request()
                            CameraReadyState.Unavailable -> bindAttempt.intValue++
                            else -> Unit
                        }
                    },
                    onSwitchToFallback = onSwitchToFallback,
                    onOpenUploadSheet = { uploadSheetOpen.value = true },
                    onShowIntro = { introVisible.value = true },
                    onToggleTorch = {
                        val next = !torchOn
                        cameraSession.setTorch(next)
                        torchOn = next
                    },
                    onRetake = {
                        capturedUri = null
                        captureReady = false
                        timedOut = false
                        wasAutoCapture = false
                        pipeline.reset()
                        videoBuffer.reset()
                        bindAttempt.intValue++
                    },
                    onConfirmCapture = {
                        val uri = capturedUri ?: return@CameraCaptureCallbacks
                        onCapturedFile(uri, !wasAutoCapture)
                    },
                    onOpenAppSettings = { openAppSettings(context) },
                ),
            previewSurface = {
                AndroidView(
                    factory = { previewView },
                    modifier = Modifier.fillMaxSize(),
                )
            },
            capturedPreview = capturedPreview,
        )

        if (introVisible.value) {
            val isPassport = pendingDocument.isPassport()
            KycIntroSheet(
                illustration =
                    when {
                        isPassport -> PlacementGuideKind.Document
                        side == Side.Front -> PlacementGuideKind.IdCardFront
                        else -> PlacementGuideKind.IdCardBack
                    },
                title =
                    when {
                        isPassport -> "Scan your passport"
                        side == Side.Front -> "Scan your ID document"
                        else -> "Now scan the back"
                    },
                subtitle =
                    when {
                        isPassport ->
                            "Open your passport to the photo page and place it inside the frame."
                        side == Side.Front ->
                            "We need to verify your identity. Position the front side of your " +
                                "document inside the frame."
                        else ->
                            "Flip your document over and place the back side inside the frame."
                    },
                eyebrow = introEyebrow(side = side, pendingDocument = pendingDocument),
                tipCards = defaultIntroTipCards(),
                buttonLabel = "Scan Document",
                onContinue = { introVisible.value = false },
            )
        }

        val sheetVisible = uploadSheetOpen.value || pendingCapture != null
        if (sheetVisible) {
            KycCameraUploadSheet(
                side = if (side == Side.Front) SideKind.Front else SideKind.Back,
                typeName = pendingDocument?.typeName,
                requireBothSides = pendingDocument?.requireBothSides == true,
                pendingCapture = pendingCapture,
                onPickFile = {
                    uploadSheetOpen.value = false
                    onPickFile()
                },
                onRetake = onRetakePickedFile,
                onConfirm = {
                    uploadSheetOpen.value = false
                    onConfirmPickedFile()
                },
                onDismiss = { uploadSheetOpen.value = false },
            )
        }
    }
}

private fun introEyebrow(
    side: Side,
    pendingDocument: AcceptedDocument?,
): String {
    val type = pendingDocument?.typeName ?: "Document"
    if (pendingDocument.isPassport()) return "Capture · $type"
    val sideLabel = if (side == Side.Front) "Front" else "Back"
    return "Capture · $type · $sideLabel"
}

/**
 * Heuristic: the only document-type signal the screen sees is the free-form
 * `typeName` (no enum), so we match the same convention used elsewhere in
 * the SDK (see DocumentSelectScreen). When the docs API ships a structured
 * kind, this helper is the single point to update.
 */
private fun AcceptedDocument?.isPassport(): Boolean = this?.typeName?.contains("passport", ignoreCase = true) == true

private fun defaultIntroTipCards(): List<IntroTipCard> =
    listOf(
        IntroTipCard(
            label = "Bright, even lighting",
            detail = "Avoid harsh backlight",
            icon = OthentoIcons.Sun,
        ),
        IntroTipCard(
            label = "All four corners visible",
            detail = "Leave a little margin",
            icon = OthentoIcons.FourCorners,
        ),
        IntroTipCard(
            label = "No glare or shadows",
            detail = "Keep matte surface flat",
            icon = OthentoIcons.Glare,
        ),
        IntroTipCard(
            label = "Real document only",
            detail = "Screen photos rejected",
            icon = OthentoIcons.NoScreen,
        ),
    )

private fun openAppSettings(context: Context) {
    val intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    runCatching { context.startActivity(intent) }
}

// 2 s of buffered footage before the shutter unlocks. The rolling-buffer
// recorder needs ≥ a second of scratch before the trim can produce a
// valid clip; tapping the shutter earlier gets a 0-byte trim → null →
// retake fallback fires instead of a real capture (the user perceives
// this as a missed click).
private const val CAPTURE_READY_DELAY_MS: Long = 2_000L
private const val GUIDE_DURATION_MS: Long = 4_000L
private const val CAPTURE_WATCHDOG_MS: Long = 5_000L
private const val POST_CAPTURE_SAMPLE_COUNT: Int = 5

