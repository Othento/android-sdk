package com.othento.core.internal.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Spacing scale per [docs/spec/04-design-system.md] §3. The web SDK clusters on
 * a 4-px grid with a few 2-px exceptions ([Px6], [Px10], [Px14]) — see spec
 * recommendation table. We expose the named scale plus the raw exception sizes
 * so call sites can mirror the spec's px values directly.
 */
@Immutable
internal data class OthentoSpacing(
    val xxs: Dp = 2.dp,
    val xs: Dp = 4.dp,
    val px6: Dp = 6.dp,
    val sm: Dp = 8.dp,
    val px10: Dp = 10.dp,
    val md: Dp = 12.dp,
    val px14: Dp = 14.dp,
    val lg: Dp = 16.dp,
    val xl: Dp = 20.dp,
    val xxl: Dp = 24.dp,
    val px28: Dp = 28.dp,
    val xxxl: Dp = 32.dp,
    val px40: Dp = 40.dp,
    val px56: Dp = 56.dp,
    val px80: Dp = 80.dp,
) {
    companion object {
        val Default: OthentoSpacing = OthentoSpacing()
    }
}

internal val LocalOthentoSpacing =
    staticCompositionLocalOf<OthentoSpacing> {
        error("OthentoSpacing not provided. Wrap content in OthentoTheme { … }.")
    }
