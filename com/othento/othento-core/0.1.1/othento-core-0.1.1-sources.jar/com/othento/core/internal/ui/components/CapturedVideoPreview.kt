@file:Suppress("MagicNumber")

package com.othento.core.internal.ui.components

import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Decode the last frame of the recorded MP4 at [uri] as an [ImageBitmap], or
 * null if the clip can't be read. The blocking `MediaMetadataRetriever` work
 * runs off the main thread.
 */
internal suspend fun lastVideoFrame(uri: Uri): ImageBitmap? =
    withContext(Dispatchers.Default) {
        runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(uri.path)
                val durationMs =
                    retriever.extractMetadata(
                        MediaMetadataRetriever.METADATA_KEY_DURATION,
                    )?.toLongOrNull() ?: 0L
                val bitmap =
                    retriever.getFrameAtTime(
                        durationMs * MICROS_PER_MILLI,
                        MediaMetadataRetriever.OPTION_CLOSEST,
                    ) ?: retriever.getFrameAtTime(ANY_FRAME_US)
                bitmap?.asImageBitmap()
            } finally {
                runCatching { retriever.release() }
            }
        }.getOrNull()
    }

/**
 * Static last-frame preview for the capture screens.
 *
 * Only manual captures reach a review step now — auto-capture uploads its clip
 * directly — and that review shows a still image (the final frame of the
 * recorded MP4) rather than the looping video the web SDK plays. Holding on the
 * last frame keeps the review surface calm and sidesteps the VideoView decoder.
 *
 * Under Paparazzi the frame extraction fails on the stub URI, so the box stays
 * black; existing snapshots assert chrome layout only.
 */
@Composable
internal fun CapturedVideoPreview(uri: Uri) {
    var frame by remember(uri) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(uri) { frame = lastVideoFrame(uri) }
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        frame?.let { bitmap ->
            Image(
                bitmap = bitmap,
                contentDescription = "Captured frame",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
    }
}

/**
 * Blurred, dimmed still rendered behind the upload sheet after auto-capture
 * fires and the camera is closed — replaces the live (and now stopped) camera
 * viewport so the "processing" state reads as a calm frozen frame.
 *
 * [frame] is the already-decoded last captured frame; a null frame falls back
 * to a plain black backdrop. `Modifier.blur` needs API 31+, so the [ScrimColor]
 * overlay keeps the backdrop intentional-looking on older devices where the
 * blur is a no-op.
 */
@Composable
internal fun BlurredCaptureBackground(
    frame: ImageBitmap?,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        if (frame != null) {
            Image(
                bitmap = frame,
                contentDescription = null,
                modifier = Modifier.fillMaxSize().blur(CaptureBlurRadius),
                contentScale = ContentScale.Crop,
            )
        }
        Box(modifier = Modifier.fillMaxSize().background(ScrimColor))
    }
}

private const val MICROS_PER_MILLI: Long = 1_000L
private const val ANY_FRAME_US: Long = -1L
private val CaptureBlurRadius: Dp = 24.dp
private val ScrimColor: Color = Color.Black.copy(alpha = 0.3f)
