/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.othento.core;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.othento.core";
  public static final String BUILD_TYPE = "release";
}
