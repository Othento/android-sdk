package com.othento.core.internal.network

import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.JsonReader
import com.squareup.moshi.JsonWriter
import com.squareup.moshi.Moshi
import com.othento.core.internal.data.model.Decision
import java.lang.reflect.Type

/**
 * Custom Moshi adapter that maps the dev backend's `decision: ""` (empty
 * string, "no decision yet") and `decision: null` to a domain `Decision?`
 * of `null`. Moshi's standard enum adapter would throw on `""` because
 * it doesn't match any enum constant.
 *
 * Hand-written rather than reflection-based (`@FromJson`/`@ToJson` method
 * scanning) so R8/ProGuard keep-rules stay tight per CLAUDE.md.
 */
internal class DecisionJsonAdapter : JsonAdapter<Decision>() {
    // Wrapped via `nullSafe()` at the factory boundary, so Moshi handles
    // the JSON `null` token before calling here — this method only sees
    // non-null reads.
    override fun fromJson(reader: JsonReader): Decision? {
        val raw = reader.nextString()
        if (raw.isBlank()) return null
        return runCatching { Decision.valueOf(raw) }.getOrNull()
    }

    override fun toJson(
        writer: JsonWriter,
        value: Decision?,
    ) {
        // `nullSafe()` handles the value == null case before this is called.
        writer.value(value!!.name)
    }

    /**
     * Factory that hands the adapter to Moshi only for the [Decision]
     * type. Registered in [OthentoHttpClientFactory.buildMoshi] before
     * Moshi's standard enum adapter so we win the lookup.
     */
    internal class Factory : JsonAdapter.Factory {
        override fun create(
            type: Type,
            annotations: Set<Annotation>,
            moshi: Moshi,
        ): JsonAdapter<*>? {
            val matches = annotations.isEmpty() && type === Decision::class.java
            return if (matches) DecisionJsonAdapter().nullSafe() else null
        }
    }
}
