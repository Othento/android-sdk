@file:Suppress("FunctionNaming", "MagicNumber", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.capture.SelfieConfig

/**
 * Selfie oval ROI overlay. Spec
 * [docs/spec/06-screens/08-selfie-capture.md] §3 — paints a semi-opaque
 * dark scrim over the camera preview with an ellipse cut out of it,
 * optionally tracing the ellipse border.
 *
 * Implemented as a `BoxWithConstraints` (so the layout pass deterministically
 * resolves the container size) wrapping a `Canvas` that combines a rect path
 * with an oval path via [PathOperation.Difference]. This is the Compose
 * equivalent of the web's `box-shadow: 0 0 0 9999px rgba(0,0,0,0.6)`.
 *
 * [onBoundsChanged] reports the oval's bounding rectangle in the overlay's
 * own coord space (px) — the screen forwards this to detection so the
 * analyzer can map face boxes back into "is this point inside the oval".
 * Reported once per layout change; safe to use as a state-writer because
 * the call site sits in a `LaunchedEffect`-friendly slot, not inside
 * `Canvas`'s draw scope.
 */
@Composable
@Suppress("LongParameterList")
// Reason: every parameter is an independent overlay knob (scrim colour /
// border colour + width / oval geometry ratios / bounds callback / modifier).
// Folding into a config object would obscure the single call site's
// keyword-argument readability.
internal fun OvalRoiOverlay(
    scrimColor: Color = Color.Black.copy(alpha = 0.6f),
    borderColor: Color? = null,
    borderWidth: Dp = 2.dp,
    widthRatio: Float = SelfieConfig.ROI_WIDTH_RATIO,
    heightToWidthRatio: Float = SelfieConfig.ROI_HEIGHT_TO_WIDTH_RATIO,
    onBoundsChanged: (android.graphics.Rect) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val ovalWidth = widthPx * widthRatio
        val ovalHeight = ovalWidth * heightToWidthRatio
        val ovalLeft = (widthPx - ovalWidth) / 2f
        val ovalTop = (heightPx - ovalHeight) / 2f
        val ovalRect =
            Rect(
                offset = Offset(ovalLeft, ovalTop),
                size = Size(ovalWidth, ovalHeight),
            )

        // Emit bounds only when the constraints actually change.
        // Skipped during the degenerate first measure pass (0×0).
        LaunchedEffect(widthPx, heightPx) {
            if (widthPx > 0f && heightPx > 0f) {
                onBoundsChanged(
                    android.graphics.Rect(
                        ovalLeft.toInt(),
                        ovalTop.toInt(),
                        (ovalLeft + ovalWidth).toInt(),
                        (ovalTop + ovalHeight).toInt(),
                    ),
                )
            }
        }

        Canvas(modifier = Modifier.fillMaxSize()) {
            val rectPath =
                Path().apply {
                    addRect(Rect(0f, 0f, size.width, size.height))
                }
            val ovalPath =
                Path().apply {
                    addOval(ovalRect)
                }
            val scrimPath =
                Path().apply {
                    op(rectPath, ovalPath, PathOperation.Difference)
                }
            drawPath(scrimPath, scrimColor)

            if (borderColor != null) {
                drawPath(
                    path = ovalPath,
                    color = borderColor,
                    style = Stroke(width = borderWidth.toPx()),
                )
            }
        }
    }
}
