package com.othento.core.internal.capture.detection.quality

/**
 * Threshold mirror of the web SDK's `apps/sdk/src/app/config/capture.config.ts`
 * — `qualityChecks` block. Values copied verbatim; tuning lives in one place
 * so the web and native validators agree on what "too bright" means.
 */
internal object StaticValidationConfig {
    // --- Brightness band ---
    const val BRIGHTNESS_MIN: Float = 50f
    const val BRIGHTNESS_MAX: Float = 220f

    // --- Blur (Laplacian variance) ---
    const val BLUR_MIN_VARIANCE: Float = 80f

    // --- Glare (ID card defaults) ---
    const val GLARE_HOT_PIXEL_BRIGHTNESS: Int = 240
    const val GLARE_MAX_BRIGHT_PIXEL_RATIO: Float = 0.03f
    const val GLARE_BLOB_MIN_AREA_RATIO: Float = 0.005f
    const val GLARE_VALIDATION_THRESHOLD: Float = 0.55f
    const val GLARE_DILATION_RADIUS: Int = 2
    const val GLARE_RESIZE_LONG_EDGE: Int = 360

    // --- Passport overrides ---
    object Passport {
        const val GLARE_HOT_PIXEL_BRIGHTNESS: Int = 230
        const val GLARE_MAX_BRIGHT_PIXEL_RATIO: Float = 0.06f
        const val GLARE_BLOB_MIN_AREA_RATIO: Float = 0.003f
        const val GLARE_VALIDATION_THRESHOLD: Float = 0.45f

        // --- Diffuse-glare grid ---
        const val DIFFUSE_GRID_COLS: Int = 8
        const val DIFFUSE_GRID_ROWS: Int = 6
        const val DIFFUSE_MIN_CELL_BRIGHTNESS: Float = 200f
        const val DIFFUSE_MAX_WASHED_RATIO: Float = 0.5f
    }
}
