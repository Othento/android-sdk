package com.othento.core.api

/**
 * Typed identity hints forwarded into the create-session call so the
 * backend can compare them against the data extracted from the document
 * and selfie.
 *
 * Mirrors the cross-platform contract's `ExpectedDetails` shape (Web / iOS
 * share the same 9 fields and the same JSON keys). All fields are optional;
 * send only what the host already knows about the user.
 *
 * Wire format: each field serializes to a JSON property with the literal
 * camelCase name shown here. `dateOfBirth` is an ISO-8601 date string
 * (e.g. `1990-04-23`).
 */
public data class OthentoExpectedDetails(
    val firstName: String? = null,
    val lastName: String? = null,
    val dateOfBirth: String? = null,
    val gender: String? = null,
    val nationality: String? = null,
    val country: String? = null,
    val address: String? = null,
    val documentNumber: String? = null,
    val ipAddress: String? = null,
)
