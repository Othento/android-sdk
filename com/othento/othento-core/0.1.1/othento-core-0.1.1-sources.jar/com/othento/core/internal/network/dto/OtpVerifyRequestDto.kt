package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass

/**
 * Wire body for `POST /api/v1/SessionToken/session/otp/verify`.
 *
 * Mirrors [docs/spec/09-data-models.md §3.9]. Used by Phase 9; defined now
 * for DTO completeness.
 */
@JsonClass(generateAdapter = true)
internal data class OtpVerifyRequestDto(
    val attemptStepId: String,
    val code: String,
)
