package com.othento.core.internal.flow

import com.othento.core.internal.data.model.Session
import com.othento.core.api.OthentoError

/**
 * Discriminated outcome of [SessionSource.resolveSession]. Matches the
 * orchestrator's `setErrorState`/happy-path split in
 * [docs/spec/07-navigation-and-flows.md] §3.
 */
internal sealed class SessionResolveResult {
    data class Ok(
        val session: Session,
    ) : SessionResolveResult()

    data class Failure(
        val error: OthentoError,
        val displayMessage: String,
        val httpStatus: Int? = null,
    ) : SessionResolveResult()
}
