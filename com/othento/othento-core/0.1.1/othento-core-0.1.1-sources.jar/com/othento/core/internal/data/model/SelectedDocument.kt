package com.othento.core.internal.data.model

/**
 * Document the user has chosen, embedded in session responses once
 * `initiate` has been called.
 *
 * Per [docs/spec/09-data-models.md §2.5]. Same identifier space as
 * [AcceptedDocument.documentId].
 */
internal data class SelectedDocument(
    val id: String,
    val widthMm: Double?,
    val heightMm: Double?,
    val requireBothSides: Boolean,
)
