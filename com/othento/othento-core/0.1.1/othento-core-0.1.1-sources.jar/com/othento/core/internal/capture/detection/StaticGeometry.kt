package com.othento.core.internal.capture.detection

import android.graphics.PointF
import android.graphics.Rect
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min

/**
 * Pure-Kotlin port of the web SDK's `apps/sdk/src/app/utils/geometry.utils.ts`.
 * Operates on `PointF` corner lists; no Android-graphics state beyond the
 * value types.
 */
internal object StaticGeometry {
    /** ±20° tolerance from a right angle on each of the 4 corners. */
    private const val ANGLE_TOLERANCE_DEG: Double = 20.0

    /** ±15% band around the expected aspect ratio. */
    private const val ASPECT_RATIO_TOLERANCE: Float = 0.15f

    /** A "landscape" quad has its bounding box wider than tall by ≥ 5%. */
    private const val LANDSCAPE_MIN_RATIO: Float = 1.05f

    /** Expected number of corners in a document quad. */
    private const val QUAD_SIZE: Int = 4

    /** Degrees in a full circle. */
    private const val FULL_CIRCLE_DEG: Double = 360.0

    /** Degrees in a half circle — threshold for wrapping angle difference. */
    private const val HALF_CIRCLE_DEG: Double = 180.0

    /** A right angle in degrees. */
    private const val RIGHT_ANGLE_DEG: Double = 90.0

    // Reason: each guard clause returns early on a logically distinct
    // precondition (null, wrong size, bad angle); flattening into a single
    // return would obscure the per-corner validation loop.
    @Suppress("ReturnCount")
    fun hasValidCornerAngles(corners: List<PointF>?): Boolean {
        if (corners == null || corners.size != QUAD_SIZE) return false
        for (i in 0 until QUAD_SIZE) {
            val prev = corners[(i + QUAD_SIZE - 1) % QUAD_SIZE]
            val curr = corners[i]
            val next = corners[(i + 1) % QUAD_SIZE]
            val ax = prev.x - curr.x
            val ay = prev.y - curr.y
            val bx = next.x - curr.x
            val by = next.y - curr.y
            val angleA = atan2(ay.toDouble(), ax.toDouble())
            val angleB = atan2(by.toDouble(), bx.toDouble())
            var diff = abs(angleB - angleA) * HALF_CIRCLE_DEG / PI
            if (diff > HALF_CIRCLE_DEG) diff = FULL_CIRCLE_DEG - diff
            if (abs(diff - RIGHT_ANGLE_DEG) > ANGLE_TOLERANCE_DEG) return false
        }
        return true
    }

    // Reason: guard clauses for null/empty and zero-height rect are distinct
    // preconditions; merging them hides the intent of each check.
    @Suppress("ReturnCount")
    fun isLandscape(corners: List<PointF>?): Boolean {
        if (corners == null || corners.isEmpty()) return false
        val rect = cornersToRect(corners)
        if (rect.height() <= 0) return false
        return rect.width().toFloat() / rect.height() >= LANDSCAPE_MIN_RATIO
    }

    // Reason: same guard-clause pattern as isLandscape — each early return
    // represents a different invalid-input condition.
    @Suppress("ReturnCount")
    fun matchesDocumentAspectRatio(
        corners: List<PointF>?,
        expected: Float,
    ): Boolean {
        if (corners == null || corners.isEmpty()) return false
        val rect = cornersToRect(corners)
        if (rect.height() <= 0) return false
        val actual = rect.width().toFloat() / rect.height()
        val low = expected * (1f - ASPECT_RATIO_TOLERANCE)
        val high = expected * (1f + ASPECT_RATIO_TOLERANCE)
        return actual in low..high
    }

    fun cornersToRect(corners: List<PointF>): Rect {
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        for (p in corners) {
            minX = min(minX, p.x)
            minY = min(minY, p.y)
            maxX = max(maxX, p.x)
            maxY = max(maxY, p.y)
        }
        return Rect(minX.toInt(), minY.toInt(), maxX.toInt(), maxY.toInt())
    }
}
