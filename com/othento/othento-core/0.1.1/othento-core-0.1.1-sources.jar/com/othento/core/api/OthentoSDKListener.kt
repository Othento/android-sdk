package com.othento.core.api

/**
 * Receives lifecycle and terminal events from a running Othento SDK session.
 *
 * Mirrors the cross-platform contract's listener surface. All callbacks
 * are dispatched on the Android main thread, asynchronously (next runloop
 * tick) — they do not run synchronously inside [OthentoSDK.start].
 *
 * Exactly one of [onCompleted] / [onCancelled] / [onError] fires per
 * session. Exceptions thrown from a listener method are caught and
 * logged by the SDK — they do not crash the SDK or prevent subsequent
 * callbacks.
 */
public interface OthentoSDKListener {
    /** Fires exactly once, before any other callback. */
    public fun onReady()

    /**
     * Fires when a new session has been minted. **[OthentoMode.Create] only.**
     * Token mode loads an existing session and skips this callback.
     */
    public fun onSessionCreated(
        externalId: String,
        sessionUrl: String,
    )

    /**
     * Session status transitioned. Deduplicated — the same status will
     * never fire twice in a row.
     */
    public fun onStatusChanged(status: OthentoSessionStatus)

    /**
     * Any non-decision terminal error. [error] carries the stable
     * [OthentoError.code] for programmatic handling; [displayMessage] is the
     * user-facing localised string that was shown on the in-SDK error
     * screen.
     */
    public fun onError(
        error: OthentoError,
        displayMessage: String,
    )

    /**
     * Fires when the user dismissed the SDK, the host called
     * [OthentoSDK.destroy], or the SDK's own UI cancelled the session before
     * a terminal status. [reason] disambiguates which.
     */
    public fun onCancelled(reason: OthentoCancelReason)

    /**
     * Fires exactly once when verification reaches a terminal decision.
     * Both [decision] and [externalId] are guaranteed non-null — if the
     * SDK cannot determine either, it emits [onError] instead.
     */
    public fun onCompleted(
        decision: OthentoDecision,
        externalId: String,
    )
}
