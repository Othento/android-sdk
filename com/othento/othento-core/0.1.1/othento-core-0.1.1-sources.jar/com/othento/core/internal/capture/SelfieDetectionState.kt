package com.othento.core.internal.capture

import com.othento.core.internal.capture.detection.face.SelfieHint
import com.othento.core.internal.capture.detection.face.SelfieWarning

/**
 * Selfie capture state machine. Drives the on-screen status pill, scan
 * line, capture-button progress ring, and auto-capture trigger. Spec
 * [docs/spec/06-screens/08-selfie-capture.md] §"States".
 *
 * State transitions are managed by
 * [com.othento.core.internal.capture.SelfieDetectionPipeline].
 */
internal sealed class SelfieDetectionState {
    /** No frames seen yet — UI shows the spinner. */
    object Idle : SelfieDetectionState()

    /**
     * Camera bound but `captureDelayMs` hasn't elapsed yet. Auto + manual
     * capture are blocked. UI shows the status pill copy "Position your
     * face in the oval".
     */
    object CaptureBlocked : SelfieDetectionState()

    /**
     * Detection running, no qualifying face right now. [hint] is the
     * sticky hint string the status pill shows; null on the first frame
     * or after the camera turns on.
     */
    data class Searching(
        val hint: SelfieHint?,
        val warning: SelfieWarning?,
    ) : SelfieDetectionState()

    /**
     * Face passed all gates this frame. [framesHeld] of the
     * stability-frames target. [progress] is `framesHeld / target` for the
     * capture-button ring fill.
     */
    data class Holding(
        val framesHeld: Int,
        val target: Int,
        val warning: SelfieWarning?,
    ) : SelfieDetectionState() {
        val progress: Float
            get() = if (target > 0) framesHeld.toFloat() / target.toFloat() else 0f
    }

    /** Stability window full — the screen may now fire auto-capture. */
    object ReadyToCapture : SelfieDetectionState()

    /** Capture fired — pipeline has stopped emitting. */
    object Captured : SelfieDetectionState()
}
