package com.othento.core.api

/**
 * Final decision on a verification session.
 *
 * Mirrors `Decision` from the web SDK contract
 * (docs/spec/02-public-api.md §6, session.model.ts:5). Only meaningful when
 * the session reaches [OthentoSessionStatus.Completed]; until then the host
 * should treat the decision as undefined.
 */
public enum class OthentoDecision {
    Approved,
    Declined,
    InReview,
}
