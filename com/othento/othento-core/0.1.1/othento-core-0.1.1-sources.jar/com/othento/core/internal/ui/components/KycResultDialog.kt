@file:Suppress(
    "FunctionNaming",
    "LongMethod",
    "MatchingDeclarationName",
    "MagicNumber",
    "TopLevelPropertyNaming",
)

package com.othento.core.internal.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/** Discriminator for the icon halo color on a [KycResultDialog]. */
internal enum class KycResultDialogTone {
    Primary,
    Warning,
    Error,
}

/**
 * Generic centered result sheet used by Phase 9 OTP for the "Code
 * expired" / "Incorrect code" / "Verification skipped" surfaces
 * ([docs/spec/06-screens/09-otp-phone.md] §"Modal/sheet overlays"). The
 * sheet sits on a 50 %-dim backdrop; tap-outside dismisses by invoking
 * [onDismiss].
 *
 * The component is intentionally generic so other phases can reuse it
 * — only the icon color (via [tone]), labels, and CTAs differ between
 * call sites.
 */
@Composable
@Suppress("LongParameterList")
internal fun KycResultDialog(
    icon: ImageVector,
    iconContentDescription: String,
    title: String,
    body: String,
    primaryLabel: String,
    onPrimary: () -> Unit,
    onDismiss: () -> Unit,
    tone: KycResultDialogTone = KycResultDialogTone.Primary,
    secondaryLabel: String? = null,
    onSecondary: (() -> Unit)? = null,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val (haloBg, haloColor) =
        when (tone) {
            KycResultDialogTone.Primary -> colors.primaryBg to colors.primary
            KycResultDialogTone.Warning -> AmberHaloBg to AmberHaloColor
            KycResultDialogTone.Error -> colors.errorBg to colors.error
        }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        // Suppress the platform's default window dim so the only scrim is the
        // explicit 50%-black backdrop below — preserves the spec's exact tone.
        val dialogView = LocalView.current
        SideEffect {
            (dialogView.parent as? DialogWindowProvider)?.window?.setDimAmount(0f)
        }
        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable(onClick = onDismiss),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier =
                    Modifier
                        .padding(24.dp)
                        .widthIn(min = 280.dp, max = 360.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(colors.bgBase)
                        .clickable(enabled = false, onClick = {})
                        .padding(PaddingValues(horizontal = 24.dp, vertical = 28.dp)),
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Box(
                        modifier =
                            Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(haloBg),
                        contentAlignment = Alignment.Center,
                    ) {
                        KycIcon(
                            imageVector = icon,
                            contentDescription = iconContentDescription,
                            sizeDp = 28.dp,
                            tint = haloColor,
                        )
                    }
                    Text(
                        text = title,
                        style = typography.titleH3,
                        color = colors.textPrimary,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        text = body,
                        style = typography.body,
                        color = colors.textSecondary,
                        textAlign = TextAlign.Center,
                    )
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        KycButton(
                            label = primaryLabel,
                            onClick = onPrimary,
                            variant = KycButtonVariant.Primary,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        if (secondaryLabel != null && onSecondary != null) {
                            KycButton(
                                label = secondaryLabel,
                                onClick = onSecondary,
                                variant = KycButtonVariant.Ghost,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                }
            }
        }
    }
}

private val AmberHaloBg: Color = Color(0xFFFEF3C7)
private val AmberHaloColor: Color = Color(0xFFB45309)
