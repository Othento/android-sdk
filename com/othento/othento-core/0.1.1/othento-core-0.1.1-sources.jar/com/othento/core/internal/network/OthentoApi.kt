package com.othento.core.internal.network

import com.othento.core.internal.network.dto.AcceptedDocumentDto
import com.othento.core.internal.network.dto.ConfirmUploadRequestDto
import com.othento.core.internal.network.dto.CreateSessionRequestDto
import com.othento.core.internal.network.dto.OtpSendRequestDto
import com.othento.core.internal.network.dto.OtpVerifyRequestDto
import com.othento.core.internal.network.dto.TokenSessionResponseDto
import com.othento.core.internal.network.dto.UploadUrlResponseDto
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Retrofit interface for the SDK's HTTP surface.
 *
 * The Android SDK is a single-mode flow (P9 in `99-open-questions.md`):
 * the create call uses apiKey auth, every subsequent call goes through the
 * token interceptor with `X-SAT` / `X-ST` / `X-SRT`. Phase 5 wires the
 * document / upload / poll endpoints; OTP arrives in Phase 9.
 */
internal interface OthentoApi {
    /**
     * `POST /api/v1/SessionToken/session` — create. `X-API-KEY` is attached
     * by [ApiKeyInterceptor] when the URL targets the configured base host.
     */
    @POST(OthentoApiPaths.CREATE_SESSION)
    suspend fun createSession(
        @Body body: CreateSessionRequestDto,
    ): TokenSessionResponseDto

    /** `GET /api/v1/SessionToken/session` — load / poll the current session. */
    @GET(OthentoApiPaths.POLL_SESSION)
    suspend fun pollSession(): TokenSessionResponseDto

    /** `GET /api/v1/SessionToken/session/documents` — accepted documents list. */
    @GET(OthentoApiPaths.DOCUMENTS)
    suspend fun getDocuments(): List<AcceptedDocumentDto>

    /**
     * `POST /api/v1/SessionToken/session/initiate?documentId=…` — initiate
     * the id-verification step with the chosen document. Body is `null`.
     */
    @POST(OthentoApiPaths.INITIATE)
    suspend fun initiateSession(
        @Query("documentId") documentId: String,
    ): TokenSessionResponseDto

    /**
     * `POST /api/v1/SessionToken/session/reinitiate?documentId=…` — re-attempt
     * the document step on a `Failed` + `canInitiate` session. Phase 5 routes
     * the `FailedRetry` "Try Again" CTA back through the document picker
     * rather than auto-reinitiating, so this entry is currently unused but
     * lives here so later phases can call it without an interface bump.
     */
    @POST(OthentoApiPaths.REINITIATE)
    suspend fun reinitiateSession(
        @Query("documentId") documentId: String,
    ): TokenSessionResponseDto

    /**
     * `GET /api/v1/SessionToken/session/upload-url` — presigned S3 URL.
     *
     * Query-param casing is the spec's exact wire shape (`AttemptStepId`,
     * `ChallengeType`, `FileName`); the dev backend is case-sensitive.
     */
    @GET(OthentoApiPaths.UPLOAD_URL)
    suspend fun getUploadUrl(
        @Query("AttemptStepId") attemptStepId: String,
        @Query("ChallengeType") challengeType: String,
        @Query("FileName") fileName: String,
    ): UploadUrlResponseDto

    /** `POST /api/v1/SessionToken/session/confirm-upload` — finalise an upload. */
    @POST(OthentoApiPaths.CONFIRM_UPLOAD)
    suspend fun confirmUpload(
        @Body body: ConfirmUploadRequestDto,
    ): TokenSessionResponseDto

    /** Phase 9 — `POST /api/v1/SessionToken/session/otp/send`. */
    @POST(OthentoApiPaths.OTP_SEND)
    suspend fun sendOtp(
        @Body body: OtpSendRequestDto,
    ): TokenSessionResponseDto

    /** Phase 9 — `POST /api/v1/SessionToken/session/otp/verify`. */
    @POST(OthentoApiPaths.OTP_VERIFY)
    suspend fun verifyOtp(
        @Body body: OtpVerifyRequestDto,
    ): TokenSessionResponseDto
}
