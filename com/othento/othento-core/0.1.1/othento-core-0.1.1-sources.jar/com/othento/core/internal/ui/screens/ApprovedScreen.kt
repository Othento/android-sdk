@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.components.StatusIconTone
import com.othento.core.internal.ui.screens.common.RETURN_TO_APP_LABEL
import com.othento.core.internal.ui.screens.common.StatusAction
import com.othento.core.internal.ui.screens.common.StatusScreenMode
import com.othento.core.internal.ui.screens.common.StatusScreenScaffold

/**
 * Spec [docs/spec/06-screens/13-approved.md]:
 * green check, "Identity Verified" title, single-line success copy, plus
 * the explicit "Return to app" CTA so dismissal is user-driven (the SDK
 * never auto-finishes the flow).
 */
@Composable
internal fun ApprovedScreen(onReturnToApp: () -> Unit) {
    StatusScreenScaffold(
        iconName = StatusIconName.Check,
        iconTone = StatusIconTone.Success,
        title = "Identity Verified",
        description = "Your identity has been successfully verified.",
        mode = StatusScreenMode.Terminal,
        primaryAction = StatusAction(label = RETURN_TO_APP_LABEL, onClick = onReturnToApp),
    )
}
