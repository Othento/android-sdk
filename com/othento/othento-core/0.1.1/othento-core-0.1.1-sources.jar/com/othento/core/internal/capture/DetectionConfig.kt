package com.othento.core.internal.capture

internal data class DetectionConfig(
    val expectedAspectRatio: Float,
    val aspectRatioTolerance: Float,
    val stabilityFramesRequired: Int,
    val requireMrz: Boolean,
    val requireFaceGate: Boolean,
    val coverageMin: Float,
    val coverageMax: Float,
    val blurThreshold: Float,
    val glareThreshold: Float,
    val brightnessRange: IntRange,
) {
    companion object {
        fun forIdFront(): DetectionConfig =
            DetectionConfig(
                expectedAspectRatio = 1.585f,
                aspectRatioTolerance = 0.15f,
                // 13 frames @ 10 fps analyzer ≈ 1.3 s — matches web's
                // `autoCaptureDurationMs = 1300`. Lower values (3-5) make
                // auto-capture feel instant the moment the document
                // appears in frame, which is jarring.
                stabilityFramesRequired = 13,
                requireMrz = false,
                requireFaceGate = false,
                coverageMin = 0.30f,
                coverageMax = 1.10f,
                blurThreshold = CaptureConfig.DEFAULT_BLUR_THRESHOLD,
                glareThreshold = CaptureConfig.DEFAULT_GLARE_THRESHOLD,
                brightnessRange = CaptureConfig.DEFAULT_BRIGHTNESS_RANGE,
            )

        fun forIdBack(): DetectionConfig = forIdFront()

        fun forPassport(): DetectionConfig =
            DetectionConfig(
                expectedAspectRatio = 1.40f,
                aspectRatioTolerance = 0.25f,
                stabilityFramesRequired = 13,
                requireMrz = true,
                requireFaceGate = true,
                coverageMin = 0.30f,
                coverageMax = 1.10f,
                blurThreshold = CaptureConfig.DEFAULT_BLUR_THRESHOLD,
                glareThreshold = CaptureConfig.DEFAULT_GLARE_THRESHOLD,
                brightnessRange = CaptureConfig.DEFAULT_BRIGHTNESS_RANGE,
            )
    }
}
