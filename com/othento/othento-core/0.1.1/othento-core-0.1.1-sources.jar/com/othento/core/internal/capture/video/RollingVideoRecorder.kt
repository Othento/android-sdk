package com.othento.core.internal.capture.video

import android.content.Context
import androidx.camera.core.UseCase
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import com.othento.core.internal.capture.CaptureConfig
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume

/**
 * Rolling-buffer video recorder. CameraX [Recorder] writes a
 * long-running scratch MP4; on capture the scratch is trimmed to the
 * last [CaptureConfig.VIDEO_WINDOW_MS] via [VideoTrim] (no re-encode).
 *
 * Replaces the Phase 7/8 `SelfieVideoRecorder` which was linear (first
 * 4 s after bind, not last 4 s before capture). Mirrors the web SDK's
 * intent — the web does it with two overlapping `MediaRecorder` slots;
 * Android's single-writer constraint makes long-record-then-trim the
 * cleanest equivalent.
 *
 * Lifecycle:
 * 1. [buildUseCase] before binding the camera.
 * 2. [start] after bind succeeds — scratch begins recording.
 * 3. [stopAndTrim] on capture — awaits `Finalize`, then trims.
 * 4. [reset] on retake / dispose — clears scratch + trimmed.
 *
 * Reference design: docs/superpowers/specs/2026-05-02-rolling-video-capture-design.md
 */
internal class RollingVideoRecorder(
    private val context: Context,
    private val flowPrefix: String,
    private val cacheDir: File = context.cacheDir,
) {
    @Volatile
    private var videoCapture: VideoCapture<Recorder>? = null

    private val activeRecording = AtomicReference<Recording?>(null)

    @Volatile
    private var scratchFile: File? = null

    @Volatile
    private var trimmedFile: File? = null

    /** Resolved by the recording's event listener when Finalize arrives. */
    @Volatile
    private var finalizeWaiter: CancellableContinuation<Boolean>? = null

    fun buildUseCase(): UseCase {
        val recorder =
            Recorder
                .Builder()
                .setQualitySelector(
                    // Force 1080p, dropping to 720p only when the device can't
                    // provide FHD in the bound stream combination. SD (480p) is
                    // deliberately left off the preference list — 99%+ of devices
                    // do at least 720p, and a 480p clip is too soft for ID/OCR.
                    // The fallback still keeps genuinely SD-only devices binding
                    // (never a hard failure) without ever *preferring* SD when HD
                    // is available.
                    QualitySelector.fromOrderedList(
                        listOf(Quality.FHD, Quality.HD),
                        FallbackStrategy.higherQualityOrLowerThan(Quality.HD),
                    ),
                )
                .setTargetVideoEncodingBitRate(CaptureConfig.VIDEO_BITS_PER_SECOND)
                .build()
        val capture = VideoCapture.withOutput(recorder)
        videoCapture = capture
        return capture
    }

    /** Begin recording into a fresh scratch file. No-op if already recording. */
    fun start() {
        if (activeRecording.get() != null) return
        val capture = videoCapture ?: return

        val out = File.createTempFile("othento-rolling-$flowPrefix-", ".mp4", cacheDir)
        scratchFile = out

        val output = FileOutputOptions.Builder(out).build()
        val recording =
            capture
                .output
                .prepareRecording(context, output)
                .start(ContextCompat.getMainExecutor(context)) { event ->
                    if (event !is VideoRecordEvent.Finalize) return@start
                    val ok = !event.hasError()
                    if (!ok) {
                        runCatching { out.delete() }
                    }
                    val waiter = finalizeWaiter
                    finalizeWaiter = null
                    if (waiter?.isActive == true) waiter.resume(ok)
                }
        activeRecording.set(recording)
    }

    /**
     * Stop the active recording, await `Finalize`, then trim the
     * scratch to the last [CaptureConfig.VIDEO_WINDOW_MS]. Returns the
     * trimmed file or `null` on any failure (no recording, finalize
     * error, trim failure). Deletes the scratch on success.
     */
    suspend fun stopAndTrim(): File? {
        val recording = activeRecording.getAndSet(null) ?: return null
        val scratch = scratchFile ?: return null
        scratchFile = null

        val finalizeOk = awaitFinalize(recording)
        if (!finalizeOk || !scratch.isFile || scratch.length() == 0L) {
            runCatching { scratch.delete() }
            return null
        }

        val trimmed = File(cacheDir, "othento-$flowPrefix-${System.currentTimeMillis()}.mp4")
        val ok = VideoTrim.trim(scratch, trimmed, CaptureConfig.VIDEO_WINDOW_MS)
        runCatching { scratch.delete() }
        if (!ok) {
            runCatching { trimmed.delete() }
            return null
        }
        trimmedFile = trimmed
        return trimmed
    }

    /**
     * Stops any active recording, deletes scratch + trimmed.
     * Leaves the recorder ready for a fresh [start] — does not
     * unbind the [VideoCapture] use case.
     */
    fun reset() {
        activeRecording.getAndSet(null)?.runCatching { stop() }
        finalizeWaiter?.takeIf { it.isActive }?.resume(false)
        finalizeWaiter = null
        scratchFile?.runCatching { delete() }
        scratchFile = null
        trimmedFile?.runCatching { delete() }
        trimmedFile = null
    }

    fun isRecording(): Boolean = activeRecording.get() != null

    private suspend fun awaitFinalize(recording: Recording): Boolean =
        suspendCancellableCoroutine { cont ->
            finalizeWaiter = cont
            cont.invokeOnCancellation { finalizeWaiter = null }
            recording.runCatching { stop() }
        }
}
