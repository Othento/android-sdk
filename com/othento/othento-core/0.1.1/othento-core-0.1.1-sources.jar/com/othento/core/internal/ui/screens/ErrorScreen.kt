@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.components.StatusIconTone
import com.othento.core.internal.ui.screens.common.RETURN_TO_APP_LABEL
import com.othento.core.internal.ui.screens.common.StatusAction
import com.othento.core.internal.ui.screens.common.StatusScreenMode
import com.othento.core.internal.ui.screens.common.StatusScreenScaffold
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.api.OthentoError

/**
 * Spec [docs/spec/06-screens/19-error.md]:
 * red cross, title varies by error kind ("Session not found" for 404,
 * "Something went wrong" otherwise), description = SDK display message,
 * optional "error code  NNN" chip in the extra slot.
 *
 * The web SDK's retry CTA is deliberately not wired (see spec
 * [docs/spec/06-screens/19-error.md] §"User inputs" — `onRetry` exists in
 * the page but isn't bound to any control on this screen). Phase 4 follows
 * the same convention: the host receives the `onError` callback and can
 * relaunch the SDK if it wants to retry.
 */
@Composable
internal fun ErrorScreen(
    error: OthentoError?,
    displayMessage: String?,
    httpStatus: Int?,
    onReturnToApp: () -> Unit,
) {
    val title = if (error == OthentoError.SessionNotFound) "Session not found" else "Something went wrong"
    val description =
        displayMessage
            ?: "The verification session could not be found. It may have expired or the link is invalid."
    val codeText = if (error == OthentoError.SessionNotFound) "404" else httpStatus?.toString()
    StatusScreenScaffold(
        iconName = StatusIconName.Cross,
        iconTone = StatusIconTone.Error,
        title = title,
        description = description,
        mode = StatusScreenMode.Terminal,
        primaryAction = StatusAction(label = RETURN_TO_APP_LABEL, onClick = onReturnToApp),
        extraContent =
            if (codeText != null) {
                {
                    ErrorCodeChip(codeText)
                }
            } else {
                null
            },
    )
}

@Composable
private fun ErrorCodeChip(code: String) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier =
            Modifier
                .clip(RoundedCornerShape(percent = 50))
                .background(colors.bgLayout)
                .border(width = 1.dp, color = colors.border, shape = RoundedCornerShape(percent = 50))
                .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(
            text = "ERROR CODE",
            style = typography.microEyebrow.copy(fontSize = 10.sp),
            color = colors.textMuted,
        )
        Text(
            text = code,
            style = typography.numericBadge.copy(fontSize = 12.sp),
            color = colors.textPrimary,
        )
    }
}
