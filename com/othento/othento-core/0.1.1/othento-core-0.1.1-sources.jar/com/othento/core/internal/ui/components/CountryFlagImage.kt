@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/**
 * Country flag image rendered from an `AcceptedDocument.countryIcon` URL.
 *
 * Mirrors the web SDK's two flag slots (spec
 * [docs/spec/04-design-system.md §"Country flag"]):
 *   - Document-select dropdown — 20×14
 *   - Camera chrome pill        — 16×12
 *
 * The flag uses the same 2 px corner-rounding the web's
 * `.doc-select__flag` and `.camera-capture__chrome-flag` apply
 * (`border-radius: 2px`). `ContentScale.Crop` matches the web's
 * `object-fit: cover` so non-3:2 source images don't stretch.
 *
 * If [url] is blank the slot collapses — same as the web's
 * `@if (country.countryIcon)` guard.
 */
@Composable
internal fun CountryFlagImage(
    url: String?,
    width: Dp,
    height: Dp,
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
) {
    if (url.isNullOrBlank()) return
    Box(
        modifier =
            modifier
                .width(width)
                .height(height)
                .clip(RoundedCornerShape(FlagCorner)),
    ) {
        AsyncImage(
            model = url,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(width, height),
        )
    }
}

/** Flag size used inside the country-select dropdown rows + closed trigger. */
internal val DropdownFlagWidth: Dp = 20.dp
internal val DropdownFlagHeight: Dp = 14.dp

/** Flag size used inside the camera capture screen's chrome pill. */
internal val ChromeFlagWidth: Dp = 16.dp
internal val ChromeFlagHeight: Dp = 12.dp

private val FlagCorner: Dp = 2.dp
