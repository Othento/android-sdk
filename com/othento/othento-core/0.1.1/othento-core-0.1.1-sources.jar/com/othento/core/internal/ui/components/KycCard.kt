@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoElevation
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoShapes

/** Spec §2 — `KycCardVariant`. */
@Immutable
internal enum class KycCardVariant { Resting, Emphasized }

/** Spec §2 — `KycCardPadding`. Source: `apps/sdk/.../kyc-card.scss:20-23`. */
@Immutable
internal enum class KycCardPadding(
    val value: Dp,
) {
    None(0.dp),
    Sm(12.dp),
    Md(16.dp),
    Lg(24.dp),
}

/**
 * Generic surface container. Faithful port of `apps/sdk/.../kyc-card/`:
 *
 * - `border-radius: var(--radius-md)` / `background: var(--color-bg-base)`.
 * - Resting: 1 dp `--color-border` + `--elevation-level-1`.
 * - Emphasized: 1 dp `--color-primary-bg` + `--elevation-level-2`.
 * - `transition: box-shadow var(--motion-duration-fast) var(--motion-ease-out)`
 *   — variant changes animate between elevations.
 */
@Composable
internal fun KycCard(
    modifier: Modifier = Modifier,
    variant: KycCardVariant = KycCardVariant.Resting,
    padding: KycCardPadding = KycCardPadding.Md,
    content: @Composable () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val shapes = LocalOthentoShapes.current
    val elevation = LocalOthentoElevation.current
    val motion = LocalOthentoMotion.current

    val borderColor: Color =
        when (variant) {
            KycCardVariant.Resting -> colors.border
            KycCardVariant.Emphasized -> colors.primaryBg
        }
    val targetElevation: Dp =
        when (variant) {
            KycCardVariant.Resting -> elevation.level1
            KycCardVariant.Emphasized -> elevation.level2
        }
    val animatedElevation by animateDpAsState(
        targetValue = targetElevation,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-card-elevation",
    )

    Box(
        modifier =
            modifier
                .shadow(elevation = animatedElevation, shape = shapes.md)
                .clip(shapes.md)
                .background(colors.bgBase)
                .border(width = 1.dp, color = borderColor, shape = shapes.md)
                .padding(padding.value),
    ) {
        content()
    }
}
