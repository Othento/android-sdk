package com.othento.core.internal.capture

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Compose-friendly camera-permission state machine.
 *
 * Three observable values:
 *   - [status]      — current permission state.
 *   - [request]     — invoke to ask the OS (or to deep-link to system
 *                     Settings if [status] is [PermissionStatus.PermanentlyDenied]).
 *
 * Detection convention for "permanently denied" mirrors the Android
 * convention captured in spec §12-permissions §3.6:
 *   - The user has been prompted at least once this session
 *     ([wasEverRequested]) AND
 *   - the permission is currently denied AND
 *   - `shouldShowRequestPermissionRationale = false`.
 *
 * The first prompt always returns `false` for `shouldShow…` regardless of
 * outcome, so we gate on [wasEverRequested] before classifying as
 * permanent.
 */
internal class CameraPermissionState(
    private val context: Context,
    private val launchPermission: () -> Unit,
    private val openAppSettings: () -> Unit,
) {
    var status: PermissionStatus by mutableStateOf(initialStatus())
        private set

    private var wasEverRequested = false

    fun request() {
        if (status == PermissionStatus.PermanentlyDenied) {
            openAppSettings()
            return
        }
        wasEverRequested = true
        launchPermission()
    }

    /**
     * Called by the launcher's result callback. Reads the activity's
     * `shouldShowRequestPermissionRationale` to classify denied vs
     * permanently-denied.
     */
    fun onPermissionResult(granted: Boolean) {
        status =
            when {
                granted -> PermissionStatus.Granted
                wasEverRequested && !rationaleNeeded() -> PermissionStatus.PermanentlyDenied
                else -> PermissionStatus.Denied
            }
    }

    /** Refresh on resume — the user may have toggled the bit in Settings. */
    fun refresh() {
        if (status == PermissionStatus.Granted) return
        if (hasPermission()) {
            status = PermissionStatus.Granted
        }
    }

    private fun initialStatus(): PermissionStatus =
        if (hasPermission()) {
            PermissionStatus.Granted
        } else {
            PermissionStatus.Unknown
        }

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun rationaleNeeded(): Boolean {
        val activity = context.findActivity() ?: return false
        return ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.CAMERA)
    }
}

internal enum class PermissionStatus {
    Unknown,
    Granted,
    Denied,
    PermanentlyDenied,
}

/**
 * Composable factory — wraps an [ActivityResultContracts.RequestPermission]
 * launcher and an "open app settings" intent launcher.
 *
 * @param onSettingsRequested host callback for routing the user to
 *   `Settings.ACTION_APPLICATION_DETAILS_SETTINGS` (the parent screen
 *   composes the intent so the SDK doesn't need to import the system
 *   Intent class graph).
 */
@Composable
internal fun rememberCameraPermissionState(onSettingsRequested: () -> Unit): CameraPermissionState {
    val context = LocalContext.current
    val state = remember { mutableStateOf<CameraPermissionState?>(null) }
    val launcher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            state.value?.onPermissionResult(granted)
        }
    LaunchedEffect(Unit) {
        if (state.value == null) {
            state.value =
                CameraPermissionState(
                    context = context,
                    launchPermission = { launcher.launch(Manifest.permission.CAMERA) },
                    openAppSettings = onSettingsRequested,
                )
        }
    }
    return state.value
        ?: CameraPermissionState(
            context = context,
            launchPermission = { launcher.launch(Manifest.permission.CAMERA) },
            openAppSettings = onSettingsRequested,
        )
}

private fun Context.findActivity(): Activity? {
    var ctx: Context? = this
    while (ctx is android.content.ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
