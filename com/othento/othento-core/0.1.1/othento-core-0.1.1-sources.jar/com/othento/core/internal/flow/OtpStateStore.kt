package com.othento.core.internal.flow

/**
 * Per-attemptStepId record of the last successful send + the cooldown /
 * expiry timestamps the spec calls for in
 * [docs/spec/11-business-logic-and-validation.md] §10.3.
 *
 * The store is a pure value object — no coroutines, no Flow. Time-based
 * derivation (cooldown countdown / `canResend` / `isExpired`) is the
 * caller's job; passing in `now` keeps it deterministic for unit tests
 * and for the screen's 1 Hz tick. The web SDK's `OtpStateService`
 * implements the same shape with a 1s `setInterval` tick + a
 * `visibilitychange` listener (`apps/sdk/.../otp-state.service.ts:24-29`).
 *
 * Notes:
 * - **Cooldown defaults** match `OTP_DEFAULTS` (60 s send-cooldown, 600 s
 *   expiry).
 * - **Per-step**: the user can be moved between phone OTP and email OTP
 *   while the SDK is open; resetting state for the new step is the
 *   coordinator's responsibility (`resetForStep`).
 * - **lastContact** carries the contact value used for the most recent
 *   send so the "Code expired" dialog's "Send new code" CTA can re-issue
 *   without prompting for the contact again.
 */
internal class OtpStateStore {
    private var record: Record? = null

    fun snapshot(now: Long): Snapshot {
        val r = record ?: return Snapshot.Empty
        val cooldownRemaining =
            ((r.cooldownSec * MS_PER_SEC) - (now - r.sendAt))
                .coerceAtLeast(0L)
        val expired = r.expiresAtMs != null && now >= r.expiresAtMs
        val canResend = expired || cooldownRemaining == 0L
        return Snapshot(
            attemptStepId = r.attemptStepId,
            lastContact = r.lastContact,
            cooldownRemainingSec = ((cooldownRemaining + MS_PER_SEC - 1) / MS_PER_SEC).toInt(),
            isExpired = expired,
            canResend = canResend,
        )
    }

    /**
     * Records a successful send. Clears any prior record for a different
     * attemptStepId (channel rotation reset, spec §"Reset transient state
     * on step rotation").
     */
    fun recordSendSuccess(
        attemptStepId: String,
        contact: String,
        sendAt: Long,
        cooldownSec: Int = DEFAULT_COOLDOWN_SEC,
        expiresAtMs: Long? = sendAt + DEFAULT_EXPIRY_SEC * MS_PER_SEC,
    ) {
        record =
            Record(
                attemptStepId = attemptStepId,
                lastContact = contact,
                sendAt = sendAt,
                cooldownSec = cooldownSec,
                expiresAtMs = expiresAtMs,
            )
    }

    /** Drops any record. Called on screen rotation / dispose. */
    fun clear() {
        record = null
    }

    /**
     * Drops the record only if it doesn't match [attemptStepId] — the
     * resolver flips between OtpPhone and OtpEmail by changing the
     * attempt-step id; this keeps the cooldown timer alive within a
     * single OTP step but resets it when the step changes.
     */
    fun resetForStep(attemptStepId: String) {
        if (record?.attemptStepId != attemptStepId) {
            record = null
        }
    }

    /** Snapshot consumed by the screen. */
    data class Snapshot(
        val attemptStepId: String?,
        val lastContact: String?,
        val cooldownRemainingSec: Int,
        val isExpired: Boolean,
        val canResend: Boolean,
    ) {
        companion object {
            val Empty: Snapshot =
                Snapshot(
                    attemptStepId = null,
                    lastContact = null,
                    cooldownRemainingSec = 0,
                    isExpired = false,
                    canResend = true,
                )
        }
    }

    private data class Record(
        val attemptStepId: String,
        val lastContact: String,
        val sendAt: Long,
        val cooldownSec: Int,
        val expiresAtMs: Long?,
    )

    internal companion object {
        const val DEFAULT_COOLDOWN_SEC: Int = 60
        const val DEFAULT_EXPIRY_SEC: Int = 600
        private const val MS_PER_SEC: Long = 1000L
    }
}
