package com.othento.core.internal.capture

/**
 * Constants used by the V30 detection pipeline. Single source of truth —
 * never inline these magic numbers in pipeline code.
 *
 * Reference design: docs/superpowers/specs/2026-05-01-phase-6-smartcropper-detection-design.md
 */
internal object CaptureConfig {
    // ──────────────────────────────────────── Analyzer cadence ────────────────────────────────────

    /**
     * Target inference rate for the SmartCropper detection pass — the main
     * per-frame work on the single analyzer thread. Lowered from 10 to 7 to cut
     * analyzer-thread load: three detectors (SmartCropper + MRZ OCR + face)
     * share this thread over 1080p frames while FHD video encodes, and the
     * combined spike when a passport is in view drops camera frames. Auto-capture
     * timing is unaffected — the hold accumulates wall-clock ms, not frames.
     */
    const val ANALYZER_TARGET_FPS: Int = 7

    /** ML Kit Face cadence on the passport screen. Lowered from 5 to 3 to trim
     *  analyzer-thread load; the face gate is a secondary check with a 3 s grace,
     *  so a slower cadence doesn't affect auto-capture reliability. */
    const val FACE_CADENCE_FPS: Int = 3

    /** ML Kit Text cadence on passport screen. */
    const val TEXT_CADENCE_FPS: Int = 2

    /** Median-of-N window for [com.othento.core.internal.capture.detection.CornerSmoother]. */
    const val CORNER_SMOOTHING_FRAMES: Int = 5

    /** History reset if no detection arrives within this window. */
    const val CORNER_SMOOTHING_RESET_MS: Long = 300L

    /**
     * Consecutive miss frames tolerated before the hold counter resets to zero.
     * Within tolerance, [DetectionPipeline] keeps advancing the hold; past it,
     * the hold snaps back to zero.
     *
     * Kept small (2 frames, ~0.3 s at [ANALYZER_TARGET_FPS]) so the hold stops
     * climbing almost immediately when the passport leaves the frame — a larger
     * window let the timer keep advancing through the gap and auto-capture after
     * the document had already been moved away. Trade-off: brief MRZ OCR flicker
     * (recognition runs at [TEXT_CADENCE_FPS]) can make the progress arc step
     * rather than fill perfectly smoothly.
     */
    const val MISS_TOLERANCE_FRAMES: Int = 2

    // ──────────────────────────────────────── Quality scoring defaults ────────────────────────────

    /** Laplacian-of-Y variance below this is "blurry". Empirical, port from web QualityAnalyzerService. */
    const val DEFAULT_BLUR_THRESHOLD: Float = 120f

    /** Fraction of hot (Y > 235) pixels in the document region above which "glare".
     *  Web uses 0.01 as a pre-filter for blob analysis; we use the same value. */
    const val DEFAULT_GLARE_THRESHOLD: Float = 0.01f

    /** Lower bound of acceptable mean Y-plane luminance (inclusive). */
    const val DEFAULT_BRIGHTNESS_MIN: Int = 55

    /** Upper bound of acceptable mean Y-plane luminance (inclusive). */
    const val DEFAULT_BRIGHTNESS_MAX: Int = 210

    /** Mean Y-plane luminance must lie inside this range. */
    val DEFAULT_BRIGHTNESS_RANGE: IntRange = DEFAULT_BRIGHTNESS_MIN..DEFAULT_BRIGHTNESS_MAX

    // ──────────────────────────────────────── Passport MRZ alignment ──────────────────────────────

    /** Min clear margin required on EACH side of the MRZ (fraction of cutout
     *  width). Below it on both sides → zoomed in (too close); below it on one
     *  side → passport shoved that way. Web SDK capture.config.ts
     *  `mrzSideMarginMin` (749ea45). */
    const val MRZ_SIDE_MARGIN_MIN: Float = 0.06f

    /** Min MRZ horizontal coverage of the cutout width. Below it the passport is
     *  too far/small — guards against a tiny centered passport reading as
     *  aligned. Web SDK `minMrzWidthCoverage` (749ea45). */
    const val MIN_MRZ_WIDTH_COVERAGE: Float = 0.7f

    /** Min box aspect ratio (long/short side) for an ML Kit OCR line to count
     *  toward the MRZ extent. Separates the wide MRZ band(s) from printed
     *  name/date fields (~10-15:1). Set below the 25:1 match threshold to
     *  tolerate mild ML Kit line fragmentation.
     *
     *  No web SDK analogue: the web measures the MRZ extent from pixel
     *  transition-density (`computeDenseExtent`), whereas this SDK reads ML Kit
     *  semantic line boxes — so this is an Android-specific knob. `18f` is an
     *  empirical starting point; calibrate on device via the `frm=`/aspect
     *  debug readout. */
    const val MRZ_EXTENT_MIN_ASPECT: Float = 18f

    /** Min clearance (fraction of cutout width) between the passport photo's
     *  face box and the cutout's left/right edges. Rejects a passport whose
     *  photo is clipped at a side. Web SDK `faceEdgeMargin` (749ea45). */
    const val FACE_EDGE_MARGIN: Float = 0.02f

    // ──────────────────────────────────────── Capture timeout ────────────────────────────────────

    /**
     * Document camera timeout — same 45 s window as the selfie screen
     * (`SelfieConfig.CAMERA_TIMEOUT_MS`). If the user hasn't captured manually
     * or via auto-detect in this window, the screen flips to the timeout
     * state. Restarts each time the intro sheet is dismissed.
     */
    const val CAMERA_TIMEOUT_MS: Long = 45_000L

    // ──────────────────────────────────────── Stream resolution ──────────────────────────────────

    /**
     * Target resolution (sensor-landscape, 16:9) for the document PREVIEW
     * stream. Dropped to 720p so the preview, the 1080p analysis stream (which
     * MRZ OCR needs), and the VideoCapture stream aren't all competing for the
     * back camera's high-res surface budget — freeing the recorded/uploaded clip
     * to bind at FHD instead of falling back to 720p. Visually free on an HD/HD+
     * screen; the preview pixels only feed the on-screen surface, while the
     * upload comes from the video stream and detection uses the analysis frames
     * and view coordinates, not the preview.
     */
    const val PREVIEW_TARGET_WIDTH: Int = 1_280
    const val PREVIEW_TARGET_HEIGHT: Int = 720

    // ──────────────────────────────────────── Video recording ─────────────────────────────────────

    /**
     * Rolling-window length the trimmed MP4 covers. Mirrors the web SDK's
     * `videoWindowMs = 4_000` (apps/sdk/src/app/config/capture.config.ts:21).
     * The on-disk scratch file may be longer; the trim-on-capture step
     * keeps only the last [VIDEO_WINDOW_MS] of footage, keyframe-aligned.
     */
    const val VIDEO_WINDOW_MS: Long = 4_000L

    /**
     * Encoder target bitrate. 5 Mbps left a 1080p moving-face clip visibly soft;
     * at 4 s × 12 Mbps a trimmed clip lands ~6 MB — still comfortably under the
     * 10 MB upload cap while keeping the face and any on-card text sharp.
     *
     * NOTE: this only helps if the recording is actually 1080p. The selfie flow
     * binds three streams on the front camera (Preview + ImageAnalysis +
     * VideoCapture); on constrained devices CameraX may downgrade the video
     * stream below FHD regardless of bitrate. If footage is still soft after this
     * bump, the next suspect is that 3-stream bind, not the bitrate.
     */
    const val VIDEO_BITS_PER_SECOND: Int = 12_000_000
}
