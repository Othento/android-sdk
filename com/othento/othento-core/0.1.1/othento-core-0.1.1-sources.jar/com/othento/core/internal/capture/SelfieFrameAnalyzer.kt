package com.othento.core.internal.capture

import android.graphics.RectF
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.othento.core.internal.capture.detection.face.FaceBox
import com.othento.core.internal.capture.detection.face.FaceDetectorClient
import com.othento.core.internal.capture.detection.face.OvalRoi

/**
 * Adapts CameraX `ImageAnalysis` into the selfie pipeline.
 *
 * Per-frame work:
 * 1. Cadence: drop frames faster than [intervalMs] (~5 Hz default).
 * 2. Build an [InputImage] via [InputImage.fromMediaImage] (zero-copy —
 *    ML Kit reads the YUV planes directly).
 * 3. Compute the oval ROI in the post-rotation image's coord space using
 *    [SelfieConfig.ROI_WIDTH_RATIO] / [SelfieConfig.ROI_HEIGHT_TO_WIDTH_RATIO]
 *    — same proportions the on-screen overlay uses, so face-vs-oval
 *    decisions match what the user sees.
 * 4. Pack the Y-plane and compute mean face brightness so the pipeline
 *    can gate on too-dark / too-bright conditions.
 * 5. Hand off to [FaceDetectorClient.scheduleLatest]. The completion
 *    callback maps `Face.boundingBox` → [FaceBox] and feeds the pipeline.
 *
 * The proxy is held until ML Kit finishes (`InputImage.fromMediaImage`
 * holds a reference into the underlying Image's planes). `image.close()`
 * runs in the completion callback, never inside `analyze()`. CameraX'
 * `STRATEGY_KEEP_ONLY_LATEST` plus the cadence guard above keeps the
 * analyzer thread from queueing.
 */
internal class SelfieFrameAnalyzer(
    private val pipeline: SelfieDetectionPipeline,
    private val client: FaceDetectorClient,
    private val intervalMs: Long = SelfieConfig.DETECTION_INTERVAL_MS,
) : ImageAnalysis.Analyzer {
    private var lastAnalyzedAt = 0L

    @androidx.camera.core.ExperimentalGetImage
    @Suppress("ReturnCount", "TooGenericExceptionCaught")
    // Reason: each early return is a distinct skip guard (cadence /
    // detector busy / no media image). The broad catch is deliberate — see
    // the `handedOff` note below: ANY throw on the per-frame path must close
    // the proxy, not propagate, or detection freezes permanently.
    override fun analyze(image: ImageProxy) {
        // The proxy MUST be closed exactly once on every path. The analysis
        // stream is bound with STRATEGY_KEEP_ONLY_LATEST, so CameraX delivers
        // the next frame only after this proxy is closed — a single leaked
        // (never-closed) proxy halts frame delivery forever, freezing BOTH
        // auto and manual detection. Once `scheduleLatest` is reached the async
        // detector callback owns the close (`handedOff = true`); the `finally`
        // below covers every other path: an early skip-guard `return`, or a
        // throw while building the frame (notably a device-specific Y-plane
        // layout in `sceneBrightness`, or `fromMediaImage` rejecting the image).
        var handedOff = false
        try {
            val now = System.currentTimeMillis()
            if (now - lastAnalyzedAt < intervalMs) return
            // Skip when the prior detection task is still running. Without
            // this guard we'd build an InputImage every cadence tick (~5 fps)
            // even though FaceDetectorClient would drop the call synchronously.
            if (client.isBusy()) return

            val mediaImage = image.image ?: return
            // Advance the cadence clock only after we know the call will be
            // scheduled — otherwise back-pressure from a slow detector starves
            // detection by sliding the cadence window forward on every dropped tick.
            lastAnalyzedAt = now

            val rotation = image.imageInfo.rotationDegrees
            val isPortrait = rotation == ROTATION_90 || rotation == ROTATION_270
            val rotatedWidth = (if (isPortrait) image.height else image.width).toFloat()
            val rotatedHeight = (if (isPortrait) image.width else image.height).toFloat()
            val oval = OvalRoi.centered(rotatedWidth, rotatedHeight)

            val sceneBrightness = sceneBrightness(image)

            val inputImage = InputImage.fromMediaImage(mediaImage, rotation)
            client.scheduleLatest(inputImage) { faces, _ ->
                try {
                    if (faces != null) {
                        pipeline.process(faces = faces.toFaceBoxes(), oval = oval, faceBrightness = sceneBrightness)
                    }
                } finally {
                    image.close()
                }
            }
            handedOff = true
        } catch (t: Throwable) {
            // A malformed frame must never kill the stream. Drop it; the
            // `finally` closes the proxy so CameraX delivers the next frame
            // and detection keeps running.
            Log.w(TAG, "frame dropped: ${t.message}")
        } finally {
            if (!handedOff) image.close()
        }
    }

    /**
     * Mean Y-plane brightness over the full frame, or `null` when it can't be
     * read. Scene-level brightness is what matters for the too-dark / too-bright
     * warning — if the environment is dark the whole frame is dark. Avoids the
     * complexity of reverse-rotating the ML Kit face bbox into sensor coords.
     *
     * Returns null rather than throwing on any device whose Y-plane stride or
     * buffer limit doesn't match the row-major assumption: a thrown read here
     * would leave the [ImageProxy] unclosed and freeze the analyzer (see
     * [analyze]). Each index is bounds-checked against the buffer limit and the
     * whole pass is wrapped, so a short or oddly-strided plane degrades to "no
     * brightness data" — which the downstream gate treats as skip, keeping
     * detection alive. Must be called before `image.close()`.
     */
    private fun sceneBrightness(image: ImageProxy): Int? =
        runCatching {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val rowStride = plane.rowStride
            val limit = buffer.limit()
            val w = image.width
            val h = image.height
            var sum = 0L
            var count = 0L
            for (y in 0 until h) {
                val rowStart = y * rowStride
                for (x in 0 until w) {
                    val idx = rowStart + x
                    if (idx >= limit) break
                    sum += (buffer.get(idx).toInt() and 0xFF)
                    count++
                }
            }
            if (count == 0L) null else (sum / count).toInt()
        }.getOrNull()

    /** Map ML Kit faces to the pipeline's source-px [FaceBox] type. */
    private fun List<Face>.toFaceBoxes(): List<FaceBox> =
        map { f ->
            val r = f.boundingBox
            FaceBox(box = RectF(r.left.toFloat(), r.top.toFloat(), r.right.toFloat(), r.bottom.toFloat()))
        }

    private companion object {
        const val TAG: String = "SelfieFrameAnalyzer"
        const val ROTATION_90: Int = 90
        const val ROTATION_270: Int = 270
    }
}
