@file:Suppress(
    "LongParameterList",
    // Reason: all 7 constructor parameters are independent configuration knobs
    // (pipeline, cutout source, three fps cadences, two optional ML Kit sub-detectors).
    // Folding them into a config data class would add indirection without benefit for
    // this internal class.
)

package com.othento.core.internal.capture

import android.graphics.Rect
import android.graphics.RectF
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.othento.core.internal.capture.detection.passport.MrzDetector
import com.othento.core.internal.capture.detection.passport.PassportPhotoGate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Adapts CameraX's `ImageAnalysis.Analyzer` callback to a [DetectionPipeline].
 *
 * Cadence: enforced by sleeping between frames if processing finishes faster
 * than 1/[targetFps]. CameraX's `STRATEGY_KEEP_ONLY_LATEST` ensures we drop
 * frames if processing falls behind — we never queue.
 *
 * For passport screens, [mrz] and [faceGate] schedule their own ML Kit work
 * at independent cadences ([mrzFps] and [faceFps]) — the analyzer fires off
 * those scheduled calls in addition to the main detection pass. ML Kit
 * results are read from `snapshot()` by the pipeline on its next tick.
 *
 * The cutout is supplied as a [RectF] of view-normalized fractions (0..1)
 * where (0,0) is the upright top-left and (1,1) is the upright bottom-right
 * of the camera viewport on screen. The analyzer converts these fractions
 * to per-frame image-coord [Rect]s using `image.width`, `image.height`, and
 * `image.imageInfo.rotationDegrees`. This decouples detection from the
 * preview/analysis resolution mismatch that arises when CameraX hands
 * different surfaces different sizes (typical when `VideoCapture` joins
 * the bind).
 */
internal class FrameAnalyzer(
    private val pipeline: DetectionPipeline,
    private val cutoutFractionProvider: () -> RectF,
    private val targetFps: Int = CaptureConfig.ANALYZER_TARGET_FPS,
    private val mrz: MrzDetector? = null,
    private val faceGate: PassportPhotoGate? = null,
    private val mrzFps: Int = CaptureConfig.TEXT_CADENCE_FPS,
    private val faceFps: Int = CaptureConfig.FACE_CADENCE_FPS,
) : ImageAnalysis.Analyzer {
    private var lastProcessedAtNs = 0L
    private var lastMrzAtNs = 0L
    private var lastFaceAtNs = 0L
    private val periodNs: Long = NS_PER_SECOND / targetFps.coerceAtLeast(1)
    private val mrzPeriodNs: Long = NS_PER_SECOND / mrzFps.coerceAtLeast(1)
    private val facePeriodNs: Long = NS_PER_SECOND / faceFps.coerceAtLeast(1)

    /** Cumulative number of frames delivered by CameraX to [analyze], including cadence-skipped frames. */
    private val _frameCount = MutableStateFlow(0)
    val frameCount: StateFlow<Int> = _frameCount.asStateFlow()

    /** Last unhandled exception caught from the pipeline. Empty when no failure. */
    private val _lastError = MutableStateFlow("")
    val lastError: StateFlow<String> = _lastError.asStateFlow()

    /**
     * Diagnostic: dimensions and rotationDegrees of the last delivered ImageProxy,
     * formatted as "WxH rot=N". Consumed by the debug overlay so the human can
     * verify the cutout rect (in claimed sensor coords) actually lines up with
     * the analyzer frame's coordinate space.
     */
    private val _lastFrameInfo = MutableStateFlow("")
    val lastFrameInfo: StateFlow<String> = _lastFrameInfo.asStateFlow()

    /**
     * Diagnostic: the most recent image-coord cutout rect the pipeline saw,
     * formatted as "L,T,R,B". Surfaced to the debug overlay so divergence
     * between the cutout and the analyzer frame's bounds is visible.
     */
    private val _lastCutout = MutableStateFlow("")
    val lastCutout: StateFlow<String> = _lastCutout.asStateFlow()

    /**
     * Structured image dimensions for the most recent ImageProxy: (width,
     * height, rotationDegrees). Consumed by the live polygon overlay to
     * map detected corners (in unrotated image coords) into upright view
     * fractions, the same projection used by [computeCutoutInImageCoords]
     * but in reverse. Defaults to (0, 0, 0) before the first frame.
     */
    private val _lastFrameDims = MutableStateFlow(Triple(0, 0, 0))
    val lastFrameDims: StateFlow<Triple<Int, Int, Int>> = _lastFrameDims.asStateFlow()

    override fun analyze(image: ImageProxy) {
        _frameCount.value = _frameCount.value + 1
        _lastFrameInfo.value = "${image.width}x${image.height} rot=${image.imageInfo.rotationDegrees}"
        _lastFrameDims.value = Triple(image.width, image.height, image.imageInfo.rotationDegrees)
        try {
            // Defensive top-level catch: any failure inside the detection pipeline
            // (OOM, native exception bubbled up from SmartCropper, NPE on a bad
            // frame layout, etc.) must not propagate — it would crash the analyzer
            // thread and the host app. The pipeline owns its own debug-reason
            // surface, but `_lastError` is the Java-level escape-hatch.
            runCatching { runPipeline(image) }
                .onFailure { e ->
                    _lastError.value = "${e.javaClass.simpleName}: ${e.message ?: "<no msg>"}"
                }
        } finally {
            image.close()
        }
    }

    /** Internal pipeline body — extracted so it can be wrapped in [runCatching]. */
    private fun runPipeline(image: ImageProxy) {
        val nowNs = System.nanoTime()
        val cutout = computeCutoutInImageCoords(image)
        _lastCutout.value = "${cutout.left},${cutout.top},${cutout.right},${cutout.bottom}"

        if (nowNs - lastMrzAtNs >= mrzPeriodNs) {
            runCatching { mrz?.schedule(image, cutoutFractionProvider()) }
            lastMrzAtNs = nowNs
        }
        if (nowNs - lastFaceAtNs >= facePeriodNs) {
            runCatching { faceGate?.schedule(image, cutout) }
            lastFaceAtNs = nowNs
        }

        if (nowNs - lastProcessedAtNs < periodNs) return
        lastProcessedAtNs = nowNs

        // Strip Y-plane padding so the pipeline can index by image.width.
        // On most devices rowStride == image.width, but some pad rows to a
        // 16/64 byte boundary — copy row-by-row to be safe.
        val yPlane = image.planes[0]
        val rowStride = yPlane.rowStride
        val packed = ByteArray(image.width * image.height)
        if (rowStride == image.width) {
            yPlane.buffer.get(packed)
        } else {
            val rowBuf = ByteArray(rowStride)
            val buf = yPlane.buffer
            for (y in 0 until image.height) {
                buf.position(y * rowStride)
                buf.get(rowBuf, 0, image.width)
                System.arraycopy(rowBuf, 0, packed, y * image.width, image.width)
            }
        }
        pipeline.process(image, cutout, packed)
    }

    /**
     * Convert the upright view-normalized cutout fractions to a [Rect] in
     * the [image]'s native (unrotated) coordinate system, so it can be used
     * directly with [ImageProxy.getPlanes] sample addressing.
     *
     * `image.imageInfo.rotationDegrees` is the rotation that would put the
     * image upright (matching what the user sees on screen). We invert that
     * mapping to project the upright fractions back into the unrotated
     * image's pixel grid.
     */
    private fun computeCutoutInImageCoords(image: ImageProxy): Rect {
        val frac = cutoutFractionProvider()
        if (frac.isEmpty) return Rect()
        val w = image.width
        val h = image.height
        val rotation = ((image.imageInfo.rotationDegrees % FULL_TURN_DEG) + FULL_TURN_DEG) % FULL_TURN_DEG
        // After rotation by `rotation` degrees CW, an upright box (l, t, r, b)
        // maps to the unrotated image coords below. The math here is
        // "for each upright corner, find the original-image pixel that
        // lands at that screen position after rotation".
        return when (rotation) {
            QUARTER_TURN_DEG -> {
                // Image is landscape; rotated 90° CW becomes upright portrait.
                // Upright (x, y) ↔ image (y * w, (1-x) * h), but axes swap so:
                // upright width fraction → image y range,
                // upright height fraction → image x range (flipped).
                Rect(
                    ((1f - frac.bottom) * w).toInt().coerceIn(0, w),
                    (frac.left * h).toInt().coerceIn(0, h),
                    ((1f - frac.top) * w).toInt().coerceIn(0, w),
                    (frac.right * h).toInt().coerceIn(0, h),
                )
            }
            HALF_TURN_DEG -> {
                Rect(
                    ((1f - frac.right) * w).toInt().coerceIn(0, w),
                    ((1f - frac.bottom) * h).toInt().coerceIn(0, h),
                    ((1f - frac.left) * w).toInt().coerceIn(0, w),
                    ((1f - frac.top) * h).toInt().coerceIn(0, h),
                )
            }
            THREE_QUARTER_TURN_DEG -> {
                Rect(
                    (frac.top * w).toInt().coerceIn(0, w),
                    ((1f - frac.right) * h).toInt().coerceIn(0, h),
                    (frac.bottom * w).toInt().coerceIn(0, h),
                    ((1f - frac.left) * h).toInt().coerceIn(0, h),
                )
            }
            else -> {
                // rotation = 0 — image is already upright.
                Rect(
                    (frac.left * w).toInt().coerceIn(0, w),
                    (frac.top * h).toInt().coerceIn(0, h),
                    (frac.right * w).toInt().coerceIn(0, w),
                    (frac.bottom * h).toInt().coerceIn(0, h),
                )
            }
        }
    }

    private companion object {
        const val NS_PER_SECOND: Long = 1_000_000_000L
        const val QUARTER_TURN_DEG: Int = 90
        const val HALF_TURN_DEG: Int = 180
        const val THREE_QUARTER_TURN_DEG: Int = 270
        const val FULL_TURN_DEG: Int = 360
    }
}
