package com.othento.core.internal.ui.screens.common

import com.othento.core.internal.data.model.Session

/**
 * Data for the FailedRetry attempts meter. Faithful port of the web SDK's
 * `failed-retry-screen.ts#attempts` computed signal.
 *
 * The remaining count prefers the backend's authoritative
 * `reinitInfo.attemptsRemaining`, falling back to the client-side
 * `maxAttempts - attemptNumber` when `reinitInfo` is absent. [from] returns
 * `null` when no reliable count exists or no attempts remain, so the meter
 * degrades gracefully (hidden) rather than showing "0 tries left".
 */
internal data class RetryAttempts(
    /** Total attempts the session allows. */
    val total: Int,
    /** Attempts the user still has, including this one. */
    val remaining: Int,
    /** Attempts already used (including the one that just failed). */
    val spent: Int,
) {
    /** Pip flags ordered spent-first: `true` = spent, `false` = remaining. */
    val pips: List<Boolean> = List(total) { it < spent }

    companion object {
        fun from(session: Session): RetryAttempts? {
            val remainingRaw =
                session.reinitInfo?.attemptsRemaining
                    ?: if (session.maxAttempts > 0) session.maxAttempts - session.attemptNumber else null
            val remaining = (remainingRaw ?: return null).coerceAtLeast(0)
            if (remaining < 1) return null

            val total =
                if (session.maxAttempts > 0 && session.maxAttempts >= remaining) {
                    session.maxAttempts
                } else {
                    remaining
                }
            return RetryAttempts(total = total, remaining = remaining, spent = total - remaining)
        }
    }
}
