package com.othento.core.internal.network

import android.content.ContentResolver
import android.net.Uri
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import okio.BufferedSink
import okio.buffer
import okio.source
import java.io.IOException

/**
 * OkHttp [RequestBody] that streams a [Uri] through the host's
 * [ContentResolver] and emits progress callbacks as bytes flow into the
 * sink.
 *
 * Mirrors the web SDK's `S3UploadService.putToS3` HTTP `reportProgress`
 * contract — for every `UploadProgress` event we hand `(bytesSent,
 * totalBytes)` to [progressCallback]. The flow layer turns that into
 * `0..99` percent values surfaced via `FlowUiState.uploadProgress`.
 *
 * **Re-opens on retry.** Each `writeTo(sink)` call re-opens the
 * `InputStream` from the resolver. The SDK does not enable OkHttp's
 * automatic retry (`retryOnConnectionFailure=false` per spec §3.3), but
 * libraries can retry interceptors; re-opening keeps the body idempotent.
 *
 * @property contentLengthValue the resolved content length (bytes). Caller
 *                              must compute via
 *                              [com.othento.core.internal.util.ImageInfo]
 *                              before construction — OkHttp uses it to set
 *                              `Content-Length` and the progress denominator.
 */
internal class ProgressRequestBody(
    private val uri: Uri,
    private val contentResolver: ContentResolver,
    private val contentTypeValue: String,
    private val contentLengthValue: Long,
    private val progressCallback: (bytesSent: Long, totalBytes: Long) -> Unit,
) : RequestBody() {
    override fun contentType(): MediaType? = contentTypeValue.toMediaTypeOrNull()

    override fun contentLength(): Long = contentLengthValue

    override fun writeTo(sink: BufferedSink) {
        val stream =
            contentResolver.openInputStream(uri)
                ?: throw IOException("ContentResolver returned null InputStream for $uri")
        stream.source().buffer().use { source -> copyWithProgress(source, sink) }
    }

    private fun copyWithProgress(
        source: okio.BufferedSource,
        sink: BufferedSink,
    ) {
        var bytesSent = 0L
        val buffer = okio.Buffer()
        while (true) {
            val read = source.read(buffer, BUFFER_SIZE)
            if (read == -1L) break
            sink.write(buffer, read)
            bytesSent += read
            progressCallback(bytesSent, contentLengthValue)
        }
    }

    private companion object {
        const val BUFFER_SIZE: Long = 8L * 1024L
    }
}
