package com.othento.core.internal.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Diagnostic HUD rendered on top of the live camera preview. Surfaces
 * everything we need to confirm on device whether `ImageAnalysis` is
 * receiving frames at the expected resolution and whether the cutout
 * rect is actually inside that frame.
 *
 * Lines (each conditional on a non-empty value):
 * - `frames: N` — cumulative frames delivered to the analyzer.
 * - frame info `WxH rot=N` — last delivered ImageProxy dims + rotation.
 * - `prev/anal: WxHxWxH` — Preview vs Analysis resolutions from
 *   `resolutionInfo` (if Preview and Analysis are at different sizes,
 *   the cutout may sit outside the analysis frame).
 * - `cut: L,T,R,B` — the cutout rect handed to the detector.
 * - `state: <name>` — current pipeline state (Idle/Searching/Holding/
 *   ReadyToCapture/Captured).
 *
 * Diagnostic-only — pull once we ship if not needed by hosts.
 */
@Composable
internal fun DetectionDebugHud(
    frameCount: Int,
    frameInfo: String,
    bindInfo: String,
    cutoutInfo: String,
    pipelineState: String,
    pipelineReason: String = "",
    mrzInfo: String = "",
    modifier: Modifier = Modifier,
) {
    Column(
        modifier =
            modifier
                .padding(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color.Black.copy(alpha = 0.55f))
                .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
        horizontalAlignment = Alignment.Start,
    ) {
        DebugLine("frames: $frameCount")
        if (frameInfo.isNotEmpty()) DebugLine(frameInfo)
        if (bindInfo.isNotEmpty()) DebugLine(bindInfo)
        if (cutoutInfo.isNotEmpty()) DebugLine(cutoutInfo)
        if (pipelineState.isNotEmpty()) DebugLine("state: $pipelineState")
        if (pipelineReason.isNotEmpty()) DebugLine("why: $pipelineReason")
        if (mrzInfo.isNotEmpty()) DebugLine(mrzInfo)
    }
}

@Composable
private fun DebugLine(text: String) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        fontFamily = FontFamily.Monospace,
    )
}
