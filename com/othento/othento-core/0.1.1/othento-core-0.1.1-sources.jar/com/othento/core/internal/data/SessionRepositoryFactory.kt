package com.othento.core.internal.data

import android.content.ContentResolver
import android.content.Context
import com.othento.core.internal.network.OthentoHttpClientFactory
import com.othento.core.internal.network.EncryptedTokenPrefs
import com.othento.core.internal.network.EnvironmentResolver
import com.othento.core.internal.network.TokenStore
import com.othento.core.api.OthentoConfig
import com.othento.core.api.OthentoMode

/**
 * Builds the per-launch repository bundle the FlowCoordinator pulls from.
 *
 * Phase 3 cached an `OthentoHttpStack` per `(apiKey, baseUrl)` pair to avoid
 * leaking OkHttp clients across the sample's "Fetch Session" taps. Phase 5
 * removes the cache: each launch mints its own [TokenStore] (so concurrent
 * launches don't share token state), and the `OkHttpClient` is light enough
 * that one-per-launch is fine. The cost is one OkHttp client per
 * `OthentoSDK.launch(...)` — not per HTTP call.
 *
 * The host's [ContentResolver] is required by [UploadRepository] to stream
 * the user's chosen `Uri` into the S3 PUT.
 */
internal object SessionRepositoryFactory {
    fun create(
        config: OthentoConfig,
        contentResolver: ContentResolver,
        appContext: Context? = null,
    ): RepositoryStack {
        val baseUrl = EnvironmentResolver.resolveBaseUrl(config)
        val tokenStore = TokenStore()
        val tokenPrefs: EncryptedTokenPrefs? =
            appContext
                ?.let { ctx -> EncryptedTokenPrefs.createOrNull(ctx) }
                ?.also { tokenStore.enablePersistence(it) }
        // Token mode: seed the SAT into the store BEFORE the first
        // outbound call so the TokenInterceptor attaches X-SAT.
        if (config.mode is OthentoMode.Token) {
            tokenStore.seedSat(config.mode.sat)
            // Best-effort rehydrate: if a prior bundle was persisted for
            // this SAT, restore ST/SRT into memory so the next call uses
            // them (skipping the SAT round-trip). Falls through silently
            // when no bundle is present.
            if (tokenPrefs != null) {
                val sessionId = tokenPrefs.lookupSessionId(config.mode.sat)
                if (sessionId != null) {
                    tokenStore.rehydrate(
                        sessionId = sessionId,
                        urlSat = config.mode.sat,
                        prefs = tokenPrefs,
                    )
                }
            }
        }
        // Defense in depth: when the host launched in Token mode, drop
        // the apiKey from the HTTP stack even if the Builder was passed
        // one. The TokenInterceptor handles X-SAT/X-ST/X-SRT exclusively
        // in this mode; leaving X-API-KEY wired would leak the key on
        // the create-session call (which Token mode skips, but the
        // interceptor matches by host + path, not by mode).
        val effectiveApiKey = if (config.mode is OthentoMode.Token) null else config.apiKey
        val stack =
            OthentoHttpClientFactory.create(
                apiKey = effectiveApiKey,
                baseUrl = baseUrl,
                tokenStore = tokenStore,
                loggingEnabled = config.loggingEnabled,
            )
        val sessionRepository =
            ApiKeySessionRepository(
                api = stack.api,
                errorMapper = stack.errorMapper,
                tokenStore = stack.tokenStore,
            )
        val documentRepository = DocumentRepository(sessionRepository)
        val uploadRepository: UploadRepository =
            UploadRepositoryImpl(
                api = stack.api,
                errorMapper = stack.errorMapper,
                sessionRepository = sessionRepository,
                tokenStore = stack.tokenStore,
                okHttpClient = stack.okHttpClient,
                contentResolver = contentResolver,
            )
        val otpRepository: OtpRepository =
            OtpRepositoryImpl(
                api = stack.api,
                tokenStore = stack.tokenStore,
            )
        return RepositoryStack(
            sessionRepository = sessionRepository,
            documentRepository = documentRepository,
            uploadRepository = uploadRepository,
            otpRepository = otpRepository,
            tokenStore = tokenStore,
        )
    }
}

/**
 * Bundle of the per-launch repository wiring the FlowCoordinator depends on.
 * Held by reference until the launching Activity finishes.
 */
internal data class RepositoryStack(
    val sessionRepository: SessionRepository,
    val documentRepository: DocumentRepository,
    val uploadRepository: UploadRepository,
    val otpRepository: OtpRepository,
    val tokenStore: TokenStore,
)
