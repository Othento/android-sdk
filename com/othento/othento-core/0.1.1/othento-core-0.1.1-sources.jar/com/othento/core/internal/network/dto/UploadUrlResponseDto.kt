package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass

/**
 * Wire response for `GET .../upload-url`.
 *
 * Mirrors [docs/spec/09-data-models.md §3.6]. Used by the S3 upload pipeline
 * starting in Phase 5; defined now so the DTO catalogue is complete.
 */
@JsonClass(generateAdapter = true)
internal data class UploadUrlResponseDto(
    val uploadUrl: String,
    val expiresAt: String,
    val contentType: String,
)
