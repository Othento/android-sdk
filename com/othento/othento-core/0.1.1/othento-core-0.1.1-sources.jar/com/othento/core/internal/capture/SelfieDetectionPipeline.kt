package com.othento.core.internal.capture

import com.othento.core.internal.capture.detection.face.FaceBox
import com.othento.core.internal.capture.detection.face.OvalRoi
import com.othento.core.internal.capture.detection.face.SelfieFaceAnalyzer
import com.othento.core.internal.capture.detection.face.SelfieGuidance
import com.othento.core.internal.capture.detection.face.SelfieHint
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.ceil
import kotlin.math.max

/**
 * Phase 7 selfie state machine. One instance per
 * [com.othento.core.internal.ui.screens.SelfieCaptureScreen]; owns one
 * [SelfieGuidance] and a [MutableStateFlow] of the current
 * [SelfieDetectionState].
 *
 * The screen calls [process] on every detector frame. Auto-capture fires
 * when [state] transitions to [SelfieDetectionState.ReadyToCapture].
 *
 * The capture-delay window — during which [state] stays in
 * [SelfieDetectionState.CaptureBlocked] regardless of detection — uses an
 * injected [Clock] so unit tests don't need real wall time.
 */
@Suppress("LongParameterList")
// Reason: each constructor knob is an independent tunable mirroring the web
// SDK's selfie.config.ts (capture delay, stability duration, tolerance,
// detection interval, clock, guidance). Tests inject several of these
// individually; rolling them into a config object would push test boilerplate
// into every call site without simplifying production code.
internal class SelfieDetectionPipeline(
    private val cameraStartedAt: Long,
    private val captureDelayMs: Long = SelfieConfig.CAPTURE_DELAY_MS,
    private val durationMs: Long = SelfieConfig.AUTO_CAPTURE_DURATION_MS,
    private val toleranceRatio: Float = SelfieConfig.AUTO_CAPTURE_TOLERANCE_RATIO,
    private val detectionIntervalMs: Long = SelfieConfig.DETECTION_INTERVAL_MS,
    private val clock: Clock = Clock { System.currentTimeMillis() },
    private val guidance: SelfieGuidance = SelfieGuidance(),
) {
    /**
     * Stability target: how many qualifying detections in a row to require.
     * Mirrors the web `selfie-auto-capture.service.ts`'s frame-count derivation
     * (`durationMs / detectionIntervalMs`, floor 1).
     */
    private val stabilityFramesRequired: Int =
        max(1, (durationMs / detectionIntervalMs).toInt())

    /**
     * Tolerance ceiling — missed-frame counter resets the stability window
     * when it exceeds this. Web: `ceil(durationMs * toleranceRatio /
     * detectionIntervalMs)`.
     */
    private val maxMissedFrames: Int =
        max(1, ceil(durationMs * toleranceRatio / detectionIntervalMs).toInt())

    private var consecutiveMisses = 0
    private var framesHeld = 0
    private var paused = false

    private val _state = MutableStateFlow<SelfieDetectionState>(SelfieDetectionState.Idle)
    val state: StateFlow<SelfieDetectionState> = _state.asStateFlow()

    /**
     * One detection frame.
     *
     * - [faces] — every face in the source-image px coords.
     * - [oval] — oval ROI in the same coord space.
     * - [faceBrightness] — mean Y-plane luminance over the largest face's
     *   bbox, or `null` when the screen can't compute it on this frame.
     *
     * `@Suppress("ReturnCount")` reason: each early return exits a distinct
     * gate (already-captured guard → capture-delay window → quality issue
     * → face-in-ROI). Folding into a single boolean expression hides the
     * gate-by-gate flow that mirrors the web SDK's selfie-auto-capture.
     */
    @Suppress("ReturnCount")
    fun process(
        faces: List<FaceBox>,
        oval: OvalRoi,
        faceBrightness: Int?,
    ) {
        if (_state.value is SelfieDetectionState.Captured) return
        if (paused) return

        val now = clock.nowMs()
        // Capture-delay window — block any auto-capture path until the
        // recorder has buffered enough footage. The screen still gets
        // hint strings during this period via Searching, but we override
        // to CaptureBlocked here so the status pill copy stays neutral.
        if (now - cameraStartedAt < captureDelayMs) {
            _state.value = SelfieDetectionState.CaptureBlocked
            consecutiveMisses = 0
            framesHeld = 0
            return
        }

        val verdict = SelfieFaceAnalyzer.analyze(faces, oval, faceBrightness)
        val stickyHint = guidance.applyHint(verdict.hint, now)
        val stickyWarning = guidance.applyWarning(verdict.warning, now)

        if (verdict.hasQualityIssue) {
            // Quality issues reset the stability counter immediately
            // (no tolerance) per spec §7.7.
            consecutiveMisses = 0
            framesHeld = 0
            _state.value = SelfieDetectionState.Searching(stickyHint, stickyWarning)
            return
        }

        if (verdict.faceInRoi) {
            consecutiveMisses = 0
            framesHeld += 1
            _state.value =
                if (framesHeld >= stabilityFramesRequired) {
                    SelfieDetectionState.ReadyToCapture
                } else {
                    SelfieDetectionState.Holding(
                        framesHeld = framesHeld,
                        target = stabilityFramesRequired,
                        warning = stickyWarning,
                    )
                }
            return
        }

        // No qualifying face but no quality issue either (e.g. transient
        // detector miss while the user holds steady). Increment the miss
        // counter and only reset when it exceeds the tolerance.
        consecutiveMisses += 1
        if (consecutiveMisses > maxMissedFrames) {
            framesHeld = 0
        }
        _state.value = SelfieDetectionState.Searching(stickyHint, stickyWarning)
    }

    /** Called by the screen once auto-capture (or manual) has fired. */
    fun markCaptured() {
        _state.value = SelfieDetectionState.Captured
    }

    /** Called on Retake to resume detection. */
    fun reset() {
        consecutiveMisses = 0
        framesHeld = 0
        _state.value = SelfieDetectionState.Idle
    }

    /**
     * Suspend frame processing while the intro bottom sheet is visible. Entering
     * pause also resets the stability counter so the post-dismissal hold rebuilds
     * from zero — otherwise a partial Holding window would race auto-capture the
     * moment the sheet closes.
     */
    fun setPaused(value: Boolean) {
        if (paused == value) return
        paused = value
        if (value) reset()
    }

    /** Stability target — exposed so the screen can show "x/y" diagnostics. */
    fun stabilityTarget(): Int = stabilityFramesRequired

    /**
     * Source of "now" for the capture-delay + sticky-message gates. Default
     * uses [System.currentTimeMillis]; tests inject a mutable clock.
     */
    internal fun interface Clock {
        fun nowMs(): Long
    }

    @Suppress("unused") // Surface-area for hint diagnostics if/when the debug overlay grows.
    internal val lastVerdictHint: SelfieHint?
        get() = (_state.value as? SelfieDetectionState.Searching)?.hint
}
