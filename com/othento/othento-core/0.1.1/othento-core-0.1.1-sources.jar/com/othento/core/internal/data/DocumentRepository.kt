package com.othento.core.internal.data

import com.othento.core.internal.data.model.AcceptedDocument
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Thin in-memory cache around [SessionRepository.getDocuments].
 *
 * Mirrors the web SDK's `SdkTokenSessionService.getDocuments` cache shape
 * ([apps/sdk/.../sdk-token-session.service.ts:64-74]) — the web persists
 * into `sessionStorage` keyed by externalId; we keep it in memory for
 * Phase 5 (R9 in `99-open-questions.md`) since the FlowCoordinator is
 * Activity-scoped and a navigation away dismantles it anyway.
 *
 * The cache is invalidated when [reset] is called — the FlowCoordinator
 * does so on `Try Again` from `FailedRetry` so the user picks against a
 * freshly loaded list.
 *
 * A [Mutex] guards the check-then-act around the cache field so two
 * concurrent `getDocuments()` calls don't both fire the network request.
 * In practice the FlowCoordinator's `inflightJob` tracking prevents this,
 * but Phase 11 (locale switcher + brand fetch) will add concurrent loaders
 * and the lock is essentially free under contention-light workloads.
 */
internal class DocumentRepository(
    private val sessionRepository: SessionRepository,
) {
    private val lock = Mutex()

    @Volatile
    private var cached: List<AcceptedDocument>? = null

    @Suppress("ReturnCount") // Three returns: pre-lock fast path / post-lock cache hit / fetched value.
    suspend fun getDocuments(): List<AcceptedDocument> {
        cached?.let { return it }
        return lock.withLock {
            cached?.let { return it }
            val fetched = sessionRepository.getDocuments()
            cached = fetched
            fetched
        }
    }

    fun reset() {
        cached = null
    }
}
