package com.othento.core.internal.flow

import com.othento.core.internal.data.SessionRepository
import com.othento.core.internal.data.model.ActiveStepStatus
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.data.model.SessionStatus
import kotlinx.coroutines.delay

/**
 * Coroutine-based session-polling loop. Mirrors the web SDK's
 * `TokenSessionPollingService.startPolling`
 * ([apps/sdk/.../services/token/token-session-polling.service.ts:29-75])
 * one-for-one, including the six-state outcome classification from spec §7.
 *
 * Configuration is pinned to [SessionConfig] — `pollIntervalMs = 2000`,
 * `maxPolls = 5`. Effective wall-clock cap ≈ 10 s.
 *
 * The driver does NOT own threading; the caller wraps the suspending entry
 * in its own scope (typically `viewModelScope`). Cancelling the scope
 * cancels the loop.
 */
internal class PollingDriver(
    private val sessionRepository: SessionRepository,
    private val config: SessionConfig = SessionConfig.Default,
) {
    /**
     * Suspends until the loop emits a non-`continue` outcome or hits
     * [SessionConfig.maxPolls]. The returned [PollingResult] always
     * carries the latest [Session] the loop saw — callers feed it into
     * [ScreenResolver] for the next screen.
     *
     * @param initialStepId snapshot of `currentStep.attemptStepId` at the
     *                      moment polling starts. Used to detect
     *                      `step_advanced` (the backend rotated to a new
     *                      step before the prior one's status flipped).
     */
    suspend fun startPolling(initialStepId: String?): PollingResult {
        var lastSession: Session? = null
        var pollCount = 0
        while (pollCount < config.maxPolls) {
            delay(config.pollIntervalMs)
            val session = sessionRepository.pollSession()
            lastSession = session
            pollCount += 1
            val outcome = evaluate(session, initialStepId, pollCount)
            if (outcome != PollingOutcome.Continue) {
                return PollingResult(session = session, outcome = outcome)
            }
        }
        // Loop fell off the bottom — `pollCount >= maxPolls` and no
        // terminal outcome was emitted (the `evaluate` call above already
        // emits `TimedOut` in that case, so this branch is only reached
        // when `maxPolls == 0`). Defensive return.
        return PollingResult(
            session = requireNotNull(lastSession) { "Polling loop completed with no observed session." },
            outcome = PollingOutcome.TimedOut,
        )
    }

    @Suppress("ReturnCount")
    // Six classification branches (spec §7); collapsing into nested `when`
    // would hide the per-state contract.
    private fun evaluate(
        session: Session,
        initialStepId: String?,
        pollCount: Int,
    ): PollingOutcome {
        val step = session.currentStep
        if (step?.status == ActiveStepStatus.Completed) return PollingOutcome.StepCompleted
        if (step?.status == ActiveStepStatus.Failed) return PollingOutcome.StepFailed
        val currentStepId = step?.attemptStepId
        if (currentStepId != initialStepId) return PollingOutcome.StepAdvanced
        if (session.status == SessionStatus.Completed) return PollingOutcome.SessionCompleted
        if (session.status == SessionStatus.Failed) return PollingOutcome.SessionFailed
        if (pollCount >= config.maxPolls) return PollingOutcome.TimedOut
        return PollingOutcome.Continue
    }
}

/** Six-state outcome of a polling loop, per spec §7. */
internal enum class PollingOutcome {
    Continue,
    StepCompleted,
    StepFailed,
    StepAdvanced,
    SessionCompleted,
    SessionFailed,
    TimedOut,
}

internal data class PollingResult(
    val session: Session,
    val outcome: PollingOutcome,
)

/**
 * Pinned constants matching the web's `session.config.ts`. Kept in a tight
 * data class so tests can substitute fast values without touching globals.
 */
internal data class SessionConfig(
    val pollIntervalMs: Long,
    val maxPolls: Int,
    val almostDoneDelayMs: Long,
    val takingLongerDelayMs: Long,
) {
    companion object {
        val Default: SessionConfig =
            SessionConfig(
                pollIntervalMs = 2_000L,
                maxPolls = 5,
                almostDoneDelayMs = 5_000L,
                takingLongerDelayMs = 12_000L,
            )
    }
}
