package com.othento.core.internal.ui.components

import android.content.Context
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil

/**
 * Phase 9 — wrapper around `libphonenumber-android` for the phone
 * destination input. The library bundles country metadata and is
 * thread-safe via its singleton; this object exposes only the two
 * operations the OTP screen actually performs (parse + validate).
 *
 * Spec [docs/spec/11-business-logic-and-validation.md] §10.4 — the
 * phone destination is invalid unless `isValidNumber(parsed)` returns
 * true. Length pre-check uses `validateLengthOf` to map per-state error
 * messages.
 */
internal class PhoneValidator(
    context: Context,
) {
    private val util: PhoneNumberUtil = PhoneNumberUtil.createInstance(context.applicationContext)

    @Suppress("ReturnCount")
    fun parseAndValidate(
        raw: String,
        regionCode: String,
    ): PhoneValidationResult {
        if (raw.isBlank()) return PhoneValidationResult.Empty
        return try {
            val parsed = util.parse(raw, regionCode)
            // Length pre-check first — gives more specific error copy than
            // bare isValid for too-short / too-long.
            val lengthIssue = util.isPossibleNumberWithReason(parsed)
            if (lengthIssue != PhoneNumberUtil.ValidationResult.IS_POSSIBLE) {
                return when (lengthIssue) {
                    PhoneNumberUtil.ValidationResult.TOO_SHORT ->
                        PhoneValidationResult.Invalid(message = "Number is too short for this country.")
                    PhoneNumberUtil.ValidationResult.TOO_LONG ->
                        PhoneValidationResult.Invalid(message = "Number is too long for this country.")
                    PhoneNumberUtil.ValidationResult.INVALID_LENGTH ->
                        PhoneValidationResult.Invalid(message = "Number length is invalid for this country.")
                    PhoneNumberUtil.ValidationResult.INVALID_COUNTRY_CODE ->
                        PhoneValidationResult.Invalid(message = "Please select a valid country.")
                    else ->
                        PhoneValidationResult.Invalid(message = "Please enter a valid phone number.")
                }
            }
            if (!util.isValidNumber(parsed)) {
                PhoneValidationResult.Invalid(message = "This doesn't look like a valid number for this country.")
            } else {
                val e164 = util.format(parsed, PhoneNumberUtil.PhoneNumberFormat.E164)
                PhoneValidationResult.Valid(e164 = e164)
            }
        } catch (_: Exception) {
            PhoneValidationResult.Invalid(message = "Please enter a valid phone number.")
        }
    }
}

internal sealed interface PhoneValidationResult {
    object Empty : PhoneValidationResult

    data class Valid(
        val e164: String,
    ) : PhoneValidationResult

    data class Invalid(
        val message: String,
    ) : PhoneValidationResult
}
