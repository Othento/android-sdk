package com.othento.core.internal.data.model

/**
 * Final outcome of a `Completed` session.
 *
 * Per [docs/spec/09-data-models.md §1.2], a `null` decision on a `Completed`
 * session is legal and triggers the randomized fallback screen (handled in
 * Phase 4's flow coordinator).
 */
internal enum class Decision {
    Approved,
    Declined,
    InReview,
}
