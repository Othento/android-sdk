@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.components.StatusIconTone
import com.othento.core.internal.ui.screens.common.RETURN_TO_APP_LABEL
import com.othento.core.internal.ui.screens.common.StatusAction
import com.othento.core.internal.ui.screens.common.StatusScreenMode
import com.othento.core.internal.ui.screens.common.StatusScreenScaffold

/** Spec [docs/spec/06-screens/18-expired.md]: amber clock, "Session Expired". */
@Composable
internal fun ExpiredScreen(onReturnToApp: () -> Unit) {
    StatusScreenScaffold(
        iconName = StatusIconName.Clock,
        iconTone = StatusIconTone.Warning,
        title = "Session Expired",
        description =
            "This verification session has expired. Please request a new session from your provider.",
        mode = StatusScreenMode.Terminal,
        primaryAction = StatusAction(label = RETURN_TO_APP_LABEL, onClick = onReturnToApp),
    )
}
