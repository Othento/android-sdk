package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass
import com.othento.core.internal.data.model.ActiveStepStatus

/**
 * Wire shape for the live (current) step on a session response.
 *
 * Mirrors [docs/spec/09-data-models.md §2.3] — same payload as a [StepDto]
 * but with the wider [ActiveStepStatus] enum and a `challenges` array.
 *
 * `configuration` and `order` are nullable with default `null` because the
 * dev backend omits them entirely on the `currentStep` payload after the
 * `initiate` call (the spec lists `order` as required, but the actual
 * response shape doesn't carry it on the live step). Keeping them
 * tolerant here is cheaper than maintaining a custom adapter for one
 * field.
 */
@JsonClass(generateAdapter = true)
internal data class ActiveStepDto(
    val attemptStepId: String,
    val configuration: Map<String, Any?>? = null,
    val stepCode: String,
    val stepName: String,
    val order: Int? = null,
    val status: ActiveStepStatus,
    // Defaults to empty so a missing or null `challenges` field on the
    // wire (the dev backend has been observed to omit it on some
    // post-confirm responses) doesn't fail Moshi parse with a
    // "Required value 'challenges' missing at $.currentStep".
    val challenges: List<ChallengeDto> = emptyList(),
)
