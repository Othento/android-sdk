package com.othento.core.internal.capture.detection.face

import android.graphics.RectF
import com.othento.core.internal.capture.SelfieConfig
import kotlin.math.PI
import kotlin.math.sqrt

/**
 * Pure-Kotlin face-against-oval geometry. Mirrors the web SDK
 * `face-detection-loop.service.ts` (lines 170-271) and
 * `selfie-guidance.service.ts`. Has no ML Kit dependency so it can be
 * unit-tested in JVM Paparazzi-style.
 *
 * Thresholds + the hint priority order come from
 * [docs/spec/11-business-logic-and-validation.md] §7.4-7.5.
 */
internal object SelfieFaceAnalyzer {
    /**
     * Run the gate chain on a single frame's detection output. Returns a
     * [SelfieVerdict] with the recommended [SelfieHint] / [SelfieWarning]
     * pair. Caller is responsible for sticky-message thresholding (see
     * [SelfieGuidance]).
     *
     * - [faces] — every face the detector returned, in source-image px coords.
     * - [oval] — oval ROI rectangle in the same source-image px coords.
     * - [faceBrightness] — mean Y-plane luminance over the largest face's
     *   bounding box. Pass `null` when the caller can't compute it (e.g.
     *   after `image.close()`); the brightness gate is skipped instead of
     *   producing a false alarm.
     *
     * `@Suppress("ReturnCount", "LongMethod")` reason: each early-return
     * models one priority slot (multi → none → too-small → too-large →
     * off-center). The function is a literal port of the web's priority
     * chain and reads as a flat decision table — splitting it into helpers
     * fragments the gate ordering.
     */
    @Suppress("ReturnCount", "LongMethod")
    fun analyze(
        faces: List<FaceBox>,
        oval: OvalRoi,
        faceBrightness: Int?,
    ): SelfieVerdict {
        // Hint priority — multi → none → too-small → too-large → off-center.
        // Each early-return path corresponds to one priority slot; collapsing
        // them obscures the priority intent.
        if (faces.size > 1) {
            return SelfieVerdict(
                hint = SelfieHint.MultipleFaces,
                warning = null,
                faceInRoi = false,
                hasQualityIssue = true,
            )
        }
        val face = faces.firstOrNull()
        if (face == null) {
            return SelfieVerdict(
                hint = SelfieHint.NoFace,
                warning = null,
                faceInRoi = false,
                hasQualityIssue = true,
            )
        }

        val faceArea = face.box.width() * face.box.height()
        val ovalArea = (PI * oval.rx * oval.ry).toFloat()
        val sizeRatio = if (ovalArea > 0f) faceArea / ovalArea else 0f
        if (sizeRatio < SelfieConfig.FILL_PERCENTAGE_MIN) {
            return SelfieVerdict(
                hint = SelfieHint.TooSmall,
                warning = null,
                sizeRatio = sizeRatio,
                faceInRoi = false,
                hasQualityIssue = true,
            )
        }
        if (sizeRatio > SelfieConfig.FILL_PERCENTAGE_MAX) {
            return SelfieVerdict(
                hint = SelfieHint.TooLarge,
                warning = null,
                sizeRatio = sizeRatio,
                faceInRoi = false,
                hasQualityIssue = true,
            )
        }

        val centerOffset = centerOffset(face, oval)
        if (centerOffset > SelfieConfig.MAX_CENTER_OFFSET) {
            return SelfieVerdict(
                hint = SelfieHint.OffCenter,
                warning = null,
                sizeRatio = sizeRatio,
                centerOffset = centerOffset,
                faceInRoi = false,
                hasQualityIssue = true,
            )
        }

        // Brightness check sits below the geometric gates because the web's
        // hint priority order routes brightness through `warning`, not `hint`.
        // A face that's correctly placed but in bad light still shows the
        // amber "find better lighting" bubble while the status pill says
        // "Hold steady...".
        val warning =
            when {
                faceBrightness == null -> null
                faceBrightness < SelfieConfig.FACE_BRIGHTNESS_MIN -> SelfieWarning.TooDark
                faceBrightness > SelfieConfig.FACE_BRIGHTNESS_MAX -> SelfieWarning.TooBright
                else -> null
            }
        return SelfieVerdict(
            hint = null,
            warning = warning,
            sizeRatio = sizeRatio,
            centerOffset = centerOffset,
            faceInRoi = true,
            // Brightness warnings reset auto-capture per spec §7.7.
            hasQualityIssue = warning != null,
        )
    }

    /**
     * Centre-to-centre distance of the face's bounding box and the oval,
     * normalised by the oval's radii. `0` is co-centric; `1` is on the
     * oval's edge along whichever axis the offset lies. Mirrors web's
     * `face-detection-loop.service.ts:188-195`.
     */
    fun centerOffset(
        face: FaceBox,
        oval: OvalRoi,
    ): Float {
        if (oval.rx <= 0f || oval.ry <= 0f) return Float.MAX_VALUE
        val faceCx = face.box.centerX()
        val faceCy = face.box.centerY()
        val dx = (faceCx - oval.cx) / oval.rx
        val dy = (faceCy - oval.cy) / oval.ry
        return sqrt(dx * dx + dy * dy)
    }
}

/** A single ML-Kit-detected face's bounding box in source-image px coords. */
internal data class FaceBox(
    val box: RectF,
)

/**
 * Oval ROI in source-image px coords. `(cx, cy)` is the centre; `(rx, ry)`
 * are the X / Y radii (so an axis-aligned ellipse).
 */
internal data class OvalRoi(
    val cx: Float,
    val cy: Float,
    val rx: Float,
    val ry: Float,
) {
    companion object {
        /** Build an oval that fits inside [containerWidth] × [containerHeight]. */
        fun centered(
            containerWidth: Float,
            containerHeight: Float,
            widthRatio: Float = SelfieConfig.ROI_WIDTH_RATIO,
            heightToWidthRatio: Float = SelfieConfig.ROI_HEIGHT_TO_WIDTH_RATIO,
        ): OvalRoi {
            val w = containerWidth * widthRatio
            val h = w * heightToWidthRatio
            return OvalRoi(
                cx = containerWidth / 2f,
                cy = containerHeight / 2f,
                rx = w / 2f,
                ry = h / 2f,
            )
        }
    }
}

/**
 * Face-against-oval verdict. The screen routes [hint] through the status
 * pill text and [warning] through the amber bubble; [hasQualityIssue]
 * tells [com.othento.core.internal.capture.SelfieDetectionPipeline]
 * whether to reset its stability counter.
 */
internal data class SelfieVerdict(
    val hint: SelfieHint?,
    val warning: SelfieWarning?,
    val sizeRatio: Float = 0f,
    val centerOffset: Float = Float.MAX_VALUE,
    val faceInRoi: Boolean = false,
    val hasQualityIssue: Boolean = true,
)

/**
 * Status-pill hint string. The web SDK strings live at
 * `selfie-guidance.service.ts:13-16`; mapped to user-facing English in
 * [text].
 */
internal enum class SelfieHint(
    val text: String,
) {
    MultipleFaces("Only one person should be visible"),
    NoFace("Position your face in the oval"),
    TooSmall("Move closer to the camera"),
    TooLarge("Move further from the camera"),
    OffCenter("Center your face in the oval"),
}

/** Amber warning-bubble strings (brightness only — face-pose isn't a warning). */
internal enum class SelfieWarning(
    val text: String,
) {
    TooDark("Find an area with better lighting"),
    TooBright("Move away from direct light"),
}

/**
 * Sticky-message gate. Hint strings flicker rapidly when the face is on the
 * boundary of a gate (e.g. close to `fillPercentageMin`); the web SDK holds
 * each new hint for [SelfieConfig.MESSAGE_MIN_DURATION_MS] before allowing
 * a downgrade. This is the testable, time-injection-friendly piece — the
 * screen owns a `clock = System::currentTimeMillis`.
 */
internal class SelfieGuidance(
    private val minDurationMs: Long = SelfieConfig.MESSAGE_MIN_DURATION_MS,
) {
    private var currentHint: SelfieHint? = null
    private var hintFirstShownAt: Long = 0L
    private var currentWarning: SelfieWarning? = null
    private var warningFirstShownAt: Long = 0L

    /** Returns the hint that should be shown right now. */
    fun applyHint(
        nextHint: SelfieHint?,
        nowMs: Long,
    ): SelfieHint? {
        // First emission, or the same hint repeating: refresh the timestamp
        // only when the value differs from the cache.
        if (nextHint == null) {
            // Hold the previous hint until the sticky window elapses.
            return if (currentHint != null && nowMs - hintFirstShownAt < minDurationMs) {
                currentHint
            } else {
                currentHint = null
                null
            }
        }
        if (nextHint != currentHint) {
            currentHint = nextHint
            hintFirstShownAt = nowMs
        }
        return currentHint
    }

    /** Same sticky logic for the warning bubble. */
    fun applyWarning(
        nextWarning: SelfieWarning?,
        nowMs: Long,
    ): SelfieWarning? {
        if (nextWarning == null) {
            return if (currentWarning != null && nowMs - warningFirstShownAt < minDurationMs) {
                currentWarning
            } else {
                currentWarning = null
                null
            }
        }
        if (nextWarning != currentWarning) {
            currentWarning = nextWarning
            warningFirstShownAt = nowMs
        }
        return currentWarning
    }
}
