@file:Suppress(
    "MagicNumber",
    "ReturnCount",
    "LongMethod",
    "CyclomaticComplexMethod",
    // Reason: Pixel-grid loops are inherently deeply nested — matches web SDK's algorithm structure.
    "NestedBlockDepth",
    // Reason: All 15 helpers are direct ports of web SDK helper functions; splitting the object
    // would obscure the 1:1 correspondence with quality-analyzer.service.ts.
    "TooManyFunctions",
    // Reason: Boundary guards in pixel loops require multi-clause conditions — unavoidable.
    "ComplexCondition",
    // Reason: Inner scan loop uses break (out-of-bounds guard) + outer uses continue (skip short
    // ray); both are algorithmic control flow from the web SDK port, not accidental complexity.
    "LoopWithTooManyJumpStatements",
)

package com.othento.core.internal.capture.detection.quality

import android.graphics.Rect
import com.othento.core.internal.capture.detection.ValidationIssue
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Pure-Kotlin port of the web SDK's `quality-analyzer.service.ts` operating on
 * ARGB `IntArray` pixel buffers. Caller is responsible for extracting pixels
 * from a Bitmap via `Bitmap.getPixels(...)`.
 *
 * All thresholds in [StaticValidationConfig].
 */
internal object StaticImageQualityAnalyzer {
    fun checkQuality(
        pixels: IntArray,
        width: Int,
        height: Int,
        region: Rect?,
        isPassport: Boolean,
    ): List<ValidationIssue> {
        if (width == 0 || height == 0) return emptyList()
        val r = region.toClampedRect(width, height)
        if (r.width() <= 0 || r.height() <= 0) return emptyList()

        val issues = mutableListOf<ValidationIssue>()

        // --- Brightness scan + glare hot-pixel prefilter ---
        val hotBrightness =
            if (isPassport) {
                StaticValidationConfig.Passport.GLARE_HOT_PIXEL_BRIGHTNESS
            } else {
                StaticValidationConfig.GLARE_HOT_PIXEL_BRIGHTNESS
            }

        var totalBrightness = 0.0
        var hotCount = 0L
        for (y in r.top until r.bottom) {
            for (x in r.left until r.right) {
                val argb = pixels[y * width + x]
                val br = luma(argb)
                totalBrightness += br
                if (br >= hotBrightness) hotCount++
            }
        }
        val area = r.width().toLong() * r.height()
        val avg = totalBrightness / area
        if (avg < StaticValidationConfig.BRIGHTNESS_MIN) issues.add(ValidationIssue.TooDark)
        if (avg > StaticValidationConfig.BRIGHTNESS_MAX) issues.add(ValidationIssue.TooBright)

        // --- Blur (Laplacian variance) ---
        if (laplacianVariance(pixels, width, r) < StaticValidationConfig.BLUR_MIN_VARIANCE) {
            issues.add(ValidationIssue.Blurry)
        }

        // --- Glare via blob analysis ---
        val hotRatio = hotCount.toDouble() / area
        val hotRatioThreshold =
            if (isPassport) {
                StaticValidationConfig.Passport.GLARE_MAX_BRIGHT_PIXEL_RATIO
            } else {
                StaticValidationConfig.GLARE_MAX_BRIGHT_PIXEL_RATIO
            }
        if (hotRatio >= hotRatioThreshold) {
            // Resize region to a max long-edge for the blob pipeline.
            val resized = resizeRegionToBuffer(pixels, width, r, StaticValidationConfig.GLARE_RESIZE_LONG_EDGE)
            val grayMask = buildGrayAndHotMask(resized.pixels, hotBrightness)
            val dilated = dilate(grayMask.hotMask, resized.w, resized.h, StaticValidationConfig.GLARE_DILATION_RADIUS)
            val blobAreaRatio =
                if (isPassport) {
                    StaticValidationConfig.Passport.GLARE_BLOB_MIN_AREA_RATIO
                } else {
                    StaticValidationConfig.GLARE_BLOB_MIN_AREA_RATIO
                }
            val minArea = (blobAreaRatio * resized.w * resized.h).toInt()
            val blobs = findBlobs(dilated, resized.w, resized.h, minArea)
            if (blobs.size == 1) {
                val score = scoreBlob(blobs[0], grayMask.gray, resized.pixels, resized.w, resized.h)
                val threshold =
                    if (isPassport) {
                        StaticValidationConfig.Passport.GLARE_VALIDATION_THRESHOLD
                    } else {
                        StaticValidationConfig.GLARE_VALIDATION_THRESHOLD
                    }
                if (score > threshold) issues.add(ValidationIssue.Glare)
            }
            // 0 or 2+ blobs → no glare (matches web rule).
        }

        // --- Passport-only diffuse-glare grid ---
        if (isPassport && !issues.contains(ValidationIssue.Glare)) {
            if (passportDiffuseGlare(pixels, width, r)) issues.add(ValidationIssue.Glare)
        }

        return issues
    }

    private fun luma(argb: Int): Float {
        val r = (argb ushr 16) and 0xFF
        val g = (argb ushr 8) and 0xFF
        val b = argb and 0xFF
        return 0.299f * r + 0.587f * g + 0.114f * b
    }

    // Laplacian-variance blur, ARGB-source variant. Matches the existing
    // Y-plane QualityAnalyzer.laplacianVariance shape but consumes IntArray.
    private fun laplacianVariance(
        pixels: IntArray,
        width: Int,
        r: Rect,
    ): Float {
        if (r.width() < 3 || r.height() < 3) return 0f
        var sum = 0.0
        var sumSq = 0.0
        var count = 0L
        for (y in (r.top + 1) until (r.bottom - 1)) {
            for (x in (r.left + 1) until (r.right - 1)) {
                val c = luma(pixels[y * width + x])
                val u = luma(pixels[(y - 1) * width + x])
                val d = luma(pixels[(y + 1) * width + x])
                val l = luma(pixels[y * width + (x - 1)])
                val rr = luma(pixels[y * width + (x + 1)])
                val lap = (4 * c - u - d - l - rr).toDouble()
                sum += lap
                sumSq += lap * lap
                count++
            }
        }
        if (count == 0L) return 0f
        val mean = sum / count
        val variance = sumSq / count - mean * mean
        return variance.toFloat()
    }

    private fun passportDiffuseGlare(
        pixels: IntArray,
        width: Int,
        r: Rect,
    ): Boolean {
        val cols = StaticValidationConfig.Passport.DIFFUSE_GRID_COLS
        val rows = StaticValidationConfig.Passport.DIFFUSE_GRID_ROWS
        val cellW = r.width() / cols
        val cellH = r.height() / rows
        if (cellW <= 0 || cellH <= 0) return false

        var washed = 0
        val total = cols * rows
        for (row in 0 until rows) {
            for (col in 0 until cols) {
                var sum = 0.0
                val sx = r.left + col * cellW
                val sy = r.top + row * cellH
                for (cy in 0 until cellH) {
                    for (cx in 0 until cellW) {
                        sum += luma(pixels[(sy + cy) * width + (sx + cx)])
                    }
                }
                val avg = sum / (cellW * cellH)
                if (avg >= StaticValidationConfig.Passport.DIFFUSE_MIN_CELL_BRIGHTNESS) washed++
            }
        }
        return washed.toFloat() / total >= StaticValidationConfig.Passport.DIFFUSE_MAX_WASHED_RATIO
    }

    // The blob-analysis helpers below are direct ports of the web's
    // `quality-analyzer.service.ts`. Implementer: when porting, search
    // for each web function name and translate verbatim.
    private data class GrayMask(
        val gray: FloatArray,
        val hotMask: ByteArray,
    )

    private data class ResizedRegion(
        val pixels: IntArray,
        val w: Int,
        val h: Int,
    )

    private data class Blob(
        val pixels: IntArray,
        val bbox: Rect,
        val area: Int,
    )

    private fun buildGrayAndHotMask(
        pixels: IntArray,
        hotBrightness: Int,
    ): GrayMask {
        val n = pixels.size
        val gray = FloatArray(n)
        val hot = ByteArray(n)
        for (i in 0 until n) {
            val br = luma(pixels[i])
            gray[i] = br
            if (br >= hotBrightness) hot[i] = 1
        }
        return GrayMask(gray, hot)
    }

    private fun dilate(
        mask: ByteArray,
        w: Int,
        h: Int,
        radius: Int,
    ): ByteArray {
        val out = ByteArray(w * h)
        val r2 = radius * radius
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (mask[y * w + x].toInt() != 1) continue
                val yMin = max(0, y - radius)
                val yMax = min(h - 1, y + radius)
                val xMin = max(0, x - radius)
                val xMax = min(w - 1, x + radius)
                for (dy in yMin..yMax) {
                    for (dx in xMin..xMax) {
                        if ((dy - y) * (dy - y) + (dx - x) * (dx - x) <= r2) {
                            out[dy * w + dx] = 1
                        }
                    }
                }
            }
        }
        return out
    }

    private fun findBlobs(
        mask: ByteArray,
        w: Int,
        h: Int,
        minArea: Int,
    ): List<Blob> {
        val visited = ByteArray(w * h)
        val blobs = mutableListOf<Blob>()
        for (i in 0 until w * h) {
            if (mask[i].toInt() != 1 || visited[i].toInt() == 1) continue
            val pixelsList = mutableListOf<Int>()
            val stack = ArrayDeque<Int>()
            stack.addLast(i)
            visited[i] = 1
            var minX = w
            var minY = h
            var maxX = 0
            var maxY = 0
            while (stack.isNotEmpty()) {
                val idx = stack.removeLast()
                pixelsList.add(idx)
                val px = idx % w
                val py = idx / w
                if (px < minX) minX = px
                if (px > maxX) maxX = px
                if (py < minY) minY = py
                if (py > maxY) maxY = py
                val neighbors =
                    intArrayOf(
                        if (py > 0) idx - w else -1,
                        if (py < h - 1) idx + w else -1,
                        if (px > 0) idx - 1 else -1,
                        if (px < w - 1) idx + 1 else -1,
                    )
                for (n in neighbors) {
                    if (n >= 0 && mask[n].toInt() == 1 && visited[n].toInt() == 0) {
                        visited[n] = 1
                        stack.addLast(n)
                    }
                }
            }
            if (pixelsList.size >= minArea) {
                blobs.add(Blob(pixelsList.toIntArray(), Rect(minX, minY, maxX + 1, maxY + 1), pixelsList.size))
            }
        }
        return blobs
    }

    private fun scoreBlob(
        blob: Blob,
        gray: FloatArray,
        pixels: IntArray,
        w: Int,
        h: Int,
    ): Float {
        // Direct port of web's validateBlob — 5 features, weighted sum.
        val weights = floatArrayOf(0.25f, 0.30f, 0.20f, 0.10f, 0.15f)
        val scores =
            floatArrayOf(
                computeGradientSmoothness(blob, gray, w, h),
                computeEdgeDensity(blob, gray, w, h),
                computeChromaticVariance(blob, pixels),
                computeCompactness(blob, w),
                computeSizeScore(blob.area, w * h),
            )
        var sum = 0f
        for (i in weights.indices) sum += weights[i] * scores[i]
        return sum
    }

    private fun computeSizeScore(
        area: Int,
        total: Int,
    ): Float {
        val ratio = area.toFloat() / total
        return if (ratio in 0.008f..0.25f) 1.0f else 0.0f
    }

    private fun computeCompactness(
        blob: Blob,
        width: Int,
    ): Float {
        val pixelSet = blob.pixels.toHashSet()
        var perimeter = 0
        for (idx in blob.pixels) {
            val px = idx % width
            val neighbors = intArrayOf(idx - width, idx + width, idx - 1, idx + 1)
            for (n in neighbors) {
                if (n < 0 || !pixelSet.contains(n)) perimeter++
            }
        }
        if (perimeter == 0) return 0f
        val compactness = (4f * PI.toFloat() * blob.area) / (perimeter.toFloat() * perimeter)
        if (compactness >= 0.25f) return 1.0f
        if (compactness <= 0.08f) return 0.0f
        return (compactness - 0.08f) / 0.17f
    }

    private fun computeEdgeDensity(
        blob: Blob,
        gray: FloatArray,
        w: Int,
        h: Int,
    ): Float {
        var edges = 0
        for (idx in blob.pixels) {
            val x = idx % w
            val y = idx / w
            if (x < 1 || x >= w - 1 || y < 1 || y >= h - 1) continue
            val tl = gray[(y - 1) * w + (x - 1)]
            val tc = gray[(y - 1) * w + x]
            val tr = gray[(y - 1) * w + (x + 1)]
            val ml = gray[y * w + (x - 1)]
            val mr = gray[y * w + (x + 1)]
            val bl = gray[(y + 1) * w + (x - 1)]
            val bc = gray[(y + 1) * w + x]
            val br = gray[(y + 1) * w + (x + 1)]
            val gx = -tl + tr - 2 * ml + 2 * mr - bl + br
            val gy = -tl - 2 * tc - tr + bl + 2 * bc + br
            if (sqrt(gx * gx + gy * gy) >= 30f) edges++
        }
        val ratio = if (blob.area > 0) edges.toFloat() / blob.area else 0f
        if (ratio <= 0.05f) return 1.0f
        if (ratio >= 0.18f) return 0.0f
        return 1.0f - (ratio - 0.05f) / 0.13f
    }

    private fun computeChromaticVariance(
        blob: Blob,
        pixels: IntArray,
    ): Float {
        val maxSamples = 200
        val step = max(1, blob.pixels.size / maxSamples)
        val hues = mutableListOf<Float>()
        val sats = mutableListOf<Float>()
        var i = 0
        while (i < blob.pixels.size) {
            val idx = blob.pixels[i]
            val argb = pixels[idx]
            val r = ((argb ushr 16) and 0xFF) / 255f
            val g = ((argb ushr 8) and 0xFF) / 255f
            val b = (argb and 0xFF) / 255f
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val delta = mx - mn
            sats.add(if (mx == 0f) 0f else delta / mx)
            if (delta > 0f) {
                val hue =
                    when (mx) {
                        r -> ((g - b) / delta) % 6f
                        g -> (b - r) / delta + 2f
                        else -> (r - g) / delta + 4f
                    } * 60f
                hues.add(if (hue < 0f) hue + 360f else hue)
            }
            i += step
        }
        val avgSat = if (sats.isNotEmpty()) sats.sum() / sats.size else 0f
        if (avgSat < 0.1f) return 1.0f
        if (hues.size < 2) return 1.0f
        var sinSum = 0f
        var cosSum = 0f
        for (hh in hues) {
            val rad = (hh * PI.toFloat()) / 180f
            sinSum += sin(rad.toDouble()).toFloat()
            cosSum += cos(rad.toDouble()).toFloat()
        }
        val mrl =
            sqrt(
                (sinSum / hues.size) * (sinSum / hues.size) + (cosSum / hues.size) * (cosSum / hues.size),
            )
        val variance = 1f - mrl
        if (variance <= 0.1f) return 1.0f
        if (variance >= 0.5f) return 0.0f
        return 1.0f - (variance - 0.1f) / 0.4f
    }

    private fun computeGradientSmoothness(
        blob: Blob,
        gray: FloatArray,
        w: Int,
        h: Int,
    ): Float {
        var cx = 0
        var cy = 0
        for (idx in blob.pixels) {
            cx += idx % w
            cy += idx / w
        }
        cx /= blob.area
        cy /= blob.area
        val dirs =
            arrayOf(
                intArrayOf(1, 0),
                intArrayOf(-1, 0),
                intArrayOf(0, 1),
                intArrayOf(0, -1),
                intArrayOf(1, 1),
                intArrayOf(-1, -1),
                intArrayOf(1, -1),
                intArrayOf(-1, 1),
            )
        val maxR = max(blob.bbox.width(), blob.bbox.height())
        var totalCorr = 0f
        var validDirs = 0
        for (d in dirs) {
            val dxs = mutableListOf<Float>()
            val brs = mutableListOf<Float>()
            for (s in 0..maxR) {
                val x = cx + d[0] * s
                val y = cy + d[1] * s
                if (x < 0 || x >= w || y < 0 || y >= h) break
                dxs.add(s.toFloat())
                brs.add(gray[y * w + x])
            }
            if (dxs.size < 3) continue
            val n = dxs.size
            var sd = 0f
            var sb = 0f
            var sdb = 0f
            var sd2 = 0f
            var sb2 = 0f
            for (k in 0 until n) {
                sd += dxs[k]
                sb += brs[k]
                sdb += dxs[k] * brs[k]
                sd2 += dxs[k] * dxs[k]
                sb2 += brs[k] * brs[k]
            }
            val num = n * sdb - sd * sb
            val den = sqrt((n * sd2 - sd * sd) * (n * sb2 - sb * sb))
            if (den == 0f) continue
            totalCorr += num / den
            validDirs++
        }
        if (validDirs == 0) return 0f
        val avg = totalCorr / validDirs
        if (avg <= -0.7f) return 1.0f
        if (avg >= -0.3f) return 0.0f
        return (-0.3f - avg) / 0.4f
    }

    private fun resizeRegionToBuffer(
        pixels: IntArray,
        srcWidth: Int,
        region: Rect,
        longEdge: Int,
    ): ResizedRegion {
        val rw = region.width()
        val rh = region.height()
        val scale = min(1f, longEdge.toFloat() / max(rw, rh))
        val newW = (rw * scale).toInt().coerceAtLeast(1)
        val newH = (rh * scale).toInt().coerceAtLeast(1)
        val out = IntArray(newW * newH)
        // Nearest-neighbor — adequate for downstream blob analysis.
        for (y in 0 until newH) {
            val srcY = region.top + (y * rh) / newH
            for (x in 0 until newW) {
                val srcX = region.left + (x * rw) / newW
                out[y * newW + x] = pixels[srcY * srcWidth + srcX]
            }
        }
        return ResizedRegion(out, newW, newH)
    }

    private fun Rect?.toClampedRect(
        w: Int,
        h: Int,
    ): Rect {
        if (this == null) return Rect(0, 0, w, h)
        return Rect(
            left.coerceIn(0, w),
            top.coerceIn(0, h),
            right.coerceIn(0, w),
            bottom.coerceIn(0, h),
        )
    }
}
