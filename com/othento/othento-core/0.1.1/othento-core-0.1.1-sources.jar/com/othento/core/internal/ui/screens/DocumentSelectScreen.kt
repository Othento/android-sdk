@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.ui.components.CountryFlagImage
import com.othento.core.internal.ui.components.DropdownFlagHeight
import com.othento.core.internal.ui.components.DropdownFlagWidth
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonSize
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycDropdown
import com.othento.core.internal.ui.components.KycDropdownOption
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.components.KycLoader
import com.othento.core.internal.ui.components.KycLoaderSize
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.screens.common.StepProgress
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Spec [docs/spec/06-screens/03-document-select.md]: country dropdown +
 * document cards, footer Continue.
 *
 * State surface (all from [com.othento.core.internal.flow.FlowUiState]):
 * - [documents] — fully loaded list, grouped by country.
 * - [selectedCountryName] — auto-set to the first country alphabetically when
 *   docs land; the user can switch via the dropdown.
 * - [selectedDocumentId] — null until the user taps a card.
 * - [loading] / [errorMessage] — loading + error states.
 *
 * The Continue CTA fires `onConfirmClick` only when [selectedDocumentId] is
 * non-null — disabled otherwise (matches the web's `[disabled]` binding).
 */
@Composable
@Suppress("LongParameterList", "LongMethod")
internal fun DocumentSelectScreen(
    documents: List<AcceptedDocument>?,
    selectedCountryName: String?,
    selectedDocumentId: String?,
    loading: Boolean,
    errorMessage: String?,
    stepProgress: StepProgress,
    onCountrySelected: (String) -> Unit,
    onDocumentSelected: (String) -> Unit,
    onConfirmClick: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current

    val countryGroups: List<CountryGroup> =
        remember(documents) {
            documents
                ?.groupBy { it.countryName }
                ?.map { (name, docs) ->
                    CountryGroup(
                        name = name,
                        countryCode = docs.firstNotNullOfOrNull { it.countryCode },
                        countryIcon = docs.firstNotNullOfOrNull { it.countryIcon.takeIf(String::isNotBlank) },
                        documents = docs,
                    )
                }?.sortedBy { it.name }
                .orEmpty()
        }
    val selectedGroup =
        remember(countryGroups, selectedCountryName) {
            countryGroups.firstOrNull { it.name == selectedCountryName }
        }
    val visibleDocuments = selectedGroup?.documents.orEmpty()
    val canConfirm = selectedDocumentId != null && !loading

    KycScreen(
        zone = KycScreenZone.Guided,
        title = "Select your document",
        subtitle = "Choose your country and document type",
        stepLabel = stepProgress.label,
        // Brand row is intentionally omitted on inner screens — the brand
        // already lives in the trust footer underneath the screen body.
        logoName = "",
        totalSegments = stepProgress.total,
        activeSegment = stepProgress.currentIndex,
        body = {
            when {
                loading ->
                    Column(
                        modifier = Modifier.fillMaxSize().padding(top = LoadingTopGap),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        KycLoader(size = KycLoaderSize.Md)
                    }
                errorMessage != null -> ErrorBlock(errorMessage)
                documents == null -> Unit
                else ->
                    DocumentSelectBody(
                        countryGroups = countryGroups,
                        selectedCountryName = selectedCountryName,
                        selectedDocumentId = selectedDocumentId,
                        visibleDocuments = visibleDocuments,
                        onCountrySelected = onCountrySelected,
                        onDocumentSelected = onDocumentSelected,
                        colors = colors,
                        typography = typography,
                    )
            }
        },
        footer = {
            KycButton(
                onClick = onConfirmClick,
                label = "Continue",
                variant = KycButtonVariant.Primary,
                size = KycButtonSize.Lg,
                enabled = canConfirm,
                fullWidth = true,
            )
        },
    )
}

@Composable
@Suppress("LongParameterList", "LongMethod")
private fun DocumentSelectBody(
    countryGroups: List<CountryGroup>,
    selectedCountryName: String?,
    selectedDocumentId: String?,
    visibleDocuments: List<AcceptedDocument>,
    onCountrySelected: (String) -> Unit,
    onDocumentSelected: (String) -> Unit,
    colors: com.othento.core.internal.ui.theme.OthentoColors,
    typography: com.othento.core.internal.ui.theme.OthentoTypography,
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = SectionTopGap),
        verticalArrangement = Arrangement.spacedBy(SectionGap),
    ) {
        Section(label = "Issuing country") {
            // Country flags are rendered from `AcceptedDocument.countryIcon`
            // (a remote URL) via Coil's AsyncImage — same pipeline the web
            // SDK uses (`<img [src]="country.countryIcon" width="20"
            // height="14">`, spec docs/spec/04-design-system.md §"Country
            // flag"). The slot collapses if the URL is blank.
            KycDropdown(
                selectedId = selectedCountryName,
                placeholder = "Select a country",
                options =
                    countryGroups.map { group ->
                        KycDropdownOption(
                            id = group.name,
                            label = group.name,
                            leading =
                                group.countryIcon?.let { url ->
                                    {
                                        CountryFlagImage(
                                            url = url,
                                            width = DropdownFlagWidth,
                                            height = DropdownFlagHeight,
                                            contentDescription = group.name,
                                        )
                                    }
                                },
                        )
                    },
                onSelect = onCountrySelected,
            )
        }
        if (selectedCountryName != null) {
            Section(label = "Choose document type") {
                Column(verticalArrangement = Arrangement.spacedBy(CardGap)) {
                    visibleDocuments.forEach { doc ->
                        DocumentCard(
                            document = doc,
                            selected = doc.documentId == selectedDocumentId,
                            onClick = { onDocumentSelected(doc.documentId) },
                            colors = colors,
                            typography = typography,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Section(
    label: String,
    body: @Composable () -> Unit,
) {
    val typography = LocalOthentoTypography.current
    val colors = LocalOthentoColors.current
    Column {
        Text(
            text = label,
            style = typography.inputLabel.copy(fontWeight = FontWeight.W600),
            color = colors.textPrimary,
        )
        Spacer(modifier = Modifier.height(LabelGap))
        body()
    }
}

@Composable
private fun DocumentCard(
    document: AcceptedDocument,
    selected: Boolean,
    onClick: () -> Unit,
    colors: com.othento.core.internal.ui.theme.OthentoColors,
    typography: com.othento.core.internal.ui.theme.OthentoTypography,
) {
    val shapes = LocalOthentoShapes.current
    val borderColor = if (selected) colors.primary else colors.border
    val backgroundColor = if (selected) colors.primaryBg else colors.bgBase
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(shapes.md)
                .border(width = CardBorderWidth, color = borderColor, shape = shapes.md)
                .background(backgroundColor)
                .clickable(onClick = onClick)
                .padding(horizontal = CardHorizontal, vertical = CardVertical),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(CardInnerGap),
    ) {
        DocumentIcon(typeName = document.typeName, selected = selected, colors = colors)
        Text(
            text = document.typeName,
            style = typography.body.copy(fontWeight = FontWeight.W500),
            color = colors.textPrimary,
            modifier = Modifier.weight(1f),
        )
        RadioMark(selected = selected, colors = colors)
    }
}

@Composable
private fun DocumentIcon(
    typeName: String,
    selected: Boolean,
    colors: com.othento.core.internal.ui.theme.OthentoColors,
) {
    val iconBg = if (selected) colors.primary else colors.bgLayout
    val iconTint = if (selected) Color.White else colors.textSecondary
    Box(
        modifier =
            Modifier
                .size(DocIconSize)
                .clip(RoundedCornerShape(8.dp))
                .background(iconBg),
        contentAlignment = Alignment.Center,
    ) {
        KycIcon(
            imageVector = iconImageVectorFor(typeName),
            contentDescription = null,
            sizeDp = DocIconGlyphSize,
            tint = iconTint,
        )
    }
}

private fun iconImageVectorFor(typeName: String) =
    when {
        typeName.contains("passport", ignoreCase = true) -> OthentoIcons.Passport
        typeName.contains("residen", ignoreCase = true) ||
            typeName.contains("permit", ignoreCase = true) -> OthentoIcons.IdCard
        typeName.contains("driv", ignoreCase = true) ||
            typeName.contains("license", ignoreCase = true) ||
            typeName.contains("licence", ignoreCase = true) -> OthentoIcons.IdCard
        else -> OthentoIcons.IdCard
    }

@Composable
private fun RadioMark(
    selected: Boolean,
    colors: com.othento.core.internal.ui.theme.OthentoColors,
) {
    Box(
        modifier =
            Modifier
                .size(RadioOuter)
                .clip(CircleShape)
                .border(
                    width = CardBorderWidth,
                    color = if (selected) colors.primary else colors.border,
                    shape = CircleShape,
                ),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Box(
                modifier =
                    Modifier
                        .size(RadioInner)
                        .clip(CircleShape)
                        .background(colors.primary),
            )
        }
    }
}

@Composable
private fun ErrorBlock(message: String) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val shapes = LocalOthentoShapes.current
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(top = ErrorTopGap)
                .clip(shapes.md)
                .background(colors.errorBg)
                .padding(horizontal = ErrorHorizontal, vertical = ErrorVertical),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = message,
            style = typography.body,
            color = colors.error,
        )
    }
}

private data class CountryGroup(
    val name: String,
    val countryCode: String?,
    val countryIcon: String?,
    val documents: List<AcceptedDocument>,
)

private val SectionTopGap = 16.dp
private val SectionGap = 24.dp
private val LabelGap = 10.dp
private val CardGap = 12.dp
private val CardHorizontal = 16.dp
private val CardVertical = 12.dp
private val CardInnerGap = 14.dp
private val CardBorderWidth: Dp = 1.5.dp
private val DocIconSize = 40.dp
private val DocIconGlyphSize = 22.dp
private val RadioOuter = 20.dp
private val RadioInner = 10.dp
private val LoadingTopGap = 48.dp
private val ErrorTopGap = 32.dp
private val ErrorHorizontal = 24.dp
private val ErrorVertical = 32.dp
