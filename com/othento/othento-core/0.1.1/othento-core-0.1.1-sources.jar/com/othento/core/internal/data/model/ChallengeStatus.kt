package com.othento.core.internal.data.model

/**
 * Lifecycle of a single challenge inside the active step.
 *
 * Per [docs/spec/09-data-models.md §1.7] the canonical enum is
 * `AwaitingUpload | Uploaded`. Test fixtures reference an additional
 * `OtpSent` value (open question 1 in the spec); Phase 9 will revisit.
 */
internal enum class ChallengeStatus {
    AwaitingUpload,
    Uploaded,
}
