package com.othento.core.internal.ui.screens.common

import com.othento.core.internal.data.model.ReinitStep
import com.othento.core.internal.data.model.Step
import com.othento.core.internal.ui.components.KycStepCardInput

/**
 * Maps a [Step] list to the [KycStepCardInput] list the Start /
 * FailedRetry hero block consumes.
 *
 * Mirrors `apps/sdk/.../shared/step-meta.ts` (`STEP_META`) per
 * [docs/spec/06-screens/20-shared.md] §"Step metadata helper". Step rows
 * Phase 4 doesn't recognise (e.g. future address-verification — open
 * question C1) fall back to a blank detail.
 *
 * `step_face_match` rows are filtered out when a `step_liveness_check`
 * exists, matching the web's `visibleSteps` rule
 * ([docs/spec/08-state-management.md] §2.4 `visibleSteps` row).
 */
internal object StepCardsBuilder {
    fun toCards(steps: List<Step>): List<KycStepCardInput> =
        build(steps.map { it.stepCode to it.stepName })

    /**
     * Card list for the backend's `reinitInfo.stepsToRetry` (the FailedRetry
     * "What to redo" list). Mirrors the web's `toStepCards`, which accepts the
     * trimmed reinit-step shape interchangeably with the full step list.
     */
    fun fromReinitSteps(steps: List<ReinitStep>): List<KycStepCardInput> =
        build(steps.map { it.stepCode to it.stepName })

    private fun build(steps: List<Pair<String, String>>): List<KycStepCardInput> =
        filterVisible(steps).map { (stepCode, stepName) ->
            KycStepCardInput(
                name = stepName.ifBlank { fallbackName(stepCode) },
                detail = STEP_DETAIL[stepCode],
                duration = STEP_DURATION[stepCode],
                stepCode = stepCode,
            )
        }

    private fun filterVisible(steps: List<Pair<String, String>>): List<Pair<String, String>> {
        val hasLiveness = steps.any { it.first == STEP_LIVENESS }
        return if (hasLiveness) steps.filterNot { it.first == STEP_FACE_MATCH } else steps
    }

    private fun fallbackName(stepCode: String): String =
        when (stepCode) {
            STEP_ID -> "Document verification"
            STEP_FACE_MATCH, STEP_LIVENESS -> "Selfie"
            STEP_PHONE -> "Phone verification"
            STEP_EMAIL -> "Email verification"
            else -> stepCode
        }

    private const val STEP_ID = "step_id_verification"
    private const val STEP_FACE_MATCH = "step_face_match"
    private const val STEP_LIVENESS = "step_liveness_check"
    private const val STEP_PHONE = "step_phone_verification"
    private const val STEP_EMAIL = "step_email_verification"

    private val STEP_DETAIL: Map<String, String> =
        mapOf(
            STEP_ID to "Personal document",
            STEP_FACE_MATCH to "Selfie",
            STEP_LIVENESS to "Selfie",
            STEP_PHONE to "SMS code",
            STEP_EMAIL to "Email code",
        )

    private val STEP_DURATION: Map<String, String> =
        mapOf(
            STEP_ID to "~20s",
            STEP_FACE_MATCH to "~10s",
            STEP_LIVENESS to "~10s",
            STEP_PHONE to "~10s",
            STEP_EMAIL to "~10s",
        )
}
