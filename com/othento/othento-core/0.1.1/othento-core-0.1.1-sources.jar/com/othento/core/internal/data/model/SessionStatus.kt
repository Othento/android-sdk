package com.othento.core.internal.data.model

/**
 * Server-driven session lifecycle status.
 *
 * Mirrors `SessionStatus` from
 * [docs/spec/09-data-models.md §1.1]. JSON values match the enum names
 * exactly — Moshi's built-in enum adapter handles serialization without
 * reflection-based field access.
 */
internal enum class SessionStatus {
    Created,
    InProgress,
    Processing,
    Completed,
    Expired,
    Failed,
}
