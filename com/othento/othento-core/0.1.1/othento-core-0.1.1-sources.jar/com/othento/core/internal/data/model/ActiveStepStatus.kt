package com.othento.core.internal.data.model

/**
 * Wider step-status enum used on the live `currentStep`.
 *
 * See [docs/spec/09-data-models.md §1.5]. The OTP / inference / awaiting-evidence
 * variants drive screen routing in Phase 4's coordinator.
 */
internal enum class ActiveStepStatus {
    Pending,
    AwaitingEvidence,
    AwaitingOtherEvidence,
    SentToInference,
    InferenceProcessing,
    Completed,
    Failed,
}
