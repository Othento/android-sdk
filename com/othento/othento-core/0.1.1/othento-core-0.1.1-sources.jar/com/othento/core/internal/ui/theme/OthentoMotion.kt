@file:Suppress("MagicNumber")

package com.othento.core.internal.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * Durations + easings per [docs/spec/04-design-system.md] §6.
 *
 * [reducedMotion] is read once at theme construction (from `Settings.Global`'s
 * animation scales — see [com.othento.core.internal.ui.theme.rememberReducedMotion]).
 * Each animated component reads it to short-circuit infinite or attention-
 * grabbing animations.
 */
@Immutable
internal data class OthentoMotion(
    val durationInstantMs: Int = 80,
    val durationFastMs: Int = 140,
    val durationBaseMs: Int = 180,
    val durationSlowMs: Int = 320,
    val durationLoopMs: Int = 1600,
    val easeOut: Easing = CubicBezierEasing(0.2f, 0f, 0f, 1f),
    val easeIn: Easing = CubicBezierEasing(0.4f, 0f, 1f, 1f),
    val easeInOut: Easing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f),
    val spring: Easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f),
    val reducedMotion: Boolean = false,
) {
    companion object {
        val Default: OthentoMotion = OthentoMotion()
    }
}

internal val LocalOthentoMotion =
    staticCompositionLocalOf<OthentoMotion> {
        error("OthentoMotion not provided. Wrap content in OthentoTheme { … }.")
    }
