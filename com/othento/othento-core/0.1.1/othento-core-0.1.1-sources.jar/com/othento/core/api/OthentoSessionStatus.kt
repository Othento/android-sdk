package com.othento.core.api

/**
 * Lifecycle status of an Othento session.
 *
 * Mirrors `SessionStatus` from the web SDK contract
 * (docs/spec/16-host-events-and-callbacks.md §1.3, session.model.ts:3).
 *
 * `Created` and `InProgress` are non-terminal. `Processing`, `Completed`,
 * `Expired`, `Failed` are terminal from the host's perspective. The decision
 * (`Approved` / `Declined` / `InReview`) is folded into `Completed` and is
 * surfaced by the visible screen, not by the status enum.
 */
public enum class OthentoSessionStatus {
    Created,
    InProgress,
    Processing,
    Completed,
    Expired,
    Failed,
}
