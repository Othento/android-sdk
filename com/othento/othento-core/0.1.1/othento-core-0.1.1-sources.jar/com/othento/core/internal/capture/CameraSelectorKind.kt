package com.othento.core.internal.capture

/**
 * Which physical camera [CameraSession.bind] should request.
 *
 * The document-capture screens use [Back] (rear sensor); the Phase 7
 * selfie-capture screen uses [Front] (user-facing sensor).
 */
internal enum class CameraSelectorKind {
    Back,
    Front,
}
