package com.othento.core.internal.data.model

/**
 * Backend-side selection of who receives the create-session callback URL.
 *
 * Per [docs/spec/09-data-models.md §1.12]. Optional on `CreateSessionRequest`;
 * default behaviour when omitted is backend-defined (open question 5 in
 * spec 09).
 */
internal enum class CallbackReceiver {
    Initiator,
    Completer,
    Both,
}
