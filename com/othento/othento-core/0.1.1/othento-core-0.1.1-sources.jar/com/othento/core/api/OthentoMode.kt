package com.othento.core.api

/**
 * Selects how the SDK obtains a session.
 *
 * - [Create] (Phase 1) — apiKey mode, no prior session. The SDK calls
 *   `POST /api/v1/SessionToken/session` once with `X-API-KEY`, then the
 *   backend hands back a SAT/ST bundle that drives every subsequent call.
 * - [Token] (Phase 10) — single-use SAT mode. The host opens the SDK
 *   with a SAT lifted from a deeplink (`/verify/s/<sat>`). The SDK skips
 *   the create call entirely and starts at `GET .../session` with
 *   `X-SAT`. The backend rotates ST/SRT into the response on first call.
 *
 * Spec [docs/spec/02-public-api.md] §1 / §2.
 */
public sealed class OthentoMode {
    public data class Create(
        val workflowExternalId: String,
        val clientData: String,
    ) : OthentoMode()

    /**
     * Single-use Session Access Token. Lifted from a deeplink URL of
     * shape `https://verify.zetatech.ae/verify/s/<sat>`. The token is
     * consumed on the first call; the response carries an ST + SRT
     * bundle that is persisted via [com.othento.core.internal.network.TokenStore].
     */
    public data class Token(
        val sat: String,
    ) : OthentoMode()
}
