package com.othento.core.internal

import com.othento.core.api.OthentoCancelReason
import com.othento.core.api.OthentoDecision
import com.othento.core.api.OthentoError
import com.othento.core.api.OthentoSDKListener
import com.othento.core.api.OthentoSessionStatus

/**
 * Decorator that calls [SdkBus.markTerminated] on the first terminal
 * listener event (`onCompleted` / `onError` / `onCancelled`).
 *
 * Why: the single-instance slot was previously released only on Activity
 * `onDestroy`, which is too late — the host commonly launches a fresh
 * `OthentoSDK` from inside `onError` / `onCompleted`, while the terminal
 * Activity is still alive. Releasing the slot at the listener-event
 * boundary lets that pattern work.
 *
 * **Slot release happens BEFORE delegating to the host.** That ordering
 * is load-bearing: a host that calls `OthentoSDK(...).start()` from inside
 * its own `onCompleted` would otherwise hit `ConfigInvalid("another
 * instance running")`, since the wrapper's `finally` block hadn't run
 * yet. Releasing first leaves the old terminal Activity alive (the user
 * still has the "Return to app" CTA on it) but lets the new flow claim
 * the slot.
 */
internal class TerminalAwareListener(
    private val delegate: OthentoSDKListener,
    private val token: String,
) : OthentoSDKListener {
    override fun onReady() = delegate.onReady()

    override fun onSessionCreated(
        externalId: String,
        sessionUrl: String,
    ) = delegate.onSessionCreated(externalId, sessionUrl)

    override fun onStatusChanged(status: OthentoSessionStatus) = delegate.onStatusChanged(status)

    override fun onError(
        error: OthentoError,
        displayMessage: String,
    ) {
        SdkBus.markTerminated(token)
        delegate.onError(error, displayMessage)
    }

    override fun onCancelled(reason: OthentoCancelReason) {
        SdkBus.markTerminated(token)
        delegate.onCancelled(reason)
    }

    override fun onCompleted(
        decision: OthentoDecision,
        externalId: String,
    ) {
        SdkBus.markTerminated(token)
        delegate.onCompleted(decision, externalId)
    }
}
