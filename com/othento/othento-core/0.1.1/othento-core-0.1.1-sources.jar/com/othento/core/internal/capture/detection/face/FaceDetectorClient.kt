package com.othento.core.internal.capture.detection.face

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Thin wrapper around ML Kit Face Detection used by both the passport
 * photo-gate (Phase 6 V30) and the Phase 7 selfie loop. Centralises the
 * detector lifecycle + single-flight scheduling pattern so each call site
 * doesn't re-implement [FaceDetector.process] glue.
 *
 * Two call modes:
 * - [scheduleLatest] — fire-and-forget; subsequent schedules dropped while
 *   one is in flight, latest result cached. The passport photo-gate uses
 *   this so its 5 fps cadence doesn't queue ML Kit calls.
 * - [detectOnce] — `suspend` form for one-shot manual-capture validation.
 *
 * Detector options:
 * - `PERFORMANCE_MODE_FAST` — bounding boxes only, no landmarks.
 * - `setMinFaceSize(minFaceSize)` — minimum face proportion of the shorter
 *   image edge. Caller-tunable.
 * - `setLandmarkMode(NO_LANDMARKS)` — explicit; the selfie loop only needs
 *   the bounding box.
 */
internal class FaceDetectorClient(
    minFaceSize: Float,
) {
    private val detector: FaceDetector =
        FaceDetection.getClient(
            FaceDetectorOptions
                .Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setMinFaceSize(minFaceSize)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
                .build(),
        )

    @Volatile
    private var inflight: Boolean = false

    @Volatile
    private var latest: List<Face> = emptyList()

    /** True while a `scheduleLatest` task hasn't yet fired its completion callback. */
    fun isBusy(): Boolean = inflight

    /**
     * Schedules a detection pass. If a prior pass is still running, returns
     * immediately without queueing — the next [latestFaces] read picks up
     * whatever the prior pass produced. [onComplete] runs even if the call
     * was dropped, so callers can release the input bitmap deterministically.
     */
    @Suppress("TooGenericExceptionCaught")
    // Reason: `detector.process` can throw synchronously (e.g. a released
    // detector). If it does, `inflight` would stick true forever — isBusy()
    // never clears, the analyzer drops every subsequent frame, and detection
    // freezes. Catch any throw, reset the flag, and still fire onComplete so
    // the caller releases its frame.
    fun scheduleLatest(
        image: InputImage,
        onComplete: (faces: List<Face>?, error: Throwable?) -> Unit,
    ) {
        if (inflight) {
            onComplete(null, null)
            return
        }
        inflight = true
        try {
            detector
                .process(image)
                .addOnSuccessListener { faces ->
                    latest = faces
                    onComplete(faces, null)
                }.addOnFailureListener { err ->
                    latest = emptyList()
                    onComplete(null, err)
                }.addOnCompleteListener {
                    inflight = false
                }
        } catch (t: Throwable) {
            inflight = false
            onComplete(null, t)
        }
    }

    /** Snapshot of the latest result. Empty when no prior pass succeeded. */
    fun latestFaces(): List<Face> = latest

    /**
     * One-shot suspending detection — used by the selfie screen's manual
     * shutter to re-validate the captured frame (zero / multiple faces
     * → re-prompt). Throws on detector errors so the caller can fall
     * through to "graceful degradation" (let the user confirm manually).
     */
    suspend fun detectOnce(image: InputImage): List<Face> =
        suspendCancellableCoroutine { cont: CancellableContinuation<List<Face>> ->
            detector
                .process(image)
                .addOnSuccessListener { faces -> if (cont.isActive) cont.resume(faces) }
                .addOnFailureListener { err -> if (cont.isActive) cont.resumeWithException(err) }
        }

    fun release() {
        runCatching { detector.close() }
    }
}
