package com.othento.core.internal.data.model

/**
 * Domain model for an entry in the flat `steps[]` listing.
 *
 * Per [docs/spec/09-data-models.md §2.1]. `configuration` is declared as
 * a free-form JSON map because the wire shape varies per step type — for
 * OTP steps it carries an `OtpStepConfiguration`-shaped object, but on the
 * wire it is typed `any` and may be null/absent.
 *
 * `status` uses the wider [ActiveStepStatus] (not the spec's `StepStatus`)
 * because the dev backend ships the wider enum on the flat `steps[]` array
 * too — see P9 in `docs/spec/99-open-questions.md`.
 */
internal data class Step(
    val attemptStepId: String,
    val configuration: Map<String, Any?>?,
    val stepCode: String,
    val stepName: String,
    val order: Int?,
    val status: ActiveStepStatus,
)
