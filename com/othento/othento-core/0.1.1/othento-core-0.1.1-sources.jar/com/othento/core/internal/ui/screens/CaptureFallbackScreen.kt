@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.flow.PendingCapture
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonSize
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.components.PreviewImage
import com.othento.core.internal.ui.components.ValidatingRow
import com.othento.core.internal.ui.components.WarningsList
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.screens.common.StepProgress
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.internal.util.countryCodeToFlagEmoji

/**
 * Spec [docs/spec/06-screens/06-capture-fallback.md]: upload-only fallback
 * for the document capture step. Phase 5 ships this for both `front` and
 * `back` sides; the camera-driven variant lands in Phase 6.
 *
 * Image-only — videos accepted by the web are deferred (R7). The picker uses
 * `PickVisualMedia(ImageOnly)` so no runtime permission is required on
 * Android 13+, and on lower API levels the `PickVisualMedia` shim falls
 * through to the system gallery picker.
 *
 * Behaviour:
 * - "Change document" link → only on the front side (matches the web).
 * - Doc-info chip showing country + type — present when the host's pending
 *   document is set.
 * - Placeholder rectangle with the document's aspect ratio (default 85.6/54
 *   per spec; passport-shaped docs may pass `widthMm/heightMm`).
 * - "Upload file" CTA opens `PickVisualMedia`. The selected URI is forwarded
 *   to the coordinator via [onFileCaptured]; size/MIME validation lives in
 *   the coordinator + [com.othento.core.internal.util.ImageInfo].
 * - The 10 MB inline error renders when the parent state's `oversizedFile`
 *   flag is set.
 */
@Composable
@Suppress("LongParameterList", "LongMethod")
internal fun CaptureFallbackScreen(
    side: Side,
    pendingDocument: AcceptedDocument?,
    pendingCapture: PendingCapture?,
    oversizedFile: Boolean,
    fileUnreadable: Boolean,
    stepProgress: StepProgress,
    onChangeDocument: () -> Unit,
    onPickFileClick: () -> Unit,
    onRetake: () -> Unit,
    onConfirm: () -> Unit,
) {
    KycScreen(
        zone = KycScreenZone.Guided,
        title =
            if (pendingCapture == null) {
                "Upload your document"
            } else {
                when (side) {
                    Side.Front -> "Front side uploaded"
                    Side.Back -> "Back side uploaded"
                }
            },
        subtitle = if (pendingCapture == null) "Take a clear photo of your document" else "",
        stepLabel = stepProgress.label,
        // Brand row is intentionally omitted on inner screens — the brand
        // already lives in the trust footer underneath the screen body.
        logoName = "",
        totalSegments = stepProgress.total,
        activeSegment = stepProgress.currentIndex,
        body = {
            if (pendingCapture == null) {
                CaptureBody(
                    side = side,
                    pendingDocument = pendingDocument,
                    oversizedFile = oversizedFile,
                    fileUnreadable = fileUnreadable,
                    onChangeDocument = onChangeDocument,
                    onPickFile = onPickFileClick,
                )
            } else {
                PreviewBody(
                    pendingCapture = pendingCapture,
                    onRetake = onRetake,
                    onConfirm = onConfirm,
                )
            }
        },
    )
}

internal enum class Side {
    Front,
    Back,
}

@Composable
@Suppress("LongMethod", "LongParameterList")
private fun CaptureBody(
    side: Side,
    pendingDocument: AcceptedDocument?,
    oversizedFile: Boolean,
    fileUnreadable: Boolean,
    onChangeDocument: () -> Unit,
    onPickFile: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current

    Column(
        modifier = Modifier.fillMaxSize().padding(top = BodyTopGap),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (side == Side.Front) {
            ChangeDocumentLink(onClick = onChangeDocument, colors = colors, typography = typography)
            Spacer(modifier = Modifier.height(LinkBottomGap))
        }
        if (pendingDocument != null) {
            DocInfoChip(document = pendingDocument)
            Spacer(modifier = Modifier.height(ChipBottomGap))
        }
        Placeholder(side = side, document = pendingDocument)
        Spacer(modifier = Modifier.height(PlaceholderBottomGap))
        KycButton(
            onClick = onPickFile,
            label = "Upload file",
            variant = KycButtonVariant.Primary,
            size = KycButtonSize.Lg,
        )
        Spacer(modifier = Modifier.height(HintTopGap))
        Text(
            text = "Max 10 MB",
            style = typography.caption,
            color = colors.textMuted,
        )
        if (oversizedFile) {
            Spacer(modifier = Modifier.height(ErrorTopGap))
            ErrorMessage(text = "File is too large. Maximum size is 10 MB.")
        }
        if (fileUnreadable) {
            Spacer(modifier = Modifier.height(ErrorTopGap))
            ErrorMessage(text = "We couldn't read that file. Please try a different image.")
        }
    }
}

@Composable
private fun ChangeDocumentLink(
    onClick: () -> Unit,
    colors: com.othento.core.internal.ui.theme.OthentoColors,
    typography: com.othento.core.internal.ui.theme.OthentoTypography,
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(LinkInnerGap),
    ) {
        KycIcon(
            imageVector = OthentoIcons.ArrowLeft,
            contentDescription = null,
            sizeDp = LinkIconSize,
            tint = colors.textSecondary,
        )
        Text(
            text = "Change document",
            style = typography.bodySm.copy(fontWeight = FontWeight.W500),
            color = colors.textSecondary,
        )
    }
}

@Composable
private fun DocInfoChip(document: AcceptedDocument) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val shapes = LocalOthentoShapes.current
    val flag = countryCodeToFlagEmoji(document.countryCode)
    Row(
        modifier =
            Modifier
                .clip(shapes.sm)
                .background(colors.bgHover)
                .border(width = 1.dp, color = colors.border, shape = shapes.sm)
                .padding(horizontal = ChipHorizontal, vertical = ChipVertical),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ChipGap),
    ) {
        if (flag != null) {
            Text(text = flag, style = typography.bodyLg)
        }
        Text(
            text = "${document.countryName} — ${document.typeName}",
            style = typography.bodySm.copy(fontWeight = FontWeight.W500),
            color = colors.textPrimary,
        )
    }
}

@Composable
private fun Placeholder(
    side: Side,
    document: AcceptedDocument?,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val isPassport = document?.typeName?.contains("passport", ignoreCase = true) == true
    val widthMm = document?.widthMm ?: if (isPassport) PASSPORT_WIDTH_MM else DEFAULT_WIDTH_MM
    val heightMm = document?.heightMm ?: if (isPassport) PASSPORT_HEIGHT_MM else DEFAULT_HEIGHT_MM
    val ratio = (widthMm / heightMm).toFloat()
    Box(
        modifier =
            Modifier
                .widthIn(max = PlaceholderMaxWidth)
                .fillMaxWidth()
                .aspectRatio(ratio)
                .clip(RoundedCornerShape(12.dp))
                .background(colors.bgHover)
                .border(width = PlaceholderBorderWidth, color = colors.border, shape = RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            KycIcon(
                imageVector = OthentoIcons.Picture,
                contentDescription = null,
                sizeDp = PlaceholderIconSize,
                tint = colors.textMuted,
            )
            Spacer(modifier = Modifier.height(PlaceholderTextGap))
            Text(
                text =
                    when {
                        isPassport -> "Photo page"
                        side == Side.Front -> "Front side"
                        else -> "Back side"
                    },
                style = typography.bodySm.copy(fontWeight = FontWeight.W500),
                color = colors.textMuted,
            )
        }
    }
}

@Composable
private fun PreviewBody(
    pendingCapture: PendingCapture,
    onRetake: () -> Unit,
    onConfirm: () -> Unit,
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize().padding(top = BodyTopGap),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PreviewImage(uri = pendingCapture.uri, context = context)
        Spacer(Modifier.height(12.dp))

        if (pendingCapture.isValidating) {
            ValidatingRow()
        } else if (pendingCapture.warnings.isNotEmpty()) {
            WarningsList(warnings = pendingCapture.warnings)
        }

        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            KycButton(
                onClick = onRetake,
                label = "Re-upload",
                variant = KycButtonVariant.Ghost,
                size = KycButtonSize.Lg,
                modifier = Modifier.weight(1f),
            )
            KycButton(
                onClick = onConfirm,
                label = "Continue",
                variant = KycButtonVariant.Primary,
                size = KycButtonSize.Lg,
                enabled = !pendingCapture.isValidating,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun ErrorMessage(text: String) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val shapes = LocalOthentoShapes.current
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(shapes.sm)
                .background(colors.errorBg)
                .padding(horizontal = ErrorHorizontal, vertical = ErrorVertical),
    ) {
        Text(
            text = text,
            style = typography.bodySm.copy(fontWeight = FontWeight.W500),
            color = colors.error,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

private val BodyTopGap = 16.dp
private val LinkBottomGap = 16.dp
private val LinkInnerGap = 6.dp
private val LinkIconSize = 16.dp
private val ChipHorizontal = 12.dp
private val ChipVertical = 6.dp
private val ChipGap = 8.dp
private val ChipBottomGap = 16.dp
private val PlaceholderMaxWidth = 320.dp
private val PlaceholderIconSize = 48.dp
private val PlaceholderTextGap = 12.dp
private val PlaceholderBottomGap = 24.dp
private val PlaceholderBorderWidth: Dp = 2.dp
private val HintTopGap = 8.dp
private val ErrorTopGap = 16.dp
private val ErrorHorizontal = 16.dp
private val ErrorVertical = 12.dp

private const val DEFAULT_WIDTH_MM: Double = 85.6
private const val DEFAULT_HEIGHT_MM: Double = 54.0

// ICAO 9303 TD3 (passport) physical dimensions — matches CameraCaptureScreenContent.
private const val PASSPORT_WIDTH_MM: Double = 125.0
private const val PASSPORT_HEIGHT_MM: Double = 88.0
