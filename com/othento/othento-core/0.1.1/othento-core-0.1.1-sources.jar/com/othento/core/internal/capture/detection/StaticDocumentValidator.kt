package com.othento.core.internal.capture.detection

import android.graphics.Bitmap
import android.graphics.Rect
import com.othento.core.internal.capture.detection.quality.StaticImageQualityAnalyzer

/** Pixel buffer extracted from a Bitmap region — width/height of the buffer. */
internal data class StaticPixels(
    val pixels: IntArray,
    val width: Int,
    val height: Int,
)

/**
 * Test seam over `Bitmap.getPixels`. The real impl extracts ARGB pixels from
 * the entire bitmap; tests pass a fake that returns a canned buffer.
 */
internal fun interface StaticPixelExtractor {
    fun extract(
        bitmap: Bitmap,
        region: Rect?,
    ): StaticPixels
}

/** The default extractor — uses Bitmap.getPixels over the full bitmap. */
internal object DefaultStaticPixelExtractor : StaticPixelExtractor {
    override fun extract(
        bitmap: Bitmap,
        region: Rect?,
    ): StaticPixels {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        return StaticPixels(pixels, w, h)
    }
}

/** Functional shape of the analyzer call so tests can fake it. */
internal fun interface StaticQualityFn {
    fun checkQuality(
        pixels: IntArray,
        width: Int,
        height: Int,
        region: Rect?,
        isPassport: Boolean,
    ): List<ValidationIssue>
}

internal class StaticDocumentValidator(
    private val detector: StaticDocumentDetector,
    private val pixelExtractor: StaticPixelExtractor = DefaultStaticPixelExtractor,
    private val analyzer: StaticQualityFn = StaticQualityFn(StaticImageQualityAnalyzer::checkQuality),
) {
    /** ID-1 aspect ratio (web `apps/sdk/src/app/services/document/document-validation.service.ts`). */
    private val idAspectRatio: Float = ID_CARD_WIDTH_MM / ID_CARD_HEIGHT_MM

    suspend fun validate(
        bitmap: Bitmap,
        docKind: DocKind,
    ): ValidationResult {
        val corners = detector.scan(bitmap)

        val isValidDocument =
            when {
                corners == null -> false
                !StaticGeometry.hasValidCornerAngles(corners) -> false
                !StaticGeometry.isLandscape(corners) -> false
                docKind == DocKind.Id && !StaticGeometry.matchesDocumentAspectRatio(corners, idAspectRatio) -> false
                else -> true
            }

        return if (isValidDocument) ValidationResult.Clean else result(listOf(ValidationIssue.NoCard))
    }

    private fun result(issues: List<ValidationIssue>): ValidationResult {
        val warnings = issues.map { ValidationWarning(it, ValidationMessages.forIssue(it)) }
        return ValidationResult(valid = issues.isEmpty(), issues = issues, warnings = warnings)
    }

    companion object {
        private const val ID_CARD_WIDTH_MM: Float = 85.6f
        private const val ID_CARD_HEIGHT_MM: Float = 54f
    }
}
