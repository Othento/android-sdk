package com.othento.core.internal.flow

import android.net.Uri
import com.othento.core.internal.capture.detection.DocKind
import com.othento.core.internal.capture.detection.ValidationWarning
import com.othento.core.internal.ui.screens.Side
import com.othento.core.internal.util.ImageInfo

/**
 * In-flight upload candidate. Set by [com.othento.core.internal.flow.FlowCoordinator]
 * after the user picks a file but before the upload starts; cleared when the
 * user confirms (proceeds to upload) or re-takes (returns to file-pick).
 *
 * Validation runs asynchronously — [isValidating] is `true` until the static
 * validator returns, then flips with the produced [warnings].
 */
internal data class PendingCapture(
    val uri: Uri,
    val imageInfo: ImageInfo.Resolved,
    val side: Side,
    val docKind: DocKind,
    val isValidating: Boolean,
    val warnings: List<ValidationWarning>,
    val isManualCapture: Boolean = false,
)
