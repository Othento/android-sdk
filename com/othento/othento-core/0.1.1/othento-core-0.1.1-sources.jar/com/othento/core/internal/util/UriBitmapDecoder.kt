@file:Suppress("MagicNumber")

package com.othento.core.internal.util

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Decodes a `content://` or `file://` [Uri] to a downsampled, EXIF-rotated
 * [Bitmap] suitable for static document validation.
 *
 * - Long-edge target ≈ 2048 px to keep memory bounded on low-RAM devices.
 * - EXIF rotation is applied via [Matrix] so the resulting bitmap is upright.
 * - Returns `null` on any decode failure — caller falls back to the
 *   "couldn't read file" error path on [FlowCoordinator.onFileUnreadable].
 */
internal object UriBitmapDecoder {
    private const val TARGET_LONG_EDGE: Int = 2048

    suspend fun decode(
        uri: Uri,
        resolver: ContentResolver,
    ): Bitmap? =
        withContext(Dispatchers.IO) {
            val bounds = readBounds(uri, resolver) ?: return@withContext null
            val sample = computeSampleSize(bounds.outWidth, bounds.outHeight)
            val decoded = decodeWithSample(uri, resolver, sample) ?: return@withContext null
            applyExifRotation(decoded, uri, resolver)
        }

    private fun readBounds(
        uri: Uri,
        resolver: ContentResolver,
    ): BitmapFactory.Options? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        return runCatching {
            resolver.openInputStream(uri).use { input ->
                if (input == null) return null
                BitmapFactory.decodeStream(input, null, opts)
            }
            if (opts.outWidth <= 0 || opts.outHeight <= 0) null else opts
        }.getOrNull()
    }

    private fun computeSampleSize(
        srcW: Int,
        srcH: Int,
    ): Int {
        val longEdge = maxOf(srcW, srcH)
        if (longEdge <= TARGET_LONG_EDGE) return 1
        var sample = 1
        while (longEdge / (sample * 2) >= TARGET_LONG_EDGE) sample *= 2
        return sample
    }

    private fun decodeWithSample(
        uri: Uri,
        resolver: ContentResolver,
        sample: Int,
    ): Bitmap? {
        val opts =
            BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
        return runCatching {
            resolver.openInputStream(uri).use { input ->
                if (input == null) return null
                BitmapFactory.decodeStream(input, null, opts)
            }
        }.getOrNull()
    }

    private fun applyExifRotation(
        bitmap: Bitmap,
        uri: Uri,
        resolver: ContentResolver,
    ): Bitmap {
        val orientation =
            runCatching {
                resolver.openInputStream(uri).use { input ->
                    if (input == null) {
                        return@runCatching ExifInterface.ORIENTATION_NORMAL
                    }
                    ExifInterface(input).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL,
                    )
                }
            }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        val rotation =
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }

        return if (rotation == 0f) {
            bitmap
        } else {
            val matrix = Matrix().apply { postRotate(rotation) }
            val rotated =
                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            if (rotated != bitmap) bitmap.recycle()
            rotated
        }
    }
}
