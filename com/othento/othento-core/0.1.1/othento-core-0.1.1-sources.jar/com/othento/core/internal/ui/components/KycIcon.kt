@file:Suppress("FunctionNaming", "MatchingDeclarationName")

package com.othento.core.internal.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Spec §3 — `KycIconSize`. Source: `apps/sdk/.../kyc-icon.scss:9-12`. */
@Immutable
internal enum class KycIconSize(
    val dimension: Dp,
) {
    Sm(16.dp),
    Md(20.dp),
    Lg(24.dp),
    Xl(48.dp),
}

/**
 * Sizing/coloring wrapper for an inline-vector glyph. Inherits color from
 * [LocalContentColor] unless overridden via [tint].
 *
 * Spec §3 — `kyc-icon`. Stroke-width is encoded in the [imageVector] itself
 * (default 1.5 px); this composable only controls the bounding size and tint.
 */
@Composable
internal fun KycIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    size: KycIconSize = KycIconSize.Md,
    tint: Color = LocalContentColor.current,
) {
    KycIcon(
        imageVector = imageVector,
        contentDescription = contentDescription,
        sizeDp = size.dimension,
        modifier = modifier,
        tint = tint,
    )
}

/** Custom-size overload — used by [KycStatusIcon] for the spec-mandated 36 dp glyph. */
@Composable
internal fun KycIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    sizeDp: Dp,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    Icon(
        imageVector = imageVector,
        contentDescription = contentDescription,
        modifier = modifier.size(sizeDp),
        tint = tint,
    )
}
