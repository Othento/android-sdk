package com.othento.core.internal.data.model

/**
 * Domain model for an entry in the documents-list response, used to render
 * the document-select screen (Phase 5).
 *
 * Per [docs/spec/09-data-models.md §2.4]. `widthMm` / `heightMm` may be
 * null when the backend doesn't know the physical dimensions; the camera
 * cutout (Phase 6) falls back to a default aspect ratio in that case.
 */
internal data class AcceptedDocument(
    val documentId: String,
    val countryCode: String?,
    val countryName: String,
    val countryIcon: String,
    val typeName: String,
    val widthMm: Double?,
    val heightMm: Double?,
    val requireBothSides: Boolean,
)
