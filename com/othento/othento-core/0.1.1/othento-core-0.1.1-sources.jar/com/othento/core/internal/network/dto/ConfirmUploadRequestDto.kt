package com.othento.core.internal.network.dto

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.othento.core.internal.data.model.ChallengeType

/**
 * Wire body for `POST .../confirm-upload`.
 *
 * Mirrors [docs/spec/09-data-models.md §3.7]. The wire spec types
 * `challengeType` as a plain string but in practice it is always a
 * [ChallengeType] literal — using the enum here lets the typesafe layer
 * propagate from the SDK's flow code.
 */
@JsonClass(generateAdapter = true)
internal data class ConfirmUploadRequestDto(
    val attemptStepId: String,
    val challengeType: ChallengeType,
    val fileName: String,
    @Json(name = "IsManualCapture") val isManualCapture: Boolean = false,
)
