package com.othento.core.internal.data.model

import com.squareup.moshi.Json

/**
 * Channel an OTP was delivered through.
 *
 * The wire values are lower-case (`phone` / `email`) per
 * [docs/spec/09-data-models.md §1.9], which differs from the Pascal-case
 * status enums — hence the explicit [Json] mapping.
 */
internal enum class OtpChannel {
    @Json(name = "phone")
    Phone,

    @Json(name = "email")
    Email,
}
