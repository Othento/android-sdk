package com.othento.core.internal.capture

import com.othento.core.internal.data.model.ChallengeStatus
import com.othento.core.internal.data.model.ChallengeType
import com.othento.core.internal.data.model.Session

/**
 * Discriminates the two purposes the selfie-capture screen serves —
 * face match (single JPEG, compared to the document photo) and passive
 * liveness check (recorded MP4 clip). Both share UI per spec
 * [docs/spec/06-screens/08-selfie-capture.md] line 220 — only the chrome
 * pill copy, intro-sheet eyebrow / title, and upload challenge type
 * differ. Phase 8.
 */
internal enum class SelfieKind {
    FaceMatch,
    Liveness,
}

/**
 * Resolves the selfie kind from the active step's challenges (NOT from
 * its stepCode). Mirrors the web SDK's
 * [`apps/sdk/.../session-flow.service.ts:76-82`] — "prefer LivenessVideo
 * if present in the current step's challenges, else Selfie". Steps in
 * the wild can carry both challenges (e.g. a liveness step with a
 * fallback Selfie challenge), and the backend rejects mismatched
 * uploads with a 404 even when the stepCode is `step_liveness_check`.
 *
 * Returns `null` only when neither challenge type is awaiting upload —
 * the screen would not have been routed to in that case.
 */
internal val Session.selfieKind: SelfieKind?
    get() {
        val challenges = currentStep?.challenges ?: return null
        val awaitingLiveness =
            challenges.any {
                it.challengeType == ChallengeType.LivenessVideo &&
                    it.challengeStatus == ChallengeStatus.AwaitingUpload
            }
        if (awaitingLiveness) return SelfieKind.Liveness
        val awaitingSelfie =
            challenges.any {
                it.challengeType == ChallengeType.Selfie &&
                    it.challengeStatus == ChallengeStatus.AwaitingUpload
            }
        if (awaitingSelfie) return SelfieKind.FaceMatch
        return null
    }
