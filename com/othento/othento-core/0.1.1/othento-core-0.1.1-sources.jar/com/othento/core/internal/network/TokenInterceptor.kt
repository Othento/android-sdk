package com.othento.core.internal.network

import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response

/**
 * OkHttp interceptor that attaches `X-SAT` / `X-ST` / `X-SRT` to requests
 * targeting token-mode endpoints on the SDK base host.
 *
 * Spec reference: [docs/spec/10-network-layer.md §2.2] (web's
 * `sdk-token-api.interceptor.ts`). The web sends all three headers when
 * present; we follow that — the dev backend picks the most specific.
 *
 * The interceptor coexists with [ApiKeyInterceptor]. Order in the OkHttp
 * chain doesn't matter for correctness because the gates are mutually
 * exclusive:
 * - [ApiKeyInterceptor] only fires on the create endpoint
 *   ([OthentoApiPaths.CREATE_SESSION]).
 * - [TokenInterceptor] fires on every other SDK-host endpoint, but only
 *   when the [TokenStore] has tokens (the create call leaves the store
 *   empty until its response is mapped).
 *
 * S3 PUTs (different host) bypass both interceptors per the host gate —
 * leaking the apiKey or the SAT/ST/SRT bundle to S3 would be a security
 * finding (spec §2.1).
 *
 * @property tokenStore in-memory store the interceptor reads from on every
 *                      request — the FlowCoordinator updates it after every
 *                      token-mode response.
 * @property baseUrl    configured SDK base URL; only requests whose
 *                      scheme + host + port match receive headers.
 */
internal class TokenInterceptor(
    private val tokenStore: TokenStore,
    baseUrl: HttpUrl,
) : Interceptor {
    /**
     * Canonical `scheme://host:port` of the configured base URL — same shape
     * as [ApiKeyInterceptor]'s `sdkOrigin` so the two gates stay in lock-step.
     */
    private val sdkOrigin: String = "${baseUrl.scheme}://${baseUrl.host}:${baseUrl.port}"

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        if (!targetsSdkHost(request.url) || !tokenStore.hasAnyToken()) {
            return chain.proceed(request)
        }
        // The create call goes through the apiKey interceptor with no token
        // headers; once the create response lands the store has tokens, but
        // create itself never re-runs in the same launch — so we don't need
        // a path-level gate here.
        return chain.proceed(addTokenHeaders(request))
    }

    private fun addTokenHeaders(request: Request): Request {
        val builder = request.newBuilder()
        tokenStore.sat?.let { builder.header(HEADER_X_SAT, it) }
        tokenStore.st?.let { builder.header(HEADER_X_ST, it) }
        tokenStore.srt?.let { builder.header(HEADER_X_SRT, it) }
        return builder.build()
    }

    private fun targetsSdkHost(url: HttpUrl): Boolean = "${url.scheme}://${url.host}:${url.port}" == sdkOrigin

    internal companion object {
        const val HEADER_X_SAT: String = "X-SAT"
        const val HEADER_X_ST: String = "X-ST"
        const val HEADER_X_SRT: String = "X-SRT"
    }
}
