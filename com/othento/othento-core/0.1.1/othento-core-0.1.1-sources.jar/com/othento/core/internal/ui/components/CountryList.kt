package com.othento.core.internal.ui.components

/**
 * Static country reference list for the Phase 9 phone-destination
 * picker. Bundled (≈ 50 KB at compile-time) to keep the SDK
 * self-contained — no runtime asset fetch, no network for the picker.
 *
 * The list is a curated subset of ISO-3166-1 alpha-2 codes that the
 * web SDK exposes. Order is by display name; the picker filters
 * client-side.
 *
 * Flag emoji is derived from the alpha-2 code via two regional-indicator
 * code points (offset `'A'.code - 0x1F1E6` per code point). Hosts
 * shipping a custom flag set should layer on top.
 */
internal data class Country(
    val code: String,
    val name: String,
    val dialCode: String,
) {
    val flagEmoji: String
        get() {
            if (code.length != 2) return ""
            val a = code[0].uppercaseChar()
            val b = code[1].uppercaseChar()
            if (a !in 'A'..'Z' || b !in 'A'..'Z') return ""
            val first = REGIONAL_INDICATOR_OFFSET + (a.code - 'A'.code)
            val second = REGIONAL_INDICATOR_OFFSET + (b.code - 'A'.code)
            val builder = StringBuilder()
            builder.appendCodePoint(first)
            builder.appendCodePoint(second)
            return builder.toString()
        }

    private companion object {
        const val REGIONAL_INDICATOR_OFFSET: Int = 0x1F1E6
    }
}

internal object CountryList {
    /**
     * Curated list. Add countries here as hosts request — keep ISO-2
     * canonical and dial codes per ITU-T E.164.
     */
    val ALL: List<Country> =
        listOf(
            Country("AE", "United Arab Emirates", "+971"),
            Country("AR", "Argentina", "+54"),
            Country("AT", "Austria", "+43"),
            Country("AU", "Australia", "+61"),
            Country("BE", "Belgium", "+32"),
            Country("BH", "Bahrain", "+973"),
            Country("BR", "Brazil", "+55"),
            Country("CA", "Canada", "+1"),
            Country("CH", "Switzerland", "+41"),
            Country("CN", "China", "+86"),
            Country("CZ", "Czechia", "+420"),
            Country("DE", "Germany", "+49"),
            Country("DK", "Denmark", "+45"),
            Country("EG", "Egypt", "+20"),
            Country("ES", "Spain", "+34"),
            Country("FI", "Finland", "+358"),
            Country("FR", "France", "+33"),
            Country("GB", "United Kingdom", "+44"),
            Country("GR", "Greece", "+30"),
            Country("HK", "Hong Kong", "+852"),
            Country("ID", "Indonesia", "+62"),
            Country("IE", "Ireland", "+353"),
            Country("IL", "Israel", "+972"),
            Country("IN", "India", "+91"),
            Country("IQ", "Iraq", "+964"),
            Country("IR", "Iran", "+98"),
            Country("IT", "Italy", "+39"),
            Country("JO", "Jordan", "+962"),
            Country("JP", "Japan", "+81"),
            Country("KE", "Kenya", "+254"),
            Country("KR", "South Korea", "+82"),
            Country("KW", "Kuwait", "+965"),
            Country("LB", "Lebanon", "+961"),
            Country("LU", "Luxembourg", "+352"),
            Country("MA", "Morocco", "+212"),
            Country("MX", "Mexico", "+52"),
            Country("MY", "Malaysia", "+60"),
            Country("NG", "Nigeria", "+234"),
            Country("NL", "Netherlands", "+31"),
            Country("NO", "Norway", "+47"),
            Country("NZ", "New Zealand", "+64"),
            Country("OM", "Oman", "+968"),
            Country("PH", "Philippines", "+63"),
            Country("PK", "Pakistan", "+92"),
            Country("PL", "Poland", "+48"),
            Country("PT", "Portugal", "+351"),
            Country("QA", "Qatar", "+974"),
            Country("RO", "Romania", "+40"),
            Country("RU", "Russia", "+7"),
            Country("SA", "Saudi Arabia", "+966"),
            Country("SE", "Sweden", "+46"),
            Country("SG", "Singapore", "+65"),
            Country("SY", "Syria", "+963"),
            Country("TH", "Thailand", "+66"),
            Country("TN", "Tunisia", "+216"),
            Country("TR", "Türkiye", "+90"),
            Country("TW", "Taiwan", "+886"),
            Country("UA", "Ukraine", "+380"),
            Country("US", "United States", "+1"),
            Country("VN", "Vietnam", "+84"),
            Country("YE", "Yemen", "+967"),
            Country("ZA", "South Africa", "+27"),
        )

    const val DEFAULT_CODE: String = "AE"

    fun byCode(code: String): Country? = ALL.firstOrNull { it.code.equals(code, ignoreCase = true) }

    fun filter(query: String): List<Country> {
        val q = query.trim()
        if (q.isEmpty()) return ALL
        return ALL.filter { country ->
            country.name.contains(q, ignoreCase = true) ||
                country.code.equals(q, ignoreCase = true) ||
                country.dialCode.contains(q, ignoreCase = false)
        }
    }
}
