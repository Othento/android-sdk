package com.othento.core.internal.flow

import com.othento.core.api.OthentoConfig

/**
 * Pluggable strategy that produces a [SessionResolveResult] for a given
 * [OthentoConfig]. Phase 4 ships a fixture-backed implementation
 * (`FixtureSessionSource`); Phase 5+ swaps in a real `SessionRepository`-
 * backed implementation that calls
 * [com.othento.core.internal.network.OthentoApi.createSession].
 */
internal interface SessionSource {
    suspend fun resolveSession(config: OthentoConfig): SessionResolveResult
}
