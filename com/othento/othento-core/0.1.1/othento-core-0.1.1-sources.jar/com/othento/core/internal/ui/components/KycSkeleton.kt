@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MatchingDeclarationName")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoShapes

/** Spec §11 — `KycSkeleton --sm/md/lg/full`. */
@Immutable
internal enum class KycSkeletonRadius { Sm, Md, Lg, Full }

/**
 * Pulsing placeholder block. Faithful port of `apps/sdk/.../kyc-skeleton/`:
 *
 * - `background: var(--color-bg-hover)`.
 * - Animation: `kyc-skeleton-pulse 1.8s ease-in-out infinite` — opacity
 *   1 → 0.4 → 1.
 * - Reduced motion: animation off, opacity fixed at 0.7.
 *
 * Default width matches the web's `display: block` (full-width block).
 */
@Composable
internal fun KycSkeleton(
    modifier: Modifier = Modifier,
    width: Dp? = null,
    height: Dp = SkeletonDefaultHeight,
    radius: KycSkeletonRadius = KycSkeletonRadius.Md,
) {
    val colors = LocalOthentoColors.current
    val motion = LocalOthentoMotion.current
    val shape = shapeFor(radius)

    val targetAlpha: Float =
        if (motion.reducedMotion) {
            ReducedMotionAlpha
        } else {
            val transition = rememberInfiniteTransition(label = "kyc-skeleton-pulse")
            val animated by transition.animateFloat(
                initialValue = 1f,
                targetValue = SkeletonMinAlpha,
                animationSpec =
                    infiniteRepeatable(
                        animation = tween(durationMillis = SkeletonPulseMs, easing = motion.easeInOut),
                        repeatMode = RepeatMode.Reverse,
                    ),
                label = "kyc-skeleton-alpha",
            )
            animated
        }

    val widthModifier = if (width != null) Modifier.width(width) else Modifier.fillMaxWidth()

    Box(
        modifier =
            modifier
                .then(widthModifier)
                .height(height)
                .clip(shape)
                .alpha(targetAlpha)
                .background(colors.bgHover),
    )
}

@Composable
private fun shapeFor(radius: KycSkeletonRadius): Shape {
    val shapes = LocalOthentoShapes.current
    return when (radius) {
        KycSkeletonRadius.Sm -> shapes.sm
        KycSkeletonRadius.Md -> shapes.md
        KycSkeletonRadius.Lg -> shapes.lg
        KycSkeletonRadius.Full -> shapes.full
    }
}

private val SkeletonDefaultHeight = 16.dp
private const val SkeletonPulseMs = 1800
private const val SkeletonMinAlpha = 0.4f
private const val ReducedMotionAlpha = 0.7f
