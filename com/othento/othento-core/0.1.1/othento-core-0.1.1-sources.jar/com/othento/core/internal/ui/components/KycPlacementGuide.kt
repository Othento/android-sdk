@file:Suppress("FunctionNaming", "MagicNumber")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * Compose port of the web's
 * `apps/sdk/src/app/components/placement-guide/placement-guide.component.ts`.
 *
 * Renders a stylised wireframe of the document the user is being asked to
 * place inside the cutout. Three variants:
 * - [PlacementGuideKind.IdCardFront] — outline + photo box + text bars.
 * - [PlacementGuideKind.IdCardBack]  — outline + magnetic stripe + signature
 *   strip + barcode lines.
 * - [PlacementGuideKind.Document]    — generic outline + three text bars.
 *
 * The passport variant (web variant `passport`) is deferred to Phase 7
 * alongside MRZ / photo-gate detection (V4).
 *
 * The guide auto-fades after the parent dismisses it via the `visible`
 * flag — typically a short window after the camera binds.
 */
@Composable
internal fun KycPlacementGuide(
    kind: PlacementGuideKind,
    visible: Boolean,
    modifier: Modifier = Modifier,
) {
    var alphaTarget by remember { mutableStateOf(0f) }
    val animatedAlpha by animateFloatAsState(
        targetValue = alphaTarget,
        animationSpec = tween(durationMillis = 350, easing = LinearEasing),
        label = "placement-guide-alpha",
    )
    LaunchedEffect(visible) {
        alphaTarget = if (visible) 1f else 0f
    }
    if (animatedAlpha == 0f && !visible) return

    Canvas(modifier = modifier.fillMaxSize()) {
        when (kind) {
            PlacementGuideKind.IdCardFront -> drawIdCardFront(animatedAlpha)
            PlacementGuideKind.IdCardBack -> drawIdCardBack(animatedAlpha)
            PlacementGuideKind.Document -> drawDocument(animatedAlpha)
            PlacementGuideKind.Selfie,
            PlacementGuideKind.Liveness,
            -> Unit
        }
    }
}

internal enum class PlacementGuideKind {
    IdCardFront,
    IdCardBack,
    Document,
    Selfie,
    Liveness,
}

private fun DrawScope.drawIdCardFront(alpha: Float) {
    val white = Color.White.copy(alpha = 0.9f * alpha)
    val whiteSoft = Color.White.copy(alpha = 0.55f * alpha)
    val w = size.width
    val h = size.height

    // Outer card outline.
    drawRoundRect(
        color = white,
        topLeft = Offset(w * 0.06f, h * 0.06f),
        size = Size(w * 0.88f, h * 0.88f),
        cornerRadius = CornerRadius(w * 0.04f),
        style = Stroke(width = w * 0.012f),
    )
    // Photo box.
    drawRoundRect(
        color = whiteSoft,
        topLeft = Offset(w * 0.12f, h * 0.20f),
        size = Size(w * 0.27f, h * 0.55f),
        cornerRadius = CornerRadius(w * 0.025f),
        style = Stroke(width = w * 0.010f),
    )
    // Text bars on the right side.
    val barX = w * 0.45f
    val barWidthMax = w * 0.45f
    listOf(
        h * 0.28f to barWidthMax,
        h * 0.40f to barWidthMax * 0.85f,
        h * 0.52f to barWidthMax * 0.65f,
    ).forEach { (y, width) ->
        drawRoundRect(
            color = whiteSoft,
            topLeft = Offset(barX, y),
            size = Size(width, h * 0.04f),
            cornerRadius = CornerRadius(h * 0.02f),
        )
    }
    // Bottom strip.
    drawRoundRect(
        color = whiteSoft.copy(alpha = whiteSoft.alpha * 0.9f),
        topLeft = Offset(w * 0.12f, h * 0.80f),
        size = Size(w * 0.76f, h * 0.04f),
        cornerRadius = CornerRadius(h * 0.02f),
    )
}

private fun DrawScope.drawIdCardBack(alpha: Float) {
    val white = Color.White.copy(alpha = 0.9f * alpha)
    val whiteSoft = Color.White.copy(alpha = 0.45f * alpha)
    val w = size.width
    val h = size.height

    drawRoundRect(
        color = white,
        topLeft = Offset(w * 0.06f, h * 0.06f),
        size = Size(w * 0.88f, h * 0.88f),
        cornerRadius = CornerRadius(w * 0.04f),
        style = Stroke(width = w * 0.012f),
    )
    // Magnetic stripe.
    drawRect(
        color = whiteSoft,
        topLeft = Offset(w * 0.06f, h * 0.16f),
        size = Size(w * 0.88f, h * 0.18f),
    )
    // Signature strip.
    drawRoundRect(
        color = whiteSoft,
        topLeft = Offset(w * 0.12f, h * 0.42f),
        size = Size(w * 0.45f, h * 0.14f),
        cornerRadius = CornerRadius(w * 0.015f),
        style = Stroke(width = w * 0.008f),
    )
    // Barcode panel.
    drawRoundRect(
        color = whiteSoft,
        topLeft = Offset(w * 0.62f, h * 0.42f),
        size = Size(w * 0.26f, h * 0.40f),
        cornerRadius = CornerRadius(w * 0.015f),
        style = Stroke(width = w * 0.008f),
    )
    // Barcode lines inside the panel.
    val baseX = w * 0.65f
    val barcodeYTop = h * 0.46f
    val barcodeHeight = h * 0.32f
    val widths = listOf(0.018f, 0.010f, 0.024f, 0.012f, 0.014f, 0.020f, 0.012f, 0.020f)
    var x = baseX
    widths.forEach { wRel ->
        drawRect(
            color = whiteSoft,
            topLeft = Offset(x, barcodeYTop),
            size = Size(w * wRel, barcodeHeight),
        )
        x += w * (wRel + 0.012f)
    }
    // Small text bars under the magnetic stripe.
    listOf(0.50f, 0.58f, 0.66f).forEachIndexed { idx, yRel ->
        val width = w * (0.50f - idx * 0.10f)
        drawRoundRect(
            color = whiteSoft.copy(alpha = whiteSoft.alpha * 0.8f),
            topLeft = Offset(w * 0.12f, h * yRel),
            size = Size(width, h * 0.02f),
            cornerRadius = CornerRadius(h * 0.01f),
        )
    }
}

private fun DrawScope.drawDocument(alpha: Float) {
    val white = Color.White.copy(alpha = 0.9f * alpha)
    val whiteSoft = Color.White.copy(alpha = 0.50f * alpha)
    val w = size.width
    val h = size.height

    drawRoundRect(
        color = white,
        topLeft = Offset(w * 0.06f, h * 0.06f),
        size = Size(w * 0.88f, h * 0.88f),
        cornerRadius = CornerRadius(w * 0.04f),
        style = Stroke(width = w * 0.012f),
    )
    listOf(
        h * 0.30f to w * 0.78f,
        h * 0.45f to w * 0.66f,
        h * 0.60f to w * 0.55f,
    ).forEach { (y, width) ->
        drawRoundRect(
            color = whiteSoft,
            topLeft = Offset(w * 0.12f, y),
            size = Size(width, h * 0.04f),
            cornerRadius = CornerRadius(h * 0.02f),
        )
    }
}
