@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber", "LongMethod")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonSize
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.components.KycStepList
import com.othento.core.internal.ui.components.KycStepListVariant
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.screens.common.RETURN_TO_APP_LABEL
import com.othento.core.internal.ui.screens.common.RetryAttempts
import com.othento.core.internal.ui.screens.common.StepCardsBuilder
import com.othento.core.internal.ui.theme.OthentoColors
import com.othento.core.internal.ui.theme.OthentoTypography
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Soft-failure recovery screen. Faithful port of the web SDK's
 * `failed-retry-screen` (`apps/sdk/.../screens/failed-retry/`): an error-red
 * header (badge → honest headline → reason → remaining-attempts meter)
 * followed by a primary-blue "What to redo" pivot and the steps to repeat.
 *
 * - Title / subtitle copy match `verify.ts` (`"That attempt didn't pass"` +
 *   the `retrySubtitle` fallback).
 * - The attempts meter prefers the backend's `reinitInfo.attemptsRemaining`
 *   ([RetryAttempts]); it hides when no reliable count remains.
 * - The step list reads `reinitInfo.stepsToRetry` when present (mid-flow
 *   partial retry), else the full `steps[]`.
 *
 * Android keeps the secondary "Return to App" CTA the web omits — the SDK is
 * launched by a host, so an escape hatch back to the host is retained
 * (logged in `99-open-questions.md`).
 */
@Composable
internal fun FailedRetryScreen(
    session: Session,
    brandName: String,
    onTryAgainClick: () -> Unit,
    onReturnToApp: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val cards =
        remember(session) {
            val reinit = session.reinitInfo?.stepsToRetry
            if (!reinit.isNullOrEmpty()) {
                StepCardsBuilder.fromReinitSteps(reinit)
            } else {
                StepCardsBuilder.toCards(session.steps)
            }
        }
    val attempts = remember(session) { RetryAttempts.from(session) }

    KycScreen(
        zone = KycScreenZone.Guided,
        bodyFill = false,
        headerBorder = false,
        logoName = brandName,
        body = {
            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(top = HeaderTopGap),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                RetryBadge(colors)
                Spacer(modifier = Modifier.height(BadgeTitleGap))
                Text(
                    text = "That attempt didn't pass",
                    style = typography.display,
                    color = colors.textHeading,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = HeroMaxWidth).padding(horizontal = HeroHorizontal),
                )
                Spacer(modifier = Modifier.height(TitleSubtitleGap))
                Text(
                    text = "We couldn't complete your verification. Review the steps below and try again.",
                    style = typography.bodyLg,
                    color = colors.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = HeroMaxWidth).padding(horizontal = HeroHorizontal),
                )
                if (attempts != null) {
                    Spacer(modifier = Modifier.height(SubtitleMeterGap))
                    AttemptsMeter(attempts = attempts, colors = colors, typography = typography)
                }
                Spacer(modifier = Modifier.height(RecoveryTopGap))
                RecoveryPivot(colors = colors, typography = typography)
                Spacer(modifier = Modifier.height(PivotStepsGap))
                KycStepList(
                    steps = cards,
                    variant = KycStepListVariant.Detailed,
                    showDurations = false,
                )
                Spacer(modifier = Modifier.height(BottomGap))
            }
        },
        footer = {
            Column(modifier = Modifier.fillMaxWidth()) {
                KycButton(
                    onClick = onTryAgainClick,
                    label = "Try Again",
                    variant = KycButtonVariant.Primary,
                    size = KycButtonSize.Lg,
                    fullWidth = true,
                )
                Spacer(modifier = Modifier.height(FooterInnerGap))
                KycButton(
                    onClick = onReturnToApp,
                    label = RETURN_TO_APP_LABEL,
                    variant = KycButtonVariant.Ghost,
                    size = KycButtonSize.Lg,
                    fullWidth = true,
                )
            }
        },
    )
}

/**
 * 56-dp error-tinted disc with a warning-triangle glyph and a faint outer
 * ring — the web badge's `box-shadow: 0 0 0 6px error@7%` over an
 * `error@11%` disc.
 */
@Composable
private fun RetryBadge(colors: OthentoColors) {
    Box(
        modifier = Modifier.size(BadgeRingSize),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier =
                Modifier
                    .size(BadgeRingSize)
                    .clip(CircleShape)
                    .background(colors.error.copy(alpha = 0.07f)),
        )
        Box(
            modifier =
                Modifier
                    .size(BadgeSize)
                    .clip(CircleShape)
                    .background(colors.errorBg),
            contentAlignment = Alignment.Center,
        ) {
            KycIcon(
                imageVector = OthentoIcons.WarningTriangle,
                contentDescription = null,
                sizeDp = BadgeGlyphSize,
                tint = colors.error,
            )
        }
    }
}

/**
 * The "you still have another chance" beat: a rounded pill with spent-first
 * pips (spent = faded-red, remaining = primary) and an "N tries left" label.
 */
@Composable
private fun AttemptsMeter(
    attempts: RetryAttempts,
    colors: OthentoColors,
    typography: OthentoTypography,
) {
    val spentPip = lerp(colors.border, colors.error, 0.42f)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(MeterGap),
        modifier =
            Modifier
                .clip(CircleShape)
                .background(colors.bgBase)
                .border(width = 1.dp, color = colors.border, shape = CircleShape)
                .padding(horizontal = MeterHorizontal, vertical = MeterVertical),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(PipGap),
        ) {
            attempts.pips.forEach { spent ->
                Box(
                    modifier =
                        Modifier
                            .size(PipSize)
                            .clip(CircleShape)
                            .background(if (spent) spentPip else colors.primary),
                )
            }
        }
        val unit = if (attempts.remaining == 1) "try" else "tries"
        Text(
            text =
                buildAnnotatedString {
                    withStyle(SpanStyle(fontWeight = FontWeight.W700, color = colors.textPrimary)) {
                        append(attempts.remaining.toString())
                    }
                    append(" $unit left")
                },
            style = typography.caption,
            color = colors.textSecondary,
        )
    }
}

/** Horizontal divider with a centered "WHAT TO REDO" eyebrow in primary. */
@Composable
private fun RecoveryPivot(
    colors: OthentoColors,
    typography: OthentoTypography,
) {
    Row(
        modifier = Modifier.fillMaxWidth().widthIn(max = PivotMaxWidth),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(PivotGap),
    ) {
        Box(modifier = Modifier.weight(1f).height(1.dp).background(colors.border))
        Text(
            text = "WHAT TO REDO",
            style = typography.microEyebrow,
            color = colors.primary,
        )
        Box(modifier = Modifier.weight(1f).height(1.dp).background(colors.border))
    }
}

private val HeaderTopGap = 24.dp
private val BadgeRingSize = 68.dp
private val BadgeSize = 56.dp
private val BadgeGlyphSize = 26.dp
private val BadgeTitleGap = 16.dp
private val TitleSubtitleGap = 12.dp
private val SubtitleMeterGap = 16.dp
private val RecoveryTopGap = 26.dp
private val PivotStepsGap = 18.dp
private val BottomGap = 16.dp
private val FooterInnerGap = 8.dp
private val HeroMaxWidth = 360.dp
private val HeroHorizontal = 8.dp
private val MeterGap = 10.dp
private val MeterHorizontal = 14.dp
private val MeterVertical = 7.dp
private val PipGap = 5.dp
private val PipSize = 8.dp
private val PivotMaxWidth = 440.dp
private val PivotGap = 12.dp
