package com.othento.core.internal.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Linear-sRGB color mix matching CSS `color-mix(in srgb, a [aPct]%, b)`.
 *
 * Example: `colorMix(primary, 0.10f, bgBase)` ≡ `color-mix(in srgb, primary 10%, bgBase)`.
 *
 * Used by `KycStepList` icon tile (10–16 % primary tint), the meta pill
 * (6 % primary tint background, 14 % primary alpha border), and a few other
 * primary-tint chrome elements throughout the SDK.
 */
internal fun colorMix(
    a: Color,
    aFraction: Float,
    b: Color,
): Color {
    val f = aFraction.coerceIn(0f, 1f)
    val g = 1f - f
    return Color(
        red = a.red * f + b.red * g,
        green = a.green * f + b.green * g,
        blue = a.blue * f + b.blue * g,
        alpha = a.alpha * f + b.alpha * g,
    )
}
