@file:Suppress("MagicNumber")

package com.othento.core.internal.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Resolved color tokens. Values are taken from [docs/spec/04-design-system.md] §1
 * (light theme; the dark palette ships with the spec but is not wired in Phase 2 —
 * see open question U2).
 */
@Immutable
internal data class OthentoColors(
    // brand / primary
    val primary: Color,
    val primaryHover: Color,
    val primaryActive: Color,
    val primaryBg: Color,
    // status — success
    val success: Color,
    val successBg: Color,
    val successBorder: Color,
    val successText: Color,
    // status — warning
    val warning: Color,
    val warningBg: Color,
    val warningBorder: Color,
    val warningText: Color,
    // status — error / danger
    val error: Color,
    val errorBg: Color,
    val errorBorder: Color,
    val errorText: Color,
    val danger: Color,
    // text neutrals
    val textPrimary: Color,
    val textHeading: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val textDisabled: Color,
    // bg / border neutrals
    val bgBase: Color,
    val bgLayout: Color,
    val bgContainer: Color,
    val bgElevated: Color,
    val bgHover: Color,
    val border: Color,
    val borderHover: Color,
) {
    companion object {
        /** Spec §1 light theme. */
        val Light: OthentoColors =
            OthentoColors(
                primary = Color(0xFF345FCF),
                primaryHover = Color(0xFF2F58BD),
                primaryActive = Color(0xFF2C50A8),
                primaryBg = Color(0xFFEEF2FB),
                success = Color(0xFF059669),
                successBg = Color(0xFFECFDF5),
                successBorder = Color(0xFF6EE7B7),
                successText = Color(0xFF065F46),
                warning = Color(0xFFD97706),
                warningBg = Color(0xFFFFFBEB),
                warningBorder = Color(0xFFFCD34D),
                warningText = Color(0xFF92400E),
                error = Color(0xFFDC2626),
                errorBg = Color(0xFFFEF2F2),
                errorBorder = Color(0xFFFECACA),
                errorText = Color(0xFF991B1B),
                danger = Color(0xFFB91C1C),
                textPrimary = Color(0xFF0F172A),
                textHeading = Color(0xFF0F172A),
                textSecondary = Color(0xFF475569),
                textMuted = Color(0xFF94A3B8),
                textDisabled = Color(0xFFCBD5E1),
                bgBase = Color(0xFFFFFFFF),
                bgLayout = Color(0xFFF8FAFC),
                bgContainer = Color(0xFFFFFFFF),
                bgElevated = Color(0xFFFFFFFF),
                bgHover = Color(0xFFF1F5F9),
                border = Color(0xFFE2E8F0),
                borderHover = Color(0xFFCBD5E1),
            )
    }
}

internal val LocalOthentoColors =
    staticCompositionLocalOf<OthentoColors> {
        error("OthentoColors not provided. Wrap content in OthentoTheme { … }.")
    }
