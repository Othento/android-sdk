package com.othento.core.api

/**
 * Immutable configuration for an Othento SDK session.
 *
 * Construct via [Builder]; instances should not be mutated after [Builder.build]
 * returns. Mirrors the cross-platform contract's `OthentoConfig` shape — there is
 * no `environment` / `baseUrlOverride` / `branding` / `locale` field on the
 * public surface. Sandbox vs production is driven entirely by the [apiKey]
 * prefix (`pk_sandbox_…` / `pk_live_…`).
 */
@ConsistentCopyVisibility
public data class OthentoConfig internal constructor(
    val mode: OthentoMode,
    val apiKey: String?,
    val callbackUrl: String?,
    val callbackReceiver: OthentoCallbackReceiver?,
    val metadata: String?,
    val expectedDetails: OthentoExpectedDetails?,
    val closeOnComplete: Boolean,
    val loggingEnabled: Boolean,
) {
    /**
     * Fluent builder. The `build()` method enforces the same required-field
     * rules as the cross-platform contract:
     *
     * | Mode      | Required fields                                              |
     * |-----------|--------------------------------------------------------------|
     * | `Create`  | `apiKey`, `workflowExternalId` (via `create`), `clientData`  |
     * | `Token`   | `sat` (via `tokenMode`); `apiKey` is **not** required        |
     *
     * Missing or malformed required fields raise [OthentoConfigException]
     * **synchronously from this method** — they never surface through
     * [OthentoSDKListener.onError].
     */
    public class Builder {
        private var mode: OthentoMode? = null
        private var apiKey: String? = null
        private var callbackUrl: String? = null
        private var callbackReceiver: OthentoCallbackReceiver? = null
        private var metadata: String? = null
        private var expectedDetails: OthentoExpectedDetails? = null
        private var closeOnComplete: Boolean = false
        private var loggingEnabled: Boolean = false

        /** Sets [OthentoMode.Create]. The SDK will create a fresh session at launch. */
        public fun create(
            workflowExternalId: String,
            clientData: String,
        ): Builder =
            apply {
                mode = OthentoMode.Create(workflowExternalId, clientData)
            }

        /**
         * Sets [OthentoMode.Token]. The SDK skips the create-session call and
         * starts at the first poll with `X-SAT`. Use when the session was
         * minted server-side and the SAT delivered to the device out-of-band
         * (typically via a deeplink).
         */
        public fun tokenMode(sat: String): Builder =
            apply {
                mode = OthentoMode.Token(sat)
            }

        public fun apiKey(apiKey: String): Builder =
            apply {
                this.apiKey = apiKey
            }

        public fun callbackUrl(url: String): Builder =
            apply {
                this.callbackUrl = url
            }

        public fun callbackReceiver(receiver: OthentoCallbackReceiver): Builder =
            apply {
                this.callbackReceiver = receiver
            }

        public fun metadata(metadata: String): Builder =
            apply {
                this.metadata = metadata
            }

        public fun expectedDetails(details: OthentoExpectedDetails): Builder =
            apply {
                this.expectedDetails = details
            }

        /**
         * When `true`, the SDK auto-dismisses itself as soon as the flow
         * reaches a terminal screen (Approved / Declined / In-review / Expired
         * / failed / error) — the host's terminal listener event still fires
         * first. When `false` (default) the SDK leaves the terminal screen up
         * until the user taps its "return to app" action. Mirrors the
         * cross-vendor `closeOnComplete` option.
         */
        public fun closeOnComplete(enabled: Boolean): Builder =
            apply {
                this.closeOnComplete = enabled
            }

        /**
         * When `true`, the SDK emits verbose HTTP logging (request/response
         * bodies, with every auth header redacted) so an integrator can debug
         * the flow against their own backend. `false` (default) logs nothing.
         * Debug builds of the SDK always log regardless of this flag.
         */
        public fun loggingEnabled(enabled: Boolean): Builder =
            apply {
                this.loggingEnabled = enabled
            }

        public fun build(): OthentoConfig {
            val resolvedMode =
                mode ?: throw OthentoConfigException(
                    OthentoError.ConfigInvalid(NO_MODE_SET_MESSAGE),
                    NO_MODE_SET_MESSAGE,
                )
            validate(resolvedMode, apiKey)

            return OthentoConfig(
                mode = resolvedMode,
                apiKey = apiKey,
                callbackUrl = callbackUrl,
                callbackReceiver = callbackReceiver,
                metadata = metadata,
                expectedDetails = expectedDetails,
                closeOnComplete = closeOnComplete,
                loggingEnabled = loggingEnabled,
            )
        }

        private companion object {
            const val NO_MODE_SET_MESSAGE =
                "No mode set on OthentoConfig.Builder; call create(...) or tokenMode(...)."
        }
    }
}

private fun validate(
    mode: OthentoMode,
    apiKey: String?,
) {
    val (error, message) = firstMissingField(mode, apiKey) ?: return
    throw OthentoConfigException(error, message)
}

private fun firstMissingField(
    mode: OthentoMode,
    apiKey: String?,
): Pair<OthentoError, String>? =
    when {
        mode is OthentoMode.Create && mode.workflowExternalId.isBlank() ->
            OthentoError.MissingWorkflow to "Missing workflow configuration"
        mode is OthentoMode.Create && mode.clientData.isBlank() ->
            OthentoError.MissingClientData to "Missing client data"
        mode is OthentoMode.Token && mode.sat.isBlank() ->
            OthentoError.ConfigInvalid("Missing session access token") to "Missing session access token"
        // apiKey is only required for the Create path. Token mode runs
        // entirely off the SAT/ST/SRT bundle.
        mode is OthentoMode.Create && apiKey.isNullOrBlank() ->
            OthentoError.MissingApiKey to "Missing API key"
        else -> null
    }
