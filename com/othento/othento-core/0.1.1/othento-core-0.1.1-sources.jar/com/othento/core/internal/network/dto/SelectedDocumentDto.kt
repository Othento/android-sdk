package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass

/**
 * Wire shape for the document the user has chosen, embedded in session
 * responses once `initiate` has been called.
 *
 * Mirrors [docs/spec/09-data-models.md §2.5].
 */
@JsonClass(generateAdapter = true)
internal data class SelectedDocumentDto(
    val id: String,
    val widthMm: Double?,
    val heightMm: Double?,
    val requireBothSides: Boolean,
)
