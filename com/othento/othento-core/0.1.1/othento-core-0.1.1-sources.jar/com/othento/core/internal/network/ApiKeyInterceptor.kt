package com.othento.core.internal.network

import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.Response

/**
 * OkHttp interceptor that attaches the `X-API-KEY` header on the **create**
 * endpoint only.
 *
 * Tightened in Phase 5: previously the interceptor attached on every SDK-host
 * request, which would have meant token-mode endpoints carried both
 * `X-API-KEY` and the `X-SAT` / `X-ST` / `X-SRT` bundle simultaneously.
 * Co-sending is harmless on the dev backend today but masks the auth model
 * (apiKey is *only* for create — see spec [10-network-layer.md §2.1] and P9
 * in `99-open-questions.md`). The path gate keeps the wire surface clean.
 *
 * Three layers of defense:
 * 1. **Host gate** — scheme + host + port must match the configured base.
 *    Guards S3 PUTs (different host) and brand-asset fetches.
 * 2. **Path gate** — the request path must end in [OthentoApiPaths.CREATE_SESSION].
 *    Guards token-mode endpoints on the same host.
 * 3. **Method gate** — only `POST` carries the apiKey. Defensive against any
 *    future GET on the same path.
 *
 * @property apiKey  host-supplied API key. When `null` or blank, the
 *                   interceptor passes the request through untouched.
 * @property baseUrl configured SDK base URL.
 */
internal class ApiKeyInterceptor(
    private val apiKey: String?,
    baseUrl: HttpUrl,
) : Interceptor {
    private val sdkOrigin: String = "${baseUrl.scheme}://${baseUrl.host}:${baseUrl.port}"

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        if (apiKey.isNullOrBlank() || !targetsCreateEndpoint(request)) {
            return chain.proceed(request)
        }
        val authedRequest =
            request
                .newBuilder()
                .header(HEADER_X_API_KEY, apiKey)
                .build()
        return chain.proceed(authedRequest)
    }

    /**
     * Match scheme + host + port + method (`POST`) + the create-session path.
     * The path comparison ignores trailing slashes and any leading path
     * prefix on the resolved base URL.
     */
    @Suppress("ReturnCount") // Three early-out gates (method / origin / path); collapsing hides the auth-attach logic.
    private fun targetsCreateEndpoint(request: okhttp3.Request): Boolean {
        if (request.method != HTTP_METHOD_POST) return false
        val url = request.url
        if ("${url.scheme}://${url.host}:${url.port}" != sdkOrigin) return false
        return url.encodedPath.endsWith(OthentoApiPaths.CREATE_SESSION)
    }

    internal companion object {
        const val HEADER_X_API_KEY: String = "X-API-KEY"
        private const val HTTP_METHOD_POST: String = "POST"
    }
}
