package com.othento.core.internal.data.model

/**
 * Backend-driven retry metadata, present on a `Failed` + `canReinitiate`
 * token session response. Mirrors the web SDK's `ReinitInfo`
 * (`apps/sdk/.../models/session.model.ts`).
 *
 * - [attemptsRemaining] is the authoritative count the retry screen's
 *   attempts meter prefers over the client-side `maxAttempts - attemptNumber`
 *   fallback.
 * - [stepsToRetry] is the specific subset of steps the backend wants the
 *   user to redo (mid-flow partial retry). When empty the retry screen falls
 *   back to the full `steps[]` list.
 * - [failureReason] is sent by the backend but not yet surfaced in the UI.
 */
internal data class ReinitInfo(
    val attemptsRemaining: Int,
    val failureReason: String?,
    val stepsToRetry: List<ReinitStep>,
)

/**
 * A single entry in [ReinitInfo.stepsToRetry]. The wire shape is the web's
 * `ReinitStep = Pick<Step, 'stepCode' | 'stepName' | 'order'>` — a trimmed
 * [Step] without the per-attempt identifiers, so it is modelled separately.
 */
internal data class ReinitStep(
    val stepCode: String,
    val stepName: String,
    val order: Int?,
)
