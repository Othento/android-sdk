package com.othento.core.internal.network

import android.util.Log
import com.squareup.moshi.JsonDataException
import com.squareup.moshi.JsonEncodingException
import com.othento.core.api.OthentoError
import retrofit2.HttpException
import java.io.IOException

/**
 * Translates Retrofit / OkHttp failures into a typed [OthentoError] plus a
 * pre-localised display message.
 *
 * Mirrors [docs/spec/15-error-catalog.md §B] (network/API errors). The
 * single hard-coded status mapping is **404 → SessionNotFound** (spec §4.3);
 * every other status falls through to the flow-specific subtype the caller
 * passes in.
 *
 * Phase 5 generalises Phase 3's create-only mapper: the caller now picks the
 * `OthentoError` factory for non-404 HTTP / IO / parse failures via [Flow].
 *
 * Strings:
 * - "Or not accessible on this device"   — spec §4.3 (`API_404`)
 * - flow-specific display string         — spec §B per flow
 * - "Unable to connect to the server."   — spec §4.1 (network unreachable)
 * - DEFAULT_ERROR_MESSAGE                — spec §B (`API_GENERIC`)
 */
internal class ErrorMapper {
    /**
     * Map a thrown error from a network call into an [OthentoNetworkException]
     * carrying both the typed [OthentoError] and the display string. Phase 3's
     * single-flow shape (`create`-only) extends to flow-tagged shapes so
     * the upload / poll / initiate / documents callers each surface a
     * subtype that matches the failed operation.
     */
    fun toException(
        throwable: Throwable,
        flow: Flow = Flow.Create,
    ): OthentoNetworkException =
        when (throwable) {
            is HttpException -> mapHttpException(throwable, flow)
            is IOException -> mapIoException(throwable, flow)
            is JsonDataException -> mapParseError(throwable, flow)
            is JsonEncodingException -> mapParseError(throwable, flow)
            else -> mapUnknown(throwable, flow)
        }

    private fun mapHttpException(
        exception: HttpException,
        flow: Flow,
    ): OthentoNetworkException {
        val status = exception.code()
        return if (status == HTTP_NOT_FOUND) {
            OthentoNetworkException(
                error = OthentoError.SessionNotFound,
                displayMessage = NOT_FOUND_BODY,
                cause = exception,
            )
        } else {
            // Surface the HTTP status (and the upload stage when applicable)
            // in the inline error so the user has an actionable diagnostic
            // rather than the generic spec fallback. The HTTP body is also
            // logged to logcat for debug builds — see [warnLogcat].
            val display = enrichDisplayMessage(flow, status, exception)
            OthentoNetworkException(
                error = flow.errorFor(status, exception),
                displayMessage = display,
                cause = exception,
            )
        }
    }

    private fun enrichDisplayMessage(
        flow: Flow,
        status: Int,
        exception: HttpException,
    ): String {
        val raw = runCatching { exception.response()?.errorBody()?.string() }.getOrNull()
        if (!raw.isNullOrBlank()) {
            warnLogcat("${flow.javaClass.simpleName}: HTTP $status body: ${raw.take(BODY_LOG_PREVIEW)}", exception)
        }
        val stageLabel =
            when (flow) {
                is Flow.Upload -> " (${flow.stage.name} HTTP $status)"
                else -> " (HTTP $status)"
            }
        return flow.displayMessage + stageLabel
    }

    private fun mapIoException(
        throwable: Throwable,
        flow: Flow,
    ): OthentoNetworkException {
        // Upload-pipeline IO failures want the `UploadFailed` subtype rather
        // than the generic `Network` one — hosts use the stage tag for
        // telemetry. All other flows surface as `Network` per spec §4.1.
        val error =
            if (flow is Flow.Upload) {
                OthentoError.UploadFailed(stage = flow.stage, httpStatus = null, cause = throwable)
            } else {
                OthentoError.Network(cause = throwable)
            }
        val message = if (flow is Flow.Upload) flow.displayMessage else NETWORK_UNREACHABLE_BODY
        return OthentoNetworkException(error = error, displayMessage = message, cause = throwable)
    }

    private fun mapParseError(
        throwable: Throwable,
        flow: Flow,
    ): OthentoNetworkException {
        // Surface the actual Moshi parse failure to logcat so a host
        // debugging an "unexpected" error screen can tell whether the
        // backend's response shape diverged from our DTOs. The displayed
        // message stays generic — we never want raw parser strings on
        // the user-facing screen.
        warnLogcat("${flow.javaClass.simpleName}: response parse failed (${throwable.message})", throwable)
        return OthentoNetworkException(
            error = flow.errorFor(httpStatus = null, cause = throwable),
            displayMessage = DEFAULT_ERROR_MESSAGE,
            cause = throwable,
        )
    }

    /**
     * Wraps `Log.w` so the same code compiles + runs in JVM unit tests.
     * `android.util.Log` is a stub on plain JVM and throws
     * `UnsatisfiedLinkError` when called — `unitTests.isIncludeAndroidResources`
     * doesn't bridge it. Catching `LinkageError` keeps production logging
     * intact while letting tests run.
     */
    @Suppress("TooGenericExceptionCaught")
    private fun warnLogcat(
        message: String,
        cause: Throwable,
    ) {
        try {
            Log.w(LOG_TAG_PARSE, message, cause)
        } catch (_: LinkageError) {
            // Unit-test environment without android.util.Log — ignore.
        } catch (_: RuntimeException) {
            // Defensive: any platform stub that throws on Log.w shouldn't
            // bubble back to the host listener as a parse error.
        }
    }

    private fun mapUnknown(
        throwable: Throwable,
        flow: Flow,
    ): OthentoNetworkException =
        OthentoNetworkException(
            error = flow.errorFor(httpStatus = null, cause = throwable),
            displayMessage = throwable.message ?: DEFAULT_ERROR_MESSAGE,
            cause = throwable,
        )

    /**
     * Tag for the operation a caller is mapping. Each flow knows how to
     * build its `OthentoError` subtype for a given HTTP status / cause and
     * provides the spec's display copy.
     */
    sealed class Flow(
        val displayMessage: String,
    ) {
        abstract fun errorFor(
            httpStatus: Int?,
            cause: Throwable,
        ): OthentoError

        object Create : Flow(displayMessage = CREATE_FAIL_BODY) {
            override fun errorFor(
                httpStatus: Int?,
                cause: Throwable,
            ): OthentoError = OthentoError.CreateFailed(httpStatus = httpStatus, cause = cause)
        }

        object Documents : Flow(displayMessage = DOCUMENTS_FAIL_BODY) {
            override fun errorFor(
                httpStatus: Int?,
                cause: Throwable,
            ): OthentoError = OthentoError.DocumentsFailed(httpStatus = httpStatus, cause = cause)
        }

        object Initiate : Flow(displayMessage = INITIATE_FAIL_BODY) {
            override fun errorFor(
                httpStatus: Int?,
                cause: Throwable,
            ): OthentoError = OthentoError.InitiateFailed(httpStatus = httpStatus, cause = cause)
        }

        object Poll : Flow(displayMessage = DEFAULT_ERROR_MESSAGE) {
            override fun errorFor(
                httpStatus: Int?,
                cause: Throwable,
            ): OthentoError = OthentoError.PollFailed(httpStatus = httpStatus, cause = cause)
        }

        class Upload(
            val stage: OthentoError.UploadStage,
        ) : Flow(displayMessage = UPLOAD_FAIL_BODY) {
            override fun errorFor(
                httpStatus: Int?,
                cause: Throwable,
            ): OthentoError = OthentoError.UploadFailed(stage = stage, httpStatus = httpStatus, cause = cause)
        }
    }

    internal companion object {
        const val DEFAULT_ERROR_MESSAGE: String =
            "Please try again or contact support if the problem persists."
        const val NOT_FOUND_BODY: String = "Or not accessible on this device"
        const val CREATE_FAIL_BODY: String = "Failed to create session"
        const val DOCUMENTS_FAIL_BODY: String = "Failed to load documents"
        const val INITIATE_FAIL_BODY: String = "Failed to start verification"
        const val UPLOAD_FAIL_BODY: String = "Failed to upload your document"
        const val NETWORK_UNREACHABLE_BODY: String =
            "Unable to connect to the server. Please check your internet connection."

        const val HTTP_NOT_FOUND: Int = 404
        const val LOG_TAG_PARSE: String = "OthentoSDK-Parse"
        const val BODY_LOG_PREVIEW: Int = 500
    }
}
