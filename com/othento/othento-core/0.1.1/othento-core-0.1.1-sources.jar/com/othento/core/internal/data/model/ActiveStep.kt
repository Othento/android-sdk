package com.othento.core.internal.data.model

/**
 * Domain model for the live (current) step.
 *
 * Per [docs/spec/09-data-models.md §2.3]. Same shape as [Step] but uses the
 * wider [ActiveStepStatus] enum and adds the [challenges] array. May be
 * null on the parent session when status is in a status-driven (terminal /
 * processing / expired) state.
 *
 * `configuration` and `order` are nullable: the dev backend omits them
 * entirely on the live `currentStep` payload after `initiate`, even though
 * the spec lists `order` as required on `Step`.
 */
internal data class ActiveStep(
    val attemptStepId: String,
    val configuration: Map<String, Any?>?,
    val stepCode: String,
    val stepName: String,
    val order: Int?,
    val status: ActiveStepStatus,
    val challenges: List<Challenge>,
)
