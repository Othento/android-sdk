@file:Suppress("ReturnCount")

package com.othento.core.internal.capture.detection.smartcropper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream

/**
 * Convert a CameraX [ImageProxy] (YUV_420_888) to an ARGB [Bitmap], optionally
 * cropped to [cutoutInImageCoords] for speed. Used to feed SmartCropper.
 *
 * SmartCropper expects an ARGB bitmap. We go via NV21 + JPEG round-trip
 * because that's the only YUV→Bitmap path in the framework that doesn't need
 * RenderScript (deprecated since API 31). The NV21 packing honours each
 * plane's `rowStride` / `pixelStride` so it produces correct chroma on both
 * planar and semi-planar device layouts.
 */
internal object YuvToBitmap {
    /** JPEG quality used for the intermediate NV21→JPEG encode step. */
    private const val JPEG_QUALITY = 90

    /**
     * Default longest-edge cap. Larger inputs are downscaled via
     * [BitmapFactory.Options.inSampleSize] to bound memory + native processing
     * time. SmartCropper's HED model resizes internally anyway — feeding it
     * something larger than ~1024 buys nothing and risks native OOM / crash.
     * Callers that need higher resolution (e.g. ML Kit OCR for the MRZ band,
     * where small character size demands native sensor pixels) can pass a
     * larger [maxDimension] to [convert].
     */
    private const val DEFAULT_MAX_DIMENSION = 1024

    fun convert(
        image: ImageProxy,
        cutoutInImageCoords: Rect?,
        maxDimension: Int = DEFAULT_MAX_DIMENSION,
    ): Bitmap? = runCatching { convertInternal(image, cutoutInImageCoords, maxDimension) }.getOrNull()

    private fun convertInternal(
        image: ImageProxy,
        cutoutInImageCoords: Rect?,
        maxDimension: Int,
    ): Bitmap? {
        val nv21 = yuv420ToNv21(image) ?: return null

        val yuv = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)

        val cropRect =
            cutoutInImageCoords?.let {
                Rect(
                    it.left.coerceIn(0, image.width),
                    it.top.coerceIn(0, image.height),
                    it.right.coerceIn(0, image.width),
                    it.bottom.coerceIn(0, image.height),
                )
            } ?: Rect(0, 0, image.width, image.height)

        if (cropRect.width() <= 0 || cropRect.height() <= 0) return null

        val out = ByteArrayOutputStream()
        if (!yuv.compressToJpeg(cropRect, JPEG_QUALITY, out)) return null

        val jpegBytes = out.toByteArray()

        // Downscale on decode if the cropped region exceeds maxDimension on
        // either axis. inSampleSize is power-of-two only.
        val opts = BitmapFactory.Options()
        var sample = 1
        while (cropRect.width() / sample > maxDimension || cropRect.height() / sample > maxDimension) {
            sample *= 2
        }
        opts.inSampleSize = sample

        return BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size, opts)
    }

    /**
     * Pack a YUV_420_888 [ImageProxy] into a tightly-packed NV21 byte array
     * (Y plane followed by interleaved VUVU…). Honours each plane's
     * `rowStride` and `pixelStride`:
     *
     * - Y plane: row-by-row copy stripping any rowStride padding. PixelStride
     *   is always 1 for the Y plane on YUV_420_888.
     * - U/V planes: per-row, per-pixel walk so we work on both layouts that
     *   CameraX emits in the wild — *planar* (separate U/V buffers,
     *   pixelStride 1) and *semi-planar* (overlapping U/V buffers pointing
     *   into the same VU memory, pixelStride 2).
     *
     * The previous implementation concatenated `Y + V_buf + U_buf` raw, which
     * produced VVVUUU on planar devices and double-writes on semi-planar
     * devices — both gave SmartCropper a bitmap with garbled chroma.
     */
    private fun yuv420ToNv21(image: ImageProxy): ByteArray? {
        val width = image.width
        val height = image.height
        if (width <= 0 || height <= 0) return null
        val ySize = width * height
        val uvSize = ySize / 2
        val nv21 = ByteArray(ySize + uvSize)

        val yPlane = image.planes[0]
        val yBuf = yPlane.buffer.duplicate()
        val yRowStride = yPlane.rowStride
        if (yRowStride == width) {
            yBuf.position(0)
            yBuf.get(nv21, 0, ySize)
        } else {
            for (row in 0 until height) {
                yBuf.position(row * yRowStride)
                yBuf.get(nv21, row * width, width)
            }
        }

        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        val uBuf = uPlane.buffer.duplicate()
        val vBuf = vPlane.buffer.duplicate()
        val uRowStride = uPlane.rowStride
        val uPixelStride = uPlane.pixelStride
        val vRowStride = vPlane.rowStride
        val vPixelStride = vPlane.pixelStride

        val chromaHeight = height / 2
        val chromaWidth = width / 2

        val vRowBuf = ByteArray(chromaWidth * vPixelStride)
        val uRowBuf = ByteArray(chromaWidth * uPixelStride)
        for (row in 0 until chromaHeight) {
            // The last chroma row's view may be short by (pixelStride - 1) bytes
            // because the underlying buffer omits the trailing companion byte;
            // clamp the read to whatever's available so we don't BufferUnderflow.
            val vAvailable = (vBuf.capacity() - row * vRowStride).coerceAtLeast(0)
            val uAvailable = (uBuf.capacity() - row * uRowStride).coerceAtLeast(0)
            val vToRead = vRowBuf.size.coerceAtMost(vAvailable)
            val uToRead = uRowBuf.size.coerceAtMost(uAvailable)
            vBuf.position(row * vRowStride)
            vBuf.get(vRowBuf, 0, vToRead)
            uBuf.position(row * uRowStride)
            uBuf.get(uRowBuf, 0, uToRead)
            val outBase = ySize + row * width
            for (col in 0 until chromaWidth) {
                val vIdx = col * vPixelStride
                val uIdx = col * uPixelStride
                if (vIdx < vToRead) nv21[outBase + col * 2] = vRowBuf[vIdx]
                if (uIdx < uToRead) nv21[outBase + col * 2 + 1] = uRowBuf[uIdx]
            }
        }
        return nv21
    }
}
