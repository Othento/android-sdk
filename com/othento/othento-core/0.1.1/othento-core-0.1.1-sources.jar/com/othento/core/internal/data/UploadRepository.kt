package com.othento.core.internal.data

import android.content.ContentResolver
import android.net.Uri
import com.othento.core.internal.data.model.ChallengeType
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.network.OthentoApi
import com.othento.core.internal.network.OthentoNetworkException
import com.othento.core.internal.network.ErrorMapper
import com.othento.core.internal.network.ProgressRequestBody
import com.othento.core.internal.network.SessionMapper
import com.othento.core.internal.network.TokenStore
import com.othento.core.internal.network.dto.ConfirmUploadRequestDto
import com.othento.core.internal.network.dto.UploadUrlResponseDto
import com.othento.core.internal.util.ImageInfo
import com.othento.core.api.OthentoError
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.channels.trySendBlocking
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Three-phase upload pipeline matching the web's `S3TokenUploadService`
 * ([apps/sdk/.../s3-token-upload.service.ts:20-47]):
 *
 * 1. `GET /SessionToken/session/upload-url?AttemptStepId=…&ChallengeType=…&FileName=…`
 * 2. `PUT <presignedUrl>` with the file's bytes; OkHttp emits progress events
 *    via the [ProgressRequestBody].
 * 3. `POST /SessionToken/session/confirm-upload {attemptStepId, challengeType,
 *    fileName}` returning the updated [Session].
 *
 * Front uploads chain after `initiateSession` per the web's
 * `TokenSessionFlowService.initiateAndUploadFront` — one user action
 * (Continue on the upload-fallback screen) drives initiate + upload as a
 * single Flow so partial states aren't surfaced. Back uploads skip initiate;
 * the back challenge is already on the session post-front-confirm.
 *
 * Extracted as an interface in Phase 5 so unit tests can substitute a stub
 * without spinning up [ContentResolver] + OkHttp.
 */
internal interface UploadRepository {
    /**
     * @param isRetry when true the front step is opened via `reinitiate`
     *   instead of `initiate`. Retry-from-failed paths that route back through
     *   document-select land here on a `Failed` + `canReinitiate` session, and
     *   the backend rejects `initiate` on such a session — mirrors the web's
     *   `TokenSessionFlowService.initiateAndUploadFront`.
     */
    fun initiateAndUploadFront(
        documentId: String,
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean = false,
        isRetry: Boolean = false,
    ): Flow<UploadProgress>

    fun uploadBack(
        attemptStepId: String,
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean = false,
    ): Flow<UploadProgress>

    /**
     * Phase 7 — selfie / face-match upload. Same three-phase pipeline as
     * [uploadBack] (get-upload-url → S3 PUT → confirm-upload) but with
     * `challengeType = Selfie`. Used when the active step is
     * `step_face_match`; the recorded MP4 clip is discarded by the screen
     * (Phase 8's liveness path is what consumes it).
     */
    fun uploadSelfie(
        attemptStepId: String,
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean = false,
    ): Flow<UploadProgress>

    /**
     * Phase 8 — passive-liveness upload. Same three-phase pipeline as
     * [uploadSelfie] but with `challengeType = LivenessVideo`. The screen
     * passes the trimmed MP4 file URI produced by
     * [com.othento.core.internal.capture.video.RollingVideoRecorder.stopAndTrim];
     * the `Content-Type` is taken verbatim from the upload-url response so
     * the backend's `video/mp4` selection wins over any client guess.
     * Spec [docs/spec/06-screens/08-selfie-capture.md] §"Network calls
     * fired" + [docs/spec/11-business-logic-and-validation.md] §11.
     */
    fun uploadLivenessVideo(
        attemptStepId: String,
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean = false,
    ): Flow<UploadProgress>
}

/**
 * Production implementation. The repository factory wires this in via
 * [com.othento.core.internal.data.SessionRepositoryFactory.create] —
 * Phase-5 tests use a hand-written stub instead.
 */
internal class UploadRepositoryImpl(
    private val api: OthentoApi,
    private val errorMapper: ErrorMapper,
    private val sessionRepository: SessionRepository,
    private val tokenStore: TokenStore,
    private val okHttpClient: OkHttpClient,
    private val contentResolver: ContentResolver,
) : UploadRepository {
    // OkHttp's default 10s write/read timeouts kill large S3 PUTs whenever a
    // single chunk write stalls past 10s on a flaky link (writeTimeout is
    // per-write, not per-call). Spec [10-network-layer.md §3.2] said "no
    // timeouts" assuming a browser baseline; OkHttp's defaults are far
    // tighter. Resolved as 99-open-questions.md §H5 — derive a dedicated
    // upload client that shares the connection pool / dispatcher but relaxes
    // timeouts for the body stream.
    private val s3Client: OkHttpClient =
        okHttpClient
            .newBuilder()
            .connectTimeout(UPLOAD_CONNECT_TIMEOUT_S, TimeUnit.SECONDS)
            .writeTimeout(UPLOAD_WRITE_TIMEOUT_S, TimeUnit.SECONDS)
            .readTimeout(UPLOAD_READ_TIMEOUT_S, TimeUnit.SECONDS)
            .callTimeout(0, TimeUnit.MILLISECONDS)
            .build()

    /**
     * Phase-1 upload entry: initiate → upload-url → PUT → confirm-upload.
     * Emits [UploadProgress.InProgress] from 0..99 during the PUT and
     * [UploadProgress.Done] with the post-confirm session. Throws
     * [OthentoNetworkException] for HTTP / IO / parse failures.
     *
     * The 10 MB cap from spec [11-business-logic-and-validation.md] §12 is
     * enforced **before** this is called — the FlowCoordinator surfaces an
     * inline error rather than launching the pipeline for an oversized file.
     * This keeps the repository concerns clean (no business validation).
     */
    override fun initiateAndUploadFront(
        documentId: String,
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean,
        isRetry: Boolean,
    ): Flow<UploadProgress> =
        flow {
            val initiated =
                if (isRetry) {
                    sessionRepository.reinitiateSession(documentId)
                } else {
                    sessionRepository.initiateSession(documentId)
                }
            val step = initiated.currentStep ?: throw initiateMissingStep()
            emitAll(
                runUpload(
                    attemptStepId = step.attemptStepId,
                    challengeType = ChallengeType.DocumentFront,
                    uri = uri,
                    info = info,
                    isManualCapture = isManualCapture,
                ),
            )
        }.flowOn(Dispatchers.IO)

    /**
     * Phase-2 upload entry: skip initiate; upload the back side using the
     * already-resolved attempt step. The post-front-confirm session carries
     * the new currentStep with the `DocumentBack` challenge AwaitingUpload.
     */
    override fun uploadBack(
        attemptStepId: String,
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean,
    ): Flow<UploadProgress> =
        runUpload(
            attemptStepId = attemptStepId,
            challengeType = ChallengeType.DocumentBack,
            uri = uri,
            info = info,
            isManualCapture = isManualCapture,
        ).flowOn(Dispatchers.IO)

    override fun uploadSelfie(
        attemptStepId: String,
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean,
    ): Flow<UploadProgress> =
        runUpload(
            attemptStepId = attemptStepId,
            challengeType = ChallengeType.Selfie,
            uri = uri,
            info = info,
            isManualCapture = isManualCapture,
        ).flowOn(Dispatchers.IO)

    override fun uploadLivenessVideo(
        attemptStepId: String,
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean,
    ): Flow<UploadProgress> =
        runUpload(
            attemptStepId = attemptStepId,
            challengeType = ChallengeType.LivenessVideo,
            uri = uri,
            info = info,
            isManualCapture = isManualCapture,
        ).flowOn(Dispatchers.IO)

    private fun runUpload(
        attemptStepId: String,
        challengeType: ChallengeType,
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean = false,
    ): Flow<UploadProgress> =
        callbackFlow {
            try {
                trySendBlocking(UploadProgress.InProgress(percent = 0))
                val urlInfo = fetchUploadUrl(attemptStepId, challengeType, info.fileName)
                putToS3(urlInfo, uri, info, ::trySendBlocking)
                val confirmed = confirmUpload(attemptStepId, challengeType, info.fileName, isManualCapture)
                trySendBlocking(UploadProgress.Done(session = confirmed))
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (e: OthentoNetworkException) {
                close(e)
                return@callbackFlow
            }
            close()
            awaitClose { /* no-op cleanup */ }
        }

    private suspend fun fetchUploadUrl(
        attemptStepId: String,
        challengeType: ChallengeType,
        fileName: String,
    ): UploadUrlResponseDto =
        runCall(OthentoError.UploadStage.UploadUrl) {
            api.getUploadUrl(
                attemptStepId = attemptStepId,
                challengeType = challengeType.name,
                fileName = fileName,
            )
        }

    // Three throws (IOException → mapper, non-successful response, response.code); each carries distinct context.
    @Suppress("ThrowsCount")
    private suspend fun putToS3(
        urlInfo: UploadUrlResponseDto,
        uri: Uri,
        info: ImageInfo.Resolved,
        emit: (UploadProgress) -> Unit,
    ) {
        val body =
            ProgressRequestBody(
                uri = uri,
                contentResolver = contentResolver,
                contentTypeValue = urlInfo.contentType,
                contentLengthValue = info.sizeBytes,
            ) { sent, total ->
                if (total <= 0L) return@ProgressRequestBody
                val pct = ((sent * UPLOAD_PCT_PUT_CEILING) / total).toInt().coerceIn(0, UPLOAD_PCT_PUT_CEILING.toInt())
                emit(UploadProgress.InProgress(percent = pct))
            }
        val request =
            Request
                .Builder()
                .url(urlInfo.uploadUrl)
                .put(body)
                .build()
        // Hold a Call reference so a coroutine cancellation (back-press
        // mid-upload) translates into Call.cancel() — OkHttp's blocking
        // execute() does NOT interrupt on Java-level interruption, so
        // without this the bytes keep streaming to S3 even after the host
        // navigates away.
        val call = s3Client.newCall(request)
        try {
            withContext(Dispatchers.IO) {
                call.execute().use { response ->
                    if (!response.isSuccessful) {
                        throw OthentoNetworkException(
                            error =
                                OthentoError.UploadFailed(
                                    stage = OthentoError.UploadStage.S3Put,
                                    httpStatus = response.code,
                                    cause = null,
                                ),
                            // Surface the S3 status in the inline error
                            // string so the user / dev sees 403 (signature
                            // expired) vs 400 (signature mismatch) vs 5xx.
                            displayMessage = "${ErrorMapper.UPLOAD_FAIL_BODY} (S3Put HTTP ${response.code})",
                        )
                    }
                }
            }
        } catch (cancellation: CancellationException) {
            call.cancel()
            throw cancellation
        } catch (e: IOException) {
            throw errorMapper.toException(e, ErrorMapper.Flow.Upload(OthentoError.UploadStage.S3Put))
        }
    }

    private suspend fun confirmUpload(
        attemptStepId: String,
        challengeType: ChallengeType,
        fileName: String,
        isManualCapture: Boolean = false,
    ): Session =
        runCall(OthentoError.UploadStage.ConfirmUpload) {
            val response =
                api.confirmUpload(
                    ConfirmUploadRequestDto(
                        attemptStepId = attemptStepId,
                        challengeType = challengeType,
                        fileName = fileName,
                        isManualCapture = isManualCapture,
                    ),
                )
            tokenStore.updateFromResponse(response)
            SessionMapper.fromTokenSessionResponse(response)
        }

    @Suppress("TooGenericExceptionCaught")
    private suspend inline fun <T> runCall(
        stage: OthentoError.UploadStage,
        crossinline block: suspend () -> T,
    ): T =
        try {
            // Retrofit's suspend fns already dispatch on OkHttp's own thread
            // pool, so wrapping in `withContext(Dispatchers.IO)` here would
            // only buy a context switch. The S3 PUT — the one place that
            // needs explicit IO dispatch — wires it separately in `putToS3`.
            block()
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: Exception) {
            throw errorMapper.toException(e, ErrorMapper.Flow.Upload(stage))
        }

    private fun initiateMissingStep(): OthentoNetworkException =
        OthentoNetworkException(
            error =
                OthentoError.InitiateFailed(
                    httpStatus = null,
                    cause = IllegalStateException("Initiate response missing currentStep"),
                ),
            displayMessage = ErrorMapper.INITIATE_FAIL_BODY,
        )

    private companion object {
        /**
         * The PUT phase tops out at 99 % so the [UploadProgress.Done] event
         * is the only carrier of the 100-percent transition — this matches
         * the web's `progress = response ? 100 : <0..99>` pattern from
         * `s3-upload.service.ts:42`.
         */
        const val UPLOAD_PCT_PUT_CEILING: Long = 99L

        const val UPLOAD_CONNECT_TIMEOUT_S: Long = 30L
        const val UPLOAD_WRITE_TIMEOUT_S: Long = 120L
        const val UPLOAD_READ_TIMEOUT_S: Long = 60L
    }
}

/**
 * Discriminated upload-pipeline progress emission. Mirrors the web's
 * `{ progress, response? }` from `s3-upload.service.ts:42`.
 */
internal sealed class UploadProgress {
    data class InProgress(
        val percent: Int,
    ) : UploadProgress()

    data class Done(
        val session: Session,
    ) : UploadProgress()
}
