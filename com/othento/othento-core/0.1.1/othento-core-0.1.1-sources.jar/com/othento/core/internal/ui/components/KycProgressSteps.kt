@file:Suppress("FunctionNaming", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion

/** Spec §8 — `KycProgressSteps`. */
@Immutable
internal enum class KycProgressVariant { Dots, Bar }

/**
 * Two-mode mini progress indicator. Spec §8.
 * - `Dots`: row of 8-dp circles, gap 6, justify-center. Active dots fill
 *   `--color-primary` and scale 1.15 ×.
 * - `Bar`: 3-dp tall track filled with a primary→primary-hover gradient that
 *   animates width from old % → new % over `motion-base-duration`.
 *
 * [current] is clamped to `0..total-1`. When [total] ≤ 0 the component renders
 * nothing — matches the web SDK's null-render guard.
 */
@Composable
internal fun KycProgressSteps(
    total: Int,
    current: Int,
    modifier: Modifier = Modifier,
    variant: KycProgressVariant = KycProgressVariant.Dots,
) {
    if (total <= 0) return
    val clampedCurrent = current.coerceIn(0, total - 1)
    val semanticsModifier =
        modifier.semantics {
            progressBarRangeInfo =
                ProgressBarRangeInfo(
                    current = (clampedCurrent + 1).toFloat(),
                    range = 0f..total.toFloat(),
                )
        }
    when (variant) {
        KycProgressVariant.Dots -> Dots(total, clampedCurrent, semanticsModifier)
        KycProgressVariant.Bar -> Bar(total, clampedCurrent, semanticsModifier)
    }
}

@Composable
private fun Dots(
    total: Int,
    current: Int,
    modifier: Modifier,
) {
    val colors = LocalOthentoColors.current
    val motion = LocalOthentoMotion.current
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(DotsGap, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(total) { index ->
            val active = index <= current
            val targetScale = if (active) ActiveScale else InactiveScale
            val scale by animateFloatAsState(
                targetValue = targetScale,
                animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
                label = "kyc-dot-scale",
            )
            val target = if (active) colors.primary else colors.border
            Box(
                modifier =
                    Modifier
                        .size(DotSize)
                        .scale(scale)
                        .clip(CircleShape)
                        .background(target),
            )
        }
    }
}

@Composable
private fun Bar(
    total: Int,
    current: Int,
    modifier: Modifier,
) {
    val colors = LocalOthentoColors.current
    val motion = LocalOthentoMotion.current
    val targetFraction = (current + 1).toFloat() / total.toFloat()
    val animatedFraction by animateIntAsState(
        targetValue = (targetFraction * BarFractionScale).toInt(),
        animationSpec = tween(durationMillis = motion.durationBaseMs, easing = motion.easeOut),
        label = "kyc-bar-width",
    )
    Box(
        modifier =
            modifier
                .fillMaxWidth()
                .height(BarHeight)
                .clip(RoundedCornerShape(BarHeight / 2))
                .background(colors.border),
    ) {
        Canvas(
            modifier =
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(animatedFraction.toFloat() / BarFractionScale),
        ) {
            drawRect(
                brush =
                    Brush.horizontalGradient(
                        colors = listOf(colors.primary, colors.primaryHover),
                    ),
                topLeft = Offset.Zero,
                size = Size(this.size.width, this.size.height),
            )
        }
    }
}

private val DotSize = 8.dp
private val DotsGap = 6.dp
private val BarHeight = 3.dp
private const val ActiveScale = 1.15f
private const val InactiveScale = 1f
private const val BarFractionScale = 1000

internal object KycProgressStepsPreview {
    /** Exposed for unit tests — mirrors the in-composable clamp logic. */
    fun clamp(
        current: Int,
        total: Int,
    ): Int = if (total <= 0) -1 else current.coerceIn(0, total - 1)
}
