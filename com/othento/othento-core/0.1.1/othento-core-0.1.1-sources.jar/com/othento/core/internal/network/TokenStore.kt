package com.othento.core.internal.network

import com.othento.core.internal.network.dto.TokenSessionResponseDto

/**
 * Holder for the SAT/ST/SRT token bundle returned by the dev backend.
 *
 * Phase 5 introduced this as in-memory only. Phase 10 added optional
 * encrypted persistence via [EncryptedTokenPrefs] — call
 * [persist] after each `updateFromResponse` and [rehydrate] before the
 * first call when launched from a deeplink / token mode.
 *
 * Contract:
 * - The create response carries a SAT in `sessionToken` (prefix `sat:`).
 *   `sessionRetryToken` is `null` on the create response (dev backend confirmed).
 * - Subsequent token-mode responses (`initiate` / `confirm-upload` / poll) carry
 *   an ST in `sessionToken` (prefix `st:`) and an SRT in `sessionRetryToken`
 *   (prefix `srt:`). Either may be rotated by the backend mid-session.
 *
 * The store **discriminates on prefix** — a missing or unrecognised prefix
 * leaves the slot untouched, which protects against future-token churn (e.g.
 * a backend rolling out a `srt2:` shape) corrupting the bundle.
 */
internal class TokenStore {
    @Volatile
    var sat: String? = null
        private set

    @Volatile
    var st: String? = null
        private set

    @Volatile
    var srt: String? = null
        private set

    @Volatile
    var stExpiresAt: String? = null
        private set

    @Volatile
    var srtExpiresAt: String? = null
        private set

    /**
     * Phase 10 — when set, every successful [updateFromResponse] also
     * persists the bundle keyed by the response's externalId. The
     * receiver wires this once at SDK launch via [enablePersistence];
     * tests leave it null.
     */
    @Volatile
    private var persistence: EncryptedTokenPrefs? = null

    fun enablePersistence(prefs: EncryptedTokenPrefs) {
        persistence = prefs
    }

    /**
     * Absorbs the per-call response, parsing `sessionToken` and
     * `sessionRetryToken` into the right slots based on their prefix.
     *
     * Spec reference: [docs/spec/10-network-layer.md §2.2] (web's
     * `TokenStoreService.updateFromResponse`).
     */
    fun updateFromResponse(response: TokenSessionResponseDto) {
        when (response.sessionToken?.tokenPrefix()) {
            SAT_PREFIX -> sat = response.sessionToken
            ST_PREFIX -> {
                st = response.sessionToken
                stExpiresAt = response.stExpiresAt
            }
            // Unknown / null prefix → leave the slot untouched. The dev
            // backend never returns a malformed prefix today; defending
            // against it here keeps the store robust without a noisy throw.
            else -> Unit
        }
        if (response.sessionRetryToken?.tokenPrefix() == SRT_PREFIX) {
            srt = response.sessionRetryToken
            srtExpiresAt = response.srtExpiresAt
        }
        // Phase 10 — auto-persist on rotation. Skipped when no
        // [EncryptedTokenPrefs] is wired (tests + create-mode launches
        // that haven't opted into persistence). Persisting also clears
        // in-memory `sat` per spec §2.2 single-use rule.
        persistence?.let { prefs -> persist(response.externalId, prefs) }
    }

    /** Reset the store. Used when the FlowCoordinator re-initiates a session. */
    fun clear() {
        sat = null
        st = null
        srt = null
        stExpiresAt = null
        srtExpiresAt = null
    }

    /** Phase 10 — seed the store from a deeplink-supplied SAT before the first call. */
    fun seedSat(sat: String) {
        this.sat = sat
    }

    /** True iff the store has at least one of `sat`/`st` for the token interceptor to attach. */
    fun hasAnyToken(): Boolean = sat != null || st != null || srt != null

    /**
     * Phase 10 — write the current bundle to encrypted prefs keyed by
     * [sessionId]. Called after every successful `updateFromResponse`
     * that produced an ST or SRT (matches spec §2.2 rule).
     *
     * After persisting, the in-memory SAT is cleared (single-use
     * guarantee) so the next interceptor pass attaches X-ST instead.
     */
    fun persist(
        sessionId: String,
        prefs: EncryptedTokenPrefs,
    ) {
        if (st == null && srt == null) return
        val bundle = encodeBundle(sat, st, srt, stExpiresAt, srtExpiresAt)
        prefs.saveBundle(sessionId = sessionId, sourceSat = sat, bundle = bundle)
        // Single-use: SAT is now baked into the persisted bundle as the
        // originating-SAT pointer; in-memory cell is cleared so the
        // interceptor stops attaching X-SAT.
        sat = null
    }

    /**
     * Phase 10 — rehydrate the in-memory cells from a persisted
     * bundle. Returns true iff the rehydrate succeeded.
     *
     * Per spec §2.2:
     * 1. If no bundle for [sessionId] → false.
     * 2. If [urlSat] is non-null and the persisted bundle's originating
     *    SAT does not match → wipe + false (different session, same app).
     * 3. If both ST + SRT have expired → wipe + false.
     * 4. Else restore whichever of ST/SRT is alive + their expiries.
     *
     * The in-memory `sat` is left as-is (the caller's seedSat call from
     * the URL is what subsequent calls see).
     */
    @Suppress("ReturnCount")
    fun rehydrate(
        sessionId: String,
        urlSat: String?,
        prefs: EncryptedTokenPrefs,
        nowMs: Long = System.currentTimeMillis(),
    ): Boolean {
        val raw = prefs.loadBundle(sessionId) ?: return false
        val parsed = decodeBundle(raw) ?: return false
        if (urlSat != null && parsed.originatingSat != null && parsed.originatingSat != urlSat) {
            prefs.clearSession(sessionId, parsed.originatingSat)
            return false
        }
        val stAlive = parsed.st != null && !isExpired(parsed.stExpiresAt, nowMs)
        val srtAlive = parsed.srt != null && !isExpired(parsed.srtExpiresAt, nowMs)
        if (!stAlive && !srtAlive) {
            prefs.clearSession(sessionId, parsed.originatingSat)
            return false
        }
        if (stAlive) {
            st = parsed.st
            stExpiresAt = parsed.stExpiresAt
        }
        if (srtAlive) {
            srt = parsed.srt
            srtExpiresAt = parsed.srtExpiresAt
        }
        return true
    }

    private fun String.tokenPrefix(): String? {
        val prefix = substringBefore(':', missingDelimiterValue = "")
        return prefix.takeIf { it.isNotEmpty() }
    }

    internal companion object {
        const val SAT_PREFIX: String = "sat"
        const val ST_PREFIX: String = "st"
        const val SRT_PREFIX: String = "srt"

        // Phase 10 — bundle codec (TokenStore line 100+). Plain `key=value`
        // newline-delimited shape; no JSON dependency. Order doesn't
        // matter on parse; missing keys decode as null.
        private const val BUNDLE_KEY_SAT: String = "sat"
        private const val BUNDLE_KEY_ST: String = "st"
        private const val BUNDLE_KEY_SRT: String = "srt"
        private const val BUNDLE_KEY_ST_EXPIRES: String = "stExpiresAt"
        private const val BUNDLE_KEY_SRT_EXPIRES: String = "srtExpiresAt"

        internal data class DecodedBundle(
            val originatingSat: String?,
            val st: String?,
            val srt: String?,
            val stExpiresAt: String?,
            val srtExpiresAt: String?,
        )

        internal fun encodeBundle(
            sat: String?,
            st: String?,
            srt: String?,
            stExpiresAt: String?,
            srtExpiresAt: String?,
        ): String =
            buildString {
                if (sat != null) append(BUNDLE_KEY_SAT).append('=').append(sat).append('\n')
                if (st != null) append(BUNDLE_KEY_ST).append('=').append(st).append('\n')
                if (srt != null) append(BUNDLE_KEY_SRT).append('=').append(srt).append('\n')
                if (stExpiresAt != null) append(BUNDLE_KEY_ST_EXPIRES).append('=').append(stExpiresAt).append('\n')
                if (srtExpiresAt != null) append(BUNDLE_KEY_SRT_EXPIRES).append('=').append(srtExpiresAt).append('\n')
            }

        internal fun decodeBundle(raw: String): DecodedBundle? {
            if (raw.isBlank()) return null
            val map: MutableMap<String, String> = mutableMapOf()
            raw.lineSequence().forEach { line ->
                val eq = line.indexOf('=')
                if (eq <= 0) return@forEach
                val key = line.substring(0, eq)
                val value = line.substring(eq + 1)
                if (value.isNotBlank()) map[key] = value
            }
            return DecodedBundle(
                originatingSat = map[BUNDLE_KEY_SAT],
                st = map[BUNDLE_KEY_ST],
                srt = map[BUNDLE_KEY_SRT],
                stExpiresAt = map[BUNDLE_KEY_ST_EXPIRES],
                srtExpiresAt = map[BUNDLE_KEY_SRT_EXPIRES],
            )
        }

        /**
         * Compares an ISO-8601 expiry timestamp to [nowMs] without using
         * [java.time.Instant] (minSdk 24 doesn't include it absent
         * core-library desugaring). Falls back to "not expired" on any
         * parse hiccup so a malformed timestamp doesn't lock the user
         * out — the backend's next call will rotate fresh tokens anyway.
         */
        @Suppress("ReturnCount", "MagicNumber")
        internal fun isExpired(
            iso: String?,
            nowMs: Long,
        ): Boolean {
            if (iso == null) return true
            val parsed = parseIso8601Utc(iso) ?: return false
            return parsed <= nowMs
        }

        /**
         * Parses an ISO-8601 UTC timestamp without `java.time.Instant`
         * (minSdk 24). Returns null on parse failure. Used by [isExpired]
         * and by Phase 9's OTP screen to read `Challenge.otpExpiresAt`.
         */
        @Suppress("ReturnCount", "MagicNumber")
        internal fun parseIso8601Utc(iso: String): Long? =
            runCatching {
                val cleaned = iso.removeSuffix("Z").removeSuffix("z")
                val parts = cleaned.split('T', limit = 2)
                if (parts.size != 2) return@runCatching null
                val datePart = parts[0]
                val timePart = parts[1].substringBefore('+').substringBefore('-')
                val dateBits = datePart.split('-')
                val timeBits = timePart.split(':')
                if (dateBits.size != 3 || timeBits.size < 2) return@runCatching null
                val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
                cal.clear()
                cal.set(
                    dateBits[0].toInt(),
                    dateBits[1].toInt() - 1,
                    dateBits[2].toInt(),
                    timeBits[0].toInt(),
                    timeBits[1].toInt(),
                    timeBits.getOrNull(2)?.substringBefore('.')?.toIntOrNull() ?: 0,
                )
                cal.timeInMillis
            }.getOrNull()
    }
}
