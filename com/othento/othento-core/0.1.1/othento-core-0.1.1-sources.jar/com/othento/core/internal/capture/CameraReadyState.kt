package com.othento.core.internal.capture

/**
 * High-level camera readiness state — the camera-capture screen renders a
 * different shell per value (spec §05-capture "States" section).
 */
internal enum class CameraReadyState {
    /** Permission unknown / camera provider warming up. */
    Loading,

    /** Camera bound; preview running. */
    Active,

    /** User declined the prompt — show rationale + retry CTA. */
    PermissionDenied,

    /**
     * User declined "Don't ask again" — only path forward is system
     * Settings. Detection convention: denied AND
     * `shouldShowRequestPermissionRationale = false` after a real prompt.
     */
    PermissionPermanentlyDenied,

    /** Camera hardware failure / no camera detected. */
    Unavailable,
}
