@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonSize
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.components.KycStepList
import com.othento.core.internal.ui.components.KycStepListVariant
import com.othento.core.internal.ui.screens.common.StepCardsBuilder
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Spec [docs/spec/06-screens/02-start.md]:
 * the first user-facing screen after session resolution. Hero
 * "Let's confirm it's you." + step-count subtitle + step list + a
 * "Begin verification →" CTA in the footer.
 *
 * Phase 4 omits the desktop QR sidebar (Android is mobile by definition —
 * spec §"start → CTA visibility" notes the CTA is always shown when the
 * device IS the user's mobile). The hero last-word highlight gradient and
 * shimmer animations from the web are simplified to a single tonal Text —
 * fancier highlight motion is a Phase-11 polish concern (see Q2 in
 * `99-open-questions.md`).
 *
 * The "Begin verification →" CTA's real destination (DocumentSelect) does
 * not exist yet — Phase 4's [onBeginClick] is a no-op placeholder.
 */
@Composable
internal fun StartScreen(
    session: Session,
    brandName: String,
    onBeginClick: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val cards = remember(session.steps) { StepCardsBuilder.toCards(session.steps) }
    KycScreen(
        zone = KycScreenZone.Guided,
        bodyFill = false,
        headerBorder = false,
        logoName = brandName,
        body = {
            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(top = HeroTopGap),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "Let's confirm it's you.",
                    style = typography.display,
                    color = colors.textHeading,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = HeroMaxWidth).padding(horizontal = HeroHorizontal),
                )
                Spacer(modifier = Modifier.height(HeroSubtitleGap))
                Text(
                    text = subtitleFor(cards.size),
                    style = typography.bodyLg,
                    color = colors.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = HeroMaxWidth).padding(horizontal = HeroHorizontal),
                )
                Spacer(modifier = Modifier.height(StepListTopGap))
                KycStepList(
                    steps = cards,
                    variant = KycStepListVariant.Detailed,
                    showDurations = false,
                )
                Spacer(modifier = Modifier.height(BottomGap))
            }
        },
        footer = {
            KycButton(
                onClick = onBeginClick,
                label = "Begin verification →",
                variant = KycButtonVariant.Primary,
                size = KycButtonSize.Lg,
                fullWidth = true,
            )
        },
    )
}

private fun subtitleFor(stepCount: Int): String {
    val word =
        when (stepCount) {
            0 -> "Zero"
            1 -> "One"
            2 -> "Two"
            3 -> "Three"
            4 -> "Four"
            5 -> "Five"
            6 -> "Six"
            else -> stepCount.toString()
        }
    return "$word short steps."
}

private val HeroTopGap = 32.dp
private val HeroSubtitleGap = 12.dp
private val HeroMaxWidth = 360.dp
private val HeroHorizontal = 8.dp
private val StepListTopGap = 32.dp
private val BottomGap = 16.dp
