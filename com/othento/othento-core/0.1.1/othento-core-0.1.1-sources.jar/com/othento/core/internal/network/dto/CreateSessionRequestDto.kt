package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass
import com.othento.core.internal.data.model.CallbackReceiver

/**
 * Wire body for the create-session call.
 *
 * Optional fields are omitted from the JSON payload when `null` (Moshi codegen
 * default), matching the cross-platform contract — hosts send only the
 * `expectedDetails` fields they actually know.
 */
@JsonClass(generateAdapter = true)
internal data class CreateSessionRequestDto(
    val workflowExternalId: String,
    val clientData: String,
    val callbackUrl: String? = null,
    val callbackReceiver: CallbackReceiver? = null,
    val metadata: String? = null,
    val expectedDetails: ExpectedDetailsDto? = null,
)

/**
 * Wire shape for `ExpectedDetails`. Mirrors the public
 * [com.othento.core.api.OthentoExpectedDetails] one-for-one; the indirection
 * keeps the public API decoupled from the Moshi codegen layer.
 */
@JsonClass(generateAdapter = true)
internal data class ExpectedDetailsDto(
    val firstName: String? = null,
    val lastName: String? = null,
    val dateOfBirth: String? = null,
    val gender: String? = null,
    val nationality: String? = null,
    val country: String? = null,
    val address: String? = null,
    val documentNumber: String? = null,
    val ipAddress: String? = null,
)
