@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.othento.core.internal.capture.SelfieKind
import com.othento.core.internal.capture.selfieKind
import com.othento.core.internal.flow.OthentoFlowViewModel
import com.othento.core.internal.flow.FlowUiState
import com.othento.core.internal.flow.ScreenState
import com.othento.core.internal.ui.screens.common.OthentoSdkScaffold
import com.othento.core.internal.ui.screens.common.StepProgress
import com.othento.core.api.OthentoError

/**
 * Compose root that observes [OthentoFlowViewModel.state] and renders the
 * matching screen wrapped in [OthentoSdkScaffold] (sandbox banner + trust
 * footer chrome). The [UploadProgressSheet] overlay layers on top of the
 * capture screens when an upload is in flight.
 */
@Composable
@Suppress(
    "CyclomaticComplexMethod",
    "LongMethod",
    // Reason: the per-ScreenState switch has 13 branches; extracting individual
    // branches to helpers doesn't improve readability — the switch is the single
    // decision table the reader expects to scan.
)
internal fun OthentoFlowHost(
    viewModel: OthentoFlowViewModel,
    onReturnToApp: () -> Unit,
) {
    val state: FlowUiState by viewModel.state.collectAsState()
    val brandName = DEFAULT_BRAND_NAME
    val isSandbox = state.session?.isSandbox == true

    // OthentoConfig.closeOnComplete — auto-hand control back to the host the
    // moment the flow lands on a terminal screen (the terminal listener event
    // has already fired). FailedRetry is recoverable, so it is NOT terminal.
    if (viewModel.closeOnComplete) {
        LaunchedEffect(state.screenState) {
            if (state.screenState in TERMINAL_SCREEN_STATES) onReturnToApp()
        }
    }
    // The `PickVisualMedia` launcher must be remembered at this level —
    // CaptureFallbackScreen takes a `() -> Unit` so it stays Paparazzi-friendly.
    val pickFile =
        rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
            if (uri != null) viewModel.onUserFileCaptured(uri, isManualCapture = true)
        }
    val onPickFileClick: () -> Unit = {
        pickFile.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    val stepProgress = StepProgress.of(state.session)

    val isImmersive =
        when {
            state.screenState == ScreenState.SelfieCapture -> true
            !state.useFallback &&
                (
                    state.screenState == ScreenState.CaptureFront ||
                        state.screenState == ScreenState.CaptureBack
                ) -> true
            else -> false
        }

    if (isImmersive) {
        // Spec §05-capture line 17 + §08-selfie-capture line 14 — the
        // camera + selfie screens are immersive: full-bleed black, no SDK
        // card chrome, no sandbox banner, no trust footer.
        Box(modifier = Modifier.fillMaxSize()) {
            when (state.screenState) {
                ScreenState.SelfieCapture ->
                    SelfieCaptureScreen(
                        kind = state.session?.selfieKind ?: SelfieKind.FaceMatch,
                        onCapturedFile = { uri, manual -> viewModel.onUserFileCaptured(uri, manual) },
                    )
                else ->
                    CaptureFrontOrBack(
                        side = if (state.screenState == ScreenState.CaptureFront) Side.Front else Side.Back,
                        state = state,
                        stepProgress = stepProgress,
                        onChangeDocument = { viewModel.onUserChangeDocument() },
                        onPickFileClick = onPickFileClick,
                        onCapturedFile = { uri, manual -> viewModel.onUserFileCaptured(uri, manual) },
                        onSwitchToFallback = { viewModel.onUserSwitchToFallback() },
                        onRetake = { viewModel.onUserRetakeCapture() },
                        onConfirm = { viewModel.onUserConfirmCapture() },
                    )
            }
            if (state.uploadProgress != null) {
                // Dark variant — mirrors web's `.sdk-upload-sheet--dark`
                // applied on capture_front/capture_back/selfie_capture for
                // visual continuity with the dark camera viewport behind it.
                UploadProgressSheet(hint = state.uploadHint, dark = true)
            }
        }
        return
    }

    OthentoSdkScaffold(isSandbox = isSandbox, brandName = brandName) {
        Box(modifier = Modifier.fillMaxSize()) {
            when (state.screenState) {
                ScreenState.Loading -> LoadingScreen()
                ScreenState.Start ->
                    state.session?.let { session ->
                        StartScreen(
                            session = session,
                            brandName = brandName,
                            onBeginClick = { viewModel.onUserBeginVerification() },
                        )
                    } ?: missingSessionError("Start", onReturnToApp = onReturnToApp)
                ScreenState.DocumentSelect ->
                    DocumentSelectScreen(
                        documents = state.documents,
                        selectedCountryName = state.selectedCountryName,
                        selectedDocumentId = state.selectedDocumentId,
                        loading = state.documentsLoading,
                        errorMessage = state.documentsError,
                        stepProgress = stepProgress,
                        onCountrySelected = { viewModel.onUserCountrySelected(it) },
                        onDocumentSelected = { viewModel.onUserDocumentSelected(it) },
                        onConfirmClick = { viewModel.onUserConfirmDocument() },
                    )
                ScreenState.CaptureFront ->
                    CaptureFrontOrBack(
                        side = Side.Front,
                        state = state,
                        stepProgress = stepProgress,
                        onChangeDocument = { viewModel.onUserChangeDocument() },
                        onPickFileClick = onPickFileClick,
                        onCapturedFile = { uri, manual -> viewModel.onUserFileCaptured(uri, manual) },
                        onSwitchToFallback = { viewModel.onUserSwitchToFallback() },
                        onRetake = { viewModel.onUserRetakeCapture() },
                        onConfirm = { viewModel.onUserConfirmCapture() },
                    )
                ScreenState.CaptureBack ->
                    CaptureFrontOrBack(
                        side = Side.Back,
                        state = state,
                        stepProgress = stepProgress,
                        onChangeDocument = { viewModel.onUserChangeDocument() },
                        onPickFileClick = onPickFileClick,
                        onCapturedFile = { uri, manual -> viewModel.onUserFileCaptured(uri, manual) },
                        onSwitchToFallback = { viewModel.onUserSwitchToFallback() },
                        onRetake = { viewModel.onUserRetakeCapture() },
                        onConfirm = { viewModel.onUserConfirmCapture() },
                    )
                ScreenState.SelfieCapture -> {
                    // Unreachable — the immersive branch above intercepts
                    // SelfieCapture before this `when` runs. Kept here so
                    // the exhaustiveness check covers every enum value.
                }
                ScreenState.OtpPhone, ScreenState.OtpEmail ->
                    state.otp?.let { otp ->
                        OtpScreen(viewModel = viewModel, otp = otp, stepProgress = stepProgress)
                    } ?: missingSessionError("OTP", onReturnToApp = onReturnToApp)
                ScreenState.Processing ->
                    ProcessingScreen(
                        timedOut = state.pollTimedOut,
                        onTryAgainClick = { viewModel.onUserPollRetry() },
                    )
                ScreenState.Approved -> ApprovedScreen(onReturnToApp = onReturnToApp)
                ScreenState.Declined -> DeclinedScreen(onReturnToApp = onReturnToApp)
                ScreenState.InReview -> InReviewScreen(onReturnToApp = onReturnToApp)
                ScreenState.Expired -> ExpiredScreen(onReturnToApp = onReturnToApp)
                ScreenState.FailedTerminal -> FailedTerminalScreen(onReturnToApp = onReturnToApp)
                ScreenState.FailedRetry ->
                    state.session?.let { session ->
                        FailedRetryScreen(
                            session = session,
                            brandName = brandName,
                            onTryAgainClick = { viewModel.onUserRetryFailed() },
                            onReturnToApp = onReturnToApp,
                        )
                    } ?: missingSessionError("FailedRetry", onReturnToApp = onReturnToApp)
                ScreenState.Error ->
                    ErrorScreen(
                        error = state.error,
                        displayMessage = state.displayMessage,
                        httpStatus = state.errorHttpStatus,
                        onReturnToApp = onReturnToApp,
                    )
            }
            // Upload-progress overlay: layers above the capture screens
            // when bytes are flowing. Spec [11-uploading.md] §B.
            if (state.uploadProgress != null) {
                UploadProgressSheet(hint = state.uploadHint)
            }
        }
    }
}

/**
 * Phase 6 — single entry point for `CaptureFront` / `CaptureBack` that
 * picks the camera HUD or the upload-only fallback depending on
 * [FlowUiState.useFallback].
 *
 * The fallback path is exactly the Phase-5 [CaptureFallbackScreen] (zero
 * regression). The camera path is the new [CameraCaptureScreen] running
 * the CameraX preview + analyzer + auto-capture pipeline.
 */
@Composable
@Suppress("LongParameterList")
private fun CaptureFrontOrBack(
    side: Side,
    state: FlowUiState,
    stepProgress: StepProgress,
    onChangeDocument: () -> Unit,
    onPickFileClick: () -> Unit,
    onCapturedFile: (Uri, Boolean) -> Unit,
    onSwitchToFallback: () -> Unit,
    onRetake: () -> Unit,
    onConfirm: () -> Unit,
) {
    if (state.useFallback) {
        CaptureFallbackScreen(
            side = side,
            pendingDocument = state.pendingDocument,
            pendingCapture = state.pendingCapture,
            oversizedFile = state.oversizedFile,
            fileUnreadable = state.fileUnreadable,
            stepProgress = stepProgress,
            onChangeDocument = onChangeDocument,
            onPickFileClick = onPickFileClick,
            onRetake = onRetake,
            onConfirm = onConfirm,
        )
    } else {
        CameraCaptureScreen(
            side = side,
            pendingDocument = state.pendingDocument,
            enableFallback = true,
            pendingCapture = state.pendingCapture,
            onChangeDocument = onChangeDocument,
            onCapturedFile = onCapturedFile,
            onSwitchToFallback = onSwitchToFallback,
            onPickFile = onPickFileClick,
            onRetakePickedFile = onRetake,
            onConfirmPickedFile = onConfirm,
        )
    }
}

/**
 * Renders the generic error screen for the (unreachable in well-behaved
 * code) case where [OthentoFlowHost] sees `screenState=Start | FailedRetry`
 * without a resolved [Session]. Emits a typed [OthentoError.Unknown] so the bug
 * surfaces visibly rather than masquerading as another `Loading` flicker.
 */
@Composable
private fun missingSessionError(
    screenName: String,
    onReturnToApp: () -> Unit,
) {
    ErrorScreen(
        error = OthentoError.Unknown("Resolved $screenName screen without a session payload."),
        displayMessage = "Something went wrong. Please relaunch verification.",
        httpStatus = null,
        onReturnToApp = onReturnToApp,
    )
}

private const val DEFAULT_BRAND_NAME = "Othento"

/**
 * Terminal screens for `closeOnComplete`: a terminal listener event
 * (`onCompleted` / `onError`) has fired and the flow is over. `FailedRetry`
 * is intentionally excluded — the user can still retry from it.
 */
private val TERMINAL_SCREEN_STATES =
    setOf(
        ScreenState.Approved,
        ScreenState.Declined,
        ScreenState.InReview,
        ScreenState.Expired,
        ScreenState.FailedTerminal,
        ScreenState.Error,
    )
