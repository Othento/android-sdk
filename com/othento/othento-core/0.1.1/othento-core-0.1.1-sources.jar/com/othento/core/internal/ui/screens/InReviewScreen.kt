@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.components.StatusIconTone
import com.othento.core.internal.ui.screens.common.RETURN_TO_APP_LABEL
import com.othento.core.internal.ui.screens.common.StatusAction
import com.othento.core.internal.ui.screens.common.StatusScreenMode
import com.othento.core.internal.ui.screens.common.StatusScreenScaffold

/**
 * Spec [docs/spec/06-screens/15-in-review.md]:
 * amber clock, "Verification Under Review", explanatory copy. The spec
 * uses `mode="in-flight"` despite this being a UI-terminal — the loop
 * intent is conceptual, the clock glyph itself is static. Adds the explicit
 * "Return to app" CTA so dismissal is user-driven.
 */
@Composable
internal fun InReviewScreen(onReturnToApp: () -> Unit) {
    StatusScreenScaffold(
        iconName = StatusIconName.Clock,
        iconTone = StatusIconTone.Warning,
        title = "Verification Under Review",
        description =
            "Your submission is being reviewed. This may take a little longer than usual. " +
                "You'll be notified once the review is complete.",
        mode = StatusScreenMode.InFlight,
        primaryAction = StatusAction(label = RETURN_TO_APP_LABEL, onClick = onReturnToApp),
    )
}
