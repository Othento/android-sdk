@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.components.StatusIconTone
import com.othento.core.internal.ui.screens.common.RETURN_TO_APP_LABEL
import com.othento.core.internal.ui.screens.common.StatusAction
import com.othento.core.internal.ui.screens.common.StatusScreenMode
import com.othento.core.internal.ui.screens.common.StatusScreenScaffold

/**
 * Spec [docs/spec/06-screens/14-declined.md]:
 * red cross, "Verification Declined", informational copy. Adds the explicit
 * "Return to app" CTA so dismissal is user-driven.
 */
@Composable
internal fun DeclinedScreen(onReturnToApp: () -> Unit) {
    StatusScreenScaffold(
        iconName = StatusIconName.Cross,
        iconTone = StatusIconTone.Error,
        title = "Verification Declined",
        description =
            "Your identity could not be verified. Please contact your service provider for further assistance.",
        mode = StatusScreenMode.Terminal,
        primaryAction = StatusAction(label = RETURN_TO_APP_LABEL, onClick = onReturnToApp),
    )
}
