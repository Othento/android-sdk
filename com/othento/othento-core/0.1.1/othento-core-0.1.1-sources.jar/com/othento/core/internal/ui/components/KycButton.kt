@file:Suppress("FunctionNaming", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoElevation
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/** Spec §1 — `KycButtonVariant`. Source: `apps/sdk/.../kyc-button.scss:44-86`. */
@Immutable
internal enum class KycButtonVariant { Primary, Secondary, Ghost, Destructive }

/** Spec §1 — `KycButtonSize`. Source: `apps/sdk/.../kyc-button.scss:32-42`. */
@Immutable
internal enum class KycButtonSize(
    val height: Dp,
    val horizontalPadding: Dp,
) {
    Md(44.dp, 20.dp),
    Lg(52.dp, 24.dp),
}

/**
 * Primary action control. Faithful port of the web `kyc-button` component
 * (`apps/sdk/src/app/components/ui/kyc-button/`):
 *
 * - Press scale 0.97 over 140 ms ease-in-out (`motion-press`).
 * - Hover background swap on pointer hover where supported (no-op on touch).
 * - Active background swap on press for the primary variant (`primary-active`).
 * - Background transitions over 140 ms ease-out.
 * - Loading: leading 16-dp arc spinner (`KycLoader.Sm`); button stays
 *   non-interactive but visually keeps the variant background.
 * - Disabled: opacity 0.5; no pointer events.
 *
 * The 3 dp `:focus-visible` outer ring (`motion-focus-ring`) is not rendered
 * — see open question U11.
 */
@Composable
@Suppress("LongParameterList", "LongMethod", "CyclomaticComplexMethod")
internal fun KycButton(
    onClick: () -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    variant: KycButtonVariant = KycButtonVariant.Primary,
    size: KycButtonSize = KycButtonSize.Md,
    enabled: Boolean = true,
    loading: Boolean = false,
    fullWidth: Boolean = false,
) {
    val colors = LocalOthentoColors.current
    val shapes = LocalOthentoShapes.current
    val elevation = LocalOthentoElevation.current
    val motion = LocalOthentoMotion.current
    val typography = LocalOthentoTypography.current

    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val isHovered by interactionSource.collectIsHoveredAsState()
    val pressedScale =
        when {
            motion.reducedMotion -> 1f
            isPressed -> PressedScale
            else -> 1f
        }
    val animatedScale by animateFloatAsState(
        targetValue = pressedScale,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeInOut),
        label = "kyc-button-press",
    )

    val isInteractive = enabled && !loading
    val palette = paletteFor(variant)
    val targetBg =
        when {
            !isInteractive -> palette.background
            variant == KycButtonVariant.Primary && isPressed -> colors.primaryActive
            variant == KycButtonVariant.Primary && isHovered -> colors.primaryHover
            variant == KycButtonVariant.Secondary && isHovered -> colors.bgHover
            variant == KycButtonVariant.Ghost && isHovered -> colors.primaryBg
            variant == KycButtonVariant.Destructive && isHovered -> colors.errorText
            else -> palette.background
        }
    val targetBorder =
        when {
            variant == KycButtonVariant.Secondary && isHovered -> colors.borderHover
            else -> palette.border
        }
    val animatedBg by animateColorAsState(
        targetValue = targetBg,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-button-bg",
    )
    val animatedBorder by animateColorAsState(
        targetValue = targetBorder ?: Color.Transparent,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-button-border",
    )

    val ctaShadow =
        when (variant) {
            KycButtonVariant.Primary -> elevation.cta
            KycButtonVariant.Secondary -> elevation.level1
            KycButtonVariant.Ghost, KycButtonVariant.Destructive -> elevation.level0
        }

    val widthModifier = if (fullWidth) Modifier.fillMaxWidth() else Modifier.wrapContentSize()

    Box(
        modifier =
            modifier
                .then(widthModifier)
                .height(size.height)
                .scale(animatedScale)
                .alpha(if (isInteractive) 1f else DisabledAlpha)
                .shadow(elevation = ctaShadow, shape = shapes.lg)
                .clip(shapes.lg)
                .background(animatedBg)
                .let {
                    if (palette.border != null) {
                        it.border(width = 1.dp, color = animatedBorder, shape = shapes.lg)
                    } else {
                        it
                    }
                }.clickable(
                    enabled = isInteractive,
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick,
                ).padding(horizontal = size.horizontalPadding),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(OuterGap, Alignment.CenterHorizontally),
        ) {
            if (loading) {
                KycLoader(
                    size = KycLoaderSize.Sm,
                    tone =
                        when (variant) {
                            KycButtonVariant.Primary, KycButtonVariant.Destructive -> KycLoaderTone.Inverse
                            KycButtonVariant.Secondary, KycButtonVariant.Ghost -> KycLoaderTone.Primary
                        },
                    contentDescription = "",
                )
            }
            Text(
                text = label,
                style = if (size == KycButtonSize.Lg) typography.buttonLg else typography.buttonMd,
                color = palette.foreground,
            )
        }
    }
}

@Immutable
private data class ButtonPalette(
    val background: Color,
    val foreground: Color,
    val border: Color?,
)

@Composable
private fun paletteFor(variant: KycButtonVariant): ButtonPalette {
    val colors = LocalOthentoColors.current
    return when (variant) {
        KycButtonVariant.Primary ->
            ButtonPalette(
                background = colors.primary,
                foreground = Color.White,
                border = null,
            )
        KycButtonVariant.Secondary ->
            ButtonPalette(
                background = colors.bgBase,
                foreground = colors.textPrimary,
                border = colors.border,
            )
        KycButtonVariant.Ghost ->
            ButtonPalette(
                background = Color.Transparent,
                foreground = colors.primary,
                border = null,
            )
        KycButtonVariant.Destructive ->
            ButtonPalette(
                background = colors.error,
                foreground = Color.White,
                border = null,
            )
    }
}

private const val PressedScale = 0.97f
private const val DisabledAlpha = 0.5f

// Outer gap between spinner and label (`kyc-button.scss:16` `.kyc-button { gap: 8px }`).
private val OuterGap = 8.dp
