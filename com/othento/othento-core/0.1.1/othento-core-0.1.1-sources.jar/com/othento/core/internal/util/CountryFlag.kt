@file:Suppress("MagicNumber")

package com.othento.core.internal.util

/**
 * Maps an ISO-3166 alpha-2 country code (`"JO"`, `"AE"`, …) to a Unicode
 * regional-indicator emoji flag (`🇯🇴`, `🇦🇪`, …).
 *
 * Each flag is encoded as two regional-indicator code points (U+1F1E6
 * through U+1F1FF). The system emoji font renders them as the matching
 * country flag on Android 7+; older devices fall back to two letter
 * glyphs, which still communicates the country at a glance.
 *
 * Returns `null` when the code is missing, the wrong length, or contains
 * non-ASCII letters — callers (the dropdown + the doc-info chip) drop the
 * leading slot in that case so we never render a half-flag.
 */
@Suppress("ReturnCount") // Three guards (null / wrong length / non-letter chars) + one happy path.
internal fun countryCodeToFlagEmoji(countryCode: String?): String? {
    if (countryCode == null) return null
    val trimmed = countryCode.trim()
    if (trimmed.length != 2) return null
    val upper = trimmed.uppercase()
    if (upper.any { it !in 'A'..'Z' }) return null
    val codePoints =
        IntArray(2) { i ->
            REGIONAL_INDICATOR_BASE + (upper[i].code - 'A'.code)
        }
    return String(codePoints, 0, codePoints.size)
}

private const val REGIONAL_INDICATOR_BASE: Int = 0x1F1E6
