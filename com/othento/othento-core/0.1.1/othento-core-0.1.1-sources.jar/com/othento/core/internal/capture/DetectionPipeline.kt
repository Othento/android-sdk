@file:Suppress(
    "ReturnCount",
    "ComplexMethod",
    "LongMethod",
    "TooManyFunctions",
    "MaxLineLength",
    // Reason: process() is a linear gate chain — each early return corresponds to
    // one failed quality/coverage/ML gate. Collapsing into a single boolean expression
    // would obscure the ordering rationale (cheapest gates first, ML Kit gates last).
    // The pattern mirrors the web SDK's QualityAnalyzerService pipeline. Debug-reason
    // strings inline the formatted values (aspect/coverage/blur/etc.) so each gate's
    // rejection cause is visible on the device debug overlay; the resulting string
    // expressions push some lines past the 120-char limit but extracting them into
    // helpers would obscure the gate-by-gate flow.
)

package com.othento.core.internal.capture

import android.graphics.PointF
import android.graphics.Rect
import androidx.camera.core.ImageProxy
import com.othento.core.internal.capture.detection.CornerSmoother
import com.othento.core.internal.capture.detection.passport.MrzDetector
import com.othento.core.internal.capture.detection.passport.PassportPhotoGate
import com.othento.core.internal.capture.detection.passport.framingHint
import com.othento.core.internal.capture.detection.quality.QualityAnalyzer
import com.othento.core.internal.capture.detection.smartcropper.SmartCropperDocumentDetector
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * V30 detection pipeline. One instance per capture screen — owns one
 * [DocumentDetector], one [CornerSmoother], optionally one [MrzDetector] +
 * one [PassportPhotoGate], and a [MutableStateFlow] of the current
 * [DetectionState].
 *
 * The screen calls [process] on every analyzer frame; the pipeline runs the
 * detector, applies smoothing + per-screen gates, and updates [state]. When
 * the stability gate is satisfied, [state] transitions to
 * [DetectionState.ReadyToCapture] — the screen observes this and fires
 * auto-capture.
 *
 * Gate ordering (cheapest first):
 * 1. Aspect ratio check (pure math)
 * 2. Coverage ratio check (pure math)
 * 3. Blur / glare / brightness quality scoring (Y-plane scan)
 * 4. MRZ gate (ML Kit Text Recognition — passport only)
 * 5. Face gate (ML Kit Face Detection — passport only)
 */
internal class DetectionPipeline(
    private val detector: DocumentDetector,
    private val config: DetectionConfig,
    private val mrz: MrzDetector? = null,
    private val faceGate: PassportPhotoGate? = null,
) {
    private val smoother = CornerSmoother()
    /**
     * Combined miss counter — incremented by BOTH hard-reject (no detection /
     * bad aspect) AND soft-reject (coverage / MRZ / face gate). Mirrors the
     * web SDK's single `missedFrames` counter that gates the tolerance window.
     * Using a single counter prevents alternating failure modes from keeping
     * the hold alive indefinitely.
     */
    private var consecutiveMisses = 0
    private var paused = false

    private var currentHint: String? = null
    private var hintShownAtMs: Long = 0L
    private var currentWarning: String? = null
    private var warningShownAtMs: Long = 0L

    /**
     * Accumulated *successful* holding time in milliseconds — the only
     * input to the auto-capture decision. Advances by `(nowMs - lastSuccess)`
     * on each frame that passes every gate; pauses (does not reset) on a
     * miss within tolerance; resets to 0 when consecutive misses exceed
     * [CaptureConfig.MISS_TOLERANCE_FRAMES] OR on retake / lifecycle
     * rebind via [reset].
     *
     * Why an accumulator rather than wall-clock from a single start
     * timestamp: a wall-clock counter advances during missed frames too,
     * so a user catching the document briefly and removing it could
     * still trigger auto-capture if they happened to hold across a
     * 1.3 s window. The accumulator requires the document to actually
     * be in frame for [HOLD_TARGET_MS] of total time.
     *
     * Exposed via [holdingStartedAtMs] (synthetic — `nowMs - effectiveHoldMs`
     * when holding) so the screen's shutter arc still reads "time since
     * holding started" semantics without needing to know about the
     * pause-on-miss machinery.
     */
    private var effectiveHoldMs: Long = 0L
    private var lastSuccessAtMs: Long = 0L

    private val _holdingStartedAtMs = MutableStateFlow(0L)
    val holdingStartedAtMs: StateFlow<Long> = _holdingStartedAtMs.asStateFlow()

    private val _holdProgress = MutableStateFlow(0f)
    val holdProgress: StateFlow<Float> = _holdProgress.asStateFlow()

    /**
     * User-friendly hint string for the status pill — positioning issues
     * only (move closer, move further, align passport). `null` when the
     * pipeline has no actionable positioning advice.
     */
    private val _hint = MutableStateFlow<String?>(null)
    val hint: StateFlow<String?> = _hint.asStateFlow()

    /**
     * Quality-specific warning for the amber bubble — blur, glare,
     * brightness. Separate from [hint] so the screen can render two
     * independent feedback elements (status pill + warning bubble),
     * matching the selfie capture pattern.
     */
    private val _warning = MutableStateFlow<String?>(null)
    val warning: StateFlow<String?> = _warning.asStateFlow()

    private val _state = MutableStateFlow<DetectionState>(DetectionState.Idle)
    val state: StateFlow<DetectionState> = _state.asStateFlow()

    /** Bridge for the screen to bootstrap the underlying detector once. */
    suspend fun initializeDetector() = detector.initialize()

    /**
     * Returns the detector's init-status flow if the detector is a
     * [SmartCropperDocumentDetector], otherwise null. Used by the debug overlay.
     */
    fun debugDetectorInitStatus(): StateFlow<String>? = (detector as? SmartCropperDocumentDetector)?.initStatus

    fun mrzOrNull(): MrzDetector? = mrz

    fun faceGateOrNull(): PassportPhotoGate? = faceGate

    /**
     * One detection frame. [packedYPlane] is the source-image Y-plane with
     * row padding stripped — width × height bytes, indexable as
     * `packedYPlane[y * image.width + x]`. The caller (FrameAnalyzer) is
     * responsible for stripping any rowStride padding before calling.
     */
    fun process(
        image: ImageProxy,
        cutoutInImageCoords: Rect,
        packedYPlane: ByteArray,
    ) {
        val current = _state.value
        if (current is DetectionState.Captured) return
        if (current is DetectionState.ReadyToCapture) return
        if (paused) return

        val raw = detector.detect(image, cutoutInImageCoords)
        val nowMs = System.currentTimeMillis()
        val smoothed = smoother.smooth(raw.corners, nowMs)
        val effective = if (smoothed != null) raw.copy(corners = smoothed) else raw

        if (!effective.detected || effective.corners == null) {
            rejectWith(nowMs)
            return
        }
        if (!aspectRatioWithinTolerance(effective.corners)) {
            rejectWith(nowMs)
            return
        }
        // Document-quad coverage gate — ID cards only. Passport positioning is
        // owned by the MRZ framing gate below, matching the web SDK (which runs
        // no document-coverage gate for passport). SmartCropper's quad is
        // unreliable on a passport booklet, and a "fill the cutout" coverage
        // check directly conflicts with framing's "leave margin on the sides"
        // rule — it would fire "Move the document closer" and mask framing's
        // directional hints. MRZ TooFar/TooClose enforce passport size instead.
        if (!config.requireMrz) {
            // When the screen can't map a sensor-space cutout (PreviewView outputTransform
            // never attaches), the detector falls back to scanning the full frame. In that
            // mode the document occupies a smaller fraction of the area, so we relax the
            // coverage gate. The aspect-ratio check above is still doing the heavy lifting
            // for "is this card-shaped".
            val isFullFrame =
                cutoutInImageCoords.isEmpty ||
                    (cutoutInImageCoords.width() >= image.width && cutoutInImageCoords.height() >= image.height)
            val coverageMin = if (isFullFrame) FULL_FRAME_COVERAGE_MIN else config.coverageMin
            val coverageMax = if (isFullFrame) FULL_FRAME_COVERAGE_MAX else config.coverageMax

            if (effective.coverageRatio < coverageMin) {
                softReject(
                    "Move the document closer",
                    effective.corners,
                    nowMs,
                )
                return
            }
            if (effective.coverageRatio > coverageMax) {
                softReject(
                    "Move the document further away",
                    effective.corners,
                    nowMs,
                )
                return
            }
        }

        // Read the MRZ snapshot once (passport only) and reuse it for both the
        // quality-scan gate and the framing gate below.
        val mrzSnap = if (config.requireMrz) mrz?.snapshot() else null

        // Passport: don't pay for the blur/glare/brightness Y-plane scans — the
        // analyzer thread's most expensive recurring work — until an MRZ is
        // actually in view. While the document is detected but no MRZ has
        // matched, the matched gate below blocks capture anyway, so the scans
        // would only burn CPU on a frame that can't capture.
        if (!config.requireMrz || mrzSnap?.matched == true) {
            val qRect = boundingRect(effective.corners)
            val blur = QualityAnalyzer.laplacianVariance(packedYPlane, image.width, image.height, qRect)
            if (blur < config.blurThreshold) {
                qualityReject(
                    "Hold steady — image is blurry",
                    effective.corners,
                    nowMs,
                )
                return
            }

            val glare = QualityAnalyzer.glareRatio(packedYPlane, image.width, image.height, qRect)
            if (glare > config.glareThreshold) {
                qualityReject(
                    "Reduce glare — adjust angle or lighting",
                    effective.corners,
                    nowMs,
                )
                return
            }

            val brightness =
                QualityAnalyzer.brightnessMean(packedYPlane, image.width, image.height, qRect).toInt()
            if (brightness !in config.brightnessRange) {
                val warn =
                    if (brightness < config.brightnessRange.first) {
                        "Improve lighting — too dark"
                    } else {
                        "Reduce lighting — too bright"
                    }
                qualityReject(
                    warn,
                    effective.corners,
                    nowMs,
                )
                return
            }
        }

        if (config.requireMrz) {
            if (mrzSnap?.matched != true) {
                softReject(
                    "Align the passport inside the frame",
                    effective.corners,
                    nowMs,
                )
                return
            }
            // Framing gate runs before the face gate — being mis-framed is more
            // fundamental than the photo position (web SDK 749ea45). softReject
            // keeps the existing miss-tolerance so a single OCR flicker doesn't
            // reset the hold.
            val mrzFramingHint = framingHint(mrzSnap.framing)
            if (mrzFramingHint != null) {
                softReject(
                    mrzFramingHint,
                    effective.corners,
                    nowMs,
                )
                return
            }
        }

        if (config.requireFaceGate && faceGate?.snapshot()?.passed != true) {
            softReject(
                "Align the passport inside the frame",
                effective.corners,
                nowMs,
            )
            return
        }

        // All gates passed — clear hint + warning (respecting sticky duration
        // so the user sees WHY a prior quality reset happened) and advance the
        // success accumulator.
        clearStickyHint(nowMs)
        clearStickyWarning(nowMs)
        consecutiveMisses = 0
        if (current !is DetectionState.Holding && current !is DetectionState.ReadyToCapture) {
            // First successful frame of a new hold window.
            effectiveHoldMs = 0L
            lastSuccessAtMs = nowMs
        } else {
            // Continuing — add the wall-clock delta since the last success.
            // Cap the per-frame delta at the analyzer's expected period so a
            // long pause doesn't translate into a sudden timer jump if it
            // happened to stay within tolerance the whole time.
            val delta = (nowMs - lastSuccessAtMs).coerceIn(0L, MAX_FRAME_DELTA_MS)
            effectiveHoldMs += delta
            lastSuccessAtMs = nowMs
        }
        _holdingStartedAtMs.value = nowMs - effectiveHoldMs
        _holdProgress.value = (effectiveHoldMs.toFloat() / HOLD_TARGET_MS).coerceIn(0f, 1f)
        val newState = stateForHoldElapsed(effective.corners)
        _state.value = newState
    }

    /**
     * Compute the Holding/ReadyToCapture state from the
     * [effectiveHoldMs] accumulator. `framesHeld` is mapped from elapsed
     * ms so the UI's progress arc fills smoothly regardless of analyzer
     * cadence.
     */
    private fun stateForHoldElapsed(corners: List<PointF>): DetectionState {
        val elapsed = effectiveHoldMs.coerceAtLeast(0L)
        if (elapsed >= HOLD_TARGET_MS) return DetectionState.ReadyToCapture(corners)
        val held =
            ((elapsed.toFloat() / HOLD_TARGET_MS.toFloat()) * config.stabilityFramesRequired)
                .toInt()
                .coerceAtLeast(1)
        return DetectionState.Holding(corners, held)
    }

    /** Called by the screen once auto-capture (or manual) has fired. */
    fun markCaptured() {
        val cur = _state.value
        val corners =
            (cur as? DetectionState.ReadyToCapture)?.corners
                ?: (cur as? DetectionState.Holding)?.corners
                ?: emptyList()
        _state.value = DetectionState.Captured(corners)
    }

    /**
     * Discard the last capture decision and resume detection. Called by the
     * screen on Retake — without this, [process] would early-return forever
     * on `DetectionState.Captured`. Also clears the stability counter and
     * the corner smoother so the next gate-pass run starts from a clean
     * baseline instead of inheriting state from the prior, now-discarded
     * capture window.
     */
    fun reset() {
        consecutiveMisses = 0
        effectiveHoldMs = 0L
        lastSuccessAtMs = 0L
        _holdingStartedAtMs.value = 0L
        _holdProgress.value = 0f
        smoother.clear()
        _state.value = DetectionState.Idle
        _hint.value = null
        currentHint = null
        _warning.value = null
        currentWarning = null
    }

    /**
     * Suspend frame processing while the intro bottom sheet is visible. Entering
     * pause also resets accumulated stability so the post-dismissal hold rebuilds
     * from zero — otherwise a partial Holding window would race auto-capture
     * the moment the sheet closes.
     */
    fun setPaused(value: Boolean) {
        if (paused == value) return
        paused = value
        if (value) reset()
    }

    fun release() {
        detector.release()
        mrz?.release()
        faceGate?.release()
    }

    // ──────────────────────────────────────── Private ────────────────────────────────────────────

    private fun rejectWith(
        nowMs: Long,
    ) {
        clearStickyHint(nowMs)
        clearStickyWarning(nowMs)
        handleMiss(nowMs)
    }

    private fun clearStickyHint(nowMs: Long) {
        if (currentHint != null && nowMs - hintShownAtMs >= HINT_MIN_DISPLAY_MS) {
            currentHint = null
            _hint.value = null
        }
    }

    private fun clearStickyWarning(nowMs: Long) {
        if (currentWarning != null && nowMs - warningShownAtMs >= HINT_MIN_DISPLAY_MS) {
            currentWarning = null
            _warning.value = null
        }
    }

    /**
     * Shared miss-tolerance bookkeeping for every transient failure — a hard
     * miss (no detection), a positioning soft-reject (coverage / MRZ / face
     * geometry), or a quality reject (blur / glare / brightness). All three
     * obey ONE rule so they can never drift apart again:
     *
     *  - increment the consecutive-miss counter;
     *  - past [CaptureConfig.MISS_TOLERANCE_FRAMES] → snap the hold back to
     *    zero and drop to [DetectionState.Searching];
     *  - within tolerance → keep advancing the hold so the progress arc climbs
     *    straight through the gap and NEVER pauses.
     *
     * Callers route their own hint / warning text first, so the failure kinds
     * differ only in the message they surface — never in how the hold behaves.
     * Consolidating this was the actual fix: earlier revisions had one path
     * pause, one advance, and one reset-immediately, which is what made the arc
     * stall (or step) on a transient miss instead of sailing through tolerance.
     *
     * [cornersForOverlay] is the detected quad when this frame produced one
     * (soft / quality rejects), or null for a hard miss.
     */
    private fun registerMissAndUpdateHold(
        cornersForOverlay: List<PointF>?,
        nowMs: Long,
    ) {
        consecutiveMisses++
        if (consecutiveMisses > CaptureConfig.MISS_TOLERANCE_FRAMES) {
            effectiveHoldMs = 0L
            lastSuccessAtMs = 0L
            _holdingStartedAtMs.value = 0L
            _holdProgress.value = 0f
            smoother.smooth(cornersForOverlay, nowMs)
            _state.value = DetectionState.Searching(lastCorners = cornersForOverlay)
            return
        }
        // Within tolerance: the document is still there — keep advancing the
        // hold so the arc climbs straight through the transient miss. It never
        // pauses mid-hold; only a miss sustained past the tolerance window
        // (above) snaps it back to zero.
        smoother.smooth(cornersForOverlay, nowMs)
        val cur = _state.value
        if (cur is DetectionState.Holding || cur is DetectionState.ReadyToCapture) {
            if (lastSuccessAtMs > 0L) {
                val delta = (nowMs - lastSuccessAtMs).coerceIn(0L, MAX_FRAME_DELTA_MS)
                effectiveHoldMs += delta
                lastSuccessAtMs = nowMs
                _holdingStartedAtMs.value = nowMs - effectiveHoldMs
                _holdProgress.value = (effectiveHoldMs.toFloat() / HOLD_TARGET_MS).coerceIn(0f, 1f)
                val corners =
                    cornersForOverlay
                        ?: (cur as? DetectionState.Holding)?.corners
                        ?: (cur as? DetectionState.ReadyToCapture)?.corners
                        ?: emptyList()
                _state.value = stateForHoldElapsed(corners)
            }
            return
        }
        _state.value =
            DetectionState.Searching(
                lastCorners = cornersForOverlay ?: (cur as? DetectionState.Searching)?.lastCorners,
            )
    }

    /**
     * Quality-reject path: a quality gate failed (blur, glare, brightness).
     * Routes the message to the amber warning bubble (not the status pill),
     * then defers to [registerMissAndUpdateHold] — so a transient blur/glare
     * dip advances the hold through the tolerance window exactly like a
     * positioning miss, rather than pausing or zeroing it.
     */
    private fun qualityReject(
        warningText: String,
        cornersForOverlay: List<PointF>?,
        nowMs: Long,
    ) {
        applyStickyWarning(warningText, nowMs)
        clearStickyHint(nowMs)
        registerMissAndUpdateHold(cornersForOverlay, nowMs)
    }

    private fun applyStickyWarning(warning: String, nowMs: Long) {
        if (warning != currentWarning) {
            if (currentWarning == null || nowMs - warningShownAtMs >= HINT_MIN_DISPLAY_MS) {
                currentWarning = warning
                warningShownAtMs = nowMs
                _warning.value = warning
            }
        }
    }

    /**
     * Soft-reject path: a positioning gate failed (coverage, MRZ, face
     * geometry) but the detector produced a valid quad. Surfaces the
     * positioning hint on the status pill, then defers to
     * [registerMissAndUpdateHold] for the tolerance bookkeeping shared with
     * [qualityReject] and [handleMiss].
     */
    private fun softReject(
        userHint: String,
        cornersForOverlay: List<PointF>?,
        nowMs: Long,
    ) {
        applyStickyHint(userHint, nowMs)
        registerMissAndUpdateHold(cornersForOverlay, nowMs)
    }

    private fun applyStickyHint(hint: String, nowMs: Long) {
        if (hint != currentHint) {
            // New hint — only replace the old one if the sticky duration elapsed.
            if (currentHint == null || nowMs - hintShownAtMs >= HINT_MIN_DISPLAY_MS) {
                currentHint = hint
                hintShownAtMs = nowMs
                _hint.value = hint
            }
        }
        // Same hint repeating — keep it visible, no update needed.
    }

    /**
     * Hard-miss path: no detection at all (the detector found nothing, or the
     * aspect-ratio gate rejected the quad). There's no overlay quad to show, so
     * it passes null to [registerMissAndUpdateHold], which still advances the
     * hold within tolerance — a brief autofocus blip or single bad SmartCropper
     * read must not stall the arc — and resets it once misses exceed tolerance.
     */
    private fun handleMiss(nowMs: Long) {
        registerMissAndUpdateHold(null, nowMs)
    }

    private fun bboxWidthHeight(corners: List<PointF>): Pair<Float, Float> {
        val xs = corners.map { it.x }
        val ys = corners.map { it.y }
        val w = (xs.max() - xs.min()).coerceAtLeast(1f)
        val h = (ys.max() - ys.min()).coerceAtLeast(1f)
        return w to h
    }

    /**
     * Orientation-agnostic aspect-ratio check: compares the quad's longer
     * bbox dimension against its shorter dimension. The analyzer delivers
     * frames in sensor-natural orientation (typically landscape with a
     * `rotationDegrees` flag), so a portrait-held card has its long edge on
     * the *short* image axis. Comparing `width / height` directly would
     * reject every correctly-held card on rotated frames; comparing
     * `max / min` handles every device rotation and user-held orientation
     * with the same threshold.
     */
    private fun aspectRatioWithinTolerance(corners: List<PointF>): Boolean {
        val (w, h) = bboxWidthHeight(corners)
        val ratio = max(w, h) / min(w, h)
        return abs(ratio - config.expectedAspectRatio) <=
            config.aspectRatioTolerance * config.expectedAspectRatio
    }

    private fun boundingRect(corners: List<PointF>): Rect {
        val xs = corners.map { it.x.toInt() }
        val ys = corners.map { it.y.toInt() }
        return Rect(xs.min(), ys.min(), xs.max(), ys.max())
    }

    private companion object {
        /** Coverage minimum used when detection runs over the full sensor frame. */
        const val FULL_FRAME_COVERAGE_MIN: Float = 0.05f

        /** Coverage maximum used when detection runs over the full sensor frame. */
        const val FULL_FRAME_COVERAGE_MAX: Float = 0.80f

        /**
         * Wall-clock duration the document must be continuously detected
         * (modulo [CaptureConfig.MISS_TOLERANCE_FRAMES] gaps) before
         * auto-capture fires. Mirrors the web SDK's
         * `autoCaptureDurationMs = 1300`.
         */
        const val HOLD_TARGET_MS: Long = 1_300L

        /**
         * Per-frame upper bound on the accumulator's delta increment.
         * At the configured 7 fps analyzer cadence the natural delta is
         * ~143 ms; the cap prevents a single delayed frame (autofocus
         * stall, GC pause, etc) from inflating `effectiveHoldMs` in one
         * jump. Set to ~2 frame periods so realistic timing variation under
         * load isn't truncated — the old 200 ms value was sized for the former
         * 10 fps cadence and, once the analyzer dropped to 7 fps, it truncated
         * normal frame deltas whenever the loaded analyzer fell below ~5 fps,
         * stretching a clean 1.3 s hold to 2–3 s. A 500 ms gap still can't add
         * 500 ms.
         */
        const val MAX_FRAME_DELTA_MS: Long = 286L

        /**
         * Minimum display duration for hint messages before they can be
         * replaced or cleared. Prevents rapid text flickering on the UI.
         * Matches the web SDK's sticky-message service (1500ms).
         */
        const val HINT_MIN_DISPLAY_MS: Long = 1_500L
    }
}
