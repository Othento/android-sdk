package com.othento.core.internal.capture

import android.graphics.PointF
import android.graphics.Rect
import androidx.camera.core.ImageProxy

/**
 * Pluggable document-corner detector. The V30 pipeline uses a
 * SmartCropper-backed implementation; the iOS rebuild may swap in
 * `VNDetectRectanglesRequest`.
 *
 * Lifecycle: callers must invoke [initialize] before [detect] and [release]
 * exactly once at end of life. [detect] is safe to call from any background
 * thread but **not** concurrently with itself — the analyzer guarantees
 * single-threaded delivery via `STRATEGY_KEEP_ONLY_LATEST`.
 */
internal interface DocumentDetector {
    suspend fun initialize()

    fun detect(
        yuvImage: ImageProxy,
        cutoutInImageCoords: Rect,
    ): DetectionResult

    fun release()
}

/**
 * Output of a single [DocumentDetector.detect] call.
 *
 * Coordinates are in the same space as the source [ImageProxy] — typically
 * camera-sensor pixels with the rotation applied. Mapping to view space is
 * the caller's job.
 */
internal data class DetectionResult(
    val detected: Boolean,
    /** TL, TR, BR, BL — null if [detected] is false. */
    val corners: List<PointF>?,
    /** Polygon area / cutout area, in `[0, 1+]`. 0 if not detected. */
    val coverageRatio: Float,
) {
    companion object {
        val NONE: DetectionResult = DetectionResult(detected = false, corners = null, coverageRatio = 0f)
    }
}
