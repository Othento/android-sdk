package com.othento.core.internal.data

import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.network.OthentoApi
import com.othento.core.internal.network.OthentoNetworkException
import com.othento.core.internal.network.ErrorMapper
import com.othento.core.internal.network.SessionMapper
import com.othento.core.internal.network.TokenStore
import com.othento.core.internal.network.dto.CreateSessionRequestDto
import com.othento.core.internal.network.dto.TokenSessionResponseDto
import kotlinx.coroutines.CancellationException

/**
 * Single source of truth for session-shaped data the rest of the SDK reads.
 *
 * The Android SDK is a single-mode flow (P9 in `99-open-questions.md`): every
 * launch creates a fresh session, the create response carries the SAT used
 * for the token-mode calls Phase 5+ adds. There is no apiKey-mode "load
 * existing session" counterpart.
 *
 * On failure, the implementation **always** throws an [OthentoNetworkException]
 * carrying the typed [com.othento.core.api.OthentoError] and a pre-formatted
 * display string. Callers may unwrap to surface to the host via the listener.
 *
 * Phase 5 adds the token-mode endpoints: `pollSession`, `getDocuments`,
 * `initiateSession`. Each call funnels its response through the [TokenStore]
 * so the [com.othento.core.internal.network.TokenInterceptor] picks up
 * rotated tokens.
 */
internal interface SessionRepository {
    /** `POST /api/v1/SessionToken/session` (apiKey-authenticated). */
    suspend fun createSession(request: CreateSessionRequestDto): Session

    /** `GET /api/v1/SessionToken/session` — load + poll the current session. */
    suspend fun pollSession(): Session

    /** `GET /api/v1/SessionToken/session/documents`. Phase 5 caches this in-memory. */
    suspend fun getDocuments(): List<AcceptedDocument>

    /** `POST /api/v1/SessionToken/session/initiate?documentId=…`. */
    suspend fun initiateSession(documentId: String): Session

    /**
     * `POST /api/v1/SessionToken/session/reinitiate?documentId=…` — re-attempt
     * the document step on a `Failed` + `canReinitiate` session. The backend
     * rejects `initiate` on a retryable-failed session, so the retry path uses
     * this instead. Mirrors the web's
     * `SdkTokenSessionService.reinitiateSession`.
     */
    suspend fun reinitiateSession(documentId: String): Session
}

/**
 * apiKey + token-mode implementation.
 *
 * The wire-vs-spec deviations are documented in `OthentoApiPaths` and P9 in
 * `docs/spec/99-open-questions.md`.
 */
internal class ApiKeySessionRepository(
    private val api: OthentoApi,
    private val errorMapper: ErrorMapper,
    private val tokenStore: TokenStore,
) : SessionRepository {
    override suspend fun createSession(request: CreateSessionRequestDto): Session =
        runCallMapping(ErrorMapper.Flow.Create) {
            absorbAndMap(api.createSession(request))
        }

    override suspend fun pollSession(): Session =
        runCallMapping(ErrorMapper.Flow.Poll) {
            absorbAndMap(api.pollSession())
        }

    override suspend fun getDocuments(): List<AcceptedDocument> =
        runCallMapping(ErrorMapper.Flow.Documents) {
            SessionMapper.mapAcceptedDocuments(api.getDocuments())
        }

    override suspend fun initiateSession(documentId: String): Session =
        runCallMapping(ErrorMapper.Flow.Initiate) {
            absorbAndMap(api.initiateSession(documentId))
        }

    override suspend fun reinitiateSession(documentId: String): Session =
        runCallMapping(ErrorMapper.Flow.Initiate) {
            absorbAndMap(api.reinitiateSession(documentId))
        }

    /**
     * Absorb the response into the [tokenStore] (so the interceptor picks
     * up rotated SAT/ST/SRT) and return the mapped [Session]. Single
     * invariant: every token-mode response goes through here.
     */
    private fun absorbAndMap(dto: TokenSessionResponseDto): Session {
        tokenStore.updateFromResponse(dto)
        return SessionMapper.fromTokenSessionResponse(dto)
    }

    @Suppress(
        "TooGenericExceptionCaught",
        // Reason: this is the single trampoline that translates *every*
        // exceptional failure mode (HTTP, IO, JSON-parse, unexpected) coming
        // out of Retrofit into a typed OthentoNetworkException. Catching narrowly
        // would let a sub-class slip through and surface as an unwrapped
        // RuntimeException to the host listener — which would break the
        // contract that all failures arrive as OthentoError. Cancellation is
        // re-thrown explicitly above to honour structured concurrency.
    )
    private inline fun <T> runCallMapping(
        flow: ErrorMapper.Flow,
        block: () -> T,
    ): T =
        try {
            block()
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: Exception) {
            throw errorMapper.toException(e, flow)
        }
}
