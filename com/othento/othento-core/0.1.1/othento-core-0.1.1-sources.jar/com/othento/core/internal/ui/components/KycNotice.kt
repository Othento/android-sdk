@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MatchingDeclarationName")

package com.othento.core.internal.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/** Spec §6 — `KycNoticeTone`. Source: `apps/sdk/.../kyc-notice.scss:36-58`. */
@Immutable
internal enum class KycNoticeTone { Info, Warning, Error, Success }

/**
 * Inline banner with icon + title + description. Faithful port of
 * `apps/sdk/.../kyc-notice/`.
 *
 * Each tone uses its bg / border / text triplet — info specifically uses
 * `--color-primary-bg` for both background and border (so the border is
 * indistinguishable from the bg) and `--color-primary` for text/icon.
 */
@Composable
internal fun KycNotice(
    modifier: Modifier = Modifier,
    tone: KycNoticeTone = KycNoticeTone.Info,
    title: String? = null,
    description: String? = null,
    icon: (@Composable () -> Unit)? = null,
) {
    val colors = LocalOthentoColors.current
    val shapes = LocalOthentoShapes.current
    val typography = LocalOthentoTypography.current
    val (bg, border, text) = palette(tone)

    Row(
        modifier =
            modifier
                .clip(shapes.md)
                .background(bg)
                .border(width = 1.dp, color = border, shape = shapes.md)
                .padding(horizontal = 14.dp, vertical = 12.dp)
                .semantics { liveRegion = LiveRegionMode.Polite },
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        if (icon != null) {
            // 1 dp top nudge per kyc-notice.scss:14-17
            Box(modifier = Modifier.padding(top = 1.dp)) { icon() }
        }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (!title.isNullOrBlank()) {
                Text(
                    text = title,
                    style = typography.bodySm.copy(fontWeight = FontWeight.W600),
                    color = text,
                )
            }
            if (!description.isNullOrBlank()) {
                Text(
                    text = description,
                    style = typography.caption,
                    color = text.copy(alpha = DescriptionAlpha),
                )
            }
        }
    }
}

@Composable
private fun palette(tone: KycNoticeTone): Triple<Color, Color, Color> {
    val colors = LocalOthentoColors.current
    return when (tone) {
        // info: bg primary-bg / border primary-bg / color primary
        KycNoticeTone.Info -> Triple(colors.primaryBg, colors.primaryBg, colors.primary)
        KycNoticeTone.Warning -> Triple(colors.warningBg, colors.warningBorder, colors.warningText)
        KycNoticeTone.Error -> Triple(colors.errorBg, colors.errorBorder, colors.errorText)
        KycNoticeTone.Success -> Triple(colors.successBg, colors.successBorder, colors.successText)
    }
}

private const val DescriptionAlpha = 0.85f
