package com.othento.core.internal.data

import com.othento.core.internal.data.model.Session

/**
 * Outcome of an OTP-send call. The on-screen error / success copy is
 * derived from this discriminator (spec §10.5 + §10.6,
 * [docs/spec/06-screens/09-otp-phone.md]).
 */
internal sealed interface OtpSendResult {
    /**
     * Code dispatched. The returned session carries `OtpSent` +
     * `otpExpiresAt` on the matching challenge per
     * [docs/spec/10-network-layer.md] §5.2 `otp/send`.
     */
    data class Sent(
        val session: Session,
    ) : OtpSendResult

    /**
     * Backend has rotated `currentStep` past this OTP step **and** set
     * `declineMessage` (spec §10.6 — too-many-failed-attempts skip).
     * The pending session must be committed via the FlowCoordinator on
     * "Continue".
     */
    data class SkipNotice(
        val pendingSession: Session,
        val message: String,
    ) : OtpSendResult

    /**
     * Generic failure (network, 4xx other than the skip case, 5xx).
     * The backend's `error.message` is preferred when present, else the
     * spec's default `"Could not send code. Please try again."`.
     */
    data class Failure(
        val displayMessage: String,
    ) : OtpSendResult

    /** HTTP 404 — escalate to the global SessionNotFound error screen. */
    data object SessionNotFound : OtpSendResult
}

/**
 * Outcome of an OTP-verify call. Distinguishes the two error dialogs
 * the spec calls out (`expired` 410, `invalid` 422) from generic
 * failures and the skip-notice flow.
 */
internal sealed interface OtpVerifyResult {
    /** Verify succeeded; returned session is the new step / status. */
    data class Advanced(
        val session: Session,
    ) : OtpVerifyResult

    /** HTTP 410 — code expired. Spec §10.5 → "Code expired" dialog. */
    data object Expired : OtpVerifyResult

    /** HTTP 422 — code invalid. Spec §10.5 → "Incorrect code" dialog. */
    data object Invalid : OtpVerifyResult

    /** Skip-notice rotation (spec §10.6). */
    data class SkipNotice(
        val pendingSession: Session,
        val message: String,
    ) : OtpVerifyResult

    /** Other errors — surfaces inline as kyc-notice. */
    data class Failure(
        val displayMessage: String,
    ) : OtpVerifyResult

    /** HTTP 404 — escalate to the global SessionNotFound error screen. */
    data object SessionNotFound : OtpVerifyResult
}
