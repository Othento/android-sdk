@file:Suppress(
    "TooManyFunctions",
    "LongMethod",
    "LargeClass",
    "ReturnCount",
    "CyclomaticComplexMethod",
)

package com.othento.core.internal.flow

import android.net.Uri
import com.othento.core.internal.capture.SelfieKind
import com.othento.core.internal.capture.detection.DocKind
import com.othento.core.internal.capture.detection.ValidationWarning
import com.othento.core.internal.capture.selfieKind
import com.othento.core.internal.data.DocumentRepository
import com.othento.core.internal.data.OtpRepository
import com.othento.core.internal.data.OtpSendResult
import com.othento.core.internal.data.OtpVerifyResult
import com.othento.core.internal.data.SessionRepository
import com.othento.core.internal.data.UploadProgress
import com.othento.core.internal.data.UploadRepository
import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.data.model.ChallengeType
import com.othento.core.internal.data.model.Decision
import com.othento.core.internal.data.model.OtpChannel
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.data.model.SessionStatus
import com.othento.core.internal.network.OthentoNetworkException
import com.othento.core.internal.network.ErrorMapper
import com.othento.core.internal.ui.screens.Side
import com.othento.core.internal.util.ImageInfo
import com.othento.core.api.OthentoCancelReason
import com.othento.core.api.OthentoConfig
import com.othento.core.api.OthentoDecision
import com.othento.core.api.OthentoError
import com.othento.core.api.OthentoMode
import com.othento.core.api.OthentoSDKListener
import com.othento.core.api.OthentoSessionStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Phase-5 evolution of Phase 4's FlowCoordinator.
 *
 * Owns the [FlowUiState] the Compose host renders and the listener-callback
 * surface from spec [docs/spec/16-host-events-and-callbacks.md] §4. Phase 5
 * adds action methods that drive the document-side flow.
 *
 * **Async model.** Action methods are split by their concurrency needs:
 * - Sync actions (`onUserCountrySelected`, `onUserConfirmDocument`,
 *   `onUserChangeDocument`, `onUserRetake`) only mutate state.
 * - `suspend` actions (`beginVerification`, `retryFailed`, `uploadAndAdvance`,
 *   `startPolling`) drive the long-running coroutines. Callers (the ViewModel)
 *   own job lifecycles via `viewModelScope` — back-press cancels everything.
 *
 * Spec callback ordering (unchanged from Phase 4):
 *   1. `onReady()` — first, always.
 *   2. `onSessionCreated(externalId, sessionUrl)` — after a successful resolve.
 *   3. `onStatusChanged(status)` — deduped against the last broadcast value.
 *   4. `onError(error, displayMessage)` — only on resolve / network failure.
 *   5. `onCancelled(reason)` — only on user dismissal / host destroy before a terminal screen.
 *   6. `onCompleted(decision, externalId)` — fires on the first
 *      Completed + non-null decision (closes F4 in `99-open-questions.md`).
 */
@Suppress("LongParameterList")
internal class FlowCoordinator(
    private val config: OthentoConfig,
    private val listener: OthentoSDKListener,
    private val sessionSource: SessionSource,
    private val stepDispatcher: CoroutineDispatcher,
    private val documentRepository: DocumentRepository,
    private val uploadRepository: UploadRepository,
    private val pollingDriver: PollingDriver,
    private val otpRepository: OtpRepository? = null,
    // Used only by the retry auto-initiate path (`retryWithAutoInitiate`) to
    // hit `/reinitiate` directly without going through the upload pipeline.
    // Optional so fixture-mode / unit-test builders can omit it and fall back
    // to the document-select retry path.
    private val sessionRepository: SessionRepository? = null,
    private val sessionConfig: SessionConfig = SessionConfig.Default,
    private val loadingMinDelayMs: Long = LOADING_MIN_DELAY_MS,
    private val nowProvider: () -> Long = { System.currentTimeMillis() },
) {
    private val internalState = MutableStateFlow(FlowUiState.Loading)
    val state: StateFlow<FlowUiState> = internalState.asStateFlow()
    private val otpStore = OtpStateStore()

    private var lastBroadcastStatus: OthentoSessionStatus? = null
    private var hasEmittedReady = false
    private var hasEmittedCancel = false
    private var hasEmittedError = false
    private var hasEmittedCompleted = false

    /**
     * Runs the resolve sequence end-to-end and chains into polling /
     * post-resolve work as needed. Returns when the flow lands on a state
     * that requires user action (or stays as Processing after polling
     * times out).
     */
    suspend fun resolve() {
        withContext(stepDispatcher) {
            emitReadyOnce()
            // Hold the loading state for a short minimum so the user sees
            // the skeleton even when the source returns synchronously
            // (Phase-4 fixtures resolve in ~zero time). Logged as Q1.
            delay(loadingMinDelayMs)
            when (val result = sessionSource.resolveSession(config)) {
                is SessionResolveResult.Ok -> applyResolved(result.session)
                is SessionResolveResult.Failure -> applyFailure(result)
            }
            // Auto-chain into polling when the resolved screen is Processing.
            if (state.value.screenState == ScreenState.Processing) {
                runPolling(
                    initialStepId =
                        state.value.session
                            ?.currentStep
                            ?.attemptStepId,
                )
            }
        }
    }

    /**
     * Cancels the running flow and fires `onCancelled(reason)` exactly once.
     * No-op after a terminal screen (terminal listener events win).
     */
    fun cancel(reason: OthentoCancelReason) {
        if (hasEmittedCancel) return
        if (state.value.screenState.isTerminal) return
        emitReadyOnce()
        hasEmittedCancel = true
        listener.onCancelled(reason)
    }

    // ---- Sync actions (state-only) ---------------------------------------

    fun onUserCountrySelected(countryName: String) {
        if (state.value.screenState != ScreenState.DocumentSelect) return
        update { it.copy(selectedCountryName = countryName, selectedDocumentId = null) }
    }

    fun onUserDocumentSelected(documentId: String) {
        if (state.value.screenState != ScreenState.DocumentSelect) return
        update { it.copy(selectedDocumentId = documentId) }
    }

    // Three early-out guards (wrong screen / no docId selected / id not in list); each is a distinct
    // precondition the caller could violate.
    @Suppress("ReturnCount")
    fun onUserConfirmDocument() {
        val current = state.value
        if (current.screenState != ScreenState.DocumentSelect) return
        val docId = current.selectedDocumentId ?: return
        val doc = current.documents?.firstOrNull { it.documentId == docId } ?: return
        // Move directly to CaptureFront; the upload pipeline (which kicks
        // off `initiate`) fires when the user picks a file and taps
        // Continue. Mirrors the web's pendingDocument → capture_front
        // transition without auto-uploading.
        update {
            it.copy(
                screenState = ScreenState.CaptureFront,
                pendingDocument = doc,
                oversizedFile = false,
                uploadProgress = null,
            )
        }
    }

    fun onUserChangeDocument() {
        if (state.value.screenState != ScreenState.CaptureFront) return
        update {
            it.copy(
                screenState = ScreenState.DocumentSelect,
                pendingDocument = null,
                oversizedFile = false,
                useFallback = false,
            )
        }
    }

    /**
     * Phase 6 — flip the renderer for the current capture screen from the
     * camera HUD to [com.othento.core.internal.ui.screens.CaptureFallbackScreen].
     * Reachable via the HUD's "Upload" button and from the permission /
     * unavailable / timeout error UIs.
     */
    fun onUserSwitchToFallback() {
        val current = state.value.screenState
        if (current != ScreenState.CaptureFront && current != ScreenState.CaptureBack) return
        update { it.copy(useFallback = true, oversizedFile = false, fileUnreadable = false) }
    }

    /**
     * Sets the pending-capture slot to a fresh "validating" entry. Called by the
     * ViewModel right after the user picks a file and `ImageInfo.resolve`
     * succeeds. The ViewModel kicks off validation on `Dispatchers.Default` and
     * later calls [updatePendingCaptureWarnings] with the result.
     */
    fun setPendingCapture(
        uri: Uri,
        info: ImageInfo.Resolved,
        side: Side,
        docKind: DocKind,
        isManualCapture: Boolean = false,
    ) {
        val pc = PendingCapture(uri, info, side, docKind, isValidating = true, warnings = emptyList(), isManualCapture = isManualCapture)
        internalState.value = state.value.copy(pendingCapture = pc)
    }

    /**
     * Updates the in-flight pending capture with validator output. No-ops if the
     * pending capture has been cleared in the meantime (e.g. user pressed
     * Re-upload before validation finished).
     */
    fun updatePendingCaptureWarnings(warnings: List<ValidationWarning>) {
        val current = state.value
        val pc = current.pendingCapture ?: return
        internalState.value =
            current.copy(
                pendingCapture = pc.copy(isValidating = false, warnings = warnings),
            )
    }

    /** Clears the pending-capture slot. Used by Re-upload + after Confirm-then-upload. */
    fun clearPendingCapture() {
        val current = state.value
        if (current.pendingCapture == null) return
        internalState.value = current.copy(pendingCapture = null)
    }

    /** Phase 6 — flip the renderer back to the camera HUD. */
    fun onUserStayOnCamera() {
        val current = state.value.screenState
        if (current != ScreenState.CaptureFront && current != ScreenState.CaptureBack) return
        update { it.copy(useFallback = false) }
    }

    fun onUserRetake() {
        update { it.copy(oversizedFile = false, fileUnreadable = false) }
    }

    /**
     * Surfaced when [com.othento.core.internal.util.ImageInfo.resolve] returns
     * `null` — usually a `content://` URI whose `OpenableColumns.SIZE` was
     * null (Google Photos and a few file managers can do this). Renders
     * inline on the capture screen alongside [oversizedFile].
     */
    fun onFileUnreadable() {
        update { it.copy(fileUnreadable = true) }
    }

    /** Surfaced when the picked file exceeds [ImageInfo.MAX_UPLOAD_SIZE_BYTES] (10 MB). */
    fun onOversizedFile() {
        update { it.copy(oversizedFile = true) }
    }

    // ---- Suspend actions (drive long-running coroutines) -----------------

    /**
     * Start CTA on the [ScreenState.Start] screen. Fetches the documents
     * list, transitions to [ScreenState.DocumentSelect], and short-circuits
     * to [ScreenState.CaptureFront] when the backend returns exactly one
     * doc (matches the web's `if (docs.length === 1) emit(...)` shortcut).
     */
    suspend fun beginVerification() {
        if (state.value.screenState != ScreenState.Start) return
        loadDocuments()
    }

    /**
     * `Try Again` CTA on [ScreenState.FailedRetry]. Mirrors the web's
     * `verify.ts#onRetryFailed`:
     * - If the document step is among the steps to redo (backend
     *   `reinitInfo.stepsToRetry`, or the first step when `reinitInfo` is
     *   absent) the user re-picks the document → [ScreenState.DocumentSelect].
     *   The subsequent front upload reinitiates rather than initiates (see
     *   [runUploadPipeline]).
     * - Otherwise the prior document is reused and we reinitiate directly via
     *   [retryWithAutoInitiate], landing the user on the failed non-ID step.
     */
    suspend fun retryFailed() {
        if (state.value.screenState != ScreenState.FailedRetry) return
        val session = state.value.session ?: return retryViaDocumentSelect()

        val stepsToRetry = session.reinitInfo?.stepsToRetry
        val needsId =
            if (stepsToRetry != null) {
                stepsToRetry.any { it.stepCode == ScreenResolver.STEP_ID_VERIFICATION }
            } else {
                session.steps.firstOrNull()?.stepCode == ScreenResolver.STEP_ID_VERIFICATION
            }

        val documentId = session.selectedDocument?.id
        if (needsId || documentId == null) {
            retryViaDocumentSelect()
        } else {
            retryWithAutoInitiate(documentId)
        }
    }

    private suspend fun retryViaDocumentSelect() {
        documentRepository.reset()
        loadDocuments()
    }

    /**
     * No-ID-repick retry: reinitiate with the previously selected document and
     * route to whichever step the backend reopens. Falls back to the
     * document-select path when no [SessionRepository] is wired (fixture mode).
     */
    private suspend fun retryWithAutoInitiate(documentId: String) {
        val repo = sessionRepository ?: return retryViaDocumentSelect()
        update { it.copy(screenState = ScreenState.Loading) }
        try {
            routeReinitiated(repo.reinitiateSession(documentId))
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: OthentoNetworkException) {
            applyFailure(
                SessionResolveResult.Failure(
                    error = e.error,
                    displayMessage = e.displayMessage,
                ),
            )
        }
    }

    /**
     * Routes a reinitiated session through the standard
     * [ScreenResolver] / status-broadcast / terminal hand-off, mirroring
     * [applyPostPoll] so a retry transition looks identical to any other.
     */
    private suspend fun routeReinitiated(session: Session) {
        emitStatusDeduped(session.status.toPublic())
        val nextScreen = ScreenResolver.resolve(session)
        update {
            it.copy(
                screenState = nextScreen,
                session = session,
                pendingDocument = null,
                otp = otpStateForScreen(nextScreen, session, prevOtp = null),
            )
        }
        when {
            nextScreen.isTerminal -> broadcastTerminal(session)
            nextScreen == ScreenState.Processing ->
                runPolling(initialStepId = session.currentStep?.attemptStepId)
            else -> Unit
        }
    }

    /**
     * Upload pipeline. Reads the side from the current screen state and
     * branches into front (initiate + upload), back (upload-only), or
     * Phase 7 selfie (upload-only against the face-match step). After the
     * post-upload session lands the coordinator routes via [ScreenResolver]
     * and chains into polling if Processing.
     */
    suspend fun uploadAndAdvance(
        uri: Uri,
        info: ImageInfo.Resolved,
        isManualCapture: Boolean = false,
    ) {
        if (info.sizeBytes > ImageInfo.MAX_UPLOAD_SIZE_BYTES) {
            update { it.copy(oversizedFile = true) }
            return
        }
        val side = state.value.screenState
        if (side != ScreenState.CaptureFront &&
            side != ScreenState.CaptureBack &&
            side != ScreenState.SelfieCapture
        ) {
            return
        }
        update { it.copy(uploadProgress = 0, uploadHint = UploadHint.None, oversizedFile = false) }
        coroutineScope {
            val hintJob = launch { runUploadHints() }
            try {
                runUploadPipeline(uri, info, side, isManualCapture)
            } finally {
                hintJob.cancel()
            }
        }
    }

    // ---- OTP actions (Phase 9) -------------------------------------------

    /**
     * Sends an OTP to [contact]. Routes the result through the screen's
     * inline error / skip-notice / cooldown timer state. Mirrors the web
     * SDK's `OtpFlowController.send` (`apps/sdk/.../otp-flow-controller.service.ts`).
     */
    suspend fun sendOtp(contact: String) {
        val repo = otpRepository ?: return
        val current = state.value
        val otp = current.otp ?: return
        val attemptStepId = current.session?.currentStep?.attemptStepId ?: return
        update { it.copy(otp = otp.copy(sendInFlight = true, sendError = null)) }
        when (val result = repo.sendOtp(attemptStepId = attemptStepId, contact = contact)) {
            is OtpSendResult.Sent -> applyOtpAfterSend(session = result.session, contact = contact)
            is OtpSendResult.Failure ->
                update {
                    it.copy(
                        otp =
                            otp.copy(
                                sendInFlight = false,
                                sendError = OtpSendErrorMapper.resolveNotice(result.displayMessage),
                            ),
                    )
                }
            is OtpSendResult.SkipNotice ->
                update {
                    it.copy(
                        otp =
                            otp.copy(
                                sendInFlight = false,
                                skipNotice = OtpUiState.SkipNotice(result.pendingSession, result.message),
                            ),
                    )
                }
            OtpSendResult.SessionNotFound -> applySessionNotFoundFromOtp()
        }
    }

    /**
     * Verifies the user's typed [code] against the active OTP step.
     * Branches on [OtpVerifyResult] per spec §10.5 / §10.6.
     */
    suspend fun verifyOtp(code: String) {
        val repo = otpRepository ?: return
        val current = state.value
        val otp = current.otp ?: return
        val attemptStepId = current.session?.currentStep?.attemptStepId ?: return
        update {
            it.copy(
                otp =
                    otp.copy(
                        verifyInFlight = true,
                        verifyError = null,
                        verifyErrorKind = null,
                    ),
            )
        }
        when (val result = repo.verifyOtp(attemptStepId = attemptStepId, code = code)) {
            is OtpVerifyResult.Advanced -> applyOtpAfterVerify(result.session)
            OtpVerifyResult.Expired ->
                update {
                    it.copy(otp = otp.copy(verifyInFlight = false, verifyErrorKind = OtpVerifyErrorKind.Expired))
                }
            OtpVerifyResult.Invalid ->
                update {
                    it.copy(otp = otp.copy(verifyInFlight = false, verifyErrorKind = OtpVerifyErrorKind.Invalid))
                }
            is OtpVerifyResult.Failure ->
                update {
                    it.copy(otp = otp.copy(verifyInFlight = false, verifyError = result.displayMessage))
                }
            is OtpVerifyResult.SkipNotice ->
                update {
                    it.copy(
                        otp =
                            otp.copy(
                                verifyInFlight = false,
                                skipNotice = OtpUiState.SkipNotice(result.pendingSession, result.message),
                            ),
                    )
                }
            OtpVerifyResult.SessionNotFound -> applySessionNotFoundFromOtp()
        }
    }

    private fun applySessionNotFoundFromOtp() {
        applyFailure(
            SessionResolveResult.Failure(
                error = OthentoError.SessionNotFound,
                displayMessage = ErrorMapper.NOT_FOUND_BODY,
                httpStatus = ErrorMapper.HTTP_NOT_FOUND,
            ),
        )
    }

    /** Tap on "Change phone/email" link in the code-entry layout. */
    fun onUserEditOtpDestination() {
        val otp = state.value.otp ?: return
        if (otp.sendInFlight || otp.verifyInFlight) return
        update { it.copy(otp = otp.copy(editing = true, sendError = null)) }
    }

    /** Tap on "Cancel" link in the destination-entry edit-mode layout. */
    fun onUserCancelOtpEdit() {
        val otp = state.value.otp ?: return
        if (otp.sendInFlight) return
        // Only cancel back to code-entry if there was a prior successful send.
        if (otp.lastContact == null) return
        update { it.copy(otp = otp.copy(editing = false, sendError = null)) }
    }

    /** Dismiss button on either error dialog (no re-send). */
    fun onUserDismissOtpDialog() {
        val otp = state.value.otp ?: return
        update { it.copy(otp = otp.copy(verifyErrorKind = null, verifyError = null)) }
    }

    /**
     * Dialog primary CTA. For Expired → re-issue a send to lastContact;
     * for Invalid → just dismiss + clear (the screen also clears the
     * code input). Spec §10.5.
     */
    suspend fun onUserOtpDialogPrimary() {
        val otp = state.value.otp ?: return
        when (otp.verifyErrorKind) {
            OtpVerifyErrorKind.Expired -> {
                val contact = otp.lastContact ?: return
                update { it.copy(otp = otp.copy(verifyErrorKind = null, verifyError = null)) }
                sendOtp(contact)
            }
            OtpVerifyErrorKind.Invalid ->
                update { it.copy(otp = otp.copy(verifyErrorKind = null, verifyError = null)) }
            null -> Unit
        }
    }

    /** Tap on "Continue" in the skip-notice sheet — commit the rotated session. */
    suspend fun onUserAcknowledgeOtpSkipNotice() {
        val otp = state.value.otp ?: return
        val pending = otp.skipNotice?.pendingSession ?: return
        update { it.copy(otp = otp.copy(skipNotice = null, sendInFlight = false, verifyInFlight = false)) }
        applyOtpCommit(pending)
    }

    /**
     * 1 Hz tick from the OTP screen's `LaunchedEffect`. Re-snapshots the
     * cooldown timer and re-emits state so the resend label updates.
     */
    fun tickOtpCooldown() {
        val otp = state.value.otp ?: return
        val snapshot = otpStore.snapshot(nowProvider())
        update {
            it.copy(
                otp =
                    otp.copy(
                        cooldownRemainingSec = snapshot.cooldownRemainingSec,
                        isExpired = snapshot.isExpired,
                        canResend = snapshot.canResend,
                        lastContact = snapshot.lastContact,
                    ),
            )
        }
    }

    /** `Try again` CTA on the timed-out [ScreenState.Processing] variant. */
    suspend fun pollRetry() {
        if (state.value.screenState != ScreenState.Processing) return
        if (!state.value.pollTimedOut) return
        update { it.copy(pollTimedOut = false) }
        runPolling(
            initialStepId =
                state.value.session
                    ?.currentStep
                    ?.attemptStepId,
        )
    }

    // ---- Internal: document fetching -------------------------------------

    private suspend fun loadDocuments() {
        update {
            it.copy(
                screenState = ScreenState.DocumentSelect,
                documentsLoading = true,
                documentsError = null,
                pendingDocument = null,
                selectedDocumentId = null,
            )
        }
        try {
            val docs = documentRepository.getDocuments()
            handleDocumentsLoaded(docs)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: OthentoNetworkException) {
            update { it.copy(documentsLoading = false, documentsError = e.displayMessage) }
        }
    }

    private fun handleDocumentsLoaded(docs: List<AcceptedDocument>) {
        val firstCountry = docs.map { it.countryName }.minOrNull()
        if (docs.size == 1) {
            update {
                it.copy(
                    screenState = ScreenState.CaptureFront,
                    documentsLoading = false,
                    documents = docs,
                    selectedCountryName = docs[0].countryName,
                    selectedDocumentId = docs[0].documentId,
                    pendingDocument = docs[0],
                )
            }
            return
        }
        update {
            it.copy(
                documentsLoading = false,
                documents = docs,
                documentsError = null,
                selectedCountryName = firstCountry,
                selectedDocumentId = null,
            )
        }
    }

    // ---- Internal: upload pipeline ---------------------------------------

    @Suppress("ReturnCount")
    private suspend fun runUploadPipeline(
        uri: Uri,
        info: ImageInfo.Resolved,
        side: ScreenState,
        isManualCapture: Boolean = false,
    ) {
        try {
            val manualCapture = isManualCapture
            val flow =
                when (side) {
                    ScreenState.CaptureFront -> {
                        val docId = state.value.pendingDocument?.documentId ?: return
                        // A `Failed` + retryable session still in state means the
                        // user reached the document picker via "Try Again"; the
                        // backend rejects `initiate` on such a session, so open the
                        // front step via `reinitiate` instead. Mirrors the web's
                        // `TokenSessionFlowService.initiateAndUploadFront`.
                        val prev = state.value.session
                        val isRetry =
                            prev?.status == SessionStatus.Failed &&
                                (prev.canReinitiate || prev.canInitiate)
                        uploadRepository.initiateAndUploadFront(
                            documentId = docId,
                            uri = uri,
                            info = info,
                            isManualCapture = manualCapture,
                            isRetry = isRetry,
                        )
                    }
                    ScreenState.CaptureBack -> {
                        val attemptStepId =
                            state.value.session
                                ?.currentStep
                                ?.attemptStepId ?: return
                        uploadRepository.uploadBack(
                            attemptStepId = attemptStepId,
                            uri = uri,
                            info = info,
                            isManualCapture = manualCapture,
                        )
                    }
                    ScreenState.SelfieCapture -> {
                        val session = state.value.session ?: return
                        val attemptStepId = session.currentStep?.attemptStepId ?: return
                        when (session.selfieKind) {
                            SelfieKind.Liveness ->
                                uploadRepository.uploadLivenessVideo(
                                    attemptStepId = attemptStepId,
                                    uri = uri,
                                    info = info,
                                    isManualCapture = manualCapture,
                                )
                            SelfieKind.FaceMatch ->
                                uploadRepository.uploadSelfie(
                                    attemptStepId = attemptStepId,
                                    uri = uri,
                                    info = info,
                                    isManualCapture = manualCapture,
                                )
                            null -> return
                        }
                    }
                    else -> return
                }
            flow.collect { progress ->
                when (progress) {
                    is UploadProgress.InProgress -> update { it.copy(uploadProgress = progress.percent) }
                    is UploadProgress.Done -> applyPostUpload(progress.session)
                }
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: OthentoNetworkException) {
            applyUploadFailure(e)
        }
    }

    private suspend fun applyPostUpload(session: Session) {
        update { it.copy(uploadProgress = null, uploadHint = UploadHint.None) }
        emitStatusDeduped(session.status.toPublic())
        val nextScreen = ScreenResolver.resolve(session)
        update {
            it.copy(
                screenState = nextScreen,
                session = session,
                pendingDocument = if (nextScreen == ScreenState.CaptureBack) it.pendingDocument else null,
                otp = otpStateForScreen(nextScreen, session, prevOtp = it.otp),
            )
        }
        when {
            nextScreen.isTerminal -> broadcastTerminal(session)
            nextScreen == ScreenState.Processing ->
                runPolling(initialStepId = session.currentStep?.attemptStepId)
            else -> Unit
        }
    }

    private fun applyUploadFailure(e: OthentoNetworkException) {
        // Reset the stale doc-state so a re-launch (host calls `OthentoSDK.launch`
        // again from the host's error UI) doesn't carry the previous
        // pendingDocument forward. The full-replacement shape mirrors
        // `applyResolved`'s success path.
        update {
            FlowUiState(
                screenState = ScreenState.Error,
                session = null,
                error = e.error,
                displayMessage = e.displayMessage,
                errorHttpStatus = (e.error as? OthentoError.UploadFailed)?.httpStatus,
            )
        }
        if (!hasEmittedError) {
            hasEmittedError = true
            listener.onError(e.error, e.displayMessage)
        }
    }

    private suspend fun runUploadHints() {
        delay(sessionConfig.almostDoneDelayMs)
        if (state.value.uploadProgress == null) return
        update { it.copy(uploadHint = UploadHint.AlmostDone) }
        delay(sessionConfig.takingLongerDelayMs - sessionConfig.almostDoneDelayMs)
        if (state.value.uploadProgress == null) return
        update { it.copy(uploadHint = UploadHint.TakingLonger) }
    }

    // ---- Internal: polling -----------------------------------------------

    private suspend fun runPolling(initialStepId: String?) {
        try {
            val result = pollingDriver.startPolling(initialStepId)
            handlePollResult(result)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (_: OthentoNetworkException) {
            // Per spec [12-processing.md] the timed-out / failed-poll UX is
            // identical: flip the warning variant and let the user tap Try
            // Again. The wire failure isn't surfaced through onError.
            update { it.copy(pollTimedOut = true) }
        }
    }

    private suspend fun handlePollResult(result: PollingResult) {
        when (result.outcome) {
            PollingOutcome.TimedOut, PollingOutcome.Continue -> update { it.copy(pollTimedOut = true) }
            PollingOutcome.StepCompleted,
            PollingOutcome.StepFailed,
            PollingOutcome.StepAdvanced,
            PollingOutcome.SessionCompleted,
            PollingOutcome.SessionFailed,
            -> applyPostPoll(result.session)
        }
    }

    private suspend fun applyPostPoll(session: Session) {
        emitStatusDeduped(session.status.toPublic())
        val nextScreen = ScreenResolver.resolve(session)
        update {
            it.copy(
                screenState = nextScreen,
                session = session,
                pollTimedOut = false,
                otp = otpStateForScreen(nextScreen, session, prevOtp = it.otp),
            )
        }
        when {
            nextScreen.isTerminal -> broadcastTerminal(session)
            nextScreen == ScreenState.Processing ->
                runPolling(initialStepId = session.currentStep?.attemptStepId)
            else -> Unit
        }
    }

    /**
     * Phase 9 — applies the new session after a successful OTP send.
     * Records the cooldown record in [OtpStateStore], flips the screen
     * to code-entry, refreshes the OTP UI state.
     *
     * `Challenge.otpExpiresAt` is parsed via the same ISO-8601 helper
     * the token-store uses for its expiry check (`TokenStore.parseIso8601Utc`)
     * — minSdk 24 doesn't ship `java.time.Instant`, but a tiny
     * Calendar-based parse is enough for the wire shape the backend
     * sends. Falls back to the spec's default 10-minute expiry on parse
     * failure / null.
     */
    private fun applyOtpAfterSend(
        session: Session,
        contact: String,
    ) {
        val attemptStepId = session.currentStep?.attemptStepId
        val challenge = session.activeOtpChallenge()
        val cooldown = OtpStateStore.DEFAULT_COOLDOWN_SEC
        val now = nowProvider()
        val expiresAt =
            challenge
                ?.otpExpiresAt
                ?.let {
                    com.othento.core.internal.network.TokenStore
                        .parseIso8601Utc(it)
                }
                ?: (now + OtpStateStore.DEFAULT_EXPIRY_SEC * MS_PER_SEC)
        if (attemptStepId != null) {
            otpStore.recordSendSuccess(
                attemptStepId = attemptStepId,
                contact = contact,
                sendAt = now,
                cooldownSec = cooldown,
                expiresAtMs = expiresAt,
            )
        }
        val snapshot = otpStore.snapshot(now)
        val current = state.value.otp
        update {
            it.copy(
                session = session,
                otp =
                    (current ?: defaultOtpUiState(it.screenState)).copy(
                        editing = false,
                        sendInFlight = false,
                        sendError = null,
                        cooldownRemainingSec = snapshot.cooldownRemainingSec,
                        isExpired = snapshot.isExpired,
                        canResend = snapshot.canResend,
                        lastContact = contact,
                        codeLength = challenge?.otpSize ?: OtpUiState.DEFAULT_OTP_LENGTH,
                        alphanumeric = challenge?.otpAlphanumeric ?: false,
                        corporateEmailOnly = challenge?.corporateEmailOnly ?: false,
                    ),
            )
        }
    }

    /**
     * Verify-success path. Routes through the standard
     * [ScreenResolver] / status-broadcast / terminal hand-off so OTP
     * → next-step transitions look identical to upload → next-step.
     */
    private suspend fun applyOtpAfterVerify(session: Session) {
        applyOtpCommit(session)
    }

    /**
     * Used by both verify-success and skip-notice acknowledged. Routes
     * the new session through the standard screen-resolver path so the
     * verification flow stays uniform across phases.
     */
    private suspend fun applyOtpCommit(session: Session) {
        emitStatusDeduped(session.status.toPublic())
        val nextScreen = ScreenResolver.resolve(session)
        // Channel rotation: if the new screen is a different OTP step,
        // wipe the prior cooldown record so the user doesn't see a
        // pre-filled "Resend in 23s" on the new step.
        val newAttemptStepId = session.currentStep?.attemptStepId
        if (newAttemptStepId != null) otpStore.resetForStep(newAttemptStepId)
        update {
            it.copy(
                screenState = nextScreen,
                session = session,
                otp = otpStateForScreen(nextScreen, session, prevOtp = null),
            )
        }
        when {
            nextScreen.isTerminal -> broadcastTerminal(session)
            nextScreen == ScreenState.Processing ->
                runPolling(initialStepId = session.currentStep?.attemptStepId)
            else -> Unit
        }
    }

    /**
     * Returns an [OtpUiState] when the next screen is `OtpPhone` or
     * `OtpEmail`, else null. Carries forward most of [prevOtp] when the
     * screen stays on the same OTP step (cooldown alive); otherwise
     * builds a fresh empty record for the new channel.
     */
    @Suppress("ReturnCount")
    private fun otpStateForScreen(
        screen: ScreenState,
        session: Session,
        prevOtp: OtpUiState?,
    ): OtpUiState? {
        if (screen != ScreenState.OtpPhone && screen != ScreenState.OtpEmail) return null
        val channel = if (screen == ScreenState.OtpPhone) OtpChannel.Phone else OtpChannel.Email
        val challenge = session.activeOtpChallenge()
        val attemptStepId = session.currentStep?.attemptStepId
        if (attemptStepId != null) otpStore.resetForStep(attemptStepId)
        val snapshot = otpStore.snapshot(nowProvider())
        val carry = prevOtp?.takeIf { it.channel == channel }
        return OtpUiState(
            channel = channel,
            editing = carry?.editing ?: (snapshot.lastContact == null),
            sendInFlight = false,
            verifyInFlight = false,
            sendError = null,
            verifyError = null,
            verifyErrorKind = null,
            skipNotice = null,
            cooldownRemainingSec = snapshot.cooldownRemainingSec,
            isExpired = snapshot.isExpired,
            canResend = snapshot.canResend,
            lastContact = snapshot.lastContact,
            codeLength = challenge?.otpSize ?: OtpUiState.DEFAULT_OTP_LENGTH,
            alphanumeric = challenge?.otpAlphanumeric ?: false,
            corporateEmailOnly = challenge?.corporateEmailOnly ?: false,
        )
    }

    private fun defaultOtpUiState(screen: ScreenState): OtpUiState =
        OtpUiState(
            channel = if (screen == ScreenState.OtpEmail) OtpChannel.Email else OtpChannel.Phone,
            editing = true,
        )

    private fun Session.activeOtpChallenge() =
        currentStep?.challenges?.firstOrNull {
            it.challengeType == ChallengeType.PhoneOtp || it.challengeType == ChallengeType.EmailOtp
        }

    // ---- Internal: state + listener helpers ------------------------------

    private fun emitReadyOnce() {
        if (hasEmittedReady) return
        hasEmittedReady = true
        listener.onReady()
    }

    private fun applyResolved(session: Session) {
        // Guard against the race where back-press fires `onCancelled` while
        // the resolve coroutine is still inside its non-suspending tail.
        // Spec §16 §1.1 requires `onCancelled` to be the last listener event.
        if (hasEmittedCancel) return
        // `onSessionCreated` is contract-bound to `OthentoMode.Create` only —
        // token-mode launches load an existing session and must not fire it.
        if (config.mode is OthentoMode.Create && session.status.isFreshlyCreated) {
            listener.onSessionCreated(session.externalId, session.sessionUrl)
        }
        emitStatusDeduped(session.status.toPublic())
        val resolvedScreen = ScreenResolver.resolve(session)
        if (resolvedScreen == ScreenState.Error &&
            session.status == SessionStatus.Completed &&
            session.decision == null
        ) {
            applyFailure(
                SessionResolveResult.Failure(
                    error = OthentoError.Unknown(NULL_DECISION_MESSAGE),
                    displayMessage = NULL_DECISION_MESSAGE,
                ),
            )
            return
        }
        update {
            FlowUiState(
                screenState = resolvedScreen,
                session = session,
                error = null,
                displayMessage = null,
                errorHttpStatus = null,
                otp = otpStateForScreen(resolvedScreen, session, prevOtp = null),
            )
        }
        if (resolvedScreen.isTerminal) {
            broadcastTerminal(session)
        }
    }

    private fun applyFailure(failure: SessionResolveResult.Failure) {
        if (hasEmittedCancel) return
        update {
            FlowUiState(
                screenState = ScreenState.Error,
                session = null,
                error = failure.error,
                displayMessage = failure.displayMessage,
                errorHttpStatus = failure.httpStatus,
            )
        }
        if (!hasEmittedError) {
            hasEmittedError = true
            listener.onError(failure.error, failure.displayMessage)
        }
    }

    private fun emitStatusDeduped(status: OthentoSessionStatus) {
        if (hasEmittedCancel) return
        if (status != lastBroadcastStatus) {
            listener.onStatusChanged(status)
            lastBroadcastStatus = status
        }
    }

    private fun broadcastTerminal(session: Session) {
        if (hasEmittedCompleted) return
        if (hasEmittedCancel) return
        if (session.status == SessionStatus.Completed && session.decision != null) {
            hasEmittedCompleted = true
            listener.onCompleted(session.decision.toPublic(), session.externalId)
        }
    }

    private inline fun update(transform: (FlowUiState) -> FlowUiState) {
        internalState.value = transform(internalState.value)
    }

    private companion object {
        const val LOADING_MIN_DELAY_MS = 250L
        const val NULL_DECISION_MESSAGE =
            "Verification reached a Completed status without a decision."
        const val MS_PER_SEC: Long = 1000L
    }
}

/**
 * Whether a session resolved to this status represents a "fresh from create"
 * launch — the only kind for which spec §16 §1.2 says `onSessionCreated`
 * should fire.
 */
internal val SessionStatus.isFreshlyCreated: Boolean
    get() =
        this == SessionStatus.Created ||
            this == SessionStatus.InProgress ||
            this == SessionStatus.Processing

internal fun SessionStatus.toPublic(): OthentoSessionStatus =
    when (this) {
        SessionStatus.Created -> OthentoSessionStatus.Created
        SessionStatus.InProgress -> OthentoSessionStatus.InProgress
        SessionStatus.Processing -> OthentoSessionStatus.Processing
        SessionStatus.Completed -> OthentoSessionStatus.Completed
        SessionStatus.Expired -> OthentoSessionStatus.Expired
        SessionStatus.Failed -> OthentoSessionStatus.Failed
    }

internal fun Decision.toPublic(): OthentoDecision =
    when (this) {
        Decision.Approved -> OthentoDecision.Approved
        Decision.Declined -> OthentoDecision.Declined
        Decision.InReview -> OthentoDecision.InReview
    }
