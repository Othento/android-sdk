package com.othento.core.internal.network

import com.squareup.moshi.Moshi
import com.othento.core.BuildConfig
import com.othento.core.internal.data.model.ActiveStepStatus
import com.othento.core.internal.data.model.ChallengeStatus
import com.othento.core.internal.data.model.ChallengeType
import com.othento.core.internal.data.model.SessionStatus
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Assembles the SDK's HTTP stack: OkHttp client (apiKey + token interceptors,
 * debug-only logging), Moshi instance, Retrofit binding for [OthentoApi].
 *
 * Per spec [10-network-layer.md §3.2/§3.3] the SDK sets **no per-request
 * timeout and no automatic retry** — failures propagate to the caller.
 *
 * Phase 5 attaches the [TokenInterceptor] alongside the apiKey one. Each
 * launch passes its own [TokenStore] so concurrent launches stay isolated.
 *
 * Logging is enabled in debug builds, or in release when the host opts in via
 * `OthentoConfig.loggingEnabled` — so production never logs request bodies
 * unless explicitly requested. When enabled, the level is `BODY` and every
 * auth header is redacted by name.
 */
internal object OthentoHttpClientFactory {
    fun create(
        apiKey: String?,
        baseUrl: String,
        tokenStore: TokenStore,
        loggingEnabled: Boolean = false,
    ): OthentoHttpStack {
        val parsedBaseUrl: HttpUrl = baseUrl.normalisedAsHttpUrl()
        val moshi: Moshi = buildMoshi()
        val client: OkHttpClient = buildOkHttp(apiKey, parsedBaseUrl, tokenStore, loggingEnabled)

        val retrofit =
            Retrofit
                .Builder()
                .baseUrl(parsedBaseUrl)
                .client(client)
                // Strict parsing — the empty-decision-string quirk is now
                // handled by `DecisionJsonAdapter` so `asLenient()` would
                // only mask future malformed-payload bugs.
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()

        return OthentoHttpStack(
            api = retrofit.create(OthentoApi::class.java),
            errorMapper = ErrorMapper(),
            okHttpClient = client,
            tokenStore = tokenStore,
        )
    }

    private fun buildMoshi(): Moshi =
        Moshi
            .Builder()
            // Decision must intercept Moshi's standard enum adapter — the
            // dev backend returns `decision: ""` (empty string) for "no
            // decision yet". Registered before the catch-all StandardJsonAdapters.
            .add(DecisionJsonAdapter.Factory())
            // Forward-compatibility: a wire enum value the SDK doesn't know
            // about (backend ships a new ChallengeStatus / ActiveStepStatus
            // before the SDK adds the matching constant) falls back to a
            // sensible default and logs a `OthentoSDK-Parse` warning rather
            // than failing the response parse outright.
            .add(
                TolerantEnumJsonAdapter(
                    fallbacks =
                        mapOf(
                            ActiveStepStatus::class.java to ActiveStepStatus.AwaitingEvidence,
                            ChallengeStatus::class.java to ChallengeStatus.AwaitingUpload,
                            ChallengeType::class.java to ChallengeType.DocumentFront,
                            SessionStatus::class.java to SessionStatus.InProgress,
                        ),
                ),
            ).build()

    private fun buildOkHttp(
        apiKey: String?,
        baseUrl: HttpUrl,
        tokenStore: TokenStore,
        loggingEnabled: Boolean,
    ): OkHttpClient {
        val builder =
            OkHttpClient
                .Builder()
                // OkHttp's defaults are 10 s for connect/read/write — too tight
                // for slow cellular links (some users hit `SocketTimeoutException`
                // on routine API calls). 20 s gives more headroom while still
                // failing fast on small JSON. The S3 PUT path overrides these
                // again with even larger envelopes — see UploadRepositoryImpl.
                .connectTimeout(API_TIMEOUT_S, TimeUnit.SECONDS)
                .readTimeout(API_TIMEOUT_S, TimeUnit.SECONDS)
                .writeTimeout(API_TIMEOUT_S, TimeUnit.SECONDS)
                .addInterceptor(ApiKeyInterceptor(apiKey, baseUrl))
                .addInterceptor(TokenInterceptor(tokenStore, baseUrl))

        // Debug builds always log; release builds log only when the host
        // opts in via OthentoConfig.loggingEnabled. Either way auth headers
        // are redacted, so a token/apiKey never reaches logcat.
        if (BuildConfig.DEBUG || loggingEnabled) {
            val logger = HttpLoggingInterceptor()
            logger.level = HttpLoggingInterceptor.Level.BODY
            // Auth headers are highly sensitive; never log them.
            logger.redactHeader(ApiKeyInterceptor.HEADER_X_API_KEY)
            logger.redactHeader(TokenInterceptor.HEADER_X_SAT)
            logger.redactHeader(TokenInterceptor.HEADER_X_ST)
            logger.redactHeader(TokenInterceptor.HEADER_X_SRT)
            builder.addInterceptor(logger)
        }

        return builder.build()
    }

    /**
     * Retrofit requires baseUrls to end with `/`. We tolerate hosts that
     * pass either form ("…:5160" or "…:5160/").
     */
    private fun String.normalisedAsHttpUrl(): HttpUrl {
        val withSlash = if (endsWith("/")) this else "$this/"
        return withSlash.toHttpUrl()
    }

    private const val API_TIMEOUT_S: Long = 20L
}

/**
 * Bundle of the per-launch HTTP plumbing the repositories need.
 *
 * [okHttpClient] is exposed so the upload pipeline can reuse the same client
 * for the S3 PUT (the PUT is to a different host so the interceptors no-op,
 * but reusing connections + thread pools is cheaper than minting a fresh
 * client per launch).
 */
internal data class OthentoHttpStack(
    val api: OthentoApi,
    val errorMapper: ErrorMapper,
    val okHttpClient: OkHttpClient,
    val tokenStore: TokenStore,
)
