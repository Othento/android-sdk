@file:Suppress(
    "MagicNumber",
    "ReturnCount",
    // Reason: Y-plane quality scorer ported from the web SDK's QualityAnalyzerService.
    // MagicNumber: literals here are algorithm constants, not arbitrary tuning values:
    //   0xFF  — standard Kotlin byte-to-unsigned-int mask (ubiquitous pattern)
    //   4     — Laplacian cross-kernel coefficient (4*center - up - down - left - right)
    //   245   — extracted as GLARE_THRESHOLD named constant; kept here for 0xFF companion
    // ReturnCount: each metric function has two early-exit guards (empty/degenerate region
    //   + zero-count check) plus the normal return — extracting them would obscure the
    //   algorithm structure without reducing complexity.
)

package com.othento.core.internal.capture.detection.quality

import android.graphics.Rect

/**
 * Y-plane quality scorer. Pure-Kotlin port of the web SDK's
 * `quality-analyzer.service.ts`. No OpenCV dependency.
 *
 * All three metrics may be computed over an optional [region] (`null` = full
 * plane). Coordinates in `region` are clamped to plane bounds — out-of-range
 * regions degrade to the visible portion.
 */
internal object QualityAnalyzer {
    private const val GLARE_THRESHOLD: Int = 235
    private const val LAPLACIAN_CENTER_WEIGHT: Int = 4

    /**
     * Laplacian-of-Y variance over a 3×3 cross kernel. Higher = sharper.
     * Empirical web threshold around 80–120 for "in focus".
     *
     * Kernel: `4*center - up - down - left - right`
     */
    fun laplacianVariance(
        yPlane: ByteArray,
        width: Int,
        height: Int,
        region: Rect?,
    ): Float {
        val r = region.toClampedRect(width, height)
        if (r.width() < 3 || r.height() < 3) return 0f

        var sum = 0.0
        var sumSq = 0.0
        var count = 0L
        for (y in (r.top + 1) until (r.bottom - 1)) {
            for (x in (r.left + 1) until (r.right - 1)) {
                val c = yPlane[y * width + x].toInt() and 0xFF
                val u = yPlane[(y - 1) * width + x].toInt() and 0xFF
                val d = yPlane[(y + 1) * width + x].toInt() and 0xFF
                val l = yPlane[y * width + (x - 1)].toInt() and 0xFF
                val rr = yPlane[y * width + (x + 1)].toInt() and 0xFF
                val lap = (LAPLACIAN_CENTER_WEIGHT * c - u - d - l - rr).toDouble()
                sum += lap
                sumSq += lap * lap
                count++
            }
        }
        if (count == 0L) return 0f
        val mean = sum / count
        val variance = sumSq / count - mean * mean
        return variance.toFloat()
    }

    /**
     * Fraction of pixels with Y > 245. Web threshold ~5%.
     */
    fun glareRatio(
        yPlane: ByteArray,
        width: Int,
        height: Int,
        region: Rect?,
    ): Float {
        val r = region.toClampedRect(width, height)
        if (r.width() <= 0 || r.height() <= 0) return 0f

        var hot = 0L
        for (y in r.top until r.bottom) {
            for (x in r.left until r.right) {
                val v = yPlane[y * width + x].toInt() and 0xFF
                if (v > GLARE_THRESHOLD) hot++
            }
        }
        val area = r.width().toLong() * r.height()
        return (hot.toDouble() / area).toFloat()
    }

    /**
     * Mean Y in `[0, 255]`. Web band: `[40, 220]`.
     */
    fun brightnessMean(
        yPlane: ByteArray,
        width: Int,
        height: Int,
        region: Rect?,
    ): Float {
        val r = region.toClampedRect(width, height)
        if (r.width() <= 0 || r.height() <= 0) return 0f

        var sum = 0L
        for (y in r.top until r.bottom) {
            for (x in r.left until r.right) {
                sum += (yPlane[y * width + x].toInt() and 0xFF)
            }
        }
        val area = r.width().toLong() * r.height()
        return (sum.toDouble() / area).toFloat()
    }

    private fun Rect?.toClampedRect(
        w: Int,
        h: Int,
    ): Rect {
        if (this == null) return Rect(0, 0, w, h)
        return Rect(
            left.coerceIn(0, w),
            top.coerceIn(0, h),
            right.coerceIn(0, w),
            bottom.coerceIn(0, h),
        )
    }
}
