package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass

/**
 * RFC 7807 `application/problem+json` envelope.
 *
 * The web SDK reads `title` and `errors` off this shape (see web's
 * `api-error.helper.ts`, summarised in [docs/spec/10-network-layer.md §4.2]).
 * Backends commonly include a `traceId` and a top-level `message` too —
 * we accept both shapes so the error mapper can pick the most useful
 * human-readable string.
 *
 * Every field is optional; [com.othento.core.internal.network.ErrorMapper]
 * tolerates a missing or unparseable body.
 */
@JsonClass(generateAdapter = true)
internal data class ProblemDetailsDto(
    val title: String? = null,
    val status: Int? = null,
    val detail: String? = null,
    val type: String? = null,
    val message: String? = null,
    val code: String? = null,
    val traceId: String? = null,
    val errors: Map<String, List<String>>? = null,
)
