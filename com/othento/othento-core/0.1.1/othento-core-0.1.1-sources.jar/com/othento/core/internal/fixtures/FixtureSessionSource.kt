package com.othento.core.internal.fixtures

import com.othento.core.internal.flow.SessionResolveResult
import com.othento.core.internal.flow.SessionSource
import com.othento.core.api.OthentoConfig
import com.othento.core.api.OthentoError
import com.othento.core.api.OthentoFixtureScenario

/**
 * Phase-4 [SessionSource] that resolves to a canned [SessionFixtures] session
 * (or to a [SessionResolveResult.Failure] for the two error scenarios) based
 * on the user-selected [OthentoFixtureScenario].
 *
 * Phase 5+ will replace this with a network-backed implementation that calls
 * `SessionRepository.createSession(...)` and maps the result the same way.
 */
internal class FixtureSessionSource(
    private val scenario: OthentoFixtureScenario,
) : SessionSource {
    override suspend fun resolveSession(config: OthentoConfig): SessionResolveResult =
        when (scenario) {
            OthentoFixtureScenario.ERROR_NOT_FOUND ->
                SessionResolveResult.Failure(
                    error = OthentoError.SessionNotFound,
                    displayMessage = NOT_FOUND_DISPLAY_MESSAGE,
                    httpStatus = HTTP_NOT_FOUND,
                )

            OthentoFixtureScenario.ERROR_NETWORK ->
                SessionResolveResult.Failure(
                    error = OthentoError.Network(cause = null),
                    displayMessage = NETWORK_DISPLAY_MESSAGE,
                    httpStatus = null,
                )

            else ->
                SessionResolveResult.Ok(SessionFixtures.forScenario(scenario))
        }

    private companion object {
        const val HTTP_NOT_FOUND = 404
        const val NOT_FOUND_DISPLAY_MESSAGE = "Or not accessible on this device"
        const val NETWORK_DISPLAY_MESSAGE =
            "We couldn't reach the verification service. Please check your connection and try again."
    }
}
