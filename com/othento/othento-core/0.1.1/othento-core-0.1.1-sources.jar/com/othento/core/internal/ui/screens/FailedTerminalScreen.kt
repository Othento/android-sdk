@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.components.StatusIconTone
import com.othento.core.internal.ui.screens.common.RETURN_TO_APP_LABEL
import com.othento.core.internal.ui.screens.common.StatusAction
import com.othento.core.internal.ui.screens.common.StatusScreenMode
import com.othento.core.internal.ui.screens.common.StatusScreenScaffold

/**
 * Spec [docs/spec/06-screens/17-failed-terminal.md]:
 * red cross, "Verification Failed", non-recoverable copy. Distinguished
 * from `Declined` (definitive negative inference) by happening **without
 * a decision**, e.g. abuse / system / max-attempts.
 */
@Composable
internal fun FailedTerminalScreen(onReturnToApp: () -> Unit) {
    StatusScreenScaffold(
        iconName = StatusIconName.Cross,
        iconTone = StatusIconTone.Error,
        title = "Verification Failed",
        description =
            "Something went wrong during verification. " +
                "Please contact your service provider for further assistance.",
        mode = StatusScreenMode.Terminal,
        primaryAction = StatusAction(label = RETURN_TO_APP_LABEL, onClick = onReturnToApp),
    )
}
