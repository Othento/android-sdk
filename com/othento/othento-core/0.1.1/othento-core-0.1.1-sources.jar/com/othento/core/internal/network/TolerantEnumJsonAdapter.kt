package com.othento.core.internal.network

import android.util.Log
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.JsonReader
import com.squareup.moshi.JsonWriter
import com.squareup.moshi.Moshi
import java.lang.reflect.Type

/**
 * Moshi adapter factory that tolerates unknown enum values for a fixed set
 * of enums. When the wire emits a string the enum doesn't define, the
 * adapter falls back to a configured default and emits a `Log.w` so the
 * dev backend's surprise value is visible in logcat (filter by
 * `OthentoSDK-Parse`) without breaking the host's flow.
 *
 * Used to keep the SDK forward-compatible with backend additions that
 * land before the matching native enum value ships (Phase 5+ document /
 * upload flow has hit this twice already).
 */
internal class TolerantEnumJsonAdapter(
    private val fallbacks: Map<Class<*>, Enum<*>>,
) : JsonAdapter.Factory {
    @Suppress("ReturnCount") // Four guards (annotations / non-class type / non-enum / no fallback) + one happy path.
    override fun create(
        type: Type,
        annotations: Set<Annotation>,
        moshi: Moshi,
    ): JsonAdapter<*>? {
        if (annotations.isNotEmpty()) return null
        val rawType = type as? Class<*> ?: return null
        if (!rawType.isEnum) return null
        val fallback = fallbacks[rawType] ?: return null
        return Adapter(rawType, fallback).nullSafe()
    }

    private class Adapter(
        private val enumType: Class<*>,
        private val fallback: Enum<*>,
    ) : JsonAdapter<Enum<*>>() {
        private val byName: Map<String, Enum<*>> =
            (enumType.enumConstants ?: emptyArray()).associate {
                val constant = it as Enum<*>
                constant.name to constant
            }

        override fun fromJson(reader: JsonReader): Enum<*>? {
            val raw = reader.nextString()
            val matched = byName[raw]
            if (matched != null) return matched
            warnLogcat("Unknown ${enumType.simpleName} value '$raw' from backend; falling back to ${fallback.name}.")
            return fallback
        }

        @Suppress("TooGenericExceptionCaught")
        private fun warnLogcat(message: String) {
            // android.util.Log throws UnsatisfiedLinkError under the JVM
            // unit-test runtime; swallow so tolerant-enum tests work.
            try {
                Log.w(LOG_TAG, message)
            } catch (_: LinkageError) {
                // unit-test environment — ignore
            } catch (_: RuntimeException) {
                // defensive
            }
        }

        override fun toJson(
            writer: JsonWriter,
            value: Enum<*>?,
        ) {
            writer.value(value?.name)
        }
    }

    internal companion object {
        const val LOG_TAG: String = "OthentoSDK-Parse"
    }
}
