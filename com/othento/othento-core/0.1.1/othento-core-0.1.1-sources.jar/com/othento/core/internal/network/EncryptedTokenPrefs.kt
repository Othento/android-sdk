package com.othento.core.internal.network

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Phase 10 — encrypted persistence for the SAT/ST/SRT bundle.
 *
 * Wraps `androidx.security:security-crypto`'s
 * `EncryptedSharedPreferences` with a master key from the Android
 * Keystore. The bundle is keyed by sessionId so concurrent launches in
 * different sessions don't clobber each other (spec
 * [docs/spec/18-security-and-privacy.md] §3 + [docs/spec/10-network-layer.md] §8.2).
 *
 * The persisted shape mirrors the web SDK's `PersistedTokens`
 * (`apps/sdk/.../token-store.service.ts:52-70`):
 *
 * ```json
 * {
 *   "sat":          "sat:...",
 *   "st":           "st:...",
 *   "srt":          "srt:...",
 *   "stExpiresAt":  "2026-05-02T...",
 *   "srtExpiresAt": "2026-05-02T..."
 * }
 * ```
 *
 * Stored as a single JSON-formatted string under
 * `othento_<sessionId>_tokens`. Plus a separate non-sensitive
 * `othento_active_session` pointer so the flow can find the active
 * session id on rehydrate.
 *
 * Per OQ-Phase10-3: the SDK additionally stores
 * `othento_sat_<sat>_pointer` mapping a SAT (lifted from a deeplink URL)
 * to the sessionId it minted the bundle for — this lets rehydrate look
 * up the right bundle without already knowing the sessionId.
 *
 * Note on deprecation: `EncryptedSharedPreferences` is deprecated in
 * `androidx.security` 1.1.0+; tracked as OQ-Phase10-1. Migration to
 * Tink-AEAD-on-DataStore is out of scope for Phase 10 — for now the
 * deprecation is suppressed at the call sites.
 */
internal class EncryptedTokenPrefs private constructor(
    private val prefs: SharedPreferences,
) {
    fun saveBundle(
        sessionId: String,
        sourceSat: String?,
        bundle: String,
    ) {
        prefs.edit().run {
            putString(bundleKey(sessionId), bundle)
            putString(ACTIVE_SESSION_KEY, sessionId)
            if (sourceSat != null) putString(satPointerKey(sourceSat), sessionId)
            apply()
        }
    }

    fun loadBundle(sessionId: String): String? = prefs.getString(bundleKey(sessionId), null)

    fun lookupSessionId(sat: String): String? = prefs.getString(satPointerKey(sat), null)

    fun clearSession(
        sessionId: String,
        sat: String?,
    ) {
        prefs.edit().run {
            remove(bundleKey(sessionId))
            if (prefs.getString(ACTIVE_SESSION_KEY, null) == sessionId) {
                remove(ACTIVE_SESSION_KEY)
            }
            if (sat != null) remove(satPointerKey(sat))
            apply()
        }
    }

    private fun bundleKey(sessionId: String): String = "othento_${sessionId}_tokens"

    /**
     * Use the SAT itself as the pointer key. The prefs file is already
     * encrypted at rest by `EncryptedSharedPreferences` so there's no
     * security argument for hashing — and `String.hashCode()` is 32-bit,
     * which would carry a real birthday-bound collision risk over the
     * population of SATs the device could see.
     */
    private fun satPointerKey(sat: String): String = "othento_sat_${sat}_session"

    internal companion object {
        const val ACTIVE_SESSION_KEY: String = "othento_active_session"
        const val PREFS_FILE: String = "othento_tokens"

        /**
         * Build an instance backed by `EncryptedSharedPreferences`. Returns
         * `null` if the master-key path fails (factory reset on a device
         * with the prior key, KeyStore unavailable, etc.) — the SDK then
         * runs token-mode purely in-memory rather than silently
         * downgrading to plaintext SharedPreferences. Spec
         * [docs/spec/18-security-and-privacy.md] §3 — never write the ST
         * bundle in the clear.
         */
        @SuppressLint("UseKtx")
        @Suppress("DEPRECATION", "TooGenericExceptionCaught")
        fun createOrNull(context: Context): EncryptedTokenPrefs? =
            try {
                val masterKey =
                    MasterKey
                        .Builder(context.applicationContext)
                        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                        .build()
                val prefs =
                    EncryptedSharedPreferences.create(
                        context.applicationContext,
                        PREFS_FILE,
                        masterKey,
                        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
                    )
                EncryptedTokenPrefs(prefs)
            } catch (_: Exception) {
                // Master-key build / decrypt failure (corrupt prefs, KeyStore
                // problem, restored backup with a missing key). Drop the
                // bundle — the next persist would be plaintext, which spec
                // §3 says we MUST NOT do. Token mode runs in-memory only.
                runCatching { context.applicationContext.deleteSharedPreferences(PREFS_FILE) }
                null
            }
    }
}
