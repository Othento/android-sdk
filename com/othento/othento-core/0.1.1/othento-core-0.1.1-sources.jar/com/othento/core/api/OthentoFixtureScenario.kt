package com.othento.core.api

/**
 * Test-only enum that selects which canned `Session` shape the SDK's flow
 * resolves to, so the unit/snapshot suite can land on each terminal screen
 * deterministically. `internal` — **not** part of the published public API;
 * production hosts cannot reach it and always drive the real backend.
 */
internal enum class OthentoFixtureScenario {
    /** `status=Created` → `Start` screen. Lets the user inspect the hero/step list. */
    CREATED,

    /** `status=Processing` → `Processing` screen with the arc-loader animation. */
    PROCESSING,

    /** `status=Completed, decision=Approved` → `Approved` terminal screen. */
    APPROVED,

    /** `status=Completed, decision=Declined` → `Declined` terminal screen. */
    DECLINED,

    /** `status=Completed, decision=InReview` → `InReview` terminal screen. */
    IN_REVIEW,

    /** `status=Expired` → `Expired` terminal screen. */
    EXPIRED,

    /** `status=Failed, canInitiate=true` → `FailedRetry` recoverable-failure screen. */
    FAILED_RETRY,

    /** `status=Failed, canInitiate=false` → `FailedTerminal` hard-failure screen. */
    FAILED_TERMINAL,

    /** Simulates a 404 → `Error` screen with the "Session not found" copy. */
    ERROR_NOT_FOUND,

    /** Simulates a network failure → `Error` screen with the generic copy. */
    ERROR_NETWORK,

    /**
     * Lands on `Processing` (sandbox-style); the flow stays there so the
     * human can exercise the cancel path (back press / cancel button) and
     * confirm `onCancelled(reason)` fires before any terminal listener event.
     */
    CANCELLED_BEFORE_TERMINAL,
}
