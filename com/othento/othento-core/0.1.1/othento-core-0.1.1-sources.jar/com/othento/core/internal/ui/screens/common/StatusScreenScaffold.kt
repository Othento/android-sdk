@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens.common

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonSize
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenTone
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.components.KycStatusIcon
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.components.StatusIconTone
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Result-zone preset matching the web SDK's `KycStatusScreen`
 * ([docs/spec/06-screens/20-shared.md] §KycStatusScreen): a centered column
 * with a 80-dp tone-tinted [KycStatusIcon], an h2 title, an optional
 * description paragraph, an optional extra slot, and zero-to-two buttons.
 *
 * Used by Approved / Declined / InReview / Expired / FailedTerminal /
 * Processing / Error screens — every Phase-4 result-zone screen.
 *
 * `mode` controls the [KycScreen] entrance animation: `Terminal` plays the
 * `kyc-screen-enter` translate-and-fade; `InFlight` suppresses it (used by
 * Processing's arc loader and InReview's static clock so the on-screen
 * change isn't double-animated).
 */
@Composable
@Suppress("LongParameterList")
internal fun StatusScreenScaffold(
    iconName: StatusIconName,
    iconTone: StatusIconTone,
    title: String,
    description: String? = null,
    mode: StatusScreenMode = StatusScreenMode.Terminal,
    primaryAction: StatusAction? = null,
    secondaryAction: StatusAction? = null,
    extraContent: (@Composable () -> Unit)? = null,
) {
    KycScreen(
        zone = KycScreenZone.Result,
        tone = toneFor(iconTone),
        animate = mode == StatusScreenMode.Terminal,
        body = {
            StatusBody(
                iconName = iconName,
                iconTone = iconTone,
                title = title,
                description = description,
                primaryAction = primaryAction,
                secondaryAction = secondaryAction,
                extraContent = extraContent,
            )
        },
    )
}

@Composable
@Suppress("LongParameterList", "LongMethod")
private fun StatusBody(
    iconName: StatusIconName,
    iconTone: StatusIconTone,
    title: String,
    description: String?,
    primaryAction: StatusAction?,
    secondaryAction: StatusAction?,
    extraContent: (@Composable () -> Unit)?,
) {
    val typography = LocalOthentoTypography.current
    val colors = LocalOthentoColors.current
    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .widthIn(max = StatusBodyMaxWidth)
                .padding(horizontal = StatusBodyHorizontal),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        KycStatusIcon(icon = iconName, tone = iconTone)
        Spacer(modifier = Modifier.height(StatusIconBottomGap))
        Text(
            text = title,
            style = typography.titleH2,
            color = colors.textHeading,
            textAlign = TextAlign.Center,
        )
        if (description != null) {
            Spacer(modifier = Modifier.height(StatusTitleBottomGap))
            Text(
                text = description,
                style = typography.bodyLg,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
            )
        }
        if (extraContent != null) {
            Spacer(modifier = Modifier.height(StatusTitleBottomGap))
            extraContent()
        }
        if (primaryAction != null) {
            Spacer(modifier = Modifier.height(StatusActionTopGap))
            KycButton(
                onClick = primaryAction.onClick,
                label = primaryAction.label,
                variant = KycButtonVariant.Primary,
                size = KycButtonSize.Lg,
                fullWidth = true,
            )
        }
        if (secondaryAction != null) {
            Spacer(modifier = Modifier.height(StatusActionInnerGap))
            KycButton(
                onClick = secondaryAction.onClick,
                label = secondaryAction.label,
                variant = KycButtonVariant.Ghost,
                size = KycButtonSize.Lg,
                fullWidth = true,
            )
        }
    }
}

internal enum class StatusScreenMode { Terminal, InFlight }

internal data class StatusAction(
    val label: String,
    val onClick: () -> Unit,
)

private fun toneFor(iconTone: StatusIconTone): KycScreenTone =
    when (iconTone) {
        StatusIconTone.Neutral -> KycScreenTone.Neutral
        StatusIconTone.Success -> KycScreenTone.Success
        StatusIconTone.Warning -> KycScreenTone.Warning
        StatusIconTone.Error -> KycScreenTone.Error
    }

private val StatusBodyMaxWidth = 420.dp
private val StatusBodyHorizontal = 24.dp
private val StatusIconBottomGap = 24.dp
private val StatusTitleBottomGap = 8.dp
private val StatusActionTopGap = 24.dp
private val StatusActionInnerGap = 8.dp
