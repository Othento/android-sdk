@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.components.StatusIconTone
import com.othento.core.internal.ui.screens.common.StatusAction
import com.othento.core.internal.ui.screens.common.StatusScreenMode
import com.othento.core.internal.ui.screens.common.StatusScreenScaffold

/**
 * Spec [docs/spec/06-screens/12-processing.md].
 *
 * Two variants:
 * - **In-flight** (default): neutral arc loader, "Verifying your identity",
 *   no buttons. Polling is active.
 * - **Timed-out** (after [SessionConfig.maxPolls] without a terminal
 *   outcome): warning clock, "Verification under review", "Try again" CTA.
 *   Polling is stopped.
 *
 * Closes Q9 in `99-open-questions.md` — Phase 4 only shipped the in-flight
 * variant because the fixture-driven source returned synchronously.
 */
@Composable
internal fun ProcessingScreen(
    timedOut: Boolean = false,
    onTryAgainClick: () -> Unit = { },
) {
    if (timedOut) {
        StatusScreenScaffold(
            iconName = StatusIconName.Clock,
            iconTone = StatusIconTone.Warning,
            title = "Verification under review",
            description = "Your submission is being reviewed. This may take a little longer than usual.",
            mode = StatusScreenMode.Terminal,
            primaryAction = StatusAction(label = "Try again", onClick = onTryAgainClick),
        )
    } else {
        StatusScreenScaffold(
            iconName = StatusIconName.Arc,
            iconTone = StatusIconTone.Neutral,
            title = "Verifying your identity",
            description = "We're running the final checks. This usually takes a few moments.",
            mode = StatusScreenMode.InFlight,
        )
    }
}
