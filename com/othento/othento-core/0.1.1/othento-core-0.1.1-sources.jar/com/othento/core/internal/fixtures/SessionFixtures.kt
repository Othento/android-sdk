package com.othento.core.internal.fixtures

import com.othento.core.internal.data.model.ActiveStepStatus
import com.othento.core.internal.data.model.Decision
import com.othento.core.internal.data.model.ReinitInfo
import com.othento.core.internal.data.model.ReinitStep
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.data.model.SessionStatus
import com.othento.core.internal.data.model.Step
import com.othento.core.api.OthentoFixtureScenario

/**
 * Canned [Session] fixtures driving Phase-4's screen sweep. Every fixture
 * carries the same workflow (`step_id_verification`, `step_face_match`,
 * `step_phone_verification`) so the Start / FailedRetry hero step lists are
 * non-trivial; only the status / decision / canInitiate triple varies per
 * scenario.
 *
 * The fixtures intentionally leave `currentStep` null so Phase-4's
 * status-driven [com.othento.core.internal.flow.ScreenResolver] is the
 * authoritative branch — `currentStep`-driven resolution lands in Phase 5+.
 */
internal object SessionFixtures {
    /**
     * Returns the canned session for a non-error scenario. Error scenarios
     * (`ERROR_NOT_FOUND`, `ERROR_NETWORK`) do not have a [Session] — the
     * `FixtureSessionSource` short-circuits to a `Failure` for those.
     */
    fun forScenario(scenario: OthentoFixtureScenario): Session =
        when (scenario) {
            OthentoFixtureScenario.CREATED ->
                baseSession.copy(status = SessionStatus.Created)

            OthentoFixtureScenario.PROCESSING,
            OthentoFixtureScenario.CANCELLED_BEFORE_TERMINAL,
            ->
                baseSession.copy(status = SessionStatus.Processing)

            OthentoFixtureScenario.APPROVED ->
                baseSession.copy(
                    status = SessionStatus.Completed,
                    decision = Decision.Approved,
                )

            OthentoFixtureScenario.DECLINED ->
                baseSession.copy(
                    status = SessionStatus.Completed,
                    decision = Decision.Declined,
                )

            OthentoFixtureScenario.IN_REVIEW ->
                baseSession.copy(
                    status = SessionStatus.Completed,
                    decision = Decision.InReview,
                )

            OthentoFixtureScenario.EXPIRED ->
                baseSession.copy(status = SessionStatus.Expired)

            OthentoFixtureScenario.FAILED_RETRY ->
                baseSession.copy(
                    status = SessionStatus.Failed,
                    canInitiate = true,
                    canReinitiate = true,
                    attemptNumber = 1,
                    maxAttempts = 3,
                    reinitInfo =
                        ReinitInfo(
                            attemptsRemaining = 2,
                            failureReason = "document_unreadable",
                            stepsToRetry =
                                listOf(
                                    ReinitStep(
                                        stepCode = "step_id_verification",
                                        stepName = "Document verification",
                                        order = 0,
                                    ),
                                ),
                        ),
                )

            OthentoFixtureScenario.FAILED_TERMINAL ->
                baseSession.copy(
                    status = SessionStatus.Failed,
                    canInitiate = false,
                    attemptNumber = 3,
                    maxAttempts = 3,
                )

            OthentoFixtureScenario.ERROR_NOT_FOUND,
            OthentoFixtureScenario.ERROR_NETWORK,
            -> error("Error scenarios do not have a Session — use FixtureSessionSource directly.")
        }

    private val baseSteps: List<Step> =
        listOf(
            Step(
                attemptStepId = "step-id-verification-fixture",
                configuration = null,
                stepCode = "step_id_verification",
                stepName = "Document verification",
                order = 0,
                status = ActiveStepStatus.AwaitingEvidence,
            ),
            Step(
                attemptStepId = "step-face-match-fixture",
                configuration = null,
                stepCode = "step_face_match",
                stepName = "Selfie",
                order = 1,
                status = ActiveStepStatus.AwaitingEvidence,
            ),
            Step(
                attemptStepId = "step-phone-fixture",
                configuration = null,
                stepCode = "step_phone_verification",
                stepName = "Phone code",
                order = 2,
                status = ActiveStepStatus.AwaitingEvidence,
            ),
        )

    private val baseSession: Session =
        Session(
            externalId = FIXTURE_EXTERNAL_ID,
            desktopAccess = false,
            sessionUrl = "$FIXTURE_SESSION_URL_BASE$FIXTURE_EXTERNAL_ID",
            status = SessionStatus.Created,
            isSandbox = true,
            maxAttempts = 3,
            attemptNumber = 0,
            estimatedPrice = null,
            expiresAt = "2026-12-31T23:59:59Z",
            currentStep = null,
            selectedDocument = null,
            steps = baseSteps,
            canInitiate = true,
            decision = null,
            sessionToken = "sat:fixture-sat-token-phase4",
            sessionRetryToken = null,
            stExpiresAt = null,
            srtExpiresAt = null,
            declineMessage = null,
        )

    private const val FIXTURE_EXTERNAL_ID = "ekyc-fixture-phase4"
    private const val FIXTURE_SESSION_URL_BASE = "https://sdk.example.zetatech.ae/verify/"
}
