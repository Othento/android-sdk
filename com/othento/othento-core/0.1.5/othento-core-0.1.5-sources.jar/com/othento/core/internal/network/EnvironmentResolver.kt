package com.othento.core.internal.network

import com.othento.core.api.OthentoConfig

/**
 * Internal-only resolver for the backend base URL.
 *
 * Whether an account is sandbox or live is decided server-side by the API key
 * the session was created with, and is reflected in the flow UI — the client
 * never routes on it. This matches the web SDK, whose verification UI calls
 * one host.
 *
 * The SDK previously routed on the apiKey prefix. Token mode carries no
 * apiKey (the host's server creates the session), so it fell through to the
 * development host and every production SAT failed.
 *
 * The only input is the host's public `OthentoConfig.apiBaseUrl`, for
 * dedicated-cloud and on-premises deployments. It replaced the earlier
 * `othento.internal.baseUrl` JVM system property, so there is exactly one way
 * to point the SDK elsewhere, and it is the tested, documented one.
 */
internal object EnvironmentResolver {
    const val PRODUCTION_BASE_URL: String = "https://sdk-api.othento.com"

    /**
     * [OthentoConfig.apiBaseUrl] is already validated and normalized by
     * `OthentoConfig.Builder.build()`; `null` means the host did not set one.
     */
    fun resolveBaseUrl(config: OthentoConfig): String = config.apiBaseUrl ?: PRODUCTION_BASE_URL
}
