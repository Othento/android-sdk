package com.othento.core.api

import com.othento.core.internal.network.HttpsOrigin

/**
 * Immutable configuration for an Othento SDK session.
 *
 * Construct via [Builder]; instances should not be mutated after [Builder.build]
 * returns. Mirrors the cross-platform contract's `OthentoConfig` shape — there is
 * no `environment` / `branding` field on the public surface. Sandbox vs
 * production is decided server-side by the API key the session was created
 * with (the SDK never routes on it), and tenant branding arrives from the
 * backend content bundle rather than from the host app (content decision 23).
 *
 * [apiBaseUrl] **is** on the public surface, which knowingly reverses the
 * original contract's "no base-URL override" rule. It exists for dedicated-cloud
 * and on-premises deployments, whose SDK API is not Othento's hosted one; it
 * mirrors iOS `apiBaseUrl` and web `sdkBaseUrl` (decided 2026-11-05).
 *
 * [language] **is** on the public surface, which knowingly reverses the earlier
 * "no locale field" note that stood here. Both native SDKs added it as part of
 * the SDK-content / localization work (content decision 4); it is the only way
 * an integrator can pick the verification language for a session it creates.
 */
@ConsistentCopyVisibility
public data class OthentoConfig internal constructor(
    val mode: OthentoMode,
    val apiKey: String?,
    val callbackUrl: String?,
    val callbackReceiver: OthentoCallbackReceiver?,
    val metadata: String?,
    val expectedDetails: OthentoExpectedDetails?,
    val closeOnComplete: Boolean,
    val loggingEnabled: Boolean,
    /**
     * BCP-47 language code (`"en"`, `"ar"`, …) recorded on the session at
     * create time and used to resolve SDK copy. `null` (default) lets the
     * backend pick the tenant default.
     *
     * The backend is the authority: request a language the tenant does not
     * publish and it resolves to the default, so the SDK renders whatever came
     * back rather than what was asked for.
     */
    val language: String?,
    /**
     * Normalized SDK API origin for a dedicated-cloud or on-premises
     * deployment (lowercase, no default `:443`, no trailing slash). `null`
     * (default) uses Othento's hosted SDK API, `https://sdk-api.othento.com`.
     */
    val apiBaseUrl: String?,
) {
    /**
     * Fluent builder. The `build()` method enforces the same required-field
     * rules as the cross-platform contract:
     *
     * | Mode      | Required fields                                              |
     * |-----------|--------------------------------------------------------------|
     * | `Create`  | `apiKey`, `workflowExternalId` (via `create`), `clientData`  |
     * | `Token`   | `sat` (via `tokenMode`); `apiKey` is **not** required        |
     *
     * Missing or malformed required fields raise [OthentoConfigException]
     * **synchronously from this method** — they never surface through
     * [OthentoSDKListener.onError].
     */
    @Suppress(
        "TooManyFunctions",
        // Reason: one setter per public config field is the builder's whole
        // contract. `language(...)` was the eleventh and tipped it over the
        // threshold, `apiBaseUrl(...)` is the twelfth; grouping setters would
        // change a published API surface.
    )
    public class Builder {
        private var mode: OthentoMode? = null
        private var apiKey: String? = null
        private var callbackUrl: String? = null
        private var callbackReceiver: OthentoCallbackReceiver? = null
        private var metadata: String? = null
        private var expectedDetails: OthentoExpectedDetails? = null
        private var closeOnComplete: Boolean = false
        private var loggingEnabled: Boolean = false
        private var language: String? = null
        private var apiBaseUrl: String? = null

        /** Sets [OthentoMode.Create]. The SDK will create a fresh session at launch. */
        public fun create(
            workflowExternalId: String,
            clientData: String,
        ): Builder =
            apply {
                mode = OthentoMode.Create(workflowExternalId, clientData)
            }

        /**
         * Sets [OthentoMode.Token]. The SDK skips the create-session call and
         * starts at the first poll with `X-SAT`. Use when the session was
         * minted server-side and the SAT delivered to the device out-of-band
         * (typically via a deeplink).
         */
        public fun tokenMode(sat: String): Builder =
            apply {
                mode = OthentoMode.Token(sat)
            }

        public fun apiKey(apiKey: String): Builder =
            apply {
                this.apiKey = apiKey
            }

        public fun callbackUrl(url: String): Builder =
            apply {
                this.callbackUrl = url
            }

        public fun callbackReceiver(receiver: OthentoCallbackReceiver): Builder =
            apply {
                this.callbackReceiver = receiver
            }

        public fun metadata(metadata: String): Builder =
            apply {
                this.metadata = metadata
            }

        public fun expectedDetails(details: OthentoExpectedDetails): Builder =
            apply {
                this.expectedDetails = details
            }

        /**
         * When `true`, the SDK auto-dismisses itself as soon as the flow
         * reaches a terminal screen (Approved / Declined / In-review / Expired
         * / failed / error) — the host's terminal listener event still fires
         * first. When `false` (default) the SDK leaves the terminal screen up
         * until the user taps its "return to app" action. Mirrors the
         * cross-vendor `closeOnComplete` option.
         */
        public fun closeOnComplete(enabled: Boolean): Builder =
            apply {
                this.closeOnComplete = enabled
            }

        /**
         * When `true`, the SDK emits verbose HTTP logging (request/response
         * bodies, with every auth header redacted) so an integrator can debug
         * the flow against their own backend. `false` (default) logs nothing.
         * Debug builds of the SDK always log regardless of this flag.
         */
        public fun loggingEnabled(enabled: Boolean): Builder =
            apply {
                this.loggingEnabled = enabled
            }

        /**
         * BCP-47 language code for the verification session — `"en"`, `"ar"`,
         * and whatever else the tenant publishes. Optional: omit it and the
         * backend applies the tenant default.
         *
         * In create mode the code is sent on the create-session call and
         * recorded against the session. In token mode the session already has
         * a language (whoever minted it chose one), so this acts only as a
         * fallback when the session does not report one.
         */
        public fun language(code: String): Builder =
            apply {
                this.language = code.trim().takeIf { it.isNotEmpty() }
            }

        /**
         * SDK API origin for a **dedicated-cloud or on-premises** deployment.
         * Omit it (default) to use Othento's hosted SDK API,
         * `https://sdk-api.othento.com`.
         *
         * This is the SDK **API** host, the same host your server creates
         * sessions against, not a web page. Set it from your app's own build or
         * configuration, never from user input or a deeplink: the SDK sends
         * the session's access tokens to this host.
         *
         * Must be an https origin such as `https://kyc-api.example.com`: scheme
         * `https`, a DNS name or IPv4 address, and an optional port. A path,
         * query, fragment, credentials, an IPv6 literal, or a non-ASCII host
         * (use the `xn--` form) makes [build] throw [OthentoConfigException]
         * with [OthentoError.ConfigInvalid]. So does a blank value: unlike
         * [language], blank is **not** treated as "unset", because silently
         * falling back to the hosted service would send an on-premises
         * customer's data off-premises.
         */
        public fun apiBaseUrl(url: String): Builder =
            apply {
                this.apiBaseUrl = url
            }

        public fun build(): OthentoConfig {
            val resolvedMode =
                mode ?: throw OthentoConfigException(
                    OthentoError.ConfigInvalid(NO_MODE_SET_MESSAGE),
                    NO_MODE_SET_MESSAGE,
                )
            validate(resolvedMode, apiKey)
            val normalizedApiBaseUrl = apiBaseUrl?.let(::requireApiOrigin)

            return OthentoConfig(
                mode = resolvedMode,
                apiKey = apiKey,
                callbackUrl = callbackUrl,
                callbackReceiver = callbackReceiver,
                metadata = metadata,
                expectedDetails = expectedDetails,
                closeOnComplete = closeOnComplete,
                loggingEnabled = loggingEnabled,
                language = language,
                apiBaseUrl = normalizedApiBaseUrl,
            )
        }

        private companion object {
            const val NO_MODE_SET_MESSAGE =
                "No mode set on OthentoConfig.Builder; call create(...) or tokenMode(...)."
        }
    }
}

/**
 * The rejected value is deliberately left out of the message: it is host input
 * that could carry credentials (`https://user:pass@…`) and the message is
 * likely to be logged.
 */
private const val API_BASE_URL_RULE =
    "apiBaseUrl must be an https origin such as https://kyc-api.example.com " +
        "(scheme https, a host, an optional port; no path, query, fragment or credentials)"

private fun requireApiOrigin(raw: String): String =
    HttpsOrigin.normalize(raw) ?: throw OthentoConfigException(
        OthentoError.ConfigInvalid(API_BASE_URL_RULE),
        API_BASE_URL_RULE,
    )

private fun validate(
    mode: OthentoMode,
    apiKey: String?,
) {
    val (error, message) = firstMissingField(mode, apiKey) ?: return
    throw OthentoConfigException(error, message)
}

private fun firstMissingField(
    mode: OthentoMode,
    apiKey: String?,
): Pair<OthentoError, String>? =
    when {
        mode is OthentoMode.Create && mode.workflowExternalId.isBlank() ->
            OthentoError.MissingWorkflow to "Missing workflow configuration"
        mode is OthentoMode.Create && mode.clientData.isBlank() ->
            OthentoError.MissingClientData to "Missing client data"
        mode is OthentoMode.Token && mode.sat.isBlank() ->
            OthentoError.ConfigInvalid("Missing session access token") to "Missing session access token"
        // apiKey is only required for the Create path. Token mode runs
        // entirely off the SAT/ST/SRT bundle.
        mode is OthentoMode.Create && apiKey.isNullOrBlank() ->
            OthentoError.MissingApiKey to "Missing API key"
        else -> null
    }
