package com.othento.core.internal.network

/**
 * Validation for a configured Othento host (`OthentoConfig.apiBaseUrl`).
 *
 * The same rule ships in all three SDKs, so one deployment config behaves the
 * same everywhere:
 *   - Web: `libs/web-sdk/src/https-origin.ts` (ekyc-frontend)
 *   - iOS: `Sources/Othento/Internal/Network/HttpsOrigin.swift` (sdk-ios)
 * Their tests run the same accept/reject cases as [HttpsOriginTest].
 *
 * The rule is an explicit grammar rather than "whatever OkHttp's `HttpUrl`
 * accepts". OkHttp (like the WHATWG URL parser) is deliberately lenient: it
 * accepts `https:host` and `https:\\host` and silently converts a Unicode host
 * to punycode, and the browser reads a host whose last label is a number
 * (`kyc.123`, `0x7f.1`) as an IPv4 address. iOS does none of that. Validating
 * with each platform's own parser would let one config string pass on one SDK
 * and fail, or point somewhere else, on another.
 *
 * Accepted: `https://` + host + an optional port (1-65535) + an optional
 * trailing `/`. The host is either
 *   - a DNS name of 1-63 character labels (letters, digits, inner hyphens)
 *     whose last label contains a letter and is not a `0x…` hex number, or
 *   - a dotted-quad IPv4 address: four decimal octets 0-255, no leading zeros.
 * Anything else (another scheme, a path, query, fragment, credentials, an IPv6
 * literal, or a non-ASCII host) is rejected. Loosening this later is
 * non-breaking; tightening it would not be.
 *
 * Non-ASCII input is rejected BEFORE lowercasing: Unicode case mapping turns
 * lookalikes such as the Kelvin sign (U+212A) into an ASCII "k" on some
 * platforms, which would make the rule differ between SDKs.
 */
internal object HttpsOrigin {
    private const val DNS_LABEL = "[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?"
    private val ORIGIN_PATTERN =
        Regex("^https://($DNS_LABEL(?:\\.$DNS_LABEL)*)(?::([0-9]{1,5}))?/?$")
    private val PRINTABLE_ASCII = Regex("^[\\x21-\\x7E]*$")
    private val LETTER = Regex("[a-z]")
    private val HEX_NUMBER = Regex("^0x[0-9a-f]*$")
    private val IPV4_OCTET = Regex("^(?:0|[1-9][0-9]{0,2})$")

    private const val HOST_GROUP = 1
    private const val PORT_GROUP = 2
    private const val DEFAULT_HTTPS_PORT = 443
    private const val MAX_PORT = 65_535
    private const val MAX_OCTET = 255
    private const val IPV4_OCTET_COUNT = 4

    /**
     * Returns the normalized origin (lowercase, no default `:443`, no trailing
     * slash), or `null` when [raw] is not an https origin under the rule above.
     * Leading and trailing whitespace is ignored; a blank value is rejected.
     */
    fun normalize(raw: String): String? {
        val candidate = raw.trim().takeIf { PRINTABLE_ASCII.matches(it) }?.lowercase()
        val match = candidate?.let { ORIGIN_PATTERN.matchEntire(it) }
        val host = match?.groupValues?.get(HOST_GROUP)?.takeIf(::isAcceptableHost)
        val port =
            match
                ?.groups
                ?.get(PORT_GROUP)
                ?.value
                ?.toInt()
        return when {
            host == null -> null
            port == null || port == DEFAULT_HTTPS_PORT -> "https://$host"
            port in 1..MAX_PORT -> "https://$host:$port"
            else -> null
        }
    }

    /** [host] is already lowercase and made only of valid DNS labels. */
    private fun isAcceptableHost(host: String): Boolean {
        val labels = host.split('.')
        val last = labels.last()
        return if (LETTER.containsMatchIn(last)) !HEX_NUMBER.matches(last) else isDottedQuad(labels)
    }

    private fun isDottedQuad(labels: List<String>): Boolean =
        labels.size == IPV4_OCTET_COUNT &&
            labels.all { IPV4_OCTET.matches(it) && it.toInt() <= MAX_OCTET }
}
