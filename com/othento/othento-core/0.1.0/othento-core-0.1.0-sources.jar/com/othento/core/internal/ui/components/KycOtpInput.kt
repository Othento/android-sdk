@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MatchingDeclarationName")

package com.othento.core.internal.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import kotlinx.coroutines.launch

/** Spec §7 — `state`. Source: `apps/sdk/.../kyc-otp-input.scss:39-50`. */
@Immutable
internal enum class KycOtpInputState { Default, Error }

/**
 * N-cell OTP code entry. Faithful port of `apps/sdk/.../kyc-otp-input/`:
 *
 * - Cells 44 × 52, 22 sp text centered, 1 dp `--color-border`, `--radius-sm`.
 * - `:focus` paints a 3 dp **outer** halo (`box-shadow 0 0 0 3px <tone-bg>`).
 * - Error state: red border + `kyc-otp-shake` 320 ms ease-in-out keyframe
 *   (translate ±4 / ±2 / 0 px); error + focus halo color is `error-bg`.
 * - Multi-character input distributes across cells starting at the focused
 *   cell (handles paste + autofill).
 * - Backspace on an empty cell focuses the previous cell.
 * - [onComplete] fires once per "filled" transition (deduped via
 *   `lastCompleteCode` state).
 *
 * Phase 9 will wire SMS Retriever / SMS User Consent for autofill — see U8.
 */
@Composable
@Suppress("LongParameterList", "LongMethod", "CyclomaticComplexMethod")
internal fun KycOtpInput(
    code: String,
    onCodeChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    length: Int = DefaultLength,
    alphanumeric: Boolean = false,
    disabled: Boolean = false,
    state: KycOtpInputState = KycOtpInputState.Default,
    onComplete: (String) -> Unit = {},
) {
    val motion = LocalOthentoMotion.current
    val density = LocalDensity.current

    val cells = remember(length) { Array(length) { FocusRequester() } }
    val padded = code.padEnd(length, ' ').take(length)

    val shakeOffset = remember { Animatable(0f) }
    val shakeAmpPx = with(density) { ShakeAmpDp.toPx() }
    val shakeAmpHalfPx = with(density) { ShakeAmpHalfDp.toPx() }
    val scope = rememberCoroutineScope()
    var lastErrorState by remember { mutableStateOf(state) }
    LaunchedEffect(state) {
        if (state == KycOtpInputState.Error && lastErrorState != KycOtpInputState.Error && !motion.reducedMotion) {
            scope.launch {
                runShake(shakeOffset, motion.durationSlowMs, shakeAmpPx, shakeAmpHalfPx, motion.easeInOut)
            }
        }
        lastErrorState = state
    }

    var lastCompleteCode by remember { mutableStateOf<String?>(null) }

    Row(
        modifier = modifier.graphicsLayer { translationX = shakeOffset.value },
        horizontalArrangement = Arrangement.spacedBy(CellGap, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (index in 0 until length) {
            val previousCellChar = padded[index].takeIf { it != ' ' }?.toString().orEmpty()
            OtpCell(
                value = previousCellChar,
                state = state,
                disabled = disabled,
                focusRequester = cells[index],
                alphanumeric = alphanumeric,
                onValueChanged = { incoming ->
                    val updated =
                        applyOtpInput(
                            current = code,
                            cellIndex = index,
                            incoming = incoming,
                            previousCellValue = previousCellChar,
                            length = length,
                            alphanumeric = alphanumeric,
                        )
                    onCodeChange(updated)
                    advanceFocus(cells, index, incoming.length)
                    val isFilled = updated.length == length && updated.all { it != ' ' }
                    if (isFilled && lastCompleteCode != updated) {
                        lastCompleteCode = updated
                        onComplete(updated)
                    } else if (!isFilled) {
                        lastCompleteCode = null
                    }
                },
                onBackspaceOnEmpty = {
                    if (index > 0) cells[index - 1].requestFocus()
                },
            )
        }
    }
}

@Composable
@Suppress("LongParameterList", "LongMethod")
private fun OtpCell(
    value: String,
    state: KycOtpInputState,
    disabled: Boolean,
    focusRequester: FocusRequester,
    alphanumeric: Boolean,
    onValueChanged: (String) -> Unit,
    onBackspaceOnEmpty: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val shapes = LocalOthentoShapes.current
    val typography = LocalOthentoTypography.current
    val motion = LocalOthentoMotion.current
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    val targetBorder =
        when {
            disabled -> colors.border
            state == KycOtpInputState.Error -> colors.error
            isFocused -> colors.primary
            else -> colors.border
        }
    val haloTone = if (state == KycOtpInputState.Error) colors.errorBg else colors.primaryBg
    val borderColor by animateColorAsState(
        targetValue = targetBorder,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-otp-border",
    )
    val haloColor by animateColorAsState(
        targetValue = if (isFocused && !disabled) haloTone else Color.Transparent,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-otp-halo",
    )

    val keyboardType = if (alphanumeric) KeyboardType.Text else KeyboardType.Number
    val tfv =
        TextFieldValue(
            text = value,
            selection = TextRange(value.length),
        )

    Box(
        modifier =
            Modifier
                .width(CellWidth)
                .height(CellHeight)
                .alpha(if (disabled) DisabledAlpha else 1f)
                .drawBehind {
                    if (haloColor != Color.Transparent) {
                        val r = SmRadiusDp.toPx()
                        val w = FocusGlowWidthDp.toPx()
                        drawRoundRect(
                            color = haloColor,
                            topLeft = Offset(-w, -w),
                            size = Size(size.width + 2f * w, size.height + 2f * w),
                            cornerRadius = CornerRadius(r + w, r + w),
                        )
                    }
                }.clip(shapes.sm)
                .background(colors.bgBase)
                .border(width = 1.dp, color = borderColor, shape = shapes.sm),
        contentAlignment = Alignment.Center,
    ) {
        BasicTextField(
            value = tfv,
            onValueChange = { incoming -> onValueChanged(incoming.text) },
            modifier =
                Modifier
                    .focusRequester(focusRequester)
                    .onKeyEvent { event ->
                        if (event.type == KeyEventType.KeyDown && event.key == Key.Backspace && value.isEmpty()) {
                            onBackspaceOnEmpty()
                            true
                        } else {
                            false
                        }
                    },
            enabled = !disabled,
            singleLine = true,
            interactionSource = interactionSource,
            textStyle =
                typography.otpCell.copy(
                    color = colors.textPrimary,
                    textAlign = TextAlign.Center,
                ),
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            cursorBrush = SolidColor(colors.primary),
            decorationBox = { inner -> inner() },
        )
    }
}

@Suppress("LongParameterList")
internal fun applyOtpInput(
    current: String,
    cellIndex: Int,
    incoming: String,
    length: Int,
    alphanumeric: Boolean,
    previousCellValue: String = "",
): String {
    val padded = current.padEnd(length, ' ').toCharArray()
    val sanitized = if (alphanumeric) incoming.filter { it.isLetterOrDigit() } else incoming.filter { it.isDigit() }
    if (sanitized.isEmpty()) {
        val userDeleted = incoming.isEmpty() && previousCellValue.isNotEmpty()
        if (userDeleted && cellIndex in 0 until length) padded[cellIndex] = ' '
    } else {
        var write = cellIndex
        for (ch in sanitized) {
            if (write >= length) break
            padded[write] = ch
            write += 1
        }
    }
    return padded.concatToString().trimEnd(' ')
}

private fun advanceFocus(
    cells: Array<FocusRequester>,
    fromIndex: Int,
    inputLength: Int,
) {
    val target = (fromIndex + inputLength.coerceAtLeast(1)).coerceAtMost(cells.size - 1)
    if (target != fromIndex) cells[target].requestFocus()
}

private suspend fun runShake(
    animatable: Animatable<Float, *>,
    durationMs: Int,
    ampPx: Float,
    halfAmpPx: Float,
    easing: androidx.compose.animation.core.Easing,
) {
    val perSegment = durationMs / SHAKE_SEGMENTS
    animatable.snapTo(0f)
    animatable.animateTo(targetValue = -ampPx, animationSpec = tween(perSegment, easing = easing))
    animatable.animateTo(targetValue = ampPx, animationSpec = tween(perSegment, easing = easing))
    animatable.animateTo(targetValue = -halfAmpPx, animationSpec = tween(perSegment, easing = easing))
    animatable.animateTo(targetValue = halfAmpPx, animationSpec = tween(perSegment, easing = easing))
    animatable.animateTo(targetValue = 0f, animationSpec = tween(perSegment, easing = easing))
}

private const val DefaultLength = 6
private val CellWidth = 44.dp
private val CellHeight = 52.dp
private val CellGap = 8.dp
private val FocusGlowWidthDp = 3.dp
private val SmRadiusDp = 4.dp
private const val DisabledAlpha = 0.5f
private val ShakeAmpDp = 4.dp
private val ShakeAmpHalfDp = 2.dp
private const val SHAKE_SEGMENTS = 5
