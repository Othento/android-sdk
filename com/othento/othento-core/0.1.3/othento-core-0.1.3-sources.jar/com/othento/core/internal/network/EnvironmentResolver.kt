package com.othento.core.internal.network

import com.othento.core.api.OthentoConfig

/**
 * Internal-only resolver that picks the backend base URL from the
 * host-supplied [OthentoConfig]. Replaces the public `OthentoEnvironment` enum
 * the SDK used to expose — the cross-platform contract requires the
 * apiKey prefix (and only the apiKey prefix) to drive sandbox vs
 * production.
 *
 * Resolution rules:
 *
 * | Mode     | apiKey prefix     | Backend      |
 * | -------- | ----------------- | ------------ |
 * | Create   | `pk_live_…`       | Production   |
 * | Create   | `pk_sandbox_…`    | Sandbox      |
 * | Create   | anything else     | Sandbox      |
 * | Token    | (no apiKey)       | Sandbox      |
 *
 * "Anything else" defaults to sandbox so a misconfigured key fails closed
 * — it cannot silently bill against a live account. Token mode without an
 * apiKey also defaults to sandbox because dev SATs are minted against
 * sandbox far more often than against production; production hosts
 * minting live SATs should provide the matching `pk_live_…` apiKey on
 * the config (the Builder no longer requires it for Token mode, but
 * accepting one routes correctly).
 */
internal object EnvironmentResolver {
    const val SANDBOX_BASE_URL: String = "https://be-dev.zetatech.ae:5160"
    const val PRODUCTION_BASE_URL: String = "https://sdk-api.othento.com"

    private const val LIVE_PREFIX = "pk_live_"

    fun resolveBaseUrl(config: OthentoConfig): String =
        if (config.apiKey?.startsWith(LIVE_PREFIX) == true) {
            PRODUCTION_BASE_URL
        } else {
            SANDBOX_BASE_URL
        }
}
