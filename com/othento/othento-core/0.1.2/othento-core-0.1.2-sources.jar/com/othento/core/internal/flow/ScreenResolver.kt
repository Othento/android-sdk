package com.othento.core.internal.flow

import com.othento.core.internal.data.model.ActiveStep
import com.othento.core.internal.data.model.ActiveStepStatus
import com.othento.core.internal.data.model.ChallengeType
import com.othento.core.internal.data.model.Decision
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.data.model.SessionStatus
import com.othento.core.internal.data.model.isAwaitingEvidence

/**
 * Pure function: maps a domain [Session] to the [ScreenState] the user
 * should see. Mirrors the web SDK's `resolveScreenForStep` +
 * `mapStatusToScreen` from
 * [apps/sdk/.../services/session/step-screen-resolver.ts] and
 * [sdk-token-session.service.ts:84-108].
 *
 * Phase 5 implements:
 * - Status-driven branches (Created / InProgress / Processing / Expired /
 *   Failed / Completed) — unchanged from Phase 4 except `InProgress` now
 *   defers to step-driven resolution.
 * - Step-driven branches for `step_id_verification` (DocumentSelect /
 *   CaptureFront / CaptureBack / Processing).
 * - Defensive fallthroughs for face-match (with-liveness → Processing,
 *   without → Error("Phase 7+ deferred")), OTP → Error("Phase 9 deferred").
 *
 * Per spec OQ #5, a `Completed` session with `decision == null` is treated
 * as a bug indicator — [ScreenState.Error] rather than the web's
 * random-fallback pick across the three terminal decisions.
 */
internal object ScreenResolver {
    fun resolve(session: Session): ScreenState =
        when {
            // Mirror the web's `resolveScreen`: a `Failed` status wins over a
            // lingering `currentStep`, so a mid-flow retry lands on the retry
            // screen rather than re-entering a capture surface.
            session.status == SessionStatus.Failed -> resolveByStatus(session)
            session.currentStep != null -> resolveByStep(session.currentStep, session)
            else -> resolveByStatus(session)
        }

    /**
     * Inspects the step's `stepCode` first, then its `challenges` /
     * `status` fields. Order matches the web's resolver so the screen
     * decision-table reads the same way across platforms.
     */
    private fun resolveByStep(
        step: ActiveStep,
        session: Session,
    ): ScreenState =
        when (step.stepCode) {
            STEP_ID_VERIFICATION -> resolveIdVerification(step, session)
            STEP_FACE_MATCH -> resolveFaceMatch(session)
            STEP_LIVENESS_CHECK -> resolveLiveness(step)
            STEP_PHONE_VERIFICATION -> ScreenState.OtpPhone
            STEP_EMAIL_VERIFICATION -> ScreenState.OtpEmail
            else -> ScreenState.Error
        }

    private fun resolveIdVerification(
        step: ActiveStep,
        session: Session,
    ): ScreenState {
        val awaitingFront =
            step.challenges.any {
                it.challengeType == ChallengeType.DocumentFront && it.challengeStatus.isAwaitingEvidence
            }
        val awaitingBack =
            step.challenges.any {
                it.challengeType == ChallengeType.DocumentBack && it.challengeStatus.isAwaitingEvidence
            }
        return when {
            // Pre-initiate: the document hasn't been picked yet. Web treats
            // this as `document_select`; we mirror it.
            session.selectedDocument == null && !awaitingFront && !awaitingBack -> ScreenState.DocumentSelect
            awaitingFront -> ScreenState.CaptureFront
            awaitingBack -> ScreenState.CaptureBack
            step.status == ActiveStepStatus.SentToInference || step.status == ActiveStepStatus.InferenceProcessing ->
                ScreenState.Processing
            // Defensive: shouldn't happen on a well-formed session but the
            // web also falls back to document_select here, so we follow.
            else -> ScreenState.DocumentSelect
        }
    }

    @Suppress("ReturnCount")
    // Reason: each early return covers a distinct case (liveness step
    // present → Processing; missing currentStep → Error; awaiting selfie /
    // inference / fallthrough). Collapsing into a single `when` would
    // require pre-computing both the step and the awaitingSelfie flag for
    // the early branches that don't read them.
    private fun resolveFaceMatch(session: Session): ScreenState {
        val hasLivenessStep = session.steps.any { it.stepCode == STEP_LIVENESS_CHECK }
        if (hasLivenessStep) {
            // Web: face match is auto-derived when liveness ships, so the
            // user never sees a face-match screen — the liveness step (and
            // its dedicated `resolveLiveness` branch above) drives the
            // capture surface instead.
            return ScreenState.Processing
        }
        val step = session.currentStep ?: return ScreenState.Error
        val awaitingSelfie =
            step.challenges.any {
                it.challengeType == ChallengeType.Selfie && it.challengeStatus.isAwaitingEvidence
            }
        return when {
            awaitingSelfie -> ScreenState.SelfieCapture
            step.status == ActiveStepStatus.SentToInference || step.status == ActiveStepStatus.InferenceProcessing ->
                ScreenState.Processing
            else -> ScreenState.Error
        }
    }

    /**
     * Phase 8 — when the active step is `step_liveness_check` we route to
     * the same [ScreenState.SelfieCapture] surface as face match. The
     * screen reads `Session.selfieKind` to switch chrome copy and choose
     * the upload challenge type. Spec
     * [docs/spec/06-screens/08-selfie-capture.md] line 220 — "Liveness step
     * has the same UI as face-match".
     */
    @Suppress("ReturnCount")
    // Reason: four early returns, one per challenge shape (rekognition /
    // passive video / unknown / inference). A single `when` would have to
    // pre-compute all four predicates on every call.
    private fun resolveLiveness(step: ActiveStep): ScreenState {
        // Phase 10 — checked first, and matching `Queued` as well as
        // `AwaitingUpload`: the Rekognition challenge is session-based with no
        // upload, so the backend parks it in `Queued` while it waits for the
        // user (web does the same — `step-screen-resolver.ts`). A resolver
        // copied from the passive path, matching `AwaitingUpload` only, would
        // never route here.
        val awaitingRekognition =
            step.challenges.any {
                it.challengeType == ChallengeType.RekognitionLivenessSession &&
                    it.challengeStatus.isAwaitingEvidence
            }
        if (awaitingRekognition) return ScreenState.RekognitionLiveness

        val awaitingVideo =
            step.challenges.any {
                it.challengeType == ChallengeType.LivenessVideo && it.challengeStatus.isAwaitingEvidence
            }
        if (awaitingVideo) return ScreenState.SelfieCapture

        // Forward-compatibility guard: the backend shipped a liveness method
        // this build does not know about. Only reachable because the tolerant
        // adapter now falls back to `Unknown` instead of `DocumentFront`.
        val awaitingUnknown =
            step.challenges.any {
                it.challengeType == ChallengeType.Unknown && it.challengeStatus.isAwaitingEvidence
            }
        if (awaitingUnknown) return ScreenState.UnsupportedUpdate

        return when {
            step.status == ActiveStepStatus.SentToInference || step.status == ActiveStepStatus.InferenceProcessing ->
                ScreenState.Processing
            else -> ScreenState.Error
        }
    }

    private fun resolveByStatus(session: Session): ScreenState =
        when (session.status) {
            SessionStatus.Created -> ScreenState.Start
            SessionStatus.InProgress, SessionStatus.Processing -> ScreenState.Processing
            SessionStatus.Expired -> ScreenState.Expired
            // Web parity (`mapStatusToScreen`): a retryable failure routes to
            // the recovery screen. Token mode signals it via `canReinitiate`;
            // fall back to `canInitiate` for robustness.
            SessionStatus.Failed ->
                if (session.canReinitiate || session.canInitiate) {
                    ScreenState.FailedRetry
                } else {
                    ScreenState.FailedTerminal
                }
            SessionStatus.Completed ->
                when (session.decision) {
                    Decision.Approved -> ScreenState.Approved
                    Decision.Declined -> ScreenState.Declined
                    Decision.InReview -> ScreenState.InReview
                    null -> ScreenState.Error
                }
        }

    /**
     * Spec [docs/spec/09-data-models.md] — every `stepCode` the resolver
     * branches on. Mirror of the web's `STEP_CODES` constants in
     * `apps/sdk/.../models/session.model.ts`.
     */
    internal const val STEP_ID_VERIFICATION: String = "step_id_verification"
    internal const val STEP_FACE_MATCH: String = "step_face_match"
    internal const val STEP_LIVENESS_CHECK: String = "step_liveness_check"
    internal const val STEP_PHONE_VERIFICATION: String = "step_phone_verification"
    internal const val STEP_EMAIL_VERIFICATION: String = "step_email_verification"
}
