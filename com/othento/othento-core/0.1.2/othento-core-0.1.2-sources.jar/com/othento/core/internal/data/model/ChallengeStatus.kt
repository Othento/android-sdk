package com.othento.core.internal.data.model

/**
 * Lifecycle of a single challenge inside the active step.
 *
 * Per [docs/spec/09-data-models.md §1.7] the canonical enum is
 * `AwaitingUpload | Uploaded`. Test fixtures reference an additional
 * `OtpSent` value (open question 1 in the spec); Phase 9 will revisit.
 */
internal enum class ChallengeStatus {
    AwaitingUpload,

    /**
     * The backend is waiting on the user for a challenge that has no upload —
     * currently only [ChallengeType.RekognitionLivenessSession]. Web has
     * carried this value since the Rekognition work landed
     * (`apps/sdk/.../models/session.model.ts`).
     *
     * Before this constant existed, a `Queued` wire value was coerced to
     * [AwaitingUpload] by the tolerant adapter. Every resolver branch
     * therefore treats the two identically via [isAwaitingEvidence] — that is
     * what keeps the passive path's behaviour unchanged.
     */
    Queued,
    Uploaded,
}

/**
 * Whether the backend is still waiting on the user for this challenge.
 *
 * Deliberately accepts both [ChallengeStatus.AwaitingUpload] and
 * [ChallengeStatus.Queued]: prior to the `Queued` constant, a `Queued` wire
 * value decoded as `AwaitingUpload`, so any branch matching `AwaitingUpload`
 * already matched `Queued` payloads. Narrowing the existing branches to
 * `AwaitingUpload` alone would be a silent behaviour change on the passive
 * path, which this feature is required not to touch.
 */
internal val ChallengeStatus.isAwaitingEvidence: Boolean
    get() = this == ChallengeStatus.AwaitingUpload || this == ChallengeStatus.Queued
