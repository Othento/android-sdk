package com.othento.core.internal.capture.detection.passport

import com.othento.core.internal.capture.CaptureHint
import kotlin.math.max
import kotlin.math.min

/**
 * Framing state of a detected passport relative to the cutout.
 *  - [Ok]        centered with margin on both sides
 *  - [TooFar]    MRZ too narrow — passport too small/distant
 *  - [TooClose]  both side margins too small (zoomed in, both edges cut off)
 *  - [OffLeft]   left margin too small (passport pushed left → move it right)
 *  - [OffRight]  right margin too small (passport pushed right → move it left)
 *
 * Ports the web SDK's passport-alignment behaviour (ekyc-frontend 749ea45).
 */
internal enum class MrzFraming { Ok, TooFar, TooClose, OffLeft, OffRight }

/** One ML Kit OCR text-line box in upright image pixels. Width = right - left. */
internal data class MrzLineBox(
    val left: Int,
    val right: Int,
    val height: Int,
)

/**
 * Union horizontal extent (left, right) in pixels of the MRZ-like lines —
 * those whose box aspect ratio (long/short side) is at least [minAspect]. The
 * MRZ band is a single wide, high-aspect row; printed name/date fields are far
 * shorter, so the aspect filter isolates the MRZ. Returns null when no line
 * qualifies (extent unmeasurable → caller treats framing as Ok / non-blocking).
 * Aspect is orientation-agnostic (long/short side); callers pass ML Kit MRZ-row boxes,
 * which are always wider than tall, so a tall-narrow box cannot be admitted in practice.
 */
internal fun mrzExtentPx(
    lines: List<MrzLineBox>,
    minAspect: Float,
): Pair<Int, Int>? {
    var left = Int.MAX_VALUE
    var right = Int.MIN_VALUE
    for (box in lines) {
        val width = box.right - box.left
        if (width <= 0 || box.height <= 0) continue
        val aspect = max(width, box.height).toFloat() / min(width, box.height).toFloat()
        if (aspect < minAspect) continue
        if (box.left < left) left = box.left
        if (box.right > right) right = box.right
    }
    return if (right > left) left to right else null
}

/**
 * Classify framing from the MRZ's per-side margins (fractions of cutout width).
 * Ported 1:1 from the web SDK's `evaluateMrzFraming` (749ea45) — returns only
 * Ok / TooClose / OffLeft / OffRight; [MrzFraming.TooFar] is produced upstream
 * by [classifyMrzFraming]'s width pre-check.
 */
internal fun evaluateMrzFraming(
    leftMargin: Float,
    rightMargin: Float,
    marginMin: Float,
): MrzFraming {
    val leftOk = leftMargin >= marginMin
    val rightOk = rightMargin >= marginMin
    return when {
        leftOk && rightOk -> MrzFraming.Ok
        !leftOk && !rightOk -> MrzFraming.TooClose
        leftOk -> MrzFraming.OffRight
        else -> MrzFraming.OffLeft
    }
}

/**
 * Full passport framing from the MRZ extent and cutout, all as view-normalized
 * upright fractions (0..1). A too-narrow MRZ (below [minWidthCoverage] of the
 * cutout width) is [MrzFraming.TooFar]; otherwise the per-side margins drive
 * [evaluateMrzFraming]. Returns [MrzFraming.Ok] for a degenerate cutout.
 */
internal fun classifyMrzFraming(
    mrzLeftFrac: Float,
    mrzRightFrac: Float,
    cutoutLeftFrac: Float,
    cutoutRightFrac: Float,
    sideMarginMin: Float,
    minWidthCoverage: Float,
): MrzFraming {
    val cutoutWidth = cutoutRightFrac - cutoutLeftFrac
    if (cutoutWidth <= 0f) return MrzFraming.Ok
    val widthCoverage = (mrzRightFrac - mrzLeftFrac) / cutoutWidth
    if (widthCoverage < minWidthCoverage) return MrzFraming.TooFar
    val leftMargin = (mrzLeftFrac - cutoutLeftFrac) / cutoutWidth
    val rightMargin = (cutoutRightFrac - mrzRightFrac) / cutoutWidth
    return evaluateMrzFraming(leftMargin, rightMargin, sideMarginMin)
}

/**
 * Status-pill hint for a non-ok framing, or null when [MrzFraming.Ok].
 * TooClose/OffLeft/OffRight copy is verbatim from the web SDK (749ea45).
 * [MrzFraming.TooFar] is Android-specific — a clear "move closer" instead of the
 * web's generic "Align the passport inside the frame", so the four directional
 * hints (closer / farther / right / left) read as a coherent set.
 */
internal fun framingHint(framing: MrzFraming): CaptureHint? =
    when (framing) {
        MrzFraming.Ok -> null
        MrzFraming.TooFar -> CaptureHint.PassportMoveCloser
        MrzFraming.TooClose -> CaptureHint.PassportMoveFurther
        MrzFraming.OffLeft -> CaptureHint.PassportMoveRight
        MrzFraming.OffRight -> CaptureHint.PassportMoveLeft
    }
