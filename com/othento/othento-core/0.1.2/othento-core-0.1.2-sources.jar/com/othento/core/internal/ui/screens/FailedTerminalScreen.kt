@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.ResultMode
import com.othento.core.internal.content.ResultTone
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.screens.common.ContentStatusScreen
import com.othento.core.internal.ui.screens.common.returnToAppLabel
import com.othento.core.internal.ui.screens.common.StatusAction

/**
 * `result.failed.*` — red cross, non-recoverable. Distinguished from
 * `Declined` (a definitive negative inference) by happening **without a
 * decision**: abuse, system failure, or max attempts.
 */
@Composable
internal fun FailedTerminalScreen(onReturnToApp: () -> Unit) {
    ContentStatusScreen(
        prefix = ContentKeys.RESULT_FAILED,
        fallbackIcon = StatusIconName.Cross,
        fallbackTone = ResultTone.Error,
        fallbackMode = ResultMode.Terminal,
        primaryAction = StatusAction(label = returnToAppLabel(), onClick = onReturnToApp),
    )
}
