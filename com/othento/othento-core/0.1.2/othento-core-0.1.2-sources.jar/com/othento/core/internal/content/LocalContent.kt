package com.othento.core.internal.content

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * Injection point for the copy bundle — mirrors the existing `OthentoTheme`
 * CompositionLocals so a screen reads content the same way it reads colours.
 *
 * The default is [ContentBundle.Empty] rather than an `error(...)`, on purpose:
 * every lookup then falls through to [ContentFallback], whose values are
 * byte-identical to the strings the screens hard-coded before this
 * integration. That keeps the 105 existing Paparazzi snapshots rendering the
 * same pixels without threading a provider through every test (plan §7).
 */
internal val LocalContent =
    staticCompositionLocalOf<ContentBundle> { ContentBundle.Empty }

/** `content(key)` — the shorthand screens use for a plain string. */
@Composable
@ReadOnlyComposable
internal fun content(key: String): String = LocalContent.current.text(key)

/** `content(key, args)` — numeric `{named}` substitution (plan §3.1). */
@Composable
@ReadOnlyComposable
internal fun content(
    key: String,
    vararg args: Pair<String, Any>,
): String = LocalContent.current.text(key, args.toMap())

/**
 * The language the backend **resolved** for the current bundle, for the copy
 * we derive on-device rather than fetch — country names, and their sort order.
 *
 * Falls back to `en`, matching the backend's own resolution when a tenant has
 * no translation. Note this is the resolved language, never the requested one:
 * asking for `?locale=ar` on a tenant without Arabic returns English, and
 * localising country names into Arabic on an otherwise-English screen would be
 * worse than not localising them at all.
 */
@Composable
@ReadOnlyComposable
internal fun contentLanguage(): String = LocalContent.current.currentLanguage() ?: DEFAULT_LANGUAGE

private const val DEFAULT_LANGUAGE = "en"

/**
 * `contentFor(prefix, key, fallback)` — copy for a backend-supplied identifier
 * (a `documentTypeCode`, a `declineReasonKey`, an error `code`), falling back
 * to the backend's own English.
 *
 * Deliberately resolved in the composition rather than where the identifier
 * arrives: a language switch then re-renders the label, instead of stranding
 * it in whichever language was active when the response landed.
 */
@Composable
@ReadOnlyComposable
internal fun contentFor(
    prefix: String,
    key: String?,
    fallback: String?,
): String = LocalContent.current.resolveBackendCopy(prefix, key, fallback)

/** `contentPlural(key, count)` — picks `key.one` / `key.other` and injects `{count}`. */
@Composable
@ReadOnlyComposable
internal fun contentPlural(
    key: String,
    count: Int,
): String = LocalContent.current.plural(key, count)
