@file:Suppress(
    "LongParameterList",
    // Reason: all 7 constructor parameters are independent configuration knobs
    // (pipeline, cutout source, three fps cadences, two optional ML Kit sub-detectors).
    // Folding them into a config data class would add indirection without benefit for
    // this internal class.
)

package com.othento.core.internal.capture

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.RectF
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.othento.core.internal.capture.detection.passport.MrzDetector
import com.othento.core.internal.capture.detection.passport.PassportPhotoGate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Adapts CameraX's `ImageAnalysis.Analyzer` callback to a [DetectionPipeline].
 *
 * Cadence: enforced by sleeping between frames if processing finishes faster
 * than 1/[targetFps]. CameraX's `STRATEGY_KEEP_ONLY_LATEST` ensures we drop
 * frames if processing falls behind — we never queue.
 *
 * For passport screens, [mrz] and [faceGate] schedule their own ML Kit work
 * at independent cadences ([mrzFps] and [faceFps]) — the analyzer fires off
 * those scheduled calls in addition to the main detection pass. ML Kit
 * results are read from `snapshot()` by the pipeline on its next tick.
 *
 * The cutout is supplied as a [RectF] of view-normalized fractions (0..1)
 * where (0,0) is the upright top-left and (1,1) is the upright bottom-right
 * of the camera viewport on screen. The analyzer converts these fractions
 * to per-frame image-coord [Rect]s using `image.width`, `image.height`, and
 * `image.imageInfo.rotationDegrees`. This decouples detection from the
 * preview/analysis resolution mismatch that arises when CameraX hands
 * different surfaces different sizes (typical when `VideoCapture` joins
 * the bind).
 */
internal class FrameAnalyzer(
    private val pipeline: DetectionPipeline,
    private val cutoutFractionProvider: () -> RectF,
    private val targetFps: Int = CaptureConfig.ANALYZER_TARGET_FPS,
    private val mrz: MrzDetector? = null,
    private val faceGate: PassportPhotoGate? = null,
    private val mrzFps: Int = CaptureConfig.TEXT_CADENCE_FPS,
    private val faceFps: Int = CaptureConfig.FACE_CADENCE_FPS,
    private val previewFps: Int = CaptureConfig.PREVIEW_RENDER_FPS,
) : ImageAnalysis.Analyzer {
    private var lastProcessedAtNs = 0L
    private var lastMrzAtNs = 0L
    private var lastFaceAtNs = 0L
    private var lastPreviewAtNs = 0L
    private val periodNs: Long = NS_PER_SECOND / targetFps.coerceAtLeast(1)
    private val mrzPeriodNs: Long = NS_PER_SECOND / mrzFps.coerceAtLeast(1)
    private val facePeriodNs: Long = NS_PER_SECOND / faceFps.coerceAtLeast(1)
    private val previewPeriodNs: Long = NS_PER_SECOND / previewFps.coerceAtLeast(1)

    // Detection runs off the camera (analyzer) thread so SmartCropper / ML Kit can
    // never stall frame delivery — that stall was the original preview jank. The
    // SmartCropper + quality pass is single-flight on this executor; a tick is
    // dropped while the previous pass is still running (KEEP_ONLY_LATEST).
    private val detectExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val detectBusy = AtomicBoolean(false)

    /**
     * CW degrees to rotate the raw camera bitmap to upright. Set from the bind
     * result's deterministic sensor rotation; the per-frame
     * `imageInfo.rotationDegrees` proved unreliable on some devices (came back 0,
     * leaving the preview sideways). -1 means "fall back to imageInfo".
     */
    @Volatile
    var uprightRotationDegrees: Int = -1

    /**
     * Latest camera frame as an upright [Bitmap], for the 2-stream capture path
     * that renders its own preview from the analysis stream (instead of binding
     * a separate Preview use case that would share — and cap — the VideoCapture
     * stream). Null until the first frame. Emitted at [previewFps]; detection
     * keeps its own (slower) cadence. Back-camera frames need no mirroring.
     */
    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    /** Cumulative number of frames delivered by CameraX to [analyze], including cadence-skipped frames. */
    private val _frameCount = MutableStateFlow(0)
    val frameCount: StateFlow<Int> = _frameCount.asStateFlow()

    /** Last unhandled exception caught from the pipeline. Empty when no failure. */
    private val _lastError = MutableStateFlow("")
    val lastError: StateFlow<String> = _lastError.asStateFlow()

    /**
     * Diagnostic: dimensions and rotationDegrees of the last delivered ImageProxy,
     * formatted as "WxH rot=N". Consumed by the debug overlay so the human can
     * verify the cutout rect (in claimed sensor coords) actually lines up with
     * the analyzer frame's coordinate space.
     */
    private val _lastFrameInfo = MutableStateFlow("")
    val lastFrameInfo: StateFlow<String> = _lastFrameInfo.asStateFlow()

    /**
     * Diagnostic: the most recent image-coord cutout rect the pipeline saw,
     * formatted as "L,T,R,B". Surfaced to the debug overlay so divergence
     * between the cutout and the analyzer frame's bounds is visible.
     */
    private val _lastCutout = MutableStateFlow("")
    val lastCutout: StateFlow<String> = _lastCutout.asStateFlow()

    /**
     * Structured image dimensions for the most recent ImageProxy: (width,
     * height, rotationDegrees). Consumed by the live polygon overlay to
     * map detected corners (in unrotated image coords) into upright view
     * fractions, the same projection used by [computeCutoutInImageCoords]
     * but in reverse. Defaults to (0, 0, 0) before the first frame.
     */
    private val _lastFrameDims = MutableStateFlow(Triple(0, 0, 0))
    val lastFrameDims: StateFlow<Triple<Int, Int, Int>> = _lastFrameDims.asStateFlow()

    override fun analyze(image: ImageProxy) {
        _frameCount.value = _frameCount.value + 1
        _lastFrameInfo.value = "${image.width}x${image.height} rot=${image.imageInfo.rotationDegrees}"
        try {
            val nowNs = System.nanoTime()
            // Throttle to the preview cadence. Skipped frames close immediately,
            // keeping frame delivery (and therefore the preview) fast.
            if (nowNs - lastPreviewAtNs < previewPeriodNs) return
            lastPreviewAtNs = nowNs

            // One upright RGB bitmap per emitted frame, shared by the preview and
            // (asynchronously) by detection. The ImageProxy is closed right after
            // the conversion (see finally), freeing the camera to deliver the next
            // frame — detection runs on this copy, off the camera thread, so it can
            // never stall the preview. Deterministic orientation: rotationDegrees,
            // not a PixelCopy guess.
            val upright = uprightBitmap(image) ?: return
            _previewBitmap.value = upright
            _lastFrameDims.value = Triple(upright.width, upright.height, 0)
            dispatchDetection(upright, nowNs)
        } catch (t: Throwable) {
            // A malformed frame must never crash the analyzer thread / host app.
            _lastError.value = "${t.javaClass.simpleName}: ${t.message ?: "<no msg>"}"
        } finally {
            image.close()
        }
    }

    /**
     * Convert [image] to an upright RGB [Bitmap] (rotated by the frame's
     * rotationDegrees), or null on a conversion failure. The intermediate
     * unrotated bitmap is recycled; the returned bitmap is owned by the preview
     * StateFlow + async detection and reclaimed by GC.
     */
    private fun uprightBitmap(image: ImageProxy): Bitmap? =
        runCatching {
            val raw = image.toBitmap()
            val rotation = if (uprightRotationDegrees >= 0) uprightRotationDegrees else image.imageInfo.rotationDegrees
            if (rotation == 0) {
                raw
            } else {
                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                Bitmap
                    .createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
                    .also { rotated -> if (rotated != raw) raw.recycle() }
            }
        }.getOrNull()

    /**
     * Fire off detection over the upright [bitmap] at each gate's cadence. MRZ and
     * the face gate are ML Kit (async + single-flight internally); the SmartCropper
     * + quality pass is dispatched to [detectExecutor], single-flight via
     * [detectBusy]. None of this runs on the camera thread, so it never blocks
     * frame delivery. The bitmap is already upright, so the cutout is a plain
     * fraction-of-bitmap rect (rotation 0).
     */
    private fun dispatchDetection(
        bitmap: Bitmap,
        nowNs: Long,
    ) {
        val frac = cutoutFractionProvider()
        val cutout = cutoutRectFor(frac, bitmap.width, bitmap.height)
        _lastCutout.value = "${cutout.left},${cutout.top},${cutout.right},${cutout.bottom}"

        if (mrz != null && nowNs - lastMrzAtNs >= mrzPeriodNs) {
            lastMrzAtNs = nowNs
            runCatching { mrz?.schedule(bitmap, frac) }
        }
        if (faceGate != null && nowNs - lastFaceAtNs >= facePeriodNs) {
            lastFaceAtNs = nowNs
            runCatching { faceGate?.schedule(bitmap, cutout) }
        }
        if (nowNs - lastProcessedAtNs >= periodNs && detectBusy.compareAndSet(false, true)) {
            lastProcessedAtNs = nowNs
            detectExecutor.execute {
                try {
                    runCatching { pipeline.processBitmap(bitmap, cutout) }
                        .onFailure { e -> _lastError.value = "${e.javaClass.simpleName}: ${e.message ?: "<no msg>"}" }
                } finally {
                    detectBusy.set(false)
                }
            }
        }
    }

    /** Map the upright view-normalized cutout fractions to upright-bitmap pixels. */
    private fun cutoutRectFor(
        frac: RectF,
        width: Int,
        height: Int,
    ): Rect {
        if (frac.isEmpty) return Rect()
        return Rect(
            (frac.left * width).toInt().coerceIn(0, width),
            (frac.top * height).toInt().coerceIn(0, height),
            (frac.right * width).toInt().coerceIn(0, width),
            (frac.bottom * height).toInt().coerceIn(0, height),
        )
    }

    /** Shut down the detection executor. Call from the host on dispose. */
    fun shutdown() {
        detectExecutor.shutdownNow()
    }

    private companion object {
        const val NS_PER_SECOND: Long = 1_000_000_000L
    }
}
