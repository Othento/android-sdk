@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import coil.compose.AsyncImage
import coil.compose.AsyncImagePainter
import coil.compose.rememberAsyncImagePainter
import com.othento.core.internal.ui.icons.OthentoIcons

/**
 * A remote content asset that is a **white-on-transparent template**: its glyph
 * lives in the alpha channel and every pixel is white.
 *
 * Render one without a tint and you get a white rectangle — on a white surface,
 * nothing at all, with no error, no broken-image glyph and no log line
 * (plan §4.1). Web lost roughly a day to that. This composable exists so the
 * tinting rule is written down exactly once.
 *
 * The two PNGs under `brand/` are the exception: full colour, never tinted.
 * Use [ContentBrandImage] for those.
 *
 * On load failure the built-in vector takes over, resolved from the asset
 * **filename** rather than from the raw value — the value is a URL, so falling
 * back on it would render a generic placeholder (plan §4.7).
 */
@Composable
@Suppress(
    "LongParameterList",
    // Reason: url + tint + size + fallback are the four things a template PNG
    // needs to render correctly. Bundling them into a data class would let a
    // call site construct one without a tint, which is the invisible-glyph bug
    // this composable exists to prevent.
)
internal fun ContentTemplateImage(
    url: String?,
    contentDescription: String?,
    tint: Color,
    size: Dp,
    modifier: Modifier = Modifier,
    /** Used when [url] is absent, or when its filename names no built-in. */
    fallback: ImageVector? = null,
) {
    val builtIn = remember(url, fallback) { ContentIconRegistry.resolve(url) ?: fallback }

    if (url.isNullOrBlank()) {
        BuiltInGlyph(builtIn, contentDescription, tint, size, modifier)
        return
    }

    val painter = rememberAsyncImagePainter(model = url)
    if (painter.state is AsyncImagePainter.State.Error) {
        BuiltInGlyph(builtIn, contentDescription, tint, size, modifier)
        return
    }

    Image(
        painter = painter,
        contentDescription = contentDescription,
        modifier = modifier.size(size),
        contentScale = ContentScale.Fit,
        // The one line that makes a template PNG visible.
        colorFilter = ColorFilter.tint(tint),
    )
}

@Composable
private fun BuiltInGlyph(
    imageVector: ImageVector?,
    contentDescription: String?,
    tint: Color,
    size: Dp,
    modifier: Modifier,
) {
    if (imageVector == null) return
    KycIcon(
        imageVector = imageVector,
        contentDescription = contentDescription,
        sizeDp = size,
        modifier = modifier,
        tint = tint,
    )
}

/**
 * A remote content asset that carries its own colour — today only the two
 * `brand/` logos. Deliberately a separate composable from
 * [ContentTemplateImage] so "is this tinted?" is answered by the call site's
 * name rather than by an easily-defaulted boolean.
 */
@Composable
internal fun ContentBrandImage(
    url: String?,
    contentDescription: String?,
    width: Dp,
    height: Dp,
    modifier: Modifier = Modifier,
) {
    if (url.isNullOrBlank()) return
    AsyncImage(
        model = url,
        contentDescription = contentDescription,
        contentScale = ContentScale.Fit,
        modifier = modifier.size(width, height),
    )
}

/**
 * Maps an asset URL back to the built-in vector that stands in for it offline.
 *
 * **Asset filenames are the built-in ids.** That is an implicit contract:
 * renaming `icons/tips/light.png` on the bucket silently degrades its offline
 * fallback. Noted here because this registry is the only place the coupling is
 * visible (plan §4.7).
 *
 * `icons/tips/no-hand.png` has no built-in counterpart and is intentionally
 * absent — an approximate glyph would be worse than an empty slot on a tip
 * card, which collapses cleanly.
 */
internal object ContentIconRegistry {
    private val byFileName: Map<String, ImageVector> =
        mapOf(
            // icons/status/ — 96 × 96 templates
            "check" to OthentoIcons.Check,
            "cross" to OthentoIcons.Cross,
            "clock" to OthentoIcons.Clock,
            "exclamation" to OthentoIcons.Exclamation,
            // icons/tips/ — 72 × 72 templates
            "light" to OthentoIcons.Sun,
            "corners" to OthentoIcons.FourCorners,
            "glare" to OthentoIcons.Glare,
            "no-screen" to OthentoIcons.NoScreen,
            "face" to OthentoIcons.Face,
            "glasses" to OthentoIcons.Glasses,
            "neutral" to OthentoIcons.Neutral,
            "info" to OthentoIcons.Info,
        )

    /** `…/icons/tips/light.png` → the `light` built-in. */
    fun resolve(url: String?): ImageVector? {
        val stem = fileStem(url) ?: return null
        return byFileName[stem]
    }

    private fun fileStem(url: String?): String? =
        url
            ?.substringBefore('?')
            ?.substringAfterLast('/')
            ?.substringBeforeLast('.')
            ?.lowercase()
            ?.takeIf { it.isNotBlank() }
}
