package com.othento.core.internal.network.dto

import com.othento.core.internal.data.model.Decision
import com.othento.core.internal.data.model.SessionStatus
import com.squareup.moshi.JsonClass

/**
 * Single wire response shape used by **every** Android-SDK call.
 *
 * The Android SDK does not split the contract along apiKey/token modes
 * the way the web SDK does. Each launch:
 * 1. Creates a fresh session with `POST /api/v1/SessionToken/session` —
 *    authenticated with `X-API-KEY`, body = [CreateSessionRequestDto].
 *    The response is this DTO with [sessionToken] carrying a SAT (prefixed
 *    `sat:`) and the SRT-related fields all `null` / empty.
 * 2. From that point on every call is token-mode (subsequent endpoints
 *    will arrive in Phase 4+); the response shape stays the same but
 *    [sessionToken] now carries an ST (`st:` prefix), [sessionRetryToken]
 *    carries an SRT (`srt:` prefix), and the `*ExpiresAt` fields are
 *    populated.
 *
 * Spec deviation logged as P9 in `docs/spec/99-open-questions.md`. Field
 * shapes match what the dev backend at `https://be-dev.zetatech.ae:5160`
 * actually returns — `sessionRetryToken` is `null` (not the empty string
 * the web spec describes) on the create response, and several fields on
 * `currentStep` are absent rather than null.
 */
@JsonClass(generateAdapter = true)
internal data class TokenSessionResponseDto(
    val externalId: String,
    val desktopAccess: Boolean,
    val sessionUrl: String,
    val status: SessionStatus,
    val attemptNumber: Int,
    val maxAttempts: Int,
    val expiresAt: String,
    val isSandbox: Boolean,
    val estimatedPrice: Double?,
    val currentStep: ActiveStepDto?,
    val selectedDocument: SelectedDocumentDto?,
    // Defensive: `steps` defaults to empty if the wire omits it. Phase-3
    // observation: the dev backend always returns it, but a missing field
    // on a slow / proxy-cached response would otherwise fail Moshi parse.
    val steps: List<StepDto> = emptyList(),
    val canInitiate: Boolean,
    // Backend retry contract (web parity). `canReinitiate` gates the
    // `Failed -> FailedRetry` screen branch and `reinitInfo` carries the
    // authoritative attempts-remaining / steps-to-retry metadata. Both
    // default so older responses (or payloads that omit them) parse cleanly.
    val canReinitiate: Boolean = false,
    val reinitInfo: ReinitInfoDto? = null,
    val decision: Decision?,
    val sessionToken: String?,
    val sessionRetryToken: String?,
    val stExpiresAt: String?,
    val srtExpiresAt: String?,
    val declineMessage: String?,
    /**
     * Stable decline-reason identifier (`otp_max_send_attempts`,
     * `liveness_failed`, …), rendered as `decline.<key>`.
     *
     * `null` when the decline predates this taxonomy or the step has no mapped
     * reason — fall back to [declineMessage] there, and treat an unknown key
     * the same way, so a key the backend adds later degrades to English
     * instead of blanking the screen.
     */
    val declineReasonKey: String? = null,
    /**
     * The language recorded on the session. Defaults to `null` so responses
     * from a backend that does not serve the field yet still parse.
     *
     * This is the **only** place token mode can learn the language — that
     * launch did not create the session, so it never chose one. Create mode
     * gets the same value echoed back from its request.
     */
    val language: String? = null,
)
