@file:Suppress("FunctionNaming", "LongMethod", "CyclomaticComplexMethod")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.othento.core.internal.data.model.OtpChannel
import com.othento.core.internal.flow.OthentoFlowViewModel
import com.othento.core.internal.flow.OtpUiState
import com.othento.core.internal.ui.components.CountryList
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.ui.components.EmailValidationResult
import com.othento.core.internal.ui.components.EmailValidator
import com.othento.core.internal.ui.components.PhoneValidationResult
import com.othento.core.internal.ui.components.PhoneValidator
import com.othento.core.internal.ui.screens.common.StepProgress
import kotlinx.coroutines.delay

/**
 * Phase 9 — runtime OTP screen. Holds the destination draft +
 * country code + code-input draft as `rememberSaveable` so screen
 * rotation doesn't lose typed input. Drives the 1 Hz cooldown tick
 * via [LaunchedEffect].
 *
 * The phone validator instantiates lazily — the first OTP screen the
 * user lands on pays the libphonenumber metadata-load cost (~tens of
 * ms on warm start). The validator is stateless so re-creating per
 * screen is fine.
 */
@Composable
internal fun OtpScreen(
    viewModel: OthentoFlowViewModel,
    otp: OtpUiState,
    stepProgress: StepProgress,
) {
    val context = LocalContext.current
    val phoneValidator = remember { PhoneValidator(context) }

    var destinationDraft by rememberSaveable(otp.channel) { mutableStateOf("") }
    var destinationCountry by rememberSaveable(otp.channel) { mutableStateOf(CountryList.DEFAULT_CODE) }
    var code by rememberSaveable(otp.channel, otp.editing) { mutableStateOf("") }

    // Recompute validation on every keystroke. Cheap — validator runs
    // bundled metadata only.
    val (destinationError, destinationValid, contactToSend) =
        when (otp.channel) {
            OtpChannel.Phone ->
                when (val v = phoneValidator.parseAndValidate(destinationDraft, destinationCountry)) {
                    is PhoneValidationResult.Valid -> Triple<String?, Boolean, String?>(null, true, v.e164)
                    is PhoneValidationResult.Invalid ->
                        Triple<String?, Boolean, String?>(validationText(v.reason.key, v.reason.fallback), false, null)
                    PhoneValidationResult.Empty -> Triple<String?, Boolean, String?>(null, false, null)
                }
            OtpChannel.Email ->
                when (val v = EmailValidator.validate(destinationDraft, corporateOnly = otp.corporateEmailOnly)) {
                    is EmailValidationResult.Valid -> Triple<String?, Boolean, String?>(null, true, v.value)
                    is EmailValidationResult.Invalid ->
                        Triple<String?, Boolean, String?>(validationText(v.reason.key, v.reason.fallback), false, null)
                    EmailValidationResult.Empty -> Triple<String?, Boolean, String?>(null, false, null)
                }
        }

    // Clear the OTP code when the kind switches (channel rotation reset).
    LaunchedEffect(otp.channel) {
        code = ""
    }

    // 1 Hz cooldown ticker — only runs when the screen is in code-entry
    // and the cooldown is active.
    val active = !otp.editing && (otp.cooldownRemainingSec > 0 || !otp.canResend)
    val tickViewModel by rememberUpdatedState(viewModel)
    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        while (true) {
            delay(TICK_INTERVAL_MS)
            tickViewModel.onUserTickOtpCooldown()
        }
    }

    OtpScreenContent(
        otp = otp,
        destinationDraft = destinationDraft,
        destinationCountry = destinationCountry,
        destinationError = destinationError,
        destinationValid = destinationValid,
        code = code,
        stepProgress = stepProgress,
        onDestinationDraftChange = { destinationDraft = it },
        onDestinationCountryChange = { destinationCountry = it },
        onCodeChange = { code = it.take(otp.codeLength) },
        onSendClick = {
            val contact = contactToSend ?: return@OtpScreenContent
            viewModel.onUserSendOtp(contact)
        },
        onVerifyClick = { viewModel.onUserVerifyOtp(code) },
        onChangeDestination = {
            destinationDraft = otp.lastContact?.takeIf { it.isNotBlank() } ?: destinationDraft
            viewModel.onUserEditOtpDestination()
        },
        onCancelEdit = { viewModel.onUserCancelOtpEdit() },
        onDialogPrimary = {
            code = ""
            viewModel.onUserOtpDialogPrimary()
        },
        onDialogDismiss = {
            code = ""
            viewModel.onUserDismissOtpDialog()
        },
        onAcknowledgeSkipNotice = { viewModel.onUserAcknowledgeOtpSkipNotice() },
    )
}

private const val TICK_INTERVAL_MS: Long = 1000L

/**
 * Resolves a validator's [key] against the bundle, falling back to the
 * validator's own English string.
 *
 * The validators are deliberately content-free — they run in JVM unit tests
 * that assert on the enum, not on wording, so the copy has to be attached here
 * rather than inside them.
 */
@Composable
@ReadOnlyComposable
private fun validationText(
    key: String,
    fallback: String,
): String = LocalContent.current.textOrNull(key) ?: fallback
