package com.othento.core.internal.flow

import com.othento.core.internal.data.OtpErrorMapping
import com.othento.core.internal.data.OtpSendResult
import com.othento.core.internal.data.OtpVerifyResult
import com.othento.core.internal.data.otpErrorFor

/**
 * Turns an OTP failure into the inline notice the screen renders.
 *
 * This is now a two-line lookup, and that is the point. The previous version
 * regex-matched the backend's English message
 * (`corporate|business|organization|company`) to recognise the corporate-email
 * policy and attach guidance to it. That silently stopped recognising anything
 * the moment the message was not in English — and the failure mode was not a
 * blank screen but a *plausible* one: the user saw the backend's rejection
 * without the guidance explaining what to type instead.
 *
 * The result carries an identity ([OtpSendResult.Failure.code]) and English
 * prose. We map the identity to a content key when we have authored copy for
 * it, and always keep the prose as the fallback — so an unmapped or absent
 * code still shows the backend's concrete reason rather than a generic one.
 *
 * Note nothing is resolved here: [OtpNotice] is deliberately a key plus a
 * fallback, resolved at render, so a language switch re-renders the notice.
 */
internal fun OtpSendResult.Failure.toNotice(): OtpNotice = notice(code, displayMessage)

internal fun OtpVerifyResult.Failure.toNotice(): OtpNotice = notice(code, displayMessage)

private fun notice(
    code: String?,
    displayMessage: String,
): OtpNotice =
    OtpNotice(
        fallback = displayMessage,
        // Only an Inline mapping belongs on this surface. A Dialog mapping
        // reaching here would mean the repository failed to route it to the
        // blocking dialog, and rendering its prefix key as an inline sentence
        // would show a dialog *title* under the field.
        contentKey = (otpErrorFor(code) as? OtpErrorMapping.Inline)?.contentKey,
    )
