@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.components

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.othento.core.internal.capture.CaptureHint
import com.othento.core.internal.capture.detection.ValidationIssue
import com.othento.core.internal.capture.detection.ValidationWarning
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.content.content
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.internal.util.UriBitmapDecoder

/**
 * Shared preview-state composables used by both [KycCameraUploadSheet] and
 * [com.othento.core.internal.ui.screens.CaptureFallbackScreen].
 *
 * Extracted in Phase 10 so neither surface duplicates these primitives.
 */

@Composable
internal fun PreviewImage(
    uri: Uri,
    context: android.content.Context,
) {
    val colors = LocalOthentoColors.current
    val bitmap by produceState<Bitmap?>(initialValue = null, uri) {
        value = UriBitmapDecoder.decode(uri, context.contentResolver)
    }
    val bmp = bitmap
    if (bmp != null) {
        Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = content(ContentKeys.A11Y_ALT_DOCUMENT_PREVIEW),
            contentScale = ContentScale.Fit,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 180.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(width = 1.dp, color = colors.border, shape = RoundedCornerShape(8.dp)),
        )
    } else {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(colors.bgHover),
        )
    }
}

@Composable
internal fun ValidatingRow() {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        KycLoader(modifier = Modifier.size(18.dp))
        Text(
            text = content(ContentKeys.IDV_CAPTURE_CHECKING_QUALITY),
            style = typography.bodySm,
            color = colors.textSecondary,
        )
    }
}

@Composable
internal fun WarningsList(warnings: List<ValidationWarning>) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // The issue enum, not the pre-built message, is what selects the copy.
        // Quality warnings existed in three places with three different
        // wordings on web (plan §7); binding by enum here makes the content
        // bundle the single source and demotes `ValidationWarning.message` —
        // which is produced off the Compose tree — to the offline fallback.
        warnings.forEach { w -> WarningRow(message = qualityWarningText(w)) }
    }
}

/** `capture.quality.*` for [warning]'s issue, falling back to its built-in message. */
@Composable
@ReadOnlyComposable
internal fun qualityWarningText(warning: ValidationWarning): String =
    LocalContent.current.textOrNull(qualityKey(warning.issue)) ?: warning.message

/**
 * `capture.quality.*` for a bare [issue] — the live path, where the pipeline
 * emits the enum with no accompanying message.
 *
 * Shares [qualityKey] with [qualityWarningText] on purpose: the live amber
 * bubble and the post-capture review row are the same warning seen twice, and
 * on web they drifted into three different wordings precisely because each site
 * picked its own string.
 */
@Composable
@ReadOnlyComposable
internal fun qualityIssueText(issue: ValidationIssue): String =
    LocalContent.current.textOrNull(qualityKey(issue)) ?: issue.fallbackText()

/**
 * `capture.hint.*` for a live positioning nudge.
 *
 * [CaptureHint] carries its own key because the pipeline that raises it runs on
 * the analyzer thread, outside the composition — the enum crosses that boundary,
 * the sentence cannot.
 */
@Composable
@ReadOnlyComposable
internal fun captureHintText(hint: CaptureHint): String = LocalContent.current.textOrNull(hint.key) ?: hint.fallbackText

private fun qualityKey(issue: ValidationIssue): String =
    when (issue) {
        ValidationIssue.TooDark -> ContentKeys.CAPTURE_QUALITY_TOO_DARK
        ValidationIssue.TooBright -> ContentKeys.CAPTURE_QUALITY_TOO_BRIGHT
        ValidationIssue.Blurry -> ContentKeys.CAPTURE_QUALITY_BLURRY
        ValidationIssue.Glare -> ContentKeys.CAPTURE_QUALITY_GLARE
        ValidationIssue.NoCard -> ContentKeys.CAPTURE_QUALITY_NO_CARD
        ValidationIssue.NoFace -> ContentKeys.SELFIE_VALIDATION_NO_FACE
    }

/** Offline copy only — byte-identical to what the live bubble showed pre-content. */
private fun ValidationIssue.fallbackText(): String =
    when (this) {
        ValidationIssue.TooDark -> "Improve lighting — too dark"
        ValidationIssue.TooBright -> "Reduce lighting — too bright"
        ValidationIssue.Blurry -> "Hold steady — image is blurry"
        ValidationIssue.Glare -> "Reduce glare — adjust angle or lighting"
        ValidationIssue.NoCard -> "No document detected"
        ValidationIssue.NoFace -> "No face detected"
    }

@Composable
internal fun WarningRow(message: String) {
    val typography = LocalOthentoTypography.current
    val colors = LocalOthentoColors.current
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(WarningBg)
                .border(width = 1.dp, color = WarningBorder, shape = RoundedCornerShape(4.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        KycIcon(
            imageVector = OthentoIcons.WarningTriangle,
            contentDescription = null,
            sizeDp = 16.dp,
            tint = WarningIcon,
        )
        Text(
            text = message,
            style = typography.bodySm.copy(fontWeight = FontWeight.W500),
            color = colors.textPrimary,
            textAlign = TextAlign.Start,
            modifier = Modifier.weight(1f),
        )
    }
}

/**
 * Shared capture-review bottom panel used by both document and selfie
 * preview screens. Video/image fills the background; a dark elevated
 * panel anchors at the bottom with title, validation state, and actions.
 */
@Composable
@Suppress("LongParameterList", "LongMethod")
internal fun CaptureReviewSheet(
    title: String,
    subtitle: String,
    validationText: String,
    capturedPreview: @Composable () -> Unit,
    isValidating: Boolean,
    warnings: List<ValidationWarning>,
    onRetake: () -> Unit,
    onConfirm: () -> Unit,
    /** Defaults to `capture.review.looksGood`; the selfie sheet passes its own. */
    confirmLabel: String? = null,
    hasBlockingIssue: Boolean =
        warnings.any { it.issue == ValidationIssue.NoCard || it.issue == ValidationIssue.NoFace },
) {
    val typography = LocalOthentoTypography.current
    val showBlockingState = hasBlockingIssue && !isValidating && warnings.isNotEmpty()
    val effectiveTitle =
        if (showBlockingState) content(ContentKeys.CAPTURE_REVIEW_ISSUES_TITLE) else title
    val effectiveSubtitle =
        if (showBlockingState) content(ContentKeys.CAPTURE_REVIEW_RETAKE_ADVICE) else subtitle

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        Box(modifier = Modifier.fillMaxSize()) {
            capturedPreview()
        }

        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter),
        ) {
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, ReviewSheetSurface),
                            ),
                        ),
            )

            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .background(ReviewSheetSurface)
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(horizontal = 24.dp)
                        .padding(top = 8.dp, bottom = 16.dp),
            ) {
                Text(
                    text = effectiveTitle,
                    style = typography.titleH3.copy(fontWeight = FontWeight.W600),
                    color = Color.White,
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(Modifier.height(4.dp))

                Text(
                    text = effectiveSubtitle,
                    style = typography.bodySm,
                    color = Color.White.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(Modifier.height(20.dp))

                if (isValidating) {
                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.07f))
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        KycLoader(modifier = Modifier.size(18.dp))
                        Text(
                            text = validationText,
                            style = typography.bodySm,
                            color = Color.White.copy(alpha = 0.7f),
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                } else if (warnings.isNotEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        warnings.forEach { w ->
                            Row(
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(WarningBg)
                                        .border(1.dp, WarningBorder, RoundedCornerShape(10.dp))
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                KycIcon(
                                    imageVector = OthentoIcons.WarningTriangle,
                                    contentDescription = null,
                                    sizeDp = 16.dp,
                                    tint = WarningIcon,
                                )
                                Text(
                                    // Bound by issue enum, exactly as `WarningsList`
                                    // above does it. `ValidationWarning.message` is
                                    // built on the analyzer thread, off the Compose
                                    // tree, so it can only ever be the compiled-in
                                    // English — rendering it directly left this row
                                    // untranslated inside otherwise-Arabic chrome.
                                    text = qualityWarningText(w),
                                    style =
                                        typography.bodySm.copy(
                                            fontWeight = FontWeight.W500,
                                        ),
                                    color = Color.White,
                                    textAlign = TextAlign.Start,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }

                if (showBlockingState) {
                    KycButton(
                        onClick = onRetake,
                        label = content(ContentKeys.CAPTURE_REVIEW_RETAKE),
                        variant = KycButtonVariant.Primary,
                        size = KycButtonSize.Lg,
                        fullWidth = true,
                    )
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        KycButton(
                            onClick = onConfirm,
                            label = confirmLabel ?: content(ContentKeys.CAPTURE_REVIEW_LOOKS_GOOD),
                            variant = KycButtonVariant.Primary,
                            size = KycButtonSize.Lg,
                            fullWidth = true,
                            enabled = !isValidating,
                        )
                        Spacer(Modifier.height(4.dp))
                        KycButton(
                            onClick = onRetake,
                            label = content(ContentKeys.CAPTURE_REVIEW_RETAKE),
                            variant = KycButtonVariant.Ghost,
                            size = KycButtonSize.Md,
                        )
                    }
                }
            }
        }
    }
}

private val ReviewSheetSurface = Color(0xFF1A1D21)

internal val WarningBg = Color(0x1FF59E0B)
internal val WarningBorder = Color(0x4DF59E0B)
internal val WarningIcon = Color(0xFFF59E0B)
