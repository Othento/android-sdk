package com.othento.core.internal.content

import androidx.compose.runtime.Immutable

// The four value shapes the `GET /api/v1/SdkContent` contract can carry.
// Everything else is a plain `String` (which may hold `{named}` placeholders).
//
// Contract reference: `docs/sdk-content-native-implementation-plan.md` §1.

/** `[{ text, detail? }]` — a bullet tip on an intro sheet. */
@Immutable
internal data class TipItem(
    val text: String,
    val detail: String? = null,
)

/**
 * `[{ icon, label, detail }]` — a tip card. [icon] is an **HTTPS PNG URL**
 * pointing at a white-on-transparent template that must be tinted at render
 * (plan §4.1). Entries missing [icon] or [label] are dropped by the parser
 * rather than passed through — the renderer dereferences both (plan §4.6).
 */
@Immutable
internal data class TipCard(
    val icon: String,
    val label: String,
    val detail: String? = null,
)

/** `[{ code, label, direction }]` — one entry of `i18n.available`. */
@Immutable
internal data class LanguageOption(
    val code: String,
    val label: String,
    /** Read and stored, deliberately **not** acted on — RTL is out of scope (plan §2). */
    val direction: String = DIRECTION_LTR,
) {
    internal companion object {
        const val DIRECTION_LTR: String = "ltr"
    }
}

/**
 * `result.*.tone` — which *static built-in* status palette a result screen
 * resolves against. Status colours are never transported (plan decision 5c),
 * so this is a name, not a colour.
 *
 * Parsed with a safe fallback so the backend can add a new tone later without
 * breaking deployed builds.
 */
internal enum class ResultTone(
    val wire: String,
) {
    Neutral("neutral"),
    Success("success"),
    Warning("warning"),
    Error("error"),
    ;

    internal companion object {
        fun parse(
            raw: String?,
            fallback: ResultTone,
        ): ResultTone = entries.firstOrNull { it.wire.equals(raw, ignoreCase = true) } ?: fallback
    }
}

/**
 * `result.*.mode` — whether the screen is an end state or a transient one.
 * Same safe-fallback parse rule as [ResultTone].
 */
internal enum class ResultMode(
    val wire: String,
) {
    Terminal("terminal"),
    InFlight("in-flight"),
    ;

    internal companion object {
        fun parse(
            raw: String?,
            fallback: ResultMode,
        ): ResultMode = entries.firstOrNull { it.wire.equals(raw, ignoreCase = true) } ?: fallback
    }
}
