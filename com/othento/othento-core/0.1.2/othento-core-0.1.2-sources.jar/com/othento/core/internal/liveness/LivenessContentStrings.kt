package com.othento.core.internal.liveness

import android.content.Context
import android.content.ContextWrapper
import android.content.res.Resources
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.amplifyframework.ui.liveness.R
import com.othento.core.internal.content.ContentBundle
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.content.ContentKeys as CK

/**
 * Feeds the content bundle into AWS Amplify's `FaceLivenessDetector`.
 *
 * ### Why this file has to exist
 * Every other screen in this SDK renders copy the SDK itself owns, so a
 * content key reaches it through `LocalContent`. The liveness challenge is the
 * one surface we do **not** draw: `FaceLivenessDetector` composes its own
 * instructions, countdown and photosensitivity dialog out of *its* string
 * resources, compiled into the Amplify AAR. No parameter on that composable
 * accepts copy.
 *
 * Android resources are resolved at build time, so the usual localisation
 * answer — ship `values-ar/strings.xml` overrides — would give a fixed set of
 * languages chosen when the AAR is built, not the tenant's live bundle. That
 * fails the requirement the rest of this SDK meets: what the user reads comes
 * from the API.
 *
 * ### How it works
 * `stringResource` resolves through `LocalContext.current.resources`. Providing
 * a [Context] whose [Resources] answers the seventeen
 * `amplify_ui_liveness_*` ids from the bundle therefore redirects Amplify's own
 * lookups without forking or reflecting into it. Anything not overridden — and
 * every other resource type — falls through to the real table untouched.
 *
 * ### Deliberate limits
 * - A key absent from the bundle is **not** put in the map, so Amplify's own
 *   English resource still answers. A blank instruction mid-challenge would be
 *   worse than an untranslated one.
 * - The `a11y` content descriptions and `REC` are left alone: the first is out
 *   of scope for this pass, the second is a universally recognised abbreviation
 *   with no contract key.
 * - This does not translate Amplify's *error* text, which arrives through the
 *   error callback and is mapped by [LivenessErrorMapper] instead.
 */
@Composable
internal fun ProvideLivenessContentStrings(content: @Composable () -> Unit) {
    val bundle = LocalContent.current
    val context = LocalContext.current

    val wrapped =
        remember(bundle, context) {
            val overrides = livenessOverrides(context.resources, bundle)
            if (overrides.isEmpty()) {
                context
            } else {
                OverrideResourcesContext(
                    base = context,
                    overridden = ContentBackedResources(context.resources, overrides),
                )
            }
        }

    CompositionLocalProvider(LocalContext provides wrapped, content = content)
}

/**
 * Amplify string id → contract key.
 *
 * Paired by meaning, not by wording: `move_face_further` ("Move back") and
 * `liveness.hint.moveBack` describe the same instruction, and the contract's
 * `liveness.hint.*` family was clearly authored against this exact surface —
 * seven of these pair off word for word against the shipped English.
 *
 * The photosensitivity *inline* copy and its *dialog* copy share one contract
 * key each: Amplify splits the warning across two presentations of the same
 * sentence, and the contract has one string for it.
 */
private val AMPLIFY_KEY_BY_STRING_ID: Map<Int, String> =
    mapOf(
        R.string.amplify_ui_liveness_challenge_connecting to CK.LIVENESS_CONNECTING,
        R.string.amplify_ui_liveness_challenge_instruction_hold_face_during_freshness to
            CK.LIVENESS_HINT_HOLD_STILL,
        R.string.amplify_ui_liveness_challenge_instruction_move_face to
            CK.LIVENESS_HINT_MOVE_FACE_IN_FRONT,
        R.string.amplify_ui_liveness_challenge_instruction_move_face_closer to
            CK.LIVENESS_HINT_MOVE_CLOSER,
        R.string.amplify_ui_liveness_challenge_instruction_move_face_further to
            CK.LIVENESS_HINT_MOVE_BACK,
        R.string.amplify_ui_liveness_challenge_instruction_multiple_faces_detected to
            CK.LIVENESS_HINT_TOO_MANY_FACES,
        R.string.amplify_ui_liveness_challenge_verifying to CK.LIVENESS_HINT_VERIFYING,
        R.string.amplify_ui_liveness_get_ready_begin_check to CK.LIVENESS_INTRO_BUTTON,
        R.string.amplify_ui_liveness_get_ready_center_face_label to CK.LIVENESS_HINT_CENTER_FACE,
        R.string.amplify_ui_liveness_get_ready_photosensitivity_title to CK.LIVENESS_WARNING_TITLE,
        R.string.amplify_ui_liveness_get_ready_photosensitivity_dialog_title to CK.LIVENESS_WARNING_TITLE,
        R.string.amplify_ui_liveness_get_ready_photosensitivity_description to CK.LIVENESS_WARNING_BODY,
        R.string.amplify_ui_liveness_get_ready_photosensitivity_dialog_description to CK.LIVENESS_WARNING_BODY,
        R.string.amplify_ui_liveness_get_ready_photosensitivity_dialog_dismiss to
            CK.LIVENESS_WARNING_CONTINUE_BUTTON,
    )

/**
 * Only the ids the bundle actually answers, and only where the answer differs
 * from what Amplify already ships — an override identical to the built-in
 * string buys nothing and makes the map look busier than it is.
 */
private fun livenessOverrides(
    base: Resources,
    bundle: ContentBundle,
): Map<Int, String> =
    AMPLIFY_KEY_BY_STRING_ID
        .mapNotNull { (id, key) ->
            val resolved = bundle.textOrNull(key) ?: return@mapNotNull null
            val existing = runCatching { base.getString(id) }.getOrNull()
            if (resolved == existing) null else id to resolved
        }.toMap()

/**
 * A [Resources] that answers [overrides] first and delegates everything else.
 *
 * Built on the deprecated three-arg constructor deliberately: it produces a
 * `Resources` bound to the *same* [android.content.res.AssetManager], so every
 * id this class does not intercept resolves against the identical resource
 * table. Wrapping by delegation is not possible — `Resources` is a concrete
 * class with non-virtual internal state, not an interface.
 */
@Suppress("DEPRECATION")
private class ContentBackedResources(
    private val base: Resources,
    private val overrides: Map<Int, String>,
) : Resources(base.assets, base.displayMetrics, base.configuration) {
    override fun getString(id: Int): String = overrides[id] ?: base.getString(id)

    override fun getString(
        id: Int,
        vararg formatArgs: Any?,
    ): String =
        overrides[id]?.let { template ->
            // Match the platform's own formatting contract for the overridden
            // value; a tenant string with no placeholders is returned as-is.
            runCatching { String.format(template, *formatArgs) }.getOrDefault(template)
        } ?: base.getString(id, *formatArgs)

    override fun getText(id: Int): CharSequence = overrides[id] ?: base.getText(id)

    override fun getText(
        id: Int,
        def: CharSequence?,
    ): CharSequence = overrides[id] ?: base.getText(id, def)
}

/** Hands [ContentBackedResources] to anything resolving through this context. */
private class OverrideResourcesContext(
    base: Context,
    private val overridden: Resources,
) : ContextWrapper(base) {
    override fun getResources(): Resources = overridden
}
