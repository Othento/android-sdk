@file:Suppress(
    "FunctionNaming",
    "TopLevelPropertyNaming",
    "MagicNumber",
    "LongMethod",
    "LongParameterList",
    "TooManyFunctions",
    "MaxLineLength",
    "CyclomaticComplexMethod",
)

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.othento.core.internal.content.content
import com.othento.core.internal.content.contentFor
import com.othento.core.internal.data.OtpVerifyErrorKind
import com.othento.core.internal.data.contentPrefix
import com.othento.core.internal.data.model.OtpChannel
import com.othento.core.internal.flow.OtpNotice
import com.othento.core.internal.flow.OtpUiState
import com.othento.core.internal.ui.components.EmailDestinationInput
import com.othento.core.internal.ui.components.ForceLtr
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.components.KycNotice
import com.othento.core.internal.ui.components.KycNoticeTone
import com.othento.core.internal.ui.components.KycOtpInput
import com.othento.core.internal.ui.components.KycOtpInputState
import com.othento.core.internal.ui.components.KycResultDialog
import com.othento.core.internal.ui.components.KycResultDialogTone
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.components.PhoneDestinationInput
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.screens.common.StepProgress
import com.othento.core.internal.ui.screens.common.progressLabel
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.internal.content.ContentKeys as CK

/**
 * Pure-render OTP screen. Phase 9. Renders both phone and email
 * variants — only chrome copy + destination input differ. Mirrors the
 * web's `apps/sdk/.../otp/otp-screen.ts` shape.
 *
 * Hosted in [OtpScreen]; this composable takes:
 * - [otp]: the [OtpUiState] from the FlowCoordinator.
 * - [destinationDraft]: local-to-screen scratchpad for the destination
 *   input that sits *outside* the FlowUiState (the user types many
 *   characters before tapping Send; pushing every keystroke through
 *   the ViewModel would needlessly recompose the whole tree).
 * - [destinationCountry]: only used when [otp.channel] is
 *   [OtpChannel.Phone]; the ISO-2 code currently picked.
 * - [destinationError]: pre-computed from the validator; null when the
 *   field is empty or valid.
 * - [destinationValid]: drives the Send button enable state.
 * - callbacks for every user action (typing, country change, send,
 *   verify, change-destination, dialog actions, skip-notice).
 */
@Composable
internal fun OtpScreenContent(
    otp: OtpUiState,
    destinationDraft: String,
    destinationCountry: String,
    destinationError: String?,
    destinationValid: Boolean,
    code: String,
    stepProgress: StepProgress,
    onDestinationDraftChange: (String) -> Unit,
    onDestinationCountryChange: (String) -> Unit,
    onCodeChange: (String) -> Unit,
    onSendClick: () -> Unit,
    onVerifyClick: () -> Unit,
    onChangeDestination: () -> Unit,
    onCancelEdit: () -> Unit,
    onDialogPrimary: () -> Unit,
    onDialogDismiss: () -> Unit,
    onAcknowledgeSkipNotice: () -> Unit,
) {
    val isPhone = otp.channel == OtpChannel.Phone
    // Guided-header strings come from content too, including ones a parent
    // would otherwise supply (decision 26) — a hard-coded header title is how
    // seven web screens stayed un-migrated while looking migrated (plan §4.2).
    val title = content(if (isPhone) CK.OTP_PHONE_STEP_TITLE else CK.OTP_EMAIL_STEP_TITLE)
    val subtitle = content(if (isPhone) CK.OTP_PHONE_STEP_SUBTITLE else CK.OTP_EMAIL_STEP_SUBTITLE)

    KycScreen(
        zone = KycScreenZone.Guided,
        title = title,
        subtitle = subtitle,
        stepLabel = stepProgress.progressLabel(),
        totalSegments = stepProgress.total,
        activeSegment = stepProgress.currentIndex,
        body = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                if (otp.editing) {
                    DestinationState(
                        otp = otp,
                        destinationDraft = destinationDraft,
                        destinationCountry = destinationCountry,
                        destinationError = destinationError,
                        destinationValid = destinationValid,
                        onDestinationDraftChange = onDestinationDraftChange,
                        onDestinationCountryChange = onDestinationCountryChange,
                        onSendClick = onSendClick,
                        onCancelEdit = onCancelEdit,
                    )
                } else {
                    CodeEntryState(
                        otp = otp,
                        code = code,
                        onCodeChange = onCodeChange,
                        onVerifyClick = onVerifyClick,
                        onChangeDestination = onChangeDestination,
                        onResendClick = onSendClick,
                    )
                }
            }
        },
    )

    // Every dialog reads `<prefix>.title|.body|.button`, so the copy comes from
    // the kind's own prefix rather than from three hand-written key triples —
    // one place to add the next code the backend introduces.
    otp.verifyErrorKind?.let { kind ->
        val prefix = kind.contentPrefix()
        KycResultDialog(
            icon = if (kind == OtpVerifyErrorKind.Invalid) OthentoIcons.WarningTriangle else OthentoIcons.Clock,
            iconContentDescription = content(prefix + CK.SUFFIX_TITLE),
            title = content(prefix + CK.SUFFIX_TITLE),
            body = content(prefix + CK.SUFFIX_BODY),
            primaryLabel = content(prefix + CK.SUFFIX_BUTTON),
            onPrimary = onDialogPrimary,
            onDismiss = onDialogDismiss,
            tone = if (kind == OtpVerifyErrorKind.Invalid) KycResultDialogTone.Error else KycResultDialogTone.Primary,
            // "Dismiss" is offered only where the primary action sends a code:
            // on the Invalid dialog the primary IS "try again", so a second
            // way to close it is noise.
            secondaryLabel = if (kind == OtpVerifyErrorKind.Invalid) null else content(CK.OTP_ERROR_DISMISS),
            onSecondary = if (kind == OtpVerifyErrorKind.Invalid) null else onDialogDismiss,
        )
    }

    otp.skipNotice?.let { notice ->
        KycResultDialog(
            icon = OthentoIcons.WarningTriangle,
            iconContentDescription = content(CK.OTP_SKIP_TITLE),
            title = content(CK.OTP_SKIP_TITLE),
            body = contentFor(CK.DECLINE_PREFIX, notice.reasonKey, notice.fallbackMessage),
            primaryLabel = content(CK.OTP_SKIP_BUTTON),
            onPrimary = onAcknowledgeSkipNotice,
            onDismiss = onAcknowledgeSkipNotice,
            tone = KycResultDialogTone.Warning,
        )
    }
}

@Composable
private fun DestinationState(
    otp: OtpUiState,
    destinationDraft: String,
    destinationCountry: String,
    destinationError: String?,
    destinationValid: Boolean,
    onDestinationDraftChange: (String) -> Unit,
    onDestinationCountryChange: (String) -> Unit,
    onSendClick: () -> Unit,
    onCancelEdit: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val isPhone = otp.channel == OtpChannel.Phone
    val resending = otp.lastContact != null
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        IllustrationCircle(icon = if (isPhone) OthentoIcons.Smartphone else OthentoIcons.Envelope)
        Text(
            // Phone and email are separate whole keys throughout this screen,
            // never one key with an interpolated channel noun (plan §3.1).
            text = content(if (isPhone) CK.OTP_PHONE_TITLE else CK.OTP_EMAIL_TITLE),
            style = typography.titleH3,
            color = colors.textPrimary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text =
                content(
                    when {
                        resending && isPhone -> CK.OTP_PHONE_EDITING_SUBTITLE
                        resending -> CK.OTP_EMAIL_EDITING_SUBTITLE
                        isPhone -> CK.OTP_PHONE_SUBTITLE
                        else -> CK.OTP_EMAIL_SUBTITLE
                    },
                ),
            style = typography.body,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().widthIn(max = 340.dp),
        )

        Text(
            text = content(if (isPhone) CK.OTP_PHONE_LABEL else CK.OTP_EMAIL_LABEL),
            style = typography.inputLabel,
            color = colors.textPrimary,
        )
        if (isPhone) {
            PhoneDestinationInput(
                raw = destinationDraft,
                countryCode = destinationCountry,
                onRawChange = onDestinationDraftChange,
                onCountryChange = onDestinationCountryChange,
                disabled = otp.sendInFlight,
                errorMessage = destinationError?.takeIf { destinationDraft.isNotEmpty() },
            )
        } else {
            EmailDestinationInput(
                raw = destinationDraft,
                onValueChange = onDestinationDraftChange,
                disabled = otp.sendInFlight,
                errorMessage = destinationError?.takeIf { destinationDraft.isNotEmpty() },
            )
        }

        otp.sendError?.let { notice ->
            KycNotice(description = notice.resolved(), tone = KycNoticeTone.Error)
        }

        val sendLabel =
            content(
                when {
                    otp.sendInFlight -> CK.OTP_SEND_LOADING
                    resending -> CK.OTP_SEND_RESEND
                    else -> CK.OTP_SEND_INITIAL
                },
            )
        KycButton(
            label = sendLabel,
            onClick = onSendClick,
            variant = KycButtonVariant.Primary,
            enabled = destinationValid && !otp.sendInFlight,
            loading = otp.sendInFlight,
            fullWidth = true,
        )
        if (resending) {
            KycButton(
                label = content(CK.OTP_CANCEL),
                onClick = onCancelEdit,
                variant = KycButtonVariant.Ghost,
                enabled = !otp.sendInFlight,
                fullWidth = true,
            )
        }

        SecurityNote()
    }
}

@Composable
private fun CodeEntryState(
    otp: OtpUiState,
    code: String,
    onCodeChange: (String) -> Unit,
    onVerifyClick: () -> Unit,
    onChangeDestination: () -> Unit,
    onResendClick: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val isPhone = otp.channel == OtpChannel.Phone
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        IllustrationCircle(icon = if (isPhone) OthentoIcons.Smartphone else OthentoIcons.Envelope)
        Text(
            text = content(if (isPhone) CK.OTP_PHONE_CODE_TITLE else CK.OTP_EMAIL_CODE_TITLE),
            style = typography.titleH3,
            color = colors.textPrimary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            // `{digits}` is numeric — the code length the backend configured.
            text = content(CK.OTP_CODE_SUBTITLE, PLACEHOLDER_DIGITS to otp.codeLength),
            style = typography.body,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )

        ContactBadge(
            contact = otp.lastContact ?: "—",
            isPhone = isPhone,
            onChange = onChangeDestination,
            disabled = otp.verifyInFlight || otp.sendInFlight,
        )

        KycOtpInput(
            code = code,
            onCodeChange = onCodeChange,
            length = otp.codeLength,
            alphanumeric = otp.alphanumeric,
            disabled = otp.verifyInFlight,
            state = if (otp.verifyError != null) KycOtpInputState.Error else KycOtpInputState.Default,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = content(CK.OTP_RESEND_PROMPT),
                style = typography.caption,
                color = colors.textSecondary,
            )
            ResendButton(
                state = otp,
                onClick = onResendClick,
            )
        }

        // Send error (e.g. a failed resend) — kept visible on the code screen
        // too, mirroring the web SDK's otp-screen.html.
        otp.sendError?.let { notice ->
            KycNotice(description = notice.resolved(), tone = KycNoticeTone.Error)
        }

        if (otp.verifyError != null && otp.verifyErrorKind == null) {
            KycNotice(description = otp.verifyError.resolved(), tone = KycNoticeTone.Error)
        }

        KycButton(
            label = content(if (otp.verifyInFlight) CK.OTP_VERIFY_LOADING else CK.OTP_VERIFY),
            onClick = onVerifyClick,
            variant = KycButtonVariant.Primary,
            enabled = code.length == otp.codeLength && code.all { it != ' ' } && !otp.verifyInFlight,
            loading = otp.verifyInFlight,
            fullWidth = true,
        )

        Text(
            text = content(if (isPhone) CK.OTP_PHONE_TIP else CK.OTP_EMAIL_TIP),
            style = typography.caption,
            color = colors.textMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().widthIn(max = 300.dp),
        )
    }
}

@Composable
private fun IllustrationCircle(icon: ImageVector) {
    val colors = LocalOthentoColors.current
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier =
                Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(colors.primaryBg),
            contentAlignment = Alignment.Center,
        ) {
            KycIcon(
                imageVector = icon,
                contentDescription = null,
                sizeDp = 40.dp,
                tint = colors.primary,
            )
        }
    }
}

@Composable
private fun ContactBadge(
    contact: String,
    isPhone: Boolean,
    onChange: () -> Unit,
    disabled: Boolean,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(
                    androidx.compose.foundation.shape
                        .RoundedCornerShape(12.dp),
                ).background(colors.bgHover)
                .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // The contact is rendered with an LTR base paragraph direction even on
        // an RTL screen. This is a **bidi** fix, not a layout one: `+` and `@`
        // are Unicode-neutral characters, so in an RTL paragraph they resolve
        // to the right-hand end and `+962790000000` renders as
        // `962790000000+`. Pinning the base direction keeps the prefix leading.
        // The "change" link below stays mirrored — it is prose.
        ForceLtr {
            Text(
                text = contact,
                style = typography.body.copy(fontWeight = FontWeight.W700),
                color = colors.textPrimary,
            )
        }
        Text(
            text = content(if (isPhone) CK.OTP_PHONE_CHANGE_BUTTON else CK.OTP_EMAIL_CHANGE_BUTTON),
            style = typography.caption.copy(fontWeight = FontWeight.W700),
            color = if (disabled) colors.textMuted else colors.primary,
            modifier =
                Modifier
                    .clickable(enabled = !disabled, onClick = onChange)
                    .padding(4.dp),
        )
    }
}

@Composable
private fun ResendButton(
    state: OtpUiState,
    onClick: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val label =
        when {
            state.sendInFlight -> content(CK.OTP_SEND_LOADING)
            state.canResend -> content(CK.OTP_SEND_RESEND)
            else ->
                content(
                    CK.OTP_SEND_RESEND_IN,
                    PLACEHOLDER_SECONDS to state.cooldownRemainingSec,
                )
        }
    val enabled = state.canResend && !state.sendInFlight
    Text(
        text = label,
        style = typography.caption.copy(fontWeight = FontWeight.W600),
        color = if (enabled) colors.primary else colors.textMuted,
        modifier =
            Modifier
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

@Composable
private fun SecurityNote() {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(
                    androidx.compose.foundation.shape
                        .RoundedCornerShape(8.dp),
                ).background(colors.bgHover)
                .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        KycIcon(
            imageVector = OthentoIcons.Lock,
            contentDescription = null,
            sizeDp = 14.dp,
            tint = colors.primary,
        )
        Text(
            text = content(CK.OTP_SECURITY),
            style = typography.caption,
            color = colors.textMuted,
        )
        Spacer(Modifier.height(0.dp))
    }
}

/**
 * Resolves an inline OTP notice at render time.
 *
 * [OtpNotice.contentKey] is already a whole key (the mapping table holds full
 * keys, not leaves), so the prefix is empty — the accessor is reused for its
 * fallback chain, not for key composition.
 */
@Composable
@ReadOnlyComposable
private fun OtpNotice.resolved(): String = contentFor(prefix = "", key = contentKey, fallback = fallback)

/** `{digits}` in `otp.code.subtitle` — the configured code length. */
private const val PLACEHOLDER_DIGITS = "digits"
private const val PLACEHOLDER_SECONDS = "seconds"
