@file:Suppress(
    "FunctionNaming",
    "TopLevelPropertyNaming",
    "MagicNumber",
    "LongMethod",
    "LongParameterList",
    "TooManyFunctions",
    // Reason: this file is the renderer for the camera HUD; it composes the
    // top chrome, status pill, cutout, capture row, loading + error states,
    // and preview state. Splitting across files fragments the visual
    // hierarchy that maps 1:1 to spec [docs/spec/06-screens/05-capture.md].
)

package com.othento.core.internal.ui.screens

import android.graphics.PointF
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.capture.CameraReadyState
import com.othento.core.internal.capture.CaptureHint
import com.othento.core.internal.capture.DetectionState
import com.othento.core.internal.capture.detection.ValidationIssue
import com.othento.core.internal.capture.detection.ValidationWarning
import com.othento.core.internal.content.content
import com.othento.core.internal.content.contentFor
import com.othento.core.internal.content.contentLanguage
import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.data.model.DocumentType
import com.othento.core.internal.ui.components.CaptureReviewSheet
import com.othento.core.internal.ui.components.ChromeFlagHeight
import com.othento.core.internal.ui.components.ChromeFlagWidth
import com.othento.core.internal.ui.components.CountryFlagImage
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonSize
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.components.KycPlacementGuide
import com.othento.core.internal.ui.components.PlacementGuideKind
import com.othento.core.internal.ui.components.captureHintText
import com.othento.core.internal.ui.components.qualityIssueText
import com.othento.core.internal.ui.components.mirrorInRtl
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.internal.util.countryDisplayName
import com.othento.core.internal.content.ContentKeys as CK

/**
 * UI state for [CameraCaptureScreenContent]. Snapshot-friendly: Paparazzi
 * tests construct a value directly without any CameraX runtime.
 */
internal data class CameraCaptureUiState(
    val cameraReady: CameraReadyState,
    val torchAvailable: Boolean,
    val torchOn: Boolean,
    val showGuide: Boolean,
    val captureReady: Boolean,
    /** `true` once the user has captured a JPEG and is reviewing it. */
    val isPreviewing: Boolean = false,
    /** V30 detection state — drives the corner polygon overlay. */
    val detectionState: DetectionState = DetectionState.Idle,
    /**
     * Analyzer image dimensions for the most recent frame:
     * `(imageWidth, imageHeight, rotationDegrees)`. Used by the live
     * overlay to project corner points (in unrotated image coords) into
     * upright view fractions. Defaults to (0, 0, 0) — overlay is hidden
     * until the analyzer produces its first frame.
     */
    val frameDims: Triple<Int, Int, Int> = Triple(0, 0, 0),
    /**
     * On-screen cutout rect in root-px coords (from
     * `coords.boundsInRoot()` of the cutout container). Drives the
     * yellow/blue color split for the polygon: corners inside the rect
     * are blue, outside are yellow. `null` until the cutout has had a
     * layout pass.
     */
    val cutoutScreenRect: android.graphics.Rect? = null,
    /**
     * Capture progress (0..1) for the shutter button arc fill.
     * `framesHeld / stabilityFramesRequired` while [DetectionState.Holding],
     * `1f` while [DetectionState.ReadyToCapture], `0f` otherwise.
     */
    val captureProgress: Float = 0f,
    /**
     * Positioning hint from the pipeline (move closer, align passport, etc),
     * rendered in the status pill above the cutout. `null` when no hint is
     * active.
     *
     * The **enum**, not the sentence — the analyzer thread cannot read content,
     * so the copy is resolved here at render time via `captureHintText`.
     */
    val hint: CaptureHint? = null,
    /**
     * Quality-specific warning from the pipeline (blur, glare,
     * brightness). Rendered as an amber bubble below the cutout,
     * matching the selfie screen's warning pattern.
     *
     * Shares [ValidationIssue] with the post-capture review, so the live
     * warning and its review-screen twin resolve through one key.
     */
    val warning: ValidationIssue? = null,
    /**
     * `true` when the 45 s capture window elapsed without a manual or auto
     * capture. Mirrors the selfie screen's timeout — the screen flips to a
     * "Try again" panel.
     */
    val timedOut: Boolean = false,
    val previewValidating: Boolean = false,
    val previewWarnings: List<ValidationWarning> = emptyList(),
)

internal data class CameraCaptureCallbacks(
    val onBack: () -> Unit,
    val onShutter: () -> Unit,
    val onTryAgain: () -> Unit,
    /** Error-state "Upload file instead" CTA (PermissionDenied / Unavailable). */
    val onSwitchToFallback: () -> Unit,
    /** HUD's bottom-left upload glyph — opens the [KycCameraUploadSheet] overlay. */
    val onOpenUploadSheet: () -> Unit,
    /** ⓘ button on the chrome — re-opens [KycIntroSheet]. */
    val onShowIntro: () -> Unit,
    val onToggleTorch: () -> Unit,
    val onRetake: () -> Unit,
    val onConfirmCapture: () -> Unit,
    val onOpenAppSettings: () -> Unit,
)

/**
 * Pure-render variant of the camera capture screen. Pulled out of
 * [CameraCaptureScreen] so Paparazzi can render every state without a
 * CameraX runtime — `previewSurface` lets snapshot tests substitute a
 * flat `Box` for the live `PreviewView` (the default sets it to a black
 * box).
 *
 * [onCutoutBoundsChanged] reports the document-cutout bounding rect in
 * root-view (px) coordinates whenever the layout settles. The live screen
 * maps this through PreviewView.outputTransform to get sensor-space coords
 * for the V30 FrameAnalyzer; Paparazzi tests leave it as the default no-op.
 *
 * Spec [docs/spec/06-screens/05-capture.md] §"Layout".
 */
@Composable
internal fun CameraCaptureScreenContent(
    state: CameraCaptureUiState,
    side: Side,
    pendingDocument: AcceptedDocument?,
    enableFallback: Boolean,
    callbacks: CameraCaptureCallbacks,
    onCutoutBoundsChanged: (android.graphics.Rect) -> Unit = {},
    previewSurface: @Composable () -> Unit = { Box(Modifier.fillMaxSize().background(Color.Black)) },
    capturedPreview: (@Composable () -> Unit)? = null,
) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        when (state.cameraReady) {
            CameraReadyState.Loading -> CameraLoading()
            CameraReadyState.PermissionDenied ->
                CameraPermissionDenied(
                    onTryAgain = callbacks.onTryAgain,
                    onUseFallback = callbacks.onSwitchToFallback,
                    enableFallback = enableFallback,
                    permanentlyDenied = false,
                    onOpenSettings = callbacks.onOpenAppSettings,
                )
            CameraReadyState.PermissionPermanentlyDenied ->
                CameraPermissionDenied(
                    onTryAgain = callbacks.onTryAgain,
                    onUseFallback = callbacks.onSwitchToFallback,
                    enableFallback = enableFallback,
                    permanentlyDenied = true,
                    onOpenSettings = callbacks.onOpenAppSettings,
                )
            CameraReadyState.Unavailable ->
                CameraUnavailable(
                    onTryAgain = callbacks.onTryAgain,
                    onUseFallback = callbacks.onSwitchToFallback,
                    enableFallback = enableFallback,
                )
            CameraReadyState.Active -> {
                when {
                    state.isPreviewing && capturedPreview != null ->
                        PreviewState(
                            capturedPreview = capturedPreview,
                            isValidating = state.previewValidating,
                            warnings = state.previewWarnings,
                            onRetake = callbacks.onRetake,
                            onConfirm = callbacks.onConfirmCapture,
                        )
                    state.timedOut ->
                        CameraTimeout(
                            onTryAgain = callbacks.onRetake,
                            onUseFallback = callbacks.onSwitchToFallback,
                            enableFallback = enableFallback,
                        )
                    else ->
                        ActiveHud(
                            state = state,
                            side = side,
                            pendingDocument = pendingDocument,
                            enableFallback = enableFallback,
                            callbacks = callbacks,
                            previewSurface = previewSurface,
                            onCutoutBoundsChanged = onCutoutBoundsChanged,
                        )
                }
            }
        }
    }
}

@Composable
private fun ActiveHud(
    state: CameraCaptureUiState,
    side: Side,
    pendingDocument: AcceptedDocument?,
    enableFallback: Boolean,
    callbacks: CameraCaptureCallbacks,
    previewSurface: @Composable () -> Unit,
    onCutoutBoundsChanged: (android.graphics.Rect) -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Live camera surface fills the screen.
        previewSurface()

        // Dark scrim with the cutout punched out — same approach as
        // OvalRoiOverlay (Path difference). Mirrors the web's
        // `box-shadow: 0 0 0 9999px rgba(0,0,0,0.5)` on the cutout frame.
        CutoutScrim(cutoutScreenRect = state.cutoutScreenRect)

        DetectionOverlay(
            detectionState = state.detectionState,
            frameDims = state.frameDims,
            cutoutScreenRect = state.cutoutScreenRect,
            isPassport = pendingDocument?.documentType == DocumentType.Passport,
            modifier = Modifier.fillMaxSize(),
        )

        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars),
        ) {
            TopChrome(
                side = side,
                pendingDocument = pendingDocument,
                onBack = callbacks.onBack,
                onTipsTap = callbacks.onShowIntro,
            )
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    DynamicStatusPill(
                        state = state,
                        side = side,
                        pendingDocument = pendingDocument,
                    )
                    Spacer(Modifier.height(StatusPillBottomGap))
                    DocumentCutout(
                        state = state,
                        pendingDocument = pendingDocument,
                        onBoundsChanged = onCutoutBoundsChanged,
                    )
                }
                state.warning?.let { issue ->
                    DocumentWarningBubble(
                        text = qualityIssueText(issue),
                        modifier =
                            Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(bottom = 4.dp),
                    )
                }
            }
            Spacer(Modifier.height(CaptureRowTopGap))
            CaptureRow(
                state = state,
                enableFallback = enableFallback,
                callbacks = callbacks,
            )
            Spacer(Modifier.height(BottomGap))
        }
    }
}

@Composable
private fun TopChrome(
    side: Side,
    pendingDocument: AcceptedDocument?,
    onBack: () -> Unit,
    onTipsTap: () -> Unit,
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(horizontal = ChromeHorizontal, vertical = ChromeVertical)
                .height(ChromeButtonSize),
        horizontalArrangement = Arrangement.spacedBy(ChromeGap),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (side == Side.Front) {
            ChromeButton(
                icon = OthentoIcons.ArrowLeft,
                contentDescription = content(CK.A11Y_BACK),
                onClick = onBack,
                mirrorInRtl = true,
            )
        } else {
            Spacer(Modifier.size(ChromeButtonSize))
        }
        ChromePill(side = side, pendingDocument = pendingDocument, modifier = Modifier.weight(1f))
        ChromeButton(
            icon = OthentoIcons.Info,
            contentDescription = content(CK.A11Y_SHOW_TIPS),
            onClick = onTipsTap,
        )
    }
}

@Composable
private fun ChromeButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    /** Set for glyphs that encode direction — an arrow has to turn around in RTL. */
    mirrorInRtl: Boolean = false,
) {
    Box(
        modifier =
            Modifier
                .size(ChromeButtonSize)
                .clip(CircleShape)
                .background(WhiteAlpha12)
                .border(width = 1.dp, color = WhiteAlpha10, shape = CircleShape)
                .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        KycIcon(
            imageVector = icon,
            contentDescription = contentDescription,
            sizeDp = 16.dp,
            tint = Color.White,
            modifier = if (mirrorInRtl) Modifier.mirrorInRtl() else Modifier,
        )
    }
}

@Composable
private fun ChromePill(
    side: Side,
    pendingDocument: AcceptedDocument?,
    modifier: Modifier = Modifier,
) {
    val typography = LocalOthentoTypography.current
    val isPassport = pendingDocument?.documentType == DocumentType.Passport
    // `idv.capture.side.*` — the same two keys the upload fallback screen
    // already reads, so the side is worded identically on both surfaces
    // instead of each one inventing its own abbreviation.
    val frontLabel = content(CK.IDV_CAPTURE_SIDE_FRONT)
    val backLabel = content(CK.IDV_CAPTURE_SIDE_BACK)
    val flagUrl = pendingDocument?.countryIcon?.takeIf { it.isNotBlank() }
    // Both document labels resolve here, at render, rather than being captured
    // when the documents were fetched — a language switch then re-renders the
    // pill instead of leaving it stranded in the previous language.
    //
    // With no document the pill falls back to a single whole sentence that
    // already names the side ("Front of your document"), so the ` · <side>`
    // segment is dropped rather than appended to it.
    val text =
        if (pendingDocument == null) {
            content(if (side == Side.Front) CK.IDV_CAPTURE_PILL_FALLBACK_FRONT else CK.IDV_CAPTURE_PILL_FALLBACK_BACK)
        } else {
            val typeName =
                contentFor(CK.DOCUMENT_TYPE_PREFIX, pendingDocument.documentTypeCode, pendingDocument.typeName)
            val countryName =
                countryDisplayName(pendingDocument.alpha2, contentLanguage(), pendingDocument.countryName)
                    .takeIf { it.isNotBlank() }
            val sideLabel =
                when {
                    isPassport -> null
                    side == Side.Front -> frontLabel
                    else -> backLabel
                }
            listOfNotNull(countryName, typeName.takeIf { it.isNotBlank() }, sideLabel?.takeIf { it.isNotBlank() })
                .joinToString(separator = " · ")
        }
    Row(
        modifier =
            modifier
                .height(ChromeButtonSize)
                .clip(RoundedCornerShape(ChromeButtonSize / 2))
                .background(WhiteAlpha12)
                .border(width = 1.dp, color = WhiteAlpha8, shape = RoundedCornerShape(ChromeButtonSize / 2))
                .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ChromePillFlagGap, Alignment.CenterHorizontally),
    ) {
        if (flagUrl != null) {
            CountryFlagImage(
                url = flagUrl,
                width = ChromeFlagWidth,
                height = ChromeFlagHeight,
                // The flag's description is the localised country name, which
                // lives inside `text` — the pill's own label already says it,
                // so announcing it twice is noise for a screen reader.
                contentDescription = null,
            )
        }
        Text(
            text = text,
            style = typography.caption.copy(fontWeight = FontWeight.W600),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

/**
 * Dynamic status pill rendered just above the cutout. Mirrors the web's
 * `camera-capture__status-pill` — text rotates between:
 * - "Hold steady... Xs" when the auto-capture timer is counting down
 *   (Holding state, progress > 0).
 * - The pipeline's [CameraCaptureUiState.hint] when a soft gate is
 *   blocking auto-capture (low light, glare, blur, reposition, etc).
 * - "Position the {side} of your {document} in the frame" as the
 *   default copy.
 *
 * Dot color matches the brackets — primary when meets-threshold, amber
 * otherwise.
 */
@Composable
private fun DynamicStatusPill(
    state: CameraCaptureUiState,
    side: Side,
    pendingDocument: AcceptedDocument?,
) {
    val typography = LocalOthentoTypography.current
    val colors = LocalOthentoColors.current
    val isPassport = pendingDocument?.documentType == DocumentType.Passport

    val isCounting = state.captureProgress > 0f && state.detectionState is DetectionState.Holding
    val text =
        when {
            // `capture.prompt.holdSteady` always carries a `{seconds}` countdown.
            // The countdown-free variant is `liveness.hint.holdStill` ("Hold
            // still") — a seeded string that says exactly this. The key is
            // liveness-namespaced but the instruction is to the person holding
            // the device, which is the same act on either screen.
            state.detectionState is DetectionState.ReadyToCapture ||
                state.detectionState is DetectionState.Captured ->
                content(CK.LIVENESS_HINT_HOLD_STILL)
            isCounting -> {
                val remainingMs = (HOLD_TARGET_MS_FOR_PILL * (1f - state.captureProgress)).toLong()
                val remainingSec = ((remainingMs + ROUND_UP_MS) / 1_000L).coerceAtLeast(1L)
                content(CK.CAPTURE_PROMPT_HOLD_STEADY, PLACEHOLDER_SECONDS to remainingSec)
            }
            state.hint != null -> captureHintText(state.hint)
            // Same instruction, and the amber bubble beside it already names
            // the specific quality problem — so this slot only has to say
            // "don't move", which `liveness.hint.holdStill` already says.
            state.warning != null -> content(CK.LIVENESS_HINT_HOLD_STILL)
            isPassport -> content(CK.CAPTURE_PROMPT_POSITION_PASSPORT)
            // Front/back are two whole keys. The old string interpolated the
            // side *and* the document type into one sentence, which cannot
            // survive translation (plan §3.1); the type name is dropped rather
            // than inserted, and stays visible in the chrome pill above.
            side == Side.Front -> content(CK.CAPTURE_PROMPT_POSITION_DOCUMENT_FRONT)
            else -> content(CK.CAPTURE_PROMPT_POSITION_DOCUMENT_BACK)
        }
    // Keyed off state, not off the rendered string. Comparing `text` to a
    // constant only worked while the pill was hard-coded English — the moment
    // the copy resolves from the bundle the comparison silently stops matching
    // and the dot goes amber on a ready-to-capture frame.
    val isReady =
        state.detectionState is DetectionState.ReadyToCapture ||
            state.detectionState is DetectionState.Captured
    val dotColor = if (isCounting || isReady) colors.primary else AmberDotColor
    Row(
        modifier =
            Modifier
                .wrapContentSize()
                .clip(RoundedCornerShape(999.dp))
                .background(Color.Black.copy(alpha = 0.55f))
                .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(modifier = Modifier.size(StatusDotSize).clip(CircleShape).background(dotColor))
        Text(
            text = text,
            style = typography.caption.copy(fontWeight = FontWeight.W600),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

private const val HOLD_TARGET_MS_FOR_PILL: Float = 1_300f
private const val ROUND_UP_MS: Long = 999L

/**
 * Full-screen dark scrim with the document cutout area punched out.
 * Sibling of `previewSurface()` in [ActiveHud]. Mirrors the web's
 * `box-shadow: 0 0 0 9999px rgba(0,0,0,0.5)` on the cutout frame —
 * focuses attention on the cutout while the live camera shows through.
 *
 * If [cutoutScreenRect] is null (first frame before layout), draws the
 * scrim solid; once the cutout's bounds are known, the rect is excluded
 * via `Path.op(rect, cutout, Difference)`, same approach as
 * [com.othento.core.internal.ui.components.OvalRoiOverlay].
 */
@Composable
private fun CutoutScrim(cutoutScreenRect: android.graphics.Rect?) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val full =
            androidx.compose.ui.geometry
                .Rect(0f, 0f, size.width, size.height)
        val rectPath = Path().apply { addRect(full) }
        if (cutoutScreenRect == null || cutoutScreenRect.isEmpty) {
            drawPath(rectPath, ScrimColor)
            return@Canvas
        }
        val cutoutRect =
            androidx.compose.ui.geometry.RoundRect(
                left = cutoutScreenRect.left.toFloat(),
                top = cutoutScreenRect.top.toFloat(),
                right = cutoutScreenRect.right.toFloat(),
                bottom = cutoutScreenRect.bottom.toFloat(),
                cornerRadius =
                    androidx.compose.ui.geometry.CornerRadius(
                        SCRIM_CUTOUT_RADIUS.toPx(),
                        SCRIM_CUTOUT_RADIUS.toPx(),
                    ),
            )
        val cutoutPath = Path().apply { addRoundRect(cutoutRect) }
        val scrimPath =
            Path().apply {
                op(rectPath, cutoutPath, androidx.compose.ui.graphics.PathOperation.Difference)
            }
        drawPath(scrimPath, ScrimColor)
    }
}

private val ScrimColor = Color.Black.copy(alpha = 0.55f)
private val SCRIM_CUTOUT_RADIUS: Dp = 12.dp

@Composable
private fun DocumentCutout(
    state: CameraCaptureUiState,
    pendingDocument: AcceptedDocument?,
    onBoundsChanged: (android.graphics.Rect) -> Unit,
    modifier: Modifier = Modifier,
) {
    // Passports default to ICAO TD3 (125 × 88 mm = 1.42:1) when the docs API
    // doesn't supply physical dimensions; otherwise fall back to ID/credit-card
    // (85.6 × 54 mm = 1.585:1). The bracket shape drives how the user frames the
    // document, which in turn controls whether SmartCropper finds the outer edge
    // (good) or smaller internal features like stamps / photo borders (bad).
    val isPassport = pendingDocument?.documentType == DocumentType.Passport
    val widthMm =
        pendingDocument?.widthMm
            ?: if (isPassport) PASSPORT_WIDTH_MM else DEFAULT_WIDTH_MM
    val heightMm =
        pendingDocument?.heightMm
            ?: if (isPassport) PASSPORT_HEIGHT_MM else DEFAULT_HEIGHT_MM
    val ratio = (widthMm / heightMm).toFloat().coerceAtLeast(0.1f)
    val borderColor = Color.White.copy(alpha = 0.85f)

    Box(modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp), contentAlignment = Alignment.Center) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth(0.9f)
                    .aspectRatio(ratio)
                    .onGloballyPositioned { coords ->
                        val bounds = coords.boundsInRoot()
                        onBoundsChanged(
                            android.graphics.Rect(
                                bounds.left.toInt(),
                                bounds.top.toInt(),
                                bounds.right.toInt(),
                                bounds.bottom.toInt(),
                            ),
                        )
                    },
        ) {
            // AbsoluteAlignment, not Alignment: this frame is a viewfinder for a
            // physical rectangle held in front of the lens, so it must render
            // identically in both directions. `Alignment.TopStart` is
            // direction-aware and puts the top-*left*-shaped bracket at the
            // top-right under RTL, which draws the corners inside-out.
            CornerBracket(borderColor = borderColor, alignment = AbsoluteAlignment.TopLeft)
            CornerBracket(borderColor = borderColor, alignment = AbsoluteAlignment.TopRight)
            CornerBracket(borderColor = borderColor, alignment = AbsoluteAlignment.BottomLeft)
            CornerBracket(borderColor = borderColor, alignment = AbsoluteAlignment.BottomRight)

            val isHolding = state.detectionState is DetectionState.Holding
            if (isHolding) {
                DocumentScanLine()
            }

            // Placement guide overlay (visible during the introductory window
            // after the camera binds).
            if (state.showGuide) {
                KycPlacementGuide(
                    kind = PlacementGuideKind.IdCardFront,
                    visible = true,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

@Composable
private fun DocumentScanLine(modifier: Modifier = Modifier) {
    val primary = LocalOthentoColors.current.primary
    val transition = rememberInfiniteTransition(label = "doc-scan")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(durationMillis = DOC_SCAN_HALF_MS, easing = EaseInOut),
                repeatMode = RepeatMode.Reverse,
            ),
        label = "doc-scan-progress",
    )
    val alpha =
        when {
            progress < DOC_SCAN_FADE -> progress / DOC_SCAN_FADE
            progress > 1f - DOC_SCAN_FADE -> (1f - progress) / DOC_SCAN_FADE
            else -> 1f
        }

    Canvas(modifier = modifier.fillMaxSize().graphicsLayer(alpha = alpha)) {
        val y = (-0.02f + progress) * size.height
        val lineH = DOC_SCAN_LINE_H.toPx()
        val glowH = DOC_SCAN_GLOW_H.toPx()
        val trailH = DOC_SCAN_TRAIL_H.toPx()

        drawRect(
            brush =
                Brush.horizontalGradient(
                    colors =
                        listOf(
                            Color.Transparent,
                            primary.copy(alpha = 0.15f),
                            primary.copy(alpha = 0.15f),
                            Color.Transparent,
                        ),
                ),
            topLeft = Offset(0f, y - glowH / 2f),
            size = Size(size.width, glowH),
        )

        drawRect(
            brush =
                Brush.horizontalGradient(
                    colors =
                        listOf(
                            Color.Transparent,
                            primary.copy(alpha = 0.35f),
                            primary.copy(alpha = 0.35f),
                            Color.Transparent,
                        ),
                ),
            topLeft = Offset(0f, y - lineH * 3f),
            size = Size(size.width, lineH * 6f),
        )

        drawRect(
            brush =
                Brush.horizontalGradient(
                    colors =
                        listOf(
                            Color.Transparent,
                            primary.copy(alpha = 0.6f),
                            primary,
                            primary.copy(alpha = 0.6f),
                            Color.Transparent,
                        ),
                ),
            topLeft = Offset(0f, y - lineH / 2f),
            size = Size(size.width, lineH),
        )

        drawRect(
            brush =
                Brush.verticalGradient(
                    colors =
                        listOf(
                            primary.copy(alpha = 0.25f),
                            Color.Transparent,
                        ),
                    startY = y,
                    endY = y + trailH,
                ),
            topLeft = Offset(0f, y),
            size = Size(size.width, trailH),
        )
    }
}

private const val DOC_SCAN_HALF_MS: Int = 1_000
private const val DOC_SCAN_FADE: Float = 0.05f
private val DOC_SCAN_LINE_H: Dp = 3.dp
private val DOC_SCAN_GLOW_H: Dp = 40.dp
private val DOC_SCAN_TRAIL_H: Dp = 40.dp

/**
 * Draws an outline around the detected document at its actual on-screen
 * position. Corners in [DetectionState] are in unrotated image (analyzer)
 * coordinates; the overlay projects them to upright view fractions using
 * `(imageWidth, imageHeight, rotationDegrees)` and renders them on a
 * full-screen Canvas.
 *
 * Colors (matches the web SDK's signal):
 * - **Yellow** — detection valid, but at least one corner sits outside
 *   the on-screen cutout. The user needs to reposition.
 * - **Blue** — all corners inside the cutout, document is being held.
 * - **Green** — `ReadyToCapture` / `Captured` — auto-shutter is firing.
 * - **Faded white** — `Searching` with stale corners, drawn dim so a
 *   single dropped frame doesn't blink the overlay off.
 *
 * If [frameDims] is uninitialized (image w/h = 0) or [cutoutScreenRect]
 * is null, the overlay returns early — nothing to project against.
 */
@Composable
internal fun DetectionOverlay(
    detectionState: DetectionState,
    frameDims: Triple<Int, Int, Int>,
    cutoutScreenRect: android.graphics.Rect?,
    isPassport: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val pair: Pair<List<PointF>, DetectionState>? =
        when (detectionState) {
            is DetectionState.Holding -> detectionState.corners to detectionState
            is DetectionState.ReadyToCapture -> detectionState.corners to detectionState
            is DetectionState.Captured -> detectionState.corners to detectionState
            is DetectionState.Searching ->
                // For passport: SmartCropper picks up internal features
                // (text, photo borders) during Searching — skip stale
                // corners to avoid noisy brackets. Only show brackets when
                // all gates pass (Holding/Ready/Captured).
                if (isPassport) {
                    null
                } else {
                    detectionState.lastCorners?.let { it to detectionState }
                }
            else -> null
        }
    if (pair == null) return
    val corners = pair.first
    val stateForColor = pair.second
    if (corners.isEmpty()) return

    val (imageW, imageH, rotation) = frameDims
    if (imageW <= 0 || imageH <= 0) return

    val primary = LocalOthentoColors.current.primary
    val meetsThreshold =
        (stateForColor is DetectionState.ReadyToCapture) ||
            (stateForColor is DetectionState.Captured) ||
            (stateForColor is DetectionState.Holding)
    val targetColor = if (meetsThreshold) primary else DetectionOutsideColor
    val animatedColor by animateColorAsState(
        targetValue = targetColor,
        animationSpec = tween(durationMillis = BORDER_COLOR_ANIM_MS),
        label = "detectionBorderColor",
    )

    Canvas(modifier = modifier) {
        val canvasPoints =
            corners
                .map { imageToViewFraction(it, imageW, imageH, rotation) }
                .map { (fx, fy) -> Offset(fx * size.width, fy * size.height) }

        // If brackets are outside the cutout while Holding, force yellow
        // immediately (no animation) — this is a positioning issue.
        val insideCutout = cutoutScreenRect != null && allInsideCutout(canvasPoints, cutoutScreenRect)
        val drawColor =
            if (!insideCutout && stateForColor is DetectionState.Holding) {
                DetectionOutsideColor
            } else {
                animatedColor
            }

        val left = canvasPoints.minOf { it.x }
        val top = canvasPoints.minOf { it.y }
        val right = canvasPoints.maxOf { it.x }
        val bottom = canvasPoints.maxOf { it.y }

        val stroke = BRACKET_STROKE.toPx()
        val arm = BRACKET_ARM.toPx().coerceAtMost((right - left) * 0.4f).coerceAtMost((bottom - top) * 0.4f)
        drawLine(drawColor, Offset(left, top + arm), Offset(left, top), stroke, StrokeCap.Round)
        drawLine(drawColor, Offset(left, top), Offset(left + arm, top), stroke, StrokeCap.Round)
        drawLine(drawColor, Offset(right - arm, top), Offset(right, top), stroke, StrokeCap.Round)
        drawLine(drawColor, Offset(right, top), Offset(right, top + arm), stroke, StrokeCap.Round)
        drawLine(drawColor, Offset(right, bottom - arm), Offset(right, bottom), stroke, StrokeCap.Round)
        drawLine(drawColor, Offset(right, bottom), Offset(right - arm, bottom), stroke, StrokeCap.Round)
        drawLine(drawColor, Offset(left + arm, bottom), Offset(left, bottom), stroke, StrokeCap.Round)
        drawLine(drawColor, Offset(left, bottom), Offset(left, bottom - arm), stroke, StrokeCap.Round)
    }
}

private const val BORDER_COLOR_ANIM_MS: Int = 300

private val BRACKET_ARM: Dp = 22.dp
private val BRACKET_STROKE: Dp = 3.dp

/**
 * Small pill rendered between the cutout and the capture row when the
 * pipeline has a user-actionable hint (low light, glare, blur,
 * reposition, etc). Mirrors the web SDK's hint banner — same yellow
 * accent as the brackets when a soft gate is blocking auto-capture.
 */
private fun imageToViewFraction(
    pt: PointF,
    imageWidth: Int,
    imageHeight: Int,
    rotationDegrees: Int,
): Pair<Float, Float> {
    val w = imageWidth.toFloat().coerceAtLeast(1f)
    val h = imageHeight.toFloat().coerceAtLeast(1f)
    val r = ((rotationDegrees % FULL_TURN) + FULL_TURN) % FULL_TURN
    return when (r) {
        QUARTER_TURN -> {
            // image is landscape; upright view is portrait.
            // imageX = (1 - viewFracY) * w → viewFracY = 1 - imageX / w
            // imageY = viewFracX * h        → viewFracX = imageY / h
            (pt.y / h) to (1f - pt.x / w)
        }
        HALF_TURN -> {
            (1f - pt.x / w) to (1f - pt.y / h)
        }
        THREE_QUARTER_TURN -> {
            (1f - pt.y / h) to (pt.x / w)
        }
        else -> (pt.x / w) to (pt.y / h)
    }
}

private fun allInsideCutout(
    canvasPoints: List<Offset>,
    cutout: android.graphics.Rect,
): Boolean =
    canvasPoints.all { p ->
        p.x >= cutout.left &&
            p.x <= cutout.right &&
            p.y >= cutout.top &&
            p.y <= cutout.bottom
    }

private const val QUARTER_TURN: Int = 90
private const val HALF_TURN: Int = 180
private const val THREE_QUARTER_TURN: Int = 270
private const val FULL_TURN: Int = 360

@Composable
private fun CornerBracket(
    borderColor: Color,
    alignment: Alignment,
) {
    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(2.dp),
        contentAlignment = alignment,
    ) {
        Canvas(modifier = Modifier.size(CornerBracketSize)) {
            val stroke = 3.dp.toPx()
            val w = size.width
            val h = size.height
            // The branches match on the same AbsoluteAlignment values the call
            // site passes, so the arms drawn here always agree with where the
            // bracket was placed. Matching on direction-aware Alignment would
            // silently fall through to `else` and draw nothing under RTL.
            when (alignment) {
                AbsoluteAlignment.TopLeft -> {
                    drawLine(borderColor, Offset(0f, 0f), Offset(0f, h), stroke, StrokeCap.Round)
                    drawLine(borderColor, Offset(0f, 0f), Offset(w, 0f), stroke, StrokeCap.Round)
                }
                AbsoluteAlignment.TopRight -> {
                    drawLine(borderColor, Offset(0f, 0f), Offset(w, 0f), stroke, StrokeCap.Round)
                    drawLine(borderColor, Offset(w, 0f), Offset(w, h), stroke, StrokeCap.Round)
                }
                AbsoluteAlignment.BottomLeft -> {
                    drawLine(borderColor, Offset(0f, 0f), Offset(0f, h), stroke, StrokeCap.Round)
                    drawLine(borderColor, Offset(0f, h), Offset(w, h), stroke, StrokeCap.Round)
                }
                AbsoluteAlignment.BottomRight -> {
                    drawLine(borderColor, Offset(w, 0f), Offset(w, h), stroke, StrokeCap.Round)
                    drawLine(borderColor, Offset(0f, h), Offset(w, h), stroke, StrokeCap.Round)
                }
                else -> Unit
            }
        }
    }
}

@Composable
private fun CaptureRow(
    state: CameraCaptureUiState,
    enableFallback: Boolean,
    callbacks: CameraCaptureCallbacks,
) {
    val appearAlpha by animateFloatAsState(
        targetValue = if (state.captureReady) 1f else 0f,
        animationSpec = tween(durationMillis = 350),
        label = "capture-row-alpha",
    )
    val appearSlide by animateFloatAsState(
        targetValue = if (state.captureReady) 0f else 12f,
        animationSpec = tween(durationMillis = 350),
        label = "capture-row-slide",
    )
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .graphicsLayer(alpha = appearAlpha, translationY = appearSlide),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (enableFallback) {
            ChromeButton(
                icon = OthentoIcons.UploadArrow,
                contentDescription = content(CK.CAPTURE_TIMEOUT_UPLOAD_INSTEAD),
                onClick = callbacks.onOpenUploadSheet,
            )
        } else {
            Spacer(Modifier.size(ChromeButtonSize))
        }
        ShutterButton(
            enabled = state.captureReady && !state.isPreviewing,
            progress = state.captureProgress,
            onClick = callbacks.onShutter,
        )
        if (state.torchAvailable) {
            TorchButton(torchOn = state.torchOn, onClick = callbacks.onToggleTorch)
        } else {
            Spacer(Modifier.size(ChromeButtonSize))
        }
    }
}

@Composable
private fun ShutterButton(
    enabled: Boolean,
    progress: Float,
    onClick: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val currentTarget by rememberUpdatedState(progress.coerceIn(0f, 1f))
    var displayed by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        // Continuous prediction + gentle correction (a complementary filter).
        // Each frame, predict the ring forward at the nominal hold rate so it
        // moves at constant velocity — one smooth flow that never waits on the
        // analyzer's discrete ~7 fps progress samples — then nudge it softly
        // toward the latest true sample `t` to bound drift. The nudge is
        // deliberately slow (a fraction per second) so it neither snaps the ring
        // back and forth as samples arrive (the flicker) nor pins it to the
        // sample staircase (the stepping); under normal load the prediction
        // already matches the real hold rate, so the correction is near zero.
        // holdProgress only ever drops to 0 on a reset, which empties the ring.
        var lastFrameMs = withFrameMillis { it }
        while (true) {
            val now = withFrameMillis { it }
            val dtSec = ((now - lastFrameMs).coerceIn(1L, 50L)) / 1000f
            lastFrameMs = now
            val t = currentTarget
            displayed =
                if (t <= 0f) {
                    0f
                } else {
                    val predicted = displayed + dtSec / SHUTTER_FILL_DURATION_SEC
                    val k = (SHUTTER_CORRECTION_RATE * dtSec).coerceIn(0f, 1f)
                    (predicted + (t - predicted) * k).coerceIn(0f, 1f)
                }
        }
    }
    val clamped = displayed
    Box(
        modifier =
            Modifier
                .size(ShutterSize)
                .clip(CircleShape)
                .background(WhiteAlpha15)
                .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = SHUTTER_RING_STROKE.toPx()
            val inset = stroke / 2f
            val topLeft = Offset(inset, inset)
            val arcSize =
                androidx.compose.ui.geometry.Size(
                    size.width - stroke,
                    size.height - stroke,
                )
            drawArc(
                color = colors.primary.copy(alpha = 0.30f),
                startAngle = 0f,
                sweepAngle = SHUTTER_FULL_SWEEP,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            if (clamped > 0f) {
                drawArc(
                    color = colors.primary.copy(alpha = 0.95f),
                    startAngle = SHUTTER_START_ANGLE,
                    sweepAngle = SHUTTER_FULL_SWEEP * clamped,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }
        }
        KycIcon(
            imageVector = OthentoIcons.Camera,
            contentDescription = content(CK.CAPTURE_SCAN_BUTTON),
            sizeDp = 28.dp,
            tint = Color.White,
        )
    }
}

private val SHUTTER_RING_STROKE: Dp = 4.dp
private const val SHUTTER_START_ANGLE: Float = -90f
private const val SHUTTER_FULL_SWEEP: Float = 360f

/**
 * Nominal seconds for the shutter ring to sweep 0 → 1 — the rate at which the
 * detection hold itself advances. Must stay equal to the pipeline's
 * `HOLD_TARGET_MS` (1300 ms); the ring's loop predicts forward at this rate
 * between the analyzer's discrete progress samples so it sweeps as one
 * continuous flow instead of stepping.
 */
private const val SHUTTER_FILL_DURATION_SEC: Float = 1.3f

/**
 * How fast the shutter ring corrects toward the true progress sample, in
 * fraction-per-second. Small on purpose: large enough to keep the ring from
 * drifting past the real hold (so it still completes with the capture), small
 * enough that the pull toward the discrete ~7 fps samples stays invisible — the
 * constant-velocity prediction dominates the motion, so the ring neither
 * flickers (no hard snap onto each sample) nor steps (not pinned to the
 * staircase).
 */
private const val SHUTTER_CORRECTION_RATE: Float = 3f

@Composable
private fun TorchButton(
    torchOn: Boolean,
    onClick: () -> Unit,
) {
    Box(
        modifier =
            Modifier
                .size(ChromeButtonSize)
                .clip(CircleShape)
                .background(if (torchOn) Color.White else WhiteAlpha12)
                .border(width = 1.dp, color = WhiteAlpha10, shape = CircleShape)
                .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        KycIcon(
            imageVector = if (torchOn) OthentoIcons.Bolt else OthentoIcons.BoltOff,
            contentDescription = content(CK.CAPTURE_FLASH_LABEL),
            sizeDp = 16.dp,
            tint = if (torchOn) Color.Black else Color.White,
        )
    }
}

@Composable
private fun CameraLoading() {
    val typography = LocalOthentoTypography.current
    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Canvas(modifier = Modifier.size(40.dp)) {
            drawArc(
                color = Color.White.copy(alpha = 0.25f),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = 4.dp.toPx()),
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            text = content(CK.CAPTURE_PREPARING_CAMERA),
            style = typography.body,
            color = Color.White,
        )
    }
}

@Composable
private fun CameraPermissionDenied(
    onTryAgain: () -> Unit,
    onUseFallback: () -> Unit,
    enableFallback: Boolean,
    permanentlyDenied: Boolean,
    onOpenSettings: () -> Unit,
) {
    // One body for both denial states. The old copy split them because the
    // permanent case had to explain *how* to grant access; now that the button
    // says "Open settings", the body no longer carries a mechanism and the two
    // states differ only in the action offered.
    val body = content(CK.CAPTURE_CAMERA_REQUIRED_DENIED)
    val primaryLabel =
        if (permanentlyDenied) {
            content(CK.CAPTURE_CAMERA_REQUIRED_OPEN_SETTINGS)
        } else {
            content(CK.CAPTURE_TIMEOUT_TRY_AGAIN)
        }
    val onPrimary = if (permanentlyDenied) onOpenSettings else onTryAgain
    CameraErrorState(
        icon = OthentoIcons.CameraSlash,
        title = content(CK.CAPTURE_CAMERA_REQUIRED_TITLE),
        body = body,
        primaryLabel = primaryLabel,
        onPrimary = onPrimary,
        secondaryLabel = if (enableFallback) content(CK.CAPTURE_TIMEOUT_UPLOAD_INSTEAD) else null,
        onSecondary = if (enableFallback) onUseFallback else null,
    )
}

@Composable
private fun CameraUnavailable(
    onTryAgain: () -> Unit,
    onUseFallback: () -> Unit,
    enableFallback: Boolean,
) {
    CameraErrorState(
        icon = OthentoIcons.CameraSlash,
        // "Camera access required" would be wrong here — nothing was denied,
        // the device simply has no camera. The contract splits this state across
        // two keys rather than giving it a title of its own: the noCamera line is
        // the headline and `error.device.cameraNotAccessible` continues it ("Or
        // not accessible on this device"). Rendering either alone loses half the
        // sentence, which is why the second key looked unused.
        title = content(CK.CAPTURE_CAMERA_REQUIRED_NO_CAMERA),
        body = content(CK.ERROR_DEVICE_CAMERA_NOT_ACCESSIBLE),
        primaryLabel = content(CK.CAPTURE_TIMEOUT_TRY_AGAIN),
        onPrimary = onTryAgain,
        secondaryLabel = if (enableFallback) content(CK.CAPTURE_TIMEOUT_UPLOAD_INSTEAD) else null,
        onSecondary = if (enableFallback) onUseFallback else null,
    )
}

@Composable
private fun CameraTimeout(
    onTryAgain: () -> Unit,
    onUseFallback: () -> Unit,
    enableFallback: Boolean,
) {
    CameraErrorState(
        icon = OthentoIcons.CameraSlash,
        title = content(CK.CAPTURE_TIMEOUT_TITLE),
        body = content(CK.CAPTURE_TIMEOUT_MESSAGE),
        primaryLabel = content(CK.CAPTURE_TIMEOUT_TRY_AGAIN),
        onPrimary = onTryAgain,
        secondaryLabel = if (enableFallback) content(CK.CAPTURE_TIMEOUT_UPLOAD_INSTEAD) else null,
        onSecondary = if (enableFallback) onUseFallback else null,
    )
}

@Composable
private fun CameraErrorState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
    primaryLabel: String,
    onPrimary: () -> Unit,
    secondaryLabel: String?,
    onSecondary: (() -> Unit)?,
) {
    val typography = LocalOthentoTypography.current
    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
                .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        KycIcon(
            imageVector = icon,
            contentDescription = null,
            sizeDp = 56.dp,
            tint = Color.White.copy(alpha = 0.7f),
        )
        Spacer(Modifier.height(20.dp))
        Text(
            text = title,
            style = typography.titleH3.copy(fontWeight = FontWeight.W600),
            color = Color.White,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = body,
            style = typography.body,
            color = Color.White.copy(alpha = 0.85f),
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(32.dp))
        KycButton(
            onClick = onPrimary,
            label = primaryLabel,
            variant = KycButtonVariant.Primary,
            size = KycButtonSize.Lg,
        )
        if (secondaryLabel != null && onSecondary != null) {
            Spacer(Modifier.height(12.dp))
            KycButton(
                onClick = onSecondary,
                label = secondaryLabel,
                variant = KycButtonVariant.Secondary,
                size = KycButtonSize.Md,
            )
        }
    }
}

@Composable
private fun PreviewState(
    capturedPreview: @Composable () -> Unit,
    isValidating: Boolean,
    warnings: List<ValidationWarning>,
    onRetake: () -> Unit,
    onConfirm: () -> Unit,
) {
    CaptureReviewSheet(
        title = content(CK.CAPTURE_REVIEW_OK_TITLE),
        subtitle = content(CK.CAPTURE_REVIEW_OK_SUBTITLE),
        validationText = content(CK.IDV_CAPTURE_CHECKING_QUALITY),
        capturedPreview = capturedPreview,
        isValidating = isValidating,
        warnings = warnings,
        onRetake = onRetake,
        onConfirm = onConfirm,
        hasBlockingIssue =
            warnings.any {
                it.issue == ValidationIssue.NoCard || it.issue == ValidationIssue.Glare
            },
    )
}

@Composable
private fun DocumentWarningBubble(
    text: String,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Row(
            modifier =
                Modifier
                    .wrapContentSize()
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(modifier = Modifier.size(StatusDotSize).clip(CircleShape).background(AmberDotColor))
            Text(
                text = text,
                style = LocalOthentoTypography.current.caption.copy(fontWeight = FontWeight.W600),
                color = AmberDotColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// --- Tokens / colors -----------------------------------------------------

private val ChromeButtonSize: Dp = 36.dp
private val ChromeHorizontal: Dp = 12.dp
private val ChromeVertical: Dp = 12.dp
private val ChromeGap: Dp = 8.dp
private val ChromePillFlagGap: Dp = 8.dp
private val StatusPillBottomGap: Dp = 12.dp
private val StatusDotSize: Dp = 6.dp
private val CornerBracketSize: Dp = 24.dp
private val ShutterSize: Dp = 64.dp
private val CaptureRowTopGap: Dp = 16.dp
private val BottomGap: Dp = 16.dp

private val WhiteAlpha8 = Color(0xFFFFFFFF).copy(alpha = 0.08f)
private val WhiteAlpha10 = Color(0xFFFFFFFF).copy(alpha = 0.10f)
private val WhiteAlpha12 = Color(0xFFFFFFFF).copy(alpha = 0.12f)
private val WhiteAlpha15 = Color(0xFFFFFFFF).copy(alpha = 0.15f)
private val AmberDotColor = Color(0xFFFBBF24)

// V30 detection overlay colours.
// Detection-overlay color when the document is NOT yet in a state where
// auto-capture would fire (outside the cutout, or stale corners while
// the pipeline searches). Mirrors the web SDK's `#FBBF24`. The "good"
// state uses the theme's primary color, picked from `LocalOthentoColors`
// per-render so brand overrides take effect.
internal val DetectionOutsideColor = Color(0xFFFBBF24)

/** `{seconds}` in `capture.prompt.holdSteady`. */
private const val PLACEHOLDER_SECONDS = "seconds"

/** No contract key for the back affordance — native-only copy (plan §8.2). */
private const val DEFAULT_WIDTH_MM: Double = 85.6
private const val DEFAULT_HEIGHT_MM: Double = 54.0

// ICAO 9303 TD3 (passport) physical dimensions.
private const val PASSPORT_WIDTH_MM: Double = 125.0
private const val PASSPORT_HEIGHT_MM: Double = 88.0
