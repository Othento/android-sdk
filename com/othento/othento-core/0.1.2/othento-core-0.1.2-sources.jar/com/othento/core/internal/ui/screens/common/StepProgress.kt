package com.othento.core.internal.ui.screens.common

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.content
import com.othento.core.internal.data.model.Session

/**
 * Step-progress numbers for the screen header — the spec's
 * `Step X of Y` label and the matching progress-segment bar.
 *
 * Mirrors the web SDK's verify.ts step-grouping logic: each step in
 * `session.steps` is mapped to a logical group (`document` / `face` / `phone`
 * / `email`), and the progress bar shows one segment per distinct group.
 *
 * - `step_id_verification` → "document" group.
 * - `step_face_match` + `step_liveness_check` → "face" group (selfie
 *   capture + liveness video are presented as one step to the user).
 * - `step_phone_verification` → "phone" group.
 * - `step_email_verification` → "email" group.
 *
 * For workflows that include only a subset of these (e.g. doc-only),
 * `total` reflects only the configured groups. The `currentIndex` is the
 * group of `session.currentStep`, falling back to group 0 when the session
 * has no current step yet (Created → Start screen, where the progress bar
 * is hidden anyway).
 */
internal data class StepProgress(
    val currentIndex: Int,
    val total: Int,
) {
    companion object {
        val Default: StepProgress = StepProgress(currentIndex = 0, total = 1)

        @Suppress("ReturnCount") // Two early-outs (null session / empty steps); one happy path.
        fun of(session: Session?): StepProgress {
            val steps = session?.steps ?: return Default
            if (steps.isEmpty()) return Default
            val groups = steps.map { stepGroupOf(it.stepCode) }.distinct()
            val total = groups.size
            val activeStepCode = session.currentStep?.stepCode ?: steps.first().stepCode
            val groupOfCurrent = stepGroupOf(activeStepCode)
            val currentIndex = groups.indexOf(groupOfCurrent).coerceAtLeast(0)
            return StepProgress(currentIndex = currentIndex, total = total)
        }

        private fun stepGroupOf(stepCode: String): String =
            when (stepCode) {
                STEP_ID_VERIFICATION -> GROUP_DOCUMENT
                STEP_FACE_MATCH, STEP_LIVENESS_CHECK -> GROUP_FACE
                STEP_PHONE_VERIFICATION -> GROUP_PHONE
                STEP_EMAIL_VERIFICATION -> GROUP_EMAIL
                else -> stepCode
            }

        private const val STEP_ID_VERIFICATION = "step_id_verification"
        private const val STEP_FACE_MATCH = "step_face_match"
        private const val STEP_LIVENESS_CHECK = "step_liveness_check"
        private const val STEP_PHONE_VERIFICATION = "step_phone_verification"
        private const val STEP_EMAIL_VERIFICATION = "step_email_verification"

        private const val GROUP_DOCUMENT = "document"
        private const val GROUP_FACE = "face"
        private const val GROUP_PHONE = "phone"
        private const val GROUP_EMAIL = "email"
    }
}

/**
 * The guided header's `Step 2 of 3`, resolved from content.
 *
 * This is a composable extension rather than a property on [StepProgress]
 * because the numbers are computed off the composition (from the session) while
 * the sentence they go into can only be read on it. Keeping the property meant
 * the label was assembled in Kotlin — `"Step ${i + 1} of $total"` — so it was
 * the one string on these three screens that stayed English no matter which
 * language the bundle resolved.
 *
 * Both placeholders are bound. Binding only one leaves the other *literal* by
 * design (see `ContentBundle`'s resolution rule 4), which surfaces as a user
 * reading `Step {index} of 3` rather than as a blank.
 */
@Composable
@ReadOnlyComposable
internal fun StepProgress.progressLabel(): String =
    content(
        ContentKeys.STEPS_PROGRESS_LABEL,
        PLACEHOLDER_INDEX to currentIndex + 1,
        PLACEHOLDER_TOTAL to total,
    )

private const val PLACEHOLDER_INDEX = "index"
private const val PLACEHOLDER_TOTAL = "total"
