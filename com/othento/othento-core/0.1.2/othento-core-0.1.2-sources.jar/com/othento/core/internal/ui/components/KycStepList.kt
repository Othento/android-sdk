@file:Suppress("FunctionNaming", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.content
import com.othento.core.internal.content.contentPlural
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.internal.ui.theme.colorMix
import kotlinx.coroutines.delay

/** Spec §14 — `KycStepCardInput`. */
@Immutable
internal data class KycStepCardInput(
    val name: String,
    val detail: String? = null,
    val duration: String? = null,
    val stepCode: String? = null,
)

/** Spec §14 — `variant`. Source: `apps/sdk/.../kyc-step-list.html:1`. */
@Immutable
internal enum class KycStepListVariant { Detailed, Compact }

/**
 * Vertical step list (detailed) or horizontal chip strip (compact). Faithful
 * port of `apps/sdk/.../kyc-step-list/`.
 */
@Composable
internal fun KycStepList(
    steps: List<KycStepCardInput>,
    modifier: Modifier = Modifier,
    variant: KycStepListVariant = KycStepListVariant.Detailed,
    showDurations: Boolean = true,
    totalEstimate: String = "",
) {
    when (variant) {
        KycStepListVariant.Detailed ->
            DetailedVariant(steps, modifier, showDurations, totalEstimate)
        KycStepListVariant.Compact ->
            CompactVariant(steps, modifier)
    }
}

// ---- Detailed -----------------------------------------------------------

@Composable
private fun DetailedVariant(
    steps: List<KycStepCardInput>,
    modifier: Modifier,
    showDurations: Boolean,
    totalEstimate: String,
) {
    Column(
        modifier =
            modifier
                .fillMaxWidth()
                .widthIn(max = DetailedMaxWidth),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (totalEstimate.isNotBlank()) {
            MetaPill(stepCount = steps.size, totalEstimate = totalEstimate)
        }
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(RowGap),
        ) {
            steps.forEachIndexed { index, step ->
                DetailedRow(
                    index = index,
                    step = step,
                    showDurations = showDurations,
                )
            }
        }
    }
}

@Composable
private fun MetaPill(
    stepCount: Int,
    totalEstimate: String,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val pillBg = remember(colors) { colorMix(colors.primary, MetaPillBgFraction, colors.bgBase) }
    val pillBorder = remember(colors) { colors.primary.copy(alpha = MetaPillBorderAlpha) }
    Row(
        modifier =
            Modifier
                .padding(bottom = MetaBottomGap)
                .clip(RoundedCornerShape(percent = 50))
                .background(pillBg)
                .border(width = 1.dp, color = pillBorder, shape = RoundedCornerShape(percent = 50))
                .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // count uses sans (font-base) per kyc-step-list.scss:58
        Text(
            text = contentPlural(ContentKeys.STEPS_COUNT_LABEL, stepCount),
            style =
                typography.microEyebrow.copy(
                    fontFamily = typography.body.fontFamily,
                    letterSpacing = MetaLetterSpacingSp,
                ),
            color = colors.primary,
        )
        // separator dot — 3 dp circle, currentColor at 0.4 alpha
        Box(
            modifier =
                Modifier
                    .size(MetaSepSize)
                    .clip(CircleShape)
                    .background(colors.primary.copy(alpha = MetaSepAlpha)),
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            KycIcon(
                imageVector = OthentoIcons.Clock,
                contentDescription = null,
                sizeDp = MetaClockSize,
                tint = colors.primary.copy(alpha = MetaTimeIconAlpha),
            )
            Text(
                text = totalEstimate,
                style = typography.numericBadge,
                color = colors.primary,
            )
        }
    }
}

@Composable
@Suppress("LongMethod")
private fun DetailedRow(
    index: Int,
    step: KycStepCardInput,
    showDurations: Boolean,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val shapes = LocalOthentoShapes.current
    val motion = LocalOthentoMotion.current
    val density = LocalDensity.current

    // Per-row staggered entry: opacity 0 → 1, translateY 8 → 0 over 380 ms
    // ease-out, with delay = i*70 + 80 ms (`kyc-step-list.scss:6-10` +
    // `kyc-step-list.html:39`).
    val opacity = remember { Animatable(0f) }
    val translateYDp = remember { Animatable(RowEnterTranslateDp.value) }
    val translateYPx = with(density) { translateYDp.value.dp.toPx() }
    LaunchedEffect(Unit) {
        if (motion.reducedMotion) {
            opacity.snapTo(1f)
            translateYDp.snapTo(0f)
            return@LaunchedEffect
        }
        delay((index * RowStaggerStepMs + RowStaggerInitialMs).toLong())
        opacity.animateTo(1f, tween(RowEnterMs, easing = motion.easeOut))
    }
    LaunchedEffect(Unit) {
        if (!motion.reducedMotion) {
            delay((index * RowStaggerStepMs + RowStaggerInitialMs).toLong())
            translateYDp.animateTo(0f, tween(RowEnterMs, easing = motion.easeOut))
        }
    }

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .alpha(opacity.value)
                .graphicsLayer { translationY = translateYPx }
                .clip(shapes.md)
                .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(RowChildGap),
    ) {
        StepIconTile(stepCode = step.stepCode, index = index)
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                Text(
                    text = content(ContentKeys.STEPS_INDEX_LABEL, PLACEHOLDER_INDEX to index + 1),
                    style = typography.stepIndex,
                    color = colors.primary.copy(alpha = StepIndexAlpha),
                )
                Text(
                    text = step.name,
                    style =
                        typography.bodyLg.copy(
                            fontWeight = FontWeight.W600,
                            fontSize = StepNameSizeSp,
                        ),
                    color = colors.textPrimary,
                )
            }
            step.detail?.takeIf { it.isNotBlank() }?.let { detail ->
                Text(
                    text = detail,
                    style = typography.caption,
                    color = colors.textMuted,
                )
            }
        }
        if (showDurations) {
            step.duration?.takeIf { it.isNotBlank() }?.let { duration ->
                Box(
                    modifier =
                        Modifier
                            .clip(RoundedCornerShape(percent = 50))
                            .background(colors.bgLayout)
                            .border(width = 1.dp, color = colors.border, shape = RoundedCornerShape(percent = 50))
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                ) {
                    Text(
                        text = duration,
                        style = typography.numericBadge,
                        color = colors.textMuted,
                    )
                }
            }
        }
    }
}

@Composable
private fun StepIconTile(
    stepCode: String?,
    index: Int,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    // Diagonal gradient: 135° = top-left → bottom-right; web uses
    // color-mix(primary 10%, bg-base) → color-mix(primary 16%, bg-base).
    val tileBrush =
        remember(colors) {
            Brush.linearGradient(
                colors =
                    listOf(
                        colorMix(colors.primary, IconTileMinFraction, colors.bgBase),
                        colorMix(colors.primary, IconTileMaxFraction, colors.bgBase),
                    ),
                start = Offset.Zero,
                end = Offset.Infinite,
            )
        }
    Box(
        modifier =
            Modifier
                .size(IconTileSize)
                .clip(RoundedCornerShape(IconTileRadius))
                .background(tileBrush),
        contentAlignment = Alignment.Center,
    ) {
        val glyph = stepGlyphFor(stepCode)
        if (glyph != null) {
            KycIcon(
                imageVector = glyph,
                contentDescription = null,
                sizeDp = IconGlyphSize,
                tint = colors.primary,
            )
        } else {
            Text(
                text = (index + 1).toString(),
                style = typography.numericBadge.copy(fontSize = IconFallbackSizeSp),
                color = colors.primary,
            )
        }
    }
}

// ---- Compact ------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CompactVariant(
    steps: List<KycStepCardInput>,
    modifier: Modifier,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    FlowRow(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        steps.forEachIndexed { index, step ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier =
                    Modifier
                        .clip(RoundedCornerShape(percent = 50))
                        .background(colors.primaryBg)
                        .padding(horizontal = 10.dp, vertical = 5.dp),
            ) {
                Box(
                    modifier =
                        Modifier
                            .size(CompactNumberSize)
                            .clip(CircleShape)
                            .background(colors.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = (index + 1).toString(),
                        style = typography.stepIndex,
                        color = Color.White,
                    )
                }
                Text(
                    text = step.name,
                    style = typography.microEyebrow,
                    color = colors.primary,
                )
            }
            if (index != steps.lastIndex) {
                Box(
                    modifier = Modifier.width(10.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    KycIcon(
                        imageVector = OthentoIcons.ChevronRight,
                        contentDescription = null,
                        size = KycIconSize.Sm,
                        tint = colors.textMuted.copy(alpha = ChevronAlpha),
                        // Separator between steps — it points the way the list
                        // progresses, so it flips with the list.
                        modifier = Modifier.mirrorInRtl(),
                    )
                }
            }
        }
    }
}

internal fun stepGlyphFor(stepCode: String?): ImageVector? =
    when (stepCode) {
        "step_id_verification" -> OthentoIcons.IdCard
        "step_face_match" -> OthentoIcons.UserCheck
        "step_liveness_check" -> OthentoIcons.ScanFace
        "step_phone_verification" -> OthentoIcons.Smartphone
        "step_email_verification" -> OthentoIcons.Envelope
        else -> null
    }

private val DetailedMaxWidth = 440.dp
private val RowGap = 4.dp
private val RowChildGap = 14.dp
private val MetaBottomGap = 20.dp
private val MetaSepSize = 3.dp
private val MetaClockSize = 11.dp
private val IconTileSize = 44.dp
private val IconTileRadius = 12.dp
private val IconGlyphSize = 22.dp
private val CompactNumberSize = 16.dp
private const val ChevronAlpha = 0.5f
private const val IconTileMinFraction = 0.10f
private const val IconTileMaxFraction = 0.16f
private const val MetaPillBgFraction = 0.06f
private const val MetaPillBorderAlpha = 0.14f
private const val MetaSepAlpha = 0.4f
private const val MetaTimeIconAlpha = 0.9f
private const val StepIndexAlpha = 0.85f
private const val RowEnterMs = 380
private const val RowStaggerStepMs = 70
private const val RowStaggerInitialMs = 80
private val RowEnterTranslateDp = 8.dp
private val MetaLetterSpacingSp = 0.3.sp
private val StepNameSizeSp = 15.sp
private val IconFallbackSizeSp = 14.sp

private const val PLACEHOLDER_INDEX = "index"
