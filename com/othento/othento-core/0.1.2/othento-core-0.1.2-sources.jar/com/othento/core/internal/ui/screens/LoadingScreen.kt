@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.content
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.components.KycSkeleton
import com.othento.core.internal.ui.components.KycSkeletonRadius

/**
 * Spec [docs/spec/06-screens/01-loading.md]:
 * a stylized skeleton placeholder mimicking the upcoming Start screen so the
 * layout doesn't visibly jump on transition.
 *
 * `KycScreen` is invoked with `animate=false` per the spec — the entrance
 * animation is suppressed (the skeleton's own shimmer is the only motion).
 *
 * The spec flags adding `aria-busy="true"` + a visually hidden "Loading
 * verification…" string as a known-gap; Phase 4 lands the latter via
 * `Modifier.semantics { contentDescription = … }` on the skeleton column so
 * TalkBack reads it.
 */
@Composable
internal fun LoadingScreen() {
    val loadingLabel = content(ContentKeys.A11Y_LOADING)
    KycScreen(
        zone = KycScreenZone.Result,
        animate = false,
        body = {
            Column(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = HorizontalPadding)
                        .semantics {
                            contentDescription = loadingLabel
                            liveRegion = LiveRegionMode.Polite
                        },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    modifier =
                        Modifier
                            .size(IconPlaceholderSize),
                ) {
                    KycSkeleton(
                        modifier = Modifier.fillMaxSize(),
                        radius = KycSkeletonRadius.Md,
                        height = IconPlaceholderSize,
                    )
                }
                Spacer(modifier = Modifier.height(SkeletonGap))
                KycSkeleton(
                    modifier = Modifier.fillMaxWidth(0.6f),
                    height = TitleHeight,
                    radius = KycSkeletonRadius.Sm,
                )
                Spacer(modifier = Modifier.height(InnerGap))
                KycSkeleton(
                    modifier = Modifier.fillMaxWidth(0.8f),
                    height = SubtitleHeight,
                    radius = KycSkeletonRadius.Sm,
                )
                Spacer(modifier = Modifier.height(StepGap))
                StepRowSkeleton()
                Spacer(modifier = Modifier.height(StepRowGap))
                StepRowSkeleton()
            }
        },
    )
}

@Composable
private fun StepRowSkeleton() {
    Row(
        modifier = Modifier.fillMaxWidth(0.85f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Left rail — 4 dp wide, 44 dp tall pill.
        KycSkeleton(
            modifier = Modifier.width(RailWidth),
            height = RailHeight,
            radius = KycSkeletonRadius.Full,
        )
        Spacer(modifier = Modifier.width(RowInnerGap))
        Column(modifier = Modifier.fillMaxWidth()) {
            KycSkeleton(
                modifier = Modifier.fillMaxWidth(0.4f),
                height = StepLineSmHeight,
                radius = KycSkeletonRadius.Sm,
            )
            Spacer(modifier = Modifier.height(StepLineGap))
            KycSkeleton(
                modifier = Modifier.fillMaxWidth(0.85f),
                height = StepLineLgHeight,
                radius = KycSkeletonRadius.Sm,
            )
        }
    }
}

private val HorizontalPadding = 24.dp
private val IconPlaceholderSize = 40.dp
private val SkeletonGap = 24.dp
private val TitleHeight = 22.dp
private val SubtitleHeight = 14.dp
private val InnerGap = 8.dp
private val StepGap = 32.dp
private val StepRowGap = 16.dp
private val RailWidth = 4.dp
private val RailHeight = 44.dp
private val RowInnerGap = 12.dp
private val StepLineSmHeight = 10.dp
private val StepLineLgHeight = 14.dp
private val StepLineGap = 4.dp
