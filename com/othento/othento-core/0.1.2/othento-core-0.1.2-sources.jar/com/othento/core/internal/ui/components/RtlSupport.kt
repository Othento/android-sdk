@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

/**
 * Opts a subtree back out of RTL mirroring.
 *
 * Most of the SDK mirrors correctly for free, so this is the exception, not the
 * habit. Reach for it only when the content is **not** prose — where the
 * left-to-right order carries meaning that a translation does not change:
 *
 * - a one-time code, whose boxes are filled in typing order,
 * - an E.164 phone number, which is LTR in every locale,
 * - a third-party Compose surface whose RTL behaviour we do not control.
 *
 * Using it anywhere else produces a screen that is half-mirrored, which reads
 * worse than either direction on its own.
 */
@Composable
internal fun ForceLtr(content: @Composable () -> Unit) {
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Ltr,
        content = content,
    )
}

/**
 * Horizontally flips a glyph when the layout is RTL.
 *
 * Layout mirroring moves a back arrow to the other side of the screen but does
 * **not** turn it around — the icon is a bitmap of a shape, and Compose has no
 * way to know the shape means "backwards". Apply this to glyphs that encode
 * direction (arrows, forward chevrons) and to nothing else: mirroring a check
 * mark, a clock or a camera just makes it look wrong.
 */
@Composable
internal fun Modifier.mirrorInRtl(): Modifier =
    if (LocalLayoutDirection.current == LayoutDirection.Rtl) {
        this.scale(scaleX = -1f, scaleY = 1f)
    } else {
        this
    }
