@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.ResultMode
import com.othento.core.internal.content.ResultTone
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.screens.common.ContentStatusScreen
import com.othento.core.internal.ui.screens.common.returnToAppLabel
import com.othento.core.internal.ui.screens.common.StatusAction

/** `result.declined.*` — red cross, definitive negative inference. */
@Composable
internal fun DeclinedScreen(onReturnToApp: () -> Unit) {
    ContentStatusScreen(
        prefix = ContentKeys.RESULT_DECLINED,
        fallbackIcon = StatusIconName.Cross,
        fallbackTone = ResultTone.Error,
        fallbackMode = ResultMode.Terminal,
        primaryAction = StatusAction(label = returnToAppLabel(), onClick = onReturnToApp),
    )
}
