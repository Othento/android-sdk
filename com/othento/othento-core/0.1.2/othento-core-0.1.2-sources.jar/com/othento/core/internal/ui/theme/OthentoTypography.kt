package com.othento.core.internal.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp

/**
 * Resolved type-scale per [docs/spec/04-design-system.md] §2.2.
 *
 * **Font families**: Phase 2 maps Plex Sans → [FontFamily.SansSerif] (Roboto on
 * Android) and Plex Mono → [FontFamily.Monospace], matching the spec's
 * documented CSS fallback chain (§2.1: `…BlinkMacSystemFont, 'Segoe UI',
 * Roboto, sans-serif`). Bundling Plex Sans + Mono as resources is deferred —
 * see open question U4.
 *
 * **That deferral is now load-bearing for RTL.** Using the system families
 * means Arabic renders through Android's own font fallback (Roboto → Noto
 * Naskh Arabic), so the SDK needs no bundled Arabic face — which is why the
 * content plan's §8.4 prerequisite ("we must bundle a font with Arabic
 * coverage before RTL") does not bite on this platform.
 *
 * The corollary is the part worth remembering: **closing U4 by bundling IBM
 * Plex Sans would break Arabic**, because Plex Sans ships no Arabic coverage
 * and an explicit [androidx.compose.ui.text.font.FontFamily] suppresses the
 * system fallback for the glyphs it claims. If U4 is ever revisited, bundle
 * IBM Plex Sans **Arabic** alongside it and select per resolved language.
 *
 * Letter-spacing is expressed in `em` (relative to the size); spec lists
 * absolute px so we convert at the call site (px = em × size).
 */
@Immutable
internal data class OthentoTypography(
    val display: TextStyle,
    val titleH1: TextStyle,
    val titleH2: TextStyle,
    val titleH3: TextStyle,
    val subtitle: TextStyle,
    val bodyLg: TextStyle,
    val body: TextStyle,
    val bodySm: TextStyle,
    val caption: TextStyle,
    val microEyebrow: TextStyle,
    val stepIndex: TextStyle,
    val numericBadge: TextStyle,
    val buttonMd: TextStyle,
    val buttonLg: TextStyle,
    val inputLabel: TextStyle,
    val otpCell: TextStyle,
    val sandboxBanner: TextStyle,
) {
    companion object {
        @Suppress("LongMethod")
        fun default(
            sans: FontFamily = FontFamily.SansSerif,
            mono: FontFamily = FontFamily.Monospace,
        ): OthentoTypography =
            OthentoTypography(
                display =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W700,
                        fontSize = 34.sp,
                        lineHeight = 1.15.em,
                        letterSpacing = (-0.7).sp,
                    ),
                titleH1 =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W700,
                        fontSize = 26.sp,
                        lineHeight = 1.2.em,
                        letterSpacing = (-0.3).sp,
                    ),
                titleH2 =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W700,
                        fontSize = 22.sp,
                    ),
                titleH3 =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W700,
                        fontSize = 20.sp,
                    ),
                subtitle =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W400,
                        fontSize = 15.sp,
                        lineHeight = 1.4.em,
                    ),
                bodyLg =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W400,
                        fontSize = 16.sp,
                        lineHeight = 1.4.em,
                    ),
                body =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W400,
                        fontSize = 14.sp,
                        lineHeight = 1.5.em,
                    ),
                bodySm =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W400,
                        fontSize = 13.sp,
                        lineHeight = 1.4.em,
                    ),
                caption =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W400,
                        fontSize = 12.sp,
                        lineHeight = 1.4.em,
                    ),
                microEyebrow =
                    TextStyle(
                        fontFamily = mono,
                        fontWeight = FontWeight.W600,
                        fontSize = 11.sp,
                        lineHeight = 1.0.em,
                        letterSpacing = 0.5.sp,
                    ),
                stepIndex =
                    TextStyle(
                        fontFamily = mono,
                        fontWeight = FontWeight.W700,
                        fontSize = 10.sp,
                        lineHeight = 1.0.em,
                        letterSpacing = 0.6.sp,
                    ),
                numericBadge =
                    TextStyle(
                        fontFamily = mono,
                        fontWeight = FontWeight.W600,
                        fontSize = 10.sp,
                        lineHeight = 1.0.em,
                        letterSpacing = 0.3.sp,
                    ),
                buttonMd =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W600,
                        fontSize = 14.sp,
                        lineHeight = 1.0.em,
                    ),
                buttonLg =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W600,
                        fontSize = 15.sp,
                        lineHeight = 1.0.em,
                    ),
                inputLabel =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W500,
                        fontSize = 13.sp,
                    ),
                otpCell =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W400,
                        fontSize = 22.sp,
                    ),
                sandboxBanner =
                    TextStyle(
                        fontFamily = sans,
                        fontWeight = FontWeight.W500,
                        fontSize = 11.sp,
                    ),
            )
    }
}

internal val LocalOthentoTypography =
    staticCompositionLocalOf<OthentoTypography> {
        error("OthentoTypography not provided. Wrap content in OthentoTheme { … }.")
    }
