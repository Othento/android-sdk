package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass

/**
 * Minimal best-effort envelope for the dev backend's 4xx/5xx body shape
 * `{ "error": { "message": "..." } }` and the alternate flat shape
 * `{ "message": "..." }`. Used by [com.othento.core.internal.data.OtpRepositoryImpl]
 * to surface a server-supplied error string in the OTP send / verify
 * inline notice.
 *
 * Both fields are optional — the parser falls back to spec defaults
 * when the body diverges.
 */
@JsonClass(generateAdapter = true)
internal data class ApiErrorEnvelopeDto(
    val error: ApiErrorBodyDto? = null,
    val message: String? = null,
    val title: String? = null,
    val detail: String? = null,
    /**
     * RFC 9110 / 7807 field-validation map, e.g.
     * `{ "request.Contact": ["Corporate email required"] }`. The OTP send
     * endpoint reports the corporate-email policy rejection here rather than
     * as a top-level `message`, so the parser flattens these before falling
     * back to the generic `title`.
     */
    val errors: Map<String, List<String>>? = null,
    /**
     * Stable machine-readable error identifier (`OTP_INVALID`,
     * `COOLDOWN_ACTIVE`, …) — the backend's `StatusCodeEnum` member name.
     *
     * This is what error handling branches on, **never** the HTTP status:
     * sibling cases share one (`OTP_EXPIRED` and `OTP_NOT_REQUESTED` are both
     * 410) and need different copy *and* a different primary action. Absent on
     * call sites the backend has not migrated yet, so every consumer must
     * tolerate `null` and fall back to the status.
     */
    val code: String? = null,
)

@JsonClass(generateAdapter = true)
internal data class ApiErrorBodyDto(
    val message: String? = null,
    val title: String? = null,
    val detail: String? = null,
    val code: String? = null,
)
