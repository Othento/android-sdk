package com.othento.core.internal.flow

import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.data.model.Session
import com.othento.core.api.OthentoError

/**
 * Snapshot of everything the Compose `OthentoFlowHost` needs to render a frame.
 *
 * Treated as immutable; [FlowCoordinator] always emits a full replacement
 * rather than mutating in place — same invariant as the web SDK's
 * `adapter.session.set(newSession)` ([docs/spec/08-state-management.md] §2.3).
 *
 * Phase 5 fields:
 * - [documents] — the accepted-documents list once loaded.
 * - [documentsLoading] / [documentsError] — loading + error states for
 *   the DocumentSelect screen.
 * - [selectedCountryKey] / [selectedDocumentId] — in-screen state for the
 *   country dropdown + cards (Phase 5 keeps these in the coordinator so the
 *   Compose screen stays a thin renderer with no `mutableStateOf` of its
 *   own — the user-test's "rotate device on document_select" scenario then
 *   preserves the picks).
 * - [pendingDocument] — selected doc carried into CaptureFront for the
 *   "doc-info chip" + the aspect-ratio cutout.
 * - [uploadProgress] — `null` when no upload is in flight; `0..100` while
 *   uploading. Renders the [com.othento.core.internal.ui.screens.UploadProgressSheet].
 * - [uploadHint] — "almost finished" / "thanks for your patience" delays.
 * - [pollTimedOut] — Processing screen flips to the warning variant.
 * - [oversizedFile] — CaptureFallback inline 10 MB error.
 * - [useFallback] — Phase 6 toggle that swaps the camera capture screen for
 *   the upload-only fallback. Default `false`; flipped to `true` when the
 *   user taps "Upload file instead" on the camera HUD or any of the
 *   permission-denied / unavailable / timeout error states. Reset back to
 *   `false` when the user changes documents (returning to DocumentSelect).
 */
internal data class FlowUiState(
    val screenState: ScreenState,
    val session: Session?,
    val error: OthentoError?,
    val displayMessage: String?,
    val errorHttpStatus: Int?,
    val documents: List<AcceptedDocument>? = null,
    val documentsLoading: Boolean = false,
    val documentsError: String? = null,
    /**
     * The country dropdown's selection, held as
     * [AcceptedDocument.countryGroupKey] — an ISO code, never a display name,
     * which is localised and therefore cannot be an identity.
     */
    val selectedCountryKey: String? = null,
    val selectedDocumentId: String? = null,
    val pendingDocument: AcceptedDocument? = null,
    val uploadProgress: Int? = null,
    val uploadHint: UploadHint = UploadHint.None,
    val pollTimedOut: Boolean = false,
    val oversizedFile: Boolean = false,
    val fileUnreadable: Boolean = false,
    val useFallback: Boolean = false,
    /**
     * Phase-11-pulled-forward — populated when the user has picked a file
     * and the validator is running / has emitted warnings. `null` everywhere
     * else, including during the live upload (which clears this and reads
     * `uploadProgress` instead).
     */
    val pendingCapture: PendingCapture? = null,
    /**
     * Phase 9 — populated when [screenState] is `OtpPhone` / `OtpEmail`.
     * Null on every other screen.
     */
    val otp: OtpUiState? = null,
) {
    companion object {
        val Loading: FlowUiState =
            FlowUiState(
                screenState = ScreenState.Loading,
                session = null,
                error = null,
                displayMessage = null,
                errorHttpStatus = null,
            )
    }
}

/** Soft hint progressively shown on long uploads — matches spec §[06-screens/11-uploading.md]. */
internal enum class UploadHint {
    /** Default — only the "Processing..." label is shown. */
    None,

    /** After 5 s — adds "We're almost finished". */
    AlmostDone,

    /** After 12 s — adds "Thanks for your patience" alongside [AlmostDone]. */
    TakingLonger,
}
