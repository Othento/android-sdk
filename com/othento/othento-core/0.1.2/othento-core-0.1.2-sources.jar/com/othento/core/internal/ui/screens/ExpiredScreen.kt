@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.ResultMode
import com.othento.core.internal.content.ResultTone
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.screens.common.ContentStatusScreen
import com.othento.core.internal.ui.screens.common.returnToAppLabel
import com.othento.core.internal.ui.screens.common.StatusAction

/** `result.expired.*` — amber clock, session past its expiry. */
@Composable
internal fun ExpiredScreen(onReturnToApp: () -> Unit) {
    ContentStatusScreen(
        prefix = ContentKeys.RESULT_EXPIRED,
        fallbackIcon = StatusIconName.Clock,
        fallbackTone = ResultTone.Warning,
        fallbackMode = ResultMode.Terminal,
        primaryAction = StatusAction(label = returnToAppLabel(), onClick = onReturnToApp),
    )
}
