package com.othento.core.internal.ui.screens

import com.amplifyframework.ui.liveness.model.FaceLivenessDetectionException
import com.othento.core.internal.data.RekognitionLivenessRepository
import com.othento.core.internal.data.model.LivenessChallengeMode
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.liveness.LivenessErrorMapper
import com.othento.core.internal.liveness.LivenessOutcome
import com.othento.core.internal.network.OthentoNetworkException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Which page of the Rekognition screen is on screen. */
internal enum class RekognitionView {
    Intro,
    Warning,
    Connecting,
    Streaming,
    Completing,
}

internal data class RekognitionUiState(
    val view: RekognitionView = RekognitionView.Intro,
    val attempts: Int = 0,
    val sessionId: String? = null,
)

/**
 * The Rekognition screen's own state machine.
 *
 * It lives here rather than in `FlowCoordinator` for the reason the design
 * calls out: the coordinator is already ~1100 lines and this flow is entirely
 * local — it reports exactly two things upward, [onCompleted] and [onFailed],
 * mirroring web's `verify.ts`, which also has just those two handlers.
 *
 * Deliberately free of Compose and Android types so the retry cap, the cancel
 * semantics and the photosensitivity gate are testable on the JVM.
 */
@Suppress("LongParameterList")
// Reason: six of the seven are the screen's inputs from the resolved session
// (repository, scope, attemptStepId, photosensitivity, challengeMode) plus the
// two upward callbacks. Bundling them into a config object would add a type
// whose only purpose is to satisfy the threshold, and would hide which values
// come from the advisory hint (and may therefore be absent).
internal class RekognitionLivenessStateHolder(
    private val repository: RekognitionLivenessRepository,
    private val scope: CoroutineScope,
    private val attemptStepId: String,
    private val photosensitivity: Boolean,
    private val challengeMode: LivenessChallengeMode?,
    private val onCompleted: (Session) -> Unit,
    private val onFailed: () -> Unit,
) {
    private val internalState = MutableStateFlow(RekognitionUiState())
    val state: StateFlow<RekognitionUiState> = internalState.asStateFlow()

    /**
     * The warning is about a sequence of coloured lights, so it applies to
     * `FaceMovementAndLight` and nothing else — `FaceMovement` shows no lights
     * at all, and warning about them there is simply wrong.
     *
     * Positive match only: a null mode (hint absent) and
     * [LivenessChallengeMode.Unknown] (a mode we do not recognise) both mean
     * "we were not told", which suppresses the warning rather than defaulting
     * it on. Verified against a live payload on 2026-07-28 that the backend
     * does populate `liveness.challengeMode`, so this gate is not silently off
     * for everyone. If the warning ever stops appearing for light challenges,
     * a null `challengeMode` on the wire is the first thing to check.
     */
    val showsPhotosensitivityWarning: Boolean
        get() = photosensitivity && challengeMode == LivenessChallengeMode.FaceMovementAndLight

    /** Intro / warning CTA. Turns the page, or starts the challenge. */
    fun onContinue() {
        if (showsPhotosensitivityWarning && internalState.value.view == RekognitionView.Intro) {
            internalState.value = internalState.value.copy(view = RekognitionView.Warning)
            return
        }
        begin()
    }

    private fun begin() {
        internalState.value = internalState.value.copy(view = RekognitionView.Connecting)
        scope.launch {
            try {
                val started = repository.start(attemptStepId)
                internalState.value =
                    internalState.value.copy(
                        view = RekognitionView.Streaming,
                        sessionId = started.sessionId,
                    )
            } catch (_: OthentoNetworkException) {
                // No session means nothing to stream to. Leaving the user on a
                // spinner is the one outcome with no way out.
                onFailed()
            }
        }
    }

    /**
     * The component finished its capture. Only now may `/complete` be called —
     * this is its single call site, which is what keeps the cancel path from
     * ever finalizing an abandoned challenge.
     */
    fun onChallengeComplete() {
        internalState.value = internalState.value.copy(view = RekognitionView.Completing)
        scope.launch {
            try {
                onCompleted(repository.complete(attemptStepId))
            } catch (_: OthentoNetworkException) {
                onFailed()
            }
        }
    }

    /**
     * Single error channel from the component. [LivenessOutcome.Cancelled]
     * arrives here rather than through a separate callback because Android has
     * no `onUserCancel` — see [LivenessErrorMapper].
     */
    fun onChallengeError(error: FaceLivenessDetectionException) {
        when (LivenessErrorMapper.map(error)) {
            LivenessOutcome.Cancelled -> {
                // Not a failure: the user backed out. Reset to a clean slate so
                // they get all three attempts if they start again, and never
                // call `/complete` — that would finalize an abandoned challenge.
                internalState.value = RekognitionUiState()
            }
            LivenessOutcome.Retry -> {
                val nextAttempt = internalState.value.attempts + 1
                if (nextAttempt < MAX_ATTEMPTS) {
                    internalState.value =
                        RekognitionUiState(view = RekognitionView.Intro, attempts = nextAttempt)
                } else {
                    onFailed()
                }
            }
            // Permission, fatal and unsupported all end the attempt: retrying
            // re-mints a session and hits the same wall.
            LivenessOutcome.PermissionDenied,
            LivenessOutcome.Fatal,
            LivenessOutcome.UnsupportedUpdate,
            -> onFailed()
        }
    }

    internal companion object {
        /** Per-step attempt cap, matching web. */
        const val MAX_ATTEMPTS: Int = 3
    }
}
