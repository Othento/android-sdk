package com.othento.core.internal.ui.components

import com.othento.core.internal.content.ContentKeys as CK

/**
 * Phase 9 — pure-Kotlin email validation matching the web SDK's
 * `EmailDestinationInput` regex + per-state error messages
 * ([docs/spec/06-screens/10-otp-email.md] §"Email destination input").
 *
 * The web SDK ships a single regex `^[^\s@]+@[^\s@]+\.[^\s@]+$` and
 * surfaces granular messages for each common failure mode (missing `@`,
 * empty local / domain, missing dot in domain). This object replicates
 * that exact behaviour so a JVM unit test can confirm parity.
 */
internal object EmailValidator {
    private val EMAIL_REGEX: Regex = Regex("""^[^\s@]+@[^\s@]+\.[^\s@]+$""")

    /**
     * Public / free email domains rejected when the email step is
     * configured corporate-only (challenge `corporateEmailOnly = true`).
     * Copied verbatim from the web portal register form's blocklist
     * (`libs/shared/logic/.../validation.service.ts#PUBLIC_EMAIL_DOMAINS`)
     * so the SDK enforces the same "work email only" rule as the portal.
     */
    private val PUBLIC_EMAIL_DOMAINS: Set<String> =
        setOf(
            "gmail.com",
            "yahoo.com",
            "hotmail.com",
            "outlook.com",
            "aol.com",
            "icloud.com",
            "mail.com",
            "protonmail.com",
            "proton.me",
            "live.com",
            "msn.com",
            "ymail.com",
        )

    const val PUBLIC_DOMAIN_MESSAGE: String = "Please use your work email. Public email domains are not allowed."

    /**
     * @param corporateOnly when `true`, an otherwise-valid address whose
     *   domain is in [PUBLIC_EMAIL_DOMAINS] is rejected. Mirrors the web
     *   portal's `ValidationService.publicEmailDomain` — domain match is
     *   case-insensitive and runs only after the format checks pass.
     */
    @Suppress("ReturnCount")
    fun validate(
        raw: String,
        corporateOnly: Boolean = false,
    ): EmailValidationResult {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return EmailValidationResult.Empty
        if (!trimmed.contains('@')) {
            return EmailValidationResult.Invalid(EmailInvalidReason.MissingAt)
        }
        val parts = trimmed.split('@', limit = 2)
        val local = parts.getOrElse(0) { "" }
        val domain = parts.getOrElse(1) { "" }
        if (local.isEmpty()) {
            return EmailValidationResult.Invalid(EmailInvalidReason.MissingLocal)
        }
        if (domain.isEmpty()) {
            return EmailValidationResult.Invalid(EmailInvalidReason.MissingDomain)
        }
        if (!domain.contains('.')) {
            return EmailValidationResult.Invalid(EmailInvalidReason.MissingDot)
        }
        if (!EMAIL_REGEX.matches(trimmed)) {
            return EmailValidationResult.Invalid(EmailInvalidReason.Malformed)
        }
        if (corporateOnly && domain.lowercase() in PUBLIC_EMAIL_DOMAINS) {
            return EmailValidationResult.Invalid(EmailInvalidReason.PublicDomain)
        }
        return EmailValidationResult.Valid(value = trimmed)
    }
}

internal sealed interface EmailValidationResult {
    object Empty : EmailValidationResult

    data class Valid(
        val value: String,
    ) : EmailValidationResult

    data class Invalid(
        val reason: EmailInvalidReason,
    ) : EmailValidationResult
}

/**
 * Why an address was rejected, as an enum rather than the sentence.
 *
 * [EmailValidator] is plain Kotlin — it runs from a unit test and from a
 * `remember` block, neither of which can read `LocalContent`. The screen
 * resolves [key] at render; [fallback] is the offline value only.
 */
internal enum class EmailInvalidReason(
    val key: String,
    val fallback: String,
) {
    MissingAt(CK.OTP_EMAIL_ERROR_MISSING_AT, "Email must contain an \"@\" symbol."),
    MissingLocal(CK.OTP_EMAIL_ERROR_MISSING_LOCAL, "Enter the part before the \"@\"."),
    MissingDomain(CK.OTP_EMAIL_ERROR_MISSING_DOMAIN, "Enter the domain after the \"@\"."),
    MissingDot(CK.OTP_EMAIL_ERROR_MISSING_DOT, "Domain must include a \".\" (e.g. example.com)."),
    Malformed(CK.OTP_EMAIL_ERROR_INVALID, "This doesn't look like a valid email address."),
    PublicDomain(CK.OTP_ERROR_CORPORATE_EMAIL_REQUIRED, EmailValidator.PUBLIC_DOMAIN_MESSAGE),
}
