package com.othento.core.internal.capture

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.RectF
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.othento.core.internal.capture.detection.face.FaceBox
import com.othento.core.internal.capture.detection.face.FaceDetectorClient
import com.othento.core.internal.capture.detection.face.OvalRoi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Adapts CameraX `ImageAnalysis` into the selfie pipeline for the 2-stream
 * capture path (ImageAnalysis + VideoCapture, no Preview use case). Binding only
 * two streams lets `VideoCapture` hold its own FHD stream instead of being
 * capped at 720p by a 3-stream (Preview + Analysis + Video) surface combination.
 *
 * Each frame is converted once to an UPRIGHT [Bitmap] that:
 * 1. drives the on-screen preview (emitted via [previewBitmap]; the renderer
 *    mirrors it for the user-facing front camera), and
 * 2. feeds ML Kit face detection ([InputImage.fromBitmap], rotation 0).
 *
 * Face detection is async (via [FaceDetectorClient]), so the analyzer thread
 * only does the `toBitmap` + brightness scan and closes the [ImageProxy]
 * immediately — detection never blocks frame delivery. The oval ROI and the
 * face box therefore live in one coordinate space (the upright bitmap), so the
 * face-vs-oval decision matches what the user sees. All positional hints are
 * symmetric ("center your face"), so mirroring the preview inverts nothing.
 */
internal class SelfieFrameAnalyzer(
    private val pipeline: SelfieDetectionPipeline,
    private val client: FaceDetectorClient,
    private val intervalMs: Long = SelfieConfig.DETECTION_INTERVAL_MS,
    private val previewFps: Int = CaptureConfig.PREVIEW_RENDER_FPS,
) : ImageAnalysis.Analyzer {
    private var lastAnalyzedAt = 0L
    private var lastPreviewAt = 0L
    private val previewIntervalMs: Long = 1_000L / previewFps.coerceAtLeast(1)

    /**
     * CW degrees to rotate the raw front-camera bitmap to upright — set from the
     * bind result's deterministic sensor rotation (the per-frame
     * `imageInfo.rotationDegrees` proved unreliable). -1 falls back to imageInfo.
     */
    @Volatile
    var uprightRotationDegrees: Int = -1

    /**
     * Latest upright camera frame for the preview. Owned by the preview
     * StateFlow + async ML Kit; never recycled here (reclaimed by GC). The
     * renderer flips it horizontally for the user-facing camera.
     */
    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    @Suppress("TooGenericExceptionCaught")
    override fun analyze(image: ImageProxy) {
        // STRATEGY_KEEP_ONLY_LATEST: the next frame is delivered only after this
        // proxy is closed, so close it on every path (finally). Detection runs on
        // the upright bitmap copy, not the proxy, so we can close immediately.
        try {
            val now = System.currentTimeMillis()
            if (now - lastPreviewAt < previewIntervalMs) return
            lastPreviewAt = now

            val upright = uprightBitmap(image) ?: return
            _previewBitmap.value = upright

            // Face detection at its own (slower) cadence, dispatched async.
            if (now - lastAnalyzedAt >= intervalMs && !client.isBusy()) {
                lastAnalyzedAt = now
                val brightness = sceneBrightness(image)
                val oval = OvalRoi.centered(upright.width.toFloat(), upright.height.toFloat())
                client.scheduleLatest(InputImage.fromBitmap(upright, 0)) { faces, _ ->
                    if (faces != null) {
                        pipeline.process(faces = faces.toFaceBoxes(), oval = oval, faceBrightness = brightness)
                    }
                }
            }
        } catch (t: Throwable) {
            // A malformed frame must never kill the analyzer stream; drop it.
            Log.w(TAG, "frame dropped: ${t.message}")
        } finally {
            image.close()
        }
    }

    /**
     * Convert [image] to an upright RGB [Bitmap] (rotated to match the display),
     * or null on a conversion failure. The intermediate unrotated bitmap is
     * recycled; the returned bitmap is owned by the preview + async detection.
     */
    private fun uprightBitmap(image: ImageProxy): Bitmap? =
        runCatching {
            val raw = image.toBitmap()
            val rotation = if (uprightRotationDegrees >= 0) uprightRotationDegrees else image.imageInfo.rotationDegrees
            if (rotation == 0) {
                raw
            } else {
                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                Bitmap
                    .createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
                    .also { rotated -> if (rotated != raw) raw.recycle() }
            }
        }.getOrNull()

    /**
     * Mean Y-plane brightness over the full frame, or `null` when it can't be
     * read. Scene-level brightness is what matters for the too-dark / too-bright
     * warning — if the environment is dark the whole frame is dark. Must be
     * called before `image.close()`. Bounds-checked + wrapped so an odd plane
     * layout degrades to "no brightness data" (a skip) rather than throwing.
     */
    private fun sceneBrightness(image: ImageProxy): Int? =
        runCatching {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val rowStride = plane.rowStride
            val limit = buffer.limit()
            val w = image.width
            val h = image.height
            var sum = 0L
            var count = 0L
            for (y in 0 until h) {
                val rowStart = y * rowStride
                for (x in 0 until w) {
                    val idx = rowStart + x
                    if (idx >= limit) break
                    sum += (buffer.get(idx).toInt() and 0xFF)
                    count++
                }
            }
            if (count == 0L) null else (sum / count).toInt()
        }.getOrNull()

    /** Map ML Kit faces to the pipeline's source-px [FaceBox] type. */
    private fun List<Face>.toFaceBoxes(): List<FaceBox> =
        map { f ->
            val r = f.boundingBox
            FaceBox(box = RectF(r.left.toFloat(), r.top.toFloat(), r.right.toFloat(), r.bottom.toFloat()))
        }

    private companion object {
        const val TAG: String = "SelfieFrameAnalyzer"
    }
}
