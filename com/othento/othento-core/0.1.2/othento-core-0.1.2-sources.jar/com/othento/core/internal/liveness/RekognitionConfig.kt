package com.othento.core.internal.liveness

/**
 * Build-time Rekognition configuration.
 *
 * [REGION] is deliberately a constant rather than something read from the
 * challenge hint: the backend's `CreateFaceLivenessSession` call and the
 * client's streaming connection must target the same region, and the client
 * has no way to verify a server-supplied one. Web makes the same choice —
 * `liveness.region` is parsed and ignored on both platforms. Changing regions
 * is an SDK release, coordinated with the backend.
 */
internal object RekognitionConfig {
    const val REGION: String = "eu-west-1"
}
