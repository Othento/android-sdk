@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.amplifyframework.ui.liveness.ui.FaceLivenessDetector
import com.amplifyframework.ui.liveness.ui.LivenessColorScheme
import com.othento.core.internal.data.RekognitionLivenessRepository
import com.othento.core.internal.data.model.LivenessChallengeMode
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.liveness.BackendCredentialsProvider
import com.othento.core.internal.liveness.ProvideLivenessContentStrings
import com.othento.core.internal.liveness.RekognitionConfig
import com.othento.core.internal.content.content
import com.othento.core.internal.ui.components.ForceLtr
import com.othento.core.internal.ui.components.IntroTipCard
import com.othento.core.internal.ui.components.KycIntroSheet
import com.othento.core.internal.ui.components.KycLoader
import com.othento.core.internal.ui.components.KycLoaderSize
import com.othento.core.internal.ui.components.PlacementGuideKind
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.screens.common.contentTipCards
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.internal.content.ContentKeys as CK

/**
 * AWS Rekognition Face Liveness screen.
 *
 * Owns intro → warning → connecting → streaming → completing via
 * [RekognitionLivenessStateHolder] and hands the camera to the AWS component.
 * The SDK holds **no** CameraX binding while this is mounted:
 * `RekognitionLiveness` is a distinct
 * [com.othento.core.internal.flow.ScreenState] from `SelfieCapture`, so the
 * selfie screen's `ProcessCameraProvider` binding is released with its
 * composable before this one mounts. The failure signature if that ever
 * regresses is a black preview or a `CameraUnavailableException` inside the
 * AWS component — it is an explicit line in the device test script.
 */
@Composable
@Suppress("LongParameterList")
internal fun RekognitionLivenessScreen(
    attemptStepId: String,
    photosensitivity: Boolean,
    challengeMode: LivenessChallengeMode?,
    repository: RekognitionLivenessRepository,
    onCompleted: (Session) -> Unit,
    onFailed: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    // Keyed on attemptStepId so a new step gets a fresh attempt counter, while
    // a recomposition (or rotation within the same step) does not.
    val holder =
        remember(attemptStepId) {
            RekognitionLivenessStateHolder(
                repository = repository,
                scope = scope,
                attemptStepId = attemptStepId,
                photosensitivity = photosensitivity,
                challengeMode = challengeMode,
                onCompleted = onCompleted,
                onFailed = onFailed,
            )
        }
    val state by holder.state.collectAsState()
    val sessionId = state.sessionId

    if (state.view == RekognitionView.Streaming && sessionId != null) {
        val credentialsProvider =
            remember(repository) { BackendCredentialsProvider(repository, scope) }
        // AWS's own colour scheme. Per the cross-platform delta spec §2.8 the
        // component's oval geometry and control positions are locked; theming
        // reaches the accent ramp and typography at most. Brand the intro,
        // accept AWS's challenge screen — do not fight its layout.
        // Pinned LTR. The component's oval geometry and control positions are
        // locked by AWS (delta spec §2.8) and its RTL behaviour is not ours to
        // verify; handing it a mirrored layout direction risks a half-mirrored
        // challenge screen on the one surface where a misplaced control means a
        // failed liveness check. Our own branded intro above it still mirrors.
        ForceLtr {
            // Redirects the component's own `amplify_ui_liveness_*` string
            // lookups at the content bundle. Without this the challenge screen
            // is the only surface in the SDK that stays English regardless of
            // the resolved language — see ProvideLivenessContentStrings.
            ProvideLivenessContentStrings {
                MaterialTheme(colorScheme = LivenessColorScheme.default()) {
                    FaceLivenessDetector(
                        sessionId = sessionId,
                        region = RekognitionConfig.REGION,
                        credentialsProvider = credentialsProvider,
                        // Our branded intro has already run; AWS's start view
                        // would be a second, unbranded one.
                        disableStartView = true,
                        onComplete = { holder.onChallengeComplete() },
                        // Single channel: cancel arrives here too, as
                        // UserCancelledException. See LivenessErrorMapper.
                        onError = { error -> holder.onChallengeError(error) },
                    )
                }
            }
        }
        return
    }

    RekognitionLivenessContent(
        state = state,
        onContinue = { holder.onContinue() },
    )
}

/**
 * The SDK-rendered pages. Split out from [RekognitionLivenessScreen] so
 * Paparazzi can cover every one of them — the AWS component cannot be
 * snapshotted (it renders a live camera).
 *
 * Intro and warning are deliberately the **same** [KycIntroSheet] call site:
 * Compose keeps the instance alive across the transition and only the
 * parameters change, so the sheet turns a page instead of one sliding out and
 * another sliding in. Splitting them into two call sites brings the double
 * animation back, along with a second run of the sheet's button-enable delay.
 *
 * Whether the warning page is reachable at all is
 * [RekognitionLivenessStateHolder]'s decision, not this function's — by the
 * time [RekognitionView.Warning] arrives here the strict photosensitivity gate
 * has already passed.
 */
@Composable
internal fun RekognitionLivenessContent(
    state: RekognitionUiState,
    onContinue: () -> Unit,
) {
    when (state.view) {
        RekognitionView.Intro, RekognitionView.Warning -> {
            val isWarning = state.view == RekognitionView.Warning
            KycIntroSheet(
                illustration = PlacementGuideKind.Liveness,
                eyebrow = if (isWarning) "" else content(CK.LIVENESS_INTRO_EYEBROW),
                title =
                    if (isWarning) {
                        content(CK.LIVENESS_WARNING_TITLE)
                    } else {
                        content(CK.LIVENESS_INTRO_TITLE)
                    },
                subtitle =
                    if (isWarning) {
                        content(CK.LIVENESS_WARNING_BODY)
                    } else {
                        content(CK.LIVENESS_INTRO_SUBTITLE)
                    },
                tipCards =
                    if (isWarning) {
                        emptyList()
                    } else {
                        contentTipCards(CK.LIVENESS_INTRO_TIP_CARDS, rekognitionIntroTipCards())
                    },
                buttonLabel =
                    if (isWarning) {
                        content(CK.LIVENESS_WARNING_CONTINUE_BUTTON)
                    } else {
                        content(CK.LIVENESS_INTRO_BUTTON)
                    },
                onContinue = onContinue,
            )
        }
        RekognitionView.Connecting ->
            RekognitionProgress(label = content(CK.LIVENESS_CONNECTING))
        // The post-challenge wrap-up is what `liveness.hint.verifying`
        // ("Verifying...") names — the AWS component raises it as a guidance
        // hint, we render it as a progress label. Same moment, same words; no
        // new key needed.
        RekognitionView.Completing ->
            RekognitionProgress(label = content(CK.LIVENESS_HINT_VERIFYING))
        // The AWS component is mounted by the caller; nothing of ours draws here.
        RekognitionView.Streaming -> Unit
    }
}

@Composable
private fun RekognitionProgress(label: String) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        KycLoader(size = KycLoaderSize.Md)
        Box(modifier = Modifier.padding(top = 16.dp)) {
            Text(
                text = label,
                style = typography.bodySm,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/**
 * Web's four Rekognition intro tip cards, using the same icons the passive
 * liveness intro uses (`SelfieCaptureScreen.livenessIntroTipCards`) so the two
 * liveness intros stay visually consistent.
 */
private fun rekognitionIntroTipCards(): List<IntroTipCard> =
    listOf(
        IntroTipCard(
            label = "Look at the camera",
            detail = "Stay natural",
            icon = OthentoIcons.Face,
        ),
        IntroTipCard(
            label = "Stay in frame",
            detail = "Face centered in the oval",
            icon = OthentoIcons.FourCorners,
        ),
        IntroTipCard(
            label = "Good lighting",
            detail = "Avoid strong backlight",
            icon = OthentoIcons.Sun,
        ),
        IntroTipCard(
            label = "Remove glasses",
            detail = "Hats and masks too",
            icon = OthentoIcons.Glasses,
        ),
    )
