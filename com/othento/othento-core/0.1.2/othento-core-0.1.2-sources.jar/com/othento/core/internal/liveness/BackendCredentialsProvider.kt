package com.othento.core.internal.liveness

import com.amplifyframework.auth.AWSCredentials
import com.amplifyframework.auth.AWSCredentialsProvider
import com.amplifyframework.auth.AuthException
import com.amplifyframework.auth.exceptions.UnknownException
import com.amplifyframework.core.Consumer
import com.othento.core.internal.data.RekognitionLivenessRepository
import com.othento.core.internal.network.OthentoNetworkException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Feeds AWS's streaming client with credentials minted by **our** backend.
 *
 * This is the whole reason the SDK needs no Cognito Identity Pool, no
 * `aws-auth-cognito` artifact and no `Amplify.configure` call: the component
 * accepts any `AWSCredentialsProvider`, and ours is a thin adapter over
 * `GET …/liveness/rekognition/credentials`. Those credentials are scoped to
 * `rekognition:StartFaceLivenessSession` alone and live ~15 minutes.
 *
 * The component may call this more than once per attempt (it refreshes
 * mid-session), so every call hits the endpoint — nothing is cached.
 *
 * A failure must reach [onError]. Handing back partial or empty credentials
 * would surface later as an opaque AWS signing failure instead of a
 * diagnosable one.
 */
internal class BackendCredentialsProvider(
    private val repository: RekognitionLivenessRepository,
    private val scope: CoroutineScope,
) : AWSCredentialsProvider<AWSCredentials> {
    override fun fetchAWSCredentials(
        onSuccess: Consumer<AWSCredentials>,
        onError: Consumer<AuthException>,
    ) {
        scope.launch {
            try {
                val fetched = repository.credentials()
                val credentials =
                    AWSCredentials.createAWSCredentials(
                        fetched.accessKeyId,
                        fetched.secretAccessKey,
                        fetched.sessionToken,
                        fetched.expirationEpochSeconds,
                    )
                if (credentials == null) {
                    onError.accept(
                        UnknownException("Backend returned credentials AWS could not construct.", null),
                    )
                } else {
                    onSuccess.accept(credentials)
                }
            } catch (e: OthentoNetworkException) {
                onError.accept(UnknownException(e.displayMessage, e))
            }
        }
    }
}
