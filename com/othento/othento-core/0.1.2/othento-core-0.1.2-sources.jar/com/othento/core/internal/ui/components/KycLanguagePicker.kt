@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import com.othento.core.internal.content.LanguageOption
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Compact language dropdown for the welcome-screen header.
 *
 * A **dropdown, not a segmented row** — the list is open-ended, driven by
 * whatever `i18n.available` carries for the tenant (plan §6 task 8).
 *
 * Behaviour worth knowing:
 * - **Hidden below two languages.** One option is not a choice.
 * - **[selectedCode] is the language the backend RESOLVED**, never the one
 *   requested. Ask for `ar` on a tenant with no Arabic and English comes back;
 *   highlighting the request would show Arabic as active on an English screen
 *   (plan §4.5).
 * - **Disabled while [switching].** Combined with the repository's
 *   re-entrancy guard, three quick taps cannot produce three overlapping
 *   requests whose *last response* — not the user's last pick — wins
 *   (plan §4.4).
 */
@Composable
@Suppress(
    "LongMethod",
    // Reason: trigger + popup are one control. The menu is already extracted;
    // splitting the trigger further would separate the `switching` guard from
    // the click handler it disables, which is the correctness-critical pairing.
)
internal fun KycLanguagePicker(
    languages: List<LanguageOption>,
    selectedCode: String?,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    switching: Boolean = false,
) {
    if (languages.size < MIN_LANGUAGES_FOR_PICKER) return

    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val shapes = LocalOthentoShapes.current
    val motion = LocalOthentoMotion.current
    var open by rememberSaveable { mutableStateOf(false) }
    val selected =
        remember(selectedCode, languages) {
            languages.firstOrNull { it.code.equals(selectedCode, ignoreCase = true) }
        }
    val chevronRotation by animateFloatAsState(
        targetValue = if (open) 180f else 0f,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-language-chevron",
    )

    Box(modifier = modifier) {
        Row(
            modifier =
                Modifier
                    .clip(shapes.full)
                    .border(width = 1.dp, color = colors.border, shape = shapes.full)
                    .background(colors.bgBase)
                    .clickable(enabled = !switching) { open = !open }
                    .padding(horizontal = TriggerHorizontal, vertical = TriggerVertical),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(TriggerGap),
        ) {
            Text(
                text = selected?.label ?: selectedCode?.uppercase().orEmpty(),
                style = typography.caption,
                color = if (switching) colors.textMuted else colors.textPrimary,
            )
            if (switching) {
                KycLoader(size = KycLoaderSize.Sm, tone = KycLoaderTone.Neutral, contentDescription = "")
            } else {
                KycIcon(
                    imageVector = OthentoIcons.ChevronDown,
                    contentDescription = null,
                    sizeDp = ChevronSize,
                    tint = colors.textSecondary,
                    modifier = Modifier.rotate(chevronRotation),
                )
            }
        }
        if (open && !switching) {
            Popup(
                offset = IntOffset(0, MENU_OFFSET_Y_PX),
                onDismissRequest = { open = false },
                properties =
                    PopupProperties(
                        focusable = true,
                        dismissOnBackPress = true,
                        dismissOnClickOutside = true,
                    ),
            ) {
                LanguageMenu(
                    languages = languages,
                    selectedCode = selected?.code,
                    onSelect = {
                        open = false
                        onSelect(it)
                    },
                )
            }
        }
    }
}

@Composable
private fun LanguageMenu(
    languages: List<LanguageOption>,
    selectedCode: String?,
    onSelect: (String) -> Unit,
) {
    val colors = LocalOthentoColors.current
    val shapes = LocalOthentoShapes.current
    val typography = LocalOthentoTypography.current
    androidx.compose.foundation.layout.Column(
        modifier =
            Modifier
                .widthIn(min = MenuMinWidth)
                .width(MenuMinWidth)
                .shadow(elevation = MenuElevation, shape = shapes.md)
                .clip(shapes.md)
                .background(colors.bgBase)
                .border(width = 1.dp, color = colors.border, shape = shapes.md)
                .heightIn(max = MenuMaxHeight)
                .padding(MenuPadding),
    ) {
        languages.forEach { option ->
            val isSelected = option.code == selectedCode
            Row(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(OptionRadius))
                        .background(if (isSelected) colors.primaryBg else Color.Transparent)
                        .clickable { onSelect(option.code) }
                        .padding(horizontal = OptionHorizontal, vertical = OptionVertical),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(OptionGap),
            ) {
                Text(
                    text = option.label,
                    style = typography.body,
                    color = if (isSelected) colors.primary else colors.textPrimary,
                    modifier = Modifier.weight(1f),
                )
                if (isSelected) {
                    KycIcon(
                        imageVector = OthentoIcons.Check,
                        contentDescription = null,
                        sizeDp = CheckSize,
                        tint = colors.primary,
                    )
                }
            }
        }
    }
}

/** One option is not a choice — the picker hides entirely below this. */
private const val MIN_LANGUAGES_FOR_PICKER = 2

private val TriggerHorizontal = 12.dp
private val TriggerVertical = 6.dp
private val TriggerGap = 6.dp
private val ChevronSize = 14.dp
private const val MENU_OFFSET_Y_PX = 8
private val MenuMinWidth: Dp = 160.dp
private val MenuMaxHeight = 280.dp
private val MenuPadding = 4.dp
private val MenuElevation = 12.dp
private val OptionRadius = 6.dp
private val OptionHorizontal = 12.dp
private val OptionVertical = 10.dp
private val OptionGap = 8.dp
private val CheckSize = 16.dp
