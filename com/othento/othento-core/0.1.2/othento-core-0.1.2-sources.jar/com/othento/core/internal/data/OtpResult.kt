package com.othento.core.internal.data

import com.othento.core.internal.data.model.Session

/**
 * Outcome of an OTP-send call. The on-screen error / success copy is
 * derived from this discriminator (spec §10.5 + §10.6,
 * [docs/spec/06-screens/09-otp-phone.md]).
 *
 * Every failure variant carries the backend's stable error `code` alongside
 * its English message. The repository does **not** resolve copy: it runs off
 * the composition and cannot read the content bundle, so it reports identity
 * and lets the screen render.
 */
internal sealed interface OtpSendResult {
    /**
     * Code dispatched. The returned session carries `OtpSent` +
     * `otpExpiresAt` on the matching challenge per
     * [docs/spec/10-network-layer.md] §5.2 `otp/send`.
     */
    data class Sent(
        val session: Session,
    ) : OtpSendResult

    /**
     * Backend has rotated `currentStep` past this OTP step **and** set
     * `declineMessage` (spec §10.6 — too-many-failed-attempts skip).
     * The pending session must be committed via the FlowCoordinator on
     * "Continue".
     */
    data class SkipNotice(
        val pendingSession: Session,
        val reasonKey: String?,
        val message: String,
    ) : OtpSendResult

    /**
     * Generic failure (network, 4xx that opens no dialog, 5xx).
     *
     * [code] is the backend's `StatusCodeEnum` member name when the response
     * carried one — `null` for a transport error or an endpoint the backend
     * has not migrated. [displayMessage] is its English, which remains the
     * fallback whenever the code maps to no authored copy.
     */
    data class Failure(
        val displayMessage: String,
        val code: String? = null,
    ) : OtpSendResult

    /** HTTP 404 — escalate to the global SessionNotFound error screen. */
    data object SessionNotFound : OtpSendResult
}

/**
 * Outcome of an OTP-verify call. Distinguishes the blocking dialog cases from
 * generic failures and the skip-notice flow.
 */
internal sealed interface OtpVerifyResult {
    /** Verify succeeded; returned session is the new step / status. */
    data class Advanced(
        val session: Session,
    ) : OtpVerifyResult

    /**
     * A failure that opens a blocking dialog, selected by the backend's error
     * code — never by HTTP status. `OTP_EXPIRED` and `OTP_NOT_REQUESTED` share
     * status 410 and need different copy *and* a different primary action,
     * which is precisely why the code exists.
     */
    data class DialogError(
        val kind: OtpVerifyErrorKind,
    ) : OtpVerifyResult

    /** Skip-notice rotation (spec §10.6). */
    data class SkipNotice(
        val pendingSession: Session,
        val reasonKey: String?,
        val message: String,
    ) : OtpVerifyResult

    /** Other errors — surfaces inline as kyc-notice. See [OtpSendResult.Failure]. */
    data class Failure(
        val displayMessage: String,
        val code: String? = null,
    ) : OtpVerifyResult

    /** HTTP 404 — escalate to the global SessionNotFound error screen. */
    data object SessionNotFound : OtpVerifyResult
}
