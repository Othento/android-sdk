@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.LanguageOption
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.content.content
import com.othento.core.internal.content.contentPlural
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonSize
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycLanguagePicker
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.components.KycStepList
import com.othento.core.internal.ui.components.KycStepListVariant
import com.othento.core.internal.ui.screens.common.StepCardsBuilder
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * The first user-facing screen after session resolution: hero title,
 * step-count subtitle, step list, and the begin CTA.
 *
 * ### Step count is a digit, not a word
 * The subtitle used to spell the count out ("Three short steps."), which
 * cannot survive translation — the word inflects with the sentence. The
 * contract instead carries `start.subtitle.steps.one` / `.other` with a
 * `{count}` placeholder, and **only numbers are ever interpolated**
 * (plan §3.1 / decisions 6 and 27).
 *
 * ### The language picker lives here and only here
 * Switching mid-flow would swap copy under a user part-way through a capture
 * or an OTP entry, so the control is deliberately confined to the welcome
 * screen (plan §6 task 8).
 *
 * Android is mobile by definition, so the desktop QR sidebar is omitted.
 */
@Composable
@Suppress(
    "LongParameterList",
    "LongMethod",
    // Reason: the whole screen is one KycScreen call with header, body and
    // footer slots. Splitting the body out would hide which strings the
    // welcome screen actually binds, which is the thing worth reading here.
)
internal fun StartScreen(
    session: Session,
    brandName: String,
    onBeginClick: () -> Unit,
    logoUrl: String? = null,
    languages: List<LanguageOption> = emptyList(),
    currentLanguage: String? = null,
    languageSwitching: Boolean = false,
    onLanguageSelected: (String) -> Unit = {},
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val bundle = LocalContent.current
    val cards = remember(session.steps, bundle) { StepCardsBuilder.toCards(session.steps, bundle) }
    KycScreen(
        zone = KycScreenZone.Guided,
        bodyFill = false,
        headerBorder = false,
        logoName = brandName,
        logoUrl = logoUrl,
        headerTrailing = {
            KycLanguagePicker(
                languages = languages,
                selectedCode = currentLanguage,
                switching = languageSwitching,
                onSelect = onLanguageSelected,
            )
        },
        body = {
            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(top = HeroTopGap),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = content(ContentKeys.START_TITLE),
                    style = typography.display,
                    color = colors.textHeading,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = HeroMaxWidth).padding(horizontal = HeroHorizontal),
                )
                Spacer(modifier = Modifier.height(HeroSubtitleGap))
                Text(
                    text = contentPlural(ContentKeys.START_SUBTITLE_STEPS, cards.size),
                    style = typography.bodyLg,
                    color = colors.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = HeroMaxWidth).padding(horizontal = HeroHorizontal),
                )
                Spacer(modifier = Modifier.height(StepListTopGap))
                KycStepList(
                    steps = cards,
                    variant = KycStepListVariant.Detailed,
                    showDurations = false,
                )
                Spacer(modifier = Modifier.height(BottomGap))
            }
        },
        footer = {
            KycButton(
                onClick = onBeginClick,
                label = content(ContentKeys.START_CTA),
                variant = KycButtonVariant.Primary,
                size = KycButtonSize.Lg,
                fullWidth = true,
            )
        },
    )
}

private val HeroTopGap = 32.dp
private val HeroSubtitleGap = 12.dp
private val HeroMaxWidth = 360.dp
private val HeroHorizontal = 8.dp
private val StepListTopGap = 32.dp
private val BottomGap = 16.dp
