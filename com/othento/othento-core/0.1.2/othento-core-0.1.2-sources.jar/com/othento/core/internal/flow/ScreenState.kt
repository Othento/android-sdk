package com.othento.core.internal.flow

/**
 * Screen the host should render. Phase 5 adds the document-side variants
 * (`DocumentSelect`, `CaptureFront`, `CaptureBack`); selfie / liveness / OTP
 * remain to-be-defined screens that arrive in Phases 7-9 — until then the
 * resolver maps unsupported step codes to [Error] with a "deferred to
 * Phase X" message (logged as R3 in `99-open-questions.md`).
 *
 * Upload progress is **not** a screen state — it overlays the capture
 * screens via `FlowUiState.uploadProgress`, mirroring the web's
 * `.sdk-upload-sheet` overlay on top of `screenState`.
 */
internal enum class ScreenState {
    Loading,
    Start,
    DocumentSelect,
    CaptureFront,
    CaptureBack,
    SelfieCapture,

    /**
     * AWS Rekognition Face Liveness. A separate state from [SelfieCapture]
     * because the AWS component acquires the camera itself — routing through
     * the selfie screen would leave a CameraX binding held when it mounts.
     */
    RekognitionLiveness,

    /**
     * The active challenge needs a capability this SDK build does not have —
     * an unrecognised `ChallengeType`, or a Rekognition challenge the bundled
     * component reports as unsupported. Terminal for cancel-suppression
     * purposes: the flow cannot continue, so a back-press here is not the user
     * cancelling an in-progress verification.
     */
    UnsupportedUpdate,
    OtpPhone,
    OtpEmail,
    Processing,
    Approved,
    Declined,
    InReview,
    Expired,
    FailedTerminal,
    FailedRetry,
    Error,
    ;

    /** Whether the host should treat this as a terminal screen for cancel-event suppression. */
    val isTerminal: Boolean
        get() =
            this == Approved ||
                this == Declined ||
                this == InReview ||
                this == Expired ||
                this == FailedTerminal ||
                this == UnsupportedUpdate ||
                this == Error
}
