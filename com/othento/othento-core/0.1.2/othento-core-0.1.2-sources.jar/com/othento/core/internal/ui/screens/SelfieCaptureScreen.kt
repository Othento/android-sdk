@file:Suppress(
    "FunctionNaming",
    "TopLevelPropertyNaming",
    "MagicNumber",
    "LongMethod",
    "LongParameterList",
    "TooManyFunctions",
    "MaxLineLength",
    // Reason: this file owns the full selfie-capture screen (runtime composable
    // + every state's pure-render variant + supporting helpers). Splitting into
    // multiple files fragments the state-to-render mapping that's the whole
    // value of co-locating these. Suppressions mirror the camera-capture screen.
)

package com.othento.core.internal.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.othento.core.internal.capture.CameraReadyState
import com.othento.core.internal.capture.CameraSelectorKind
import com.othento.core.internal.capture.CameraSession
import com.othento.core.internal.capture.CaptureConfig
import com.othento.core.internal.capture.PermissionStatus
import com.othento.core.internal.capture.SelfieConfig
import com.othento.core.internal.capture.SelfieDetectionPipeline
import com.othento.core.internal.capture.SelfieDetectionState
import com.othento.core.internal.capture.SelfieFrameAnalyzer
import com.othento.core.internal.capture.SelfieKind
import com.othento.core.internal.capture.detection.ValidationIssue
import com.othento.core.internal.capture.detection.ValidationWarning
import com.othento.core.internal.capture.detection.face.FaceDetectorClient
import com.othento.core.internal.capture.detection.face.SelfieHint
import com.othento.core.internal.capture.detection.face.SelfieWarning
import com.othento.core.internal.capture.rememberCameraPermissionState
import com.othento.core.internal.capture.video.RollingVideoRecorder
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.content.content
import com.othento.core.internal.ui.components.BlurredCaptureBackground
import com.othento.core.internal.ui.components.CameraFramePreview
import com.othento.core.internal.ui.components.CaptureReviewSheet
import com.othento.core.internal.ui.components.CapturedVideoPreview
import com.othento.core.internal.ui.components.IntroTipCard
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.components.KycIntroSheet
import com.othento.core.internal.ui.components.KycLoader
import com.othento.core.internal.ui.components.KycLoaderSize
import com.othento.core.internal.ui.components.OvalRoiOverlay
import com.othento.core.internal.ui.components.PlacementGuideKind
import com.othento.core.internal.ui.components.lastVideoFrame
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.screens.common.contentTipCards
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import com.othento.core.internal.content.ContentKeys as CK

/**
 * Phase 7 selfie / face-match capture surface. Spec
 * [docs/spec/06-screens/08-selfie-capture.md].
 *
 * Owns the runtime side: front-camera bind via [CameraSession] +
 * [CameraSelectorKind.Front], ML Kit face detection via [FaceDetectorClient]
 * driven by [SelfieFrameAnalyzer], stability gating via
 * [SelfieDetectionPipeline], rolling video buffer via [RollingVideoRecorder],
 * preview-then-confirm.
 *
 * Pure rendering lives in [SelfieCaptureScreenContent] so Paparazzi snapshot
 * tests cover every state.
 */
@Composable
@Suppress("CyclomaticComplexMethod")
internal fun SelfieCaptureScreen(
    kind: SelfieKind,
    onCapturedFile: (Uri, Boolean) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val cameraSession = remember { CameraSession(context) }
    val faceClient = remember { FaceDetectorClient(minFaceSize = SelfieConfig.MIN_FACE_SIZE_HINT) }
    val bindAttempt = remember { mutableIntStateOf(0) }
    // Pipeline + analyzer are keyed on bindAttempt so a retake gets a fresh
    // capture-delay window. Critically: do NOT use a `mutableStateOf` for the
    // start-time and write to it inside the bind effect — that path triggers
    // a recomposition that creates a new pipeline AFTER the analyzer was
    // already bound to the old one, leaving the screen observing a state
    // flow no frames are flowing into.
    val pipeline =
        remember(bindAttempt.intValue) {
            SelfieDetectionPipeline(cameraStartedAt = System.currentTimeMillis())
        }
    val analyzer =
        remember(pipeline) {
            SelfieFrameAnalyzer(pipeline = pipeline, client = faceClient)
        }
    val videoBuffer =
        remember(kind) {
            val prefix = if (kind == SelfieKind.Liveness) "liveness" else "selfie"
            RollingVideoRecorder(context = context, flowPrefix = prefix)
        }

    DisposableEffect(Unit) {
        onDispose {
            videoBuffer.reset()
            faceClient.release()
            cameraSession.shutdown()
        }
    }

    val permissionState =
        rememberCameraPermissionState(
            onSettingsRequested = { openSelfieAppSettings(context) },
        )

    var cameraReady by remember { mutableStateOf(CameraReadyState.Loading) }
    var captureReady by remember { mutableStateOf(false) }
    var capturedUri by remember { mutableStateOf<Uri?>(null) }
    var previewWarnings by remember { mutableStateOf(emptyList<ValidationWarning>()) }
    var validating by remember { mutableStateOf(false) }
    var captureJob by remember { mutableStateOf<Job?>(null) }
    var timedOut by remember { mutableStateOf(false) }
    var wasAutoCapture by remember { mutableStateOf(false) }
    // Auto-capture closes the camera and shows a blurred frozen frame behind
    // the upload sheet while the clip uploads. `uploadFrame` is the last frame
    // of the captured clip; `uploading` swaps the live HUD for that backdrop.
    var uploading by remember { mutableStateOf(false) }
    var uploadFrame by remember { mutableStateOf<ImageBitmap?>(null) }

    val introVisible = remember { mutableStateOf(true) }

    LaunchedEffect(permissionState.status) {
        cameraReady =
            when (permissionState.status) {
                PermissionStatus.Granted -> cameraReady
                PermissionStatus.Denied -> CameraReadyState.PermissionDenied
                PermissionStatus.PermanentlyDenied -> CameraReadyState.PermissionPermanentlyDenied
                PermissionStatus.Unknown -> CameraReadyState.Loading
            }
    }

    LaunchedEffect(introVisible.value) {
        if (!introVisible.value && permissionState.status != PermissionStatus.Granted) {
            permissionState.request()
        }
    }

    // Pause auto-detection while the intro sheet is open. Reopening intro
    // mid-session via the ⓘ button must also halt the stability counter so
    // we don't auto-capture the instant the sheet closes again. Keyed on
    // `pipeline` too so a retake (which rebuilds the pipeline) inherits
    // the current paused state.
    LaunchedEffect(pipeline, introVisible.value) {
        pipeline.setPaused(introVisible.value)
        if (introVisible.value) timedOut = false
    }

    // Bind front camera + ImageAnalysis (face) + VideoCapture.
    // Same single-effect pattern as CameraCaptureScreen so retake works
    // through bindAttempt without restating the lifecycle dance. Each retake
    // resets the rolling recorder before re-binding so no orphaned MediaCodec
    // surfaces linger across bind attempts.
    LaunchedEffect(permissionState.status, bindAttempt.intValue) {
        if (permissionState.status != PermissionStatus.Granted) return@LaunchedEffect
        cameraReady = CameraReadyState.Loading
        captureReady = false
        timedOut = false
        previewWarnings = emptyList()
        videoBuffer.reset()

        val videoUseCase = videoBuffer.buildUseCase()
        val bindResult =
            cameraSession.bind(
                lifecycleOwner = lifecycleOwner,
                // Two streams only: ImageAnalysis (face + preview source) +
                // VideoCapture. No Preview use case — a 3rd stream caps the
                // recorded MP4 at 720p. The analyzer renders the preview from its
                // frames, so VideoCapture keeps its own FHD front-camera stream.
                previewView = null,
                analyzer = analyzer,
                selector = CameraSelectorKind.Front,
                extraUseCase = videoUseCase,
                analysisTargetResolution =
                    android.util.Size(
                        CaptureConfig.DOC_ANALYSIS_TARGET_WIDTH,
                        CaptureConfig.DOC_ANALYSIS_TARGET_HEIGHT,
                    ),
            )
        when (bindResult) {
            is CameraSession.BindResult.Bound -> {
                // Rotate analyzer frames to upright by the deterministic front
                // sensor rotation (per-frame imageInfo.rotationDegrees was unreliable).
                analyzer.uprightRotationDegrees = bindResult.sensorRotationDegrees
                cameraReady = CameraReadyState.Active
                videoBuffer.start()
                delay(SELFIE_CAPTURE_READY_DELAY_MS)
                captureReady = true
            }
            is CameraSession.BindResult.Failed -> {
                cameraReady = CameraReadyState.Unavailable
            }
        }
    }

    // Camera-timeout watchdog — if no successful detection within
    // SelfieConfig.CAMERA_TIMEOUT_MS, flip to the timeout error state.
    // Keyed on `introVisible` so the 45 s window restarts each time the
    // user dismisses the intro sheet (initial open or mid-session reopen);
    // the timer must not run behind the intro.
    LaunchedEffect(cameraReady, capturedUri, introVisible.value) {
        if (cameraReady != CameraReadyState.Active) return@LaunchedEffect
        if (capturedUri != null) return@LaunchedEffect
        if (introVisible.value) return@LaunchedEffect
        delay(SelfieConfig.CAMERA_TIMEOUT_MS)
        if (capturedUri == null) {
            timedOut = true
        }
    }

    // Read on the composition and closed over by the effect below: the frame
    // sampling runs on Dispatchers.Default, where `LocalContent` is out of
    // reach. `selfie.validation.noFace` is the message; `ValidationIssue.NoCard`
    // only routes it to the warning row, and its own `capture.quality.noCard`
    // copy ("No document detected") would be wrong on a selfie — so the message
    // is passed explicitly rather than resolved from the issue.
    val noFaceMessage = content(CK.SELFIE_VALIDATION_NO_FACE)

    // Post-capture face check for manual captures — sample video frames
    // and verify at least one contains a face. Auto-capture already passed
    // the pipeline's face gate so it skips this.
    LaunchedEffect(capturedUri, noFaceMessage) {
        val uri =
            capturedUri ?: run {
                validating = false
                previewWarnings = emptyList()
                return@LaunchedEffect
            }
        if (wasAutoCapture) {
            validating = false
            previewWarnings = emptyList()
            return@LaunchedEffect
        }
        validating = true
        previewWarnings = emptyList()
        val warnings =
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                runCatching {
                    val retriever = android.media.MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(uri.path)
                        val durationMs =
                            retriever
                                .extractMetadata(
                                    android.media.MediaMetadataRetriever.METADATA_KEY_DURATION,
                                )?.toLongOrNull() ?: 0L
                        val durationUs = durationMs * 1_000L
                        val count = SELFIE_POST_CAPTURE_SAMPLES
                        val stepUs = if (durationUs > 0 && count > 1) durationUs / (count - 1) else 0L
                        val checker = FaceDetectorClient(minFaceSize = 0.25f)
                        try {
                            for (i in 0 until count) {
                                val timeUs = if (count > 1) i * stepUs else 0L
                                val frame =
                                    retriever.getFrameAtTime(
                                        timeUs,
                                        android.media.MediaMetadataRetriever.OPTION_CLOSEST,
                                    ) ?: continue
                                val input =
                                    com.google.mlkit.vision.common.InputImage
                                        .fromBitmap(frame, 0)
                                val faces = checker.detectOnce(input)
                                frame.recycle()
                                if (faces.isNotEmpty()) return@runCatching emptyList()
                            }
                            listOf(
                                ValidationWarning(
                                    issue = ValidationIssue.NoFace,
                                    message = noFaceMessage,
                                ),
                            )
                        } finally {
                            checker.release()
                        }
                    } finally {
                        runCatching { retriever.release() }
                    }
                }.getOrElse { emptyList() }
            }
        validating = false
        previewWarnings = warnings
    }

    // Auto-capture trigger — observe pipeline state.
    val detectionState by pipeline.state.collectAsState()
    LaunchedEffect(detectionState) {
        if (capturedUri != null) return@LaunchedEffect // in preview — don't re-capture
        if (detectionState !is SelfieDetectionState.ReadyToCapture) return@LaunchedEffect
        if (!captureReady) return@LaunchedEffect
        if (captureJob != null) return@LaunchedEffect
        pipeline.markCaptured()
        wasAutoCapture = true
        captureJob =
            scope.launch {
                val uri =
                    runCatching {
                        withTimeoutOrNull(SELFIE_CAPTURE_WATCHDOG_MS) { videoBuffer.stopAndTrim() }
                    }.getOrNull()?.let { Uri.fromFile(it) }
                if (uri != null) {
                    // Auto-capture already passed the face gate — skip the review
                    // step and upload directly. Freeze on a blurred last frame and
                    // close the camera so the upload sheet sits over a calm
                    // backdrop, not the live viewport.
                    uploadFrame = lastVideoFrame(uri)
                    uploading = true
                    cameraSession.unbind()
                    onCapturedFile(uri, false)
                } else {
                    // Trim failed — fall back to retake.
                    pipeline.reset()
                    videoBuffer.reset()
                    captureReady = false
                    bindAttempt.intValue++
                }
                captureJob = null
            }
    }

    val capturedPreview: (@Composable () -> Unit)? =
        capturedUri?.let { uri ->
            { CapturedVideoPreview(uri = uri) }
        }

    val state =
        SelfieCaptureUiState(
            cameraReady = cameraReady,
            detectionState = detectionState,
            captureReady = captureReady,
            isPreviewing = capturedUri != null,
            timedOut = timedOut,
            previewWarnings = previewWarnings,
            validating = validating,
        )
    val callbacks =
        SelfieCaptureCallbacks(
            onShutter = {
                if (capturedUri != null) return@SelfieCaptureCallbacks
                if (!captureReady || captureJob != null) return@SelfieCaptureCallbacks
                if (detectionState is SelfieDetectionState.CaptureBlocked) return@SelfieCaptureCallbacks
                pipeline.markCaptured()
                wasAutoCapture = false
                captureJob =
                    scope.launch {
                        fireCapture(videoBuffer = videoBuffer) { uri ->
                            if (uri != null) {
                                capturedUri = uri
                            } else {
                                // Trim failed — fall back to retake.
                                pipeline.reset()
                                videoBuffer.reset()
                                captureReady = false
                                bindAttempt.intValue++
                            }
                        }
                        captureJob = null
                    }
            },
            onShowIntro = { introVisible.value = true },
            onTryAgain = {
                when (cameraReady) {
                    CameraReadyState.PermissionDenied,
                    CameraReadyState.PermissionPermanentlyDenied,
                    -> permissionState.request()
                    CameraReadyState.Unavailable -> bindAttempt.intValue++
                    else -> Unit
                }
            },
            onRetake = {
                capturedUri = null
                previewWarnings = emptyList()
                validating = false
                captureReady = false
                timedOut = false
                wasAutoCapture = false
                pipeline.reset()
                bindAttempt.intValue++
            },
            onConfirmCapture = {
                val uri = capturedUri ?: return@SelfieCaptureCallbacks
                onCapturedFile(uri, !wasAutoCapture)
            },
            onOpenAppSettings = { openSelfieAppSettings(context) },
        )

    Box(modifier = Modifier.fillMaxSize()) {
        if (uploading) {
            // Camera is closed; show the blurred frozen frame. The host layers
            // the UploadProgressSheet on top while the clip uploads.
            BlurredCaptureBackground(frame = uploadFrame, modifier = Modifier.fillMaxSize())
            return@Box
        }
        SelfieCaptureScreenContent(
            state = state,
            callbacks = callbacks,
            kind = kind,
            previewSurface = {
                val previewBitmap by analyzer.previewBitmap.collectAsState()
                CameraFramePreview(
                    bitmap = previewBitmap,
                    mirror = true,
                    modifier = Modifier.fillMaxSize(),
                )
            },
            capturedPreview = capturedPreview,
        )

        if (introVisible.value) {
            // Face-match and liveness share this screen but not their copy:
            // `selfie.*` and `liveness.*` are separate key families, and the
            // built-in [selfieIntroFor] copy survives only as the offline
            // fallback for each field.
            val intro = selfieIntroFor(kind)
            val prefix = if (kind == SelfieKind.Liveness) CK.LIVENESS else CK.SELFIE
            KycIntroSheet(
                illustration =
                    when (kind) {
                        SelfieKind.Liveness -> PlacementGuideKind.Liveness
                        SelfieKind.FaceMatch -> PlacementGuideKind.Selfie
                    },
                title = content(prefix + CK.SUFFIX_INTRO_TITLE).ifBlank { intro.title },
                subtitle = content(prefix + CK.SUFFIX_INTRO_SUBTITLE).ifBlank { intro.subtitle },
                eyebrow = content(prefix + CK.SUFFIX_INTRO_EYEBROW).ifBlank { intro.eyebrow },
                tipCards =
                    contentTipCards(
                        key = prefix + CK.SUFFIX_INTRO_TIP_CARDS,
                        fallback =
                            when (kind) {
                                SelfieKind.FaceMatch -> faceMatchIntroTipCards()
                                SelfieKind.Liveness -> livenessIntroTipCards()
                            },
                    ),
                buttonLabel =
                    content(
                        if (kind == SelfieKind.Liveness) {
                            CK.LIVENESS_INTRO_BUTTON
                        } else {
                            CK.SELFIE_INTRO_BUTTON
                        },
                    ).ifBlank { intro.buttonLabel },
                onContinue = { introVisible.value = false },
            )
        }
    }
}

private data class SelfieIntroCopy(
    val eyebrow: String,
    val title: String,
    val subtitle: String,
    val buttonLabel: String,
)

private fun selfieIntroFor(kind: SelfieKind): SelfieIntroCopy =
    when (kind) {
        SelfieKind.FaceMatch ->
            SelfieIntroCopy(
                eyebrow = "Face match · Selfie",
                title = "Now a quick selfie.",
                subtitle = "We'll match your face to the photo on your ID. Takes 2 seconds.",
                buttonLabel = "Start selfie",
            )
        SelfieKind.Liveness ->
            SelfieIntroCopy(
                eyebrow = "Liveness",
                title = "Quick liveness check.",
                subtitle = "Just look at the camera. We’ll confirm you’re really here — no action needed.",
                buttonLabel = "Continue",
            )
    }

// ──────────────────────────────────────── Pure-render content ─────────────────────────────────────

internal data class SelfieCaptureUiState(
    val cameraReady: CameraReadyState,
    val detectionState: SelfieDetectionState,
    val captureReady: Boolean,
    val isPreviewing: Boolean,
    val timedOut: Boolean = false,
    val previewWarnings: List<ValidationWarning> = emptyList(),
    val validating: Boolean = false,
) {
    val statusHint: SelfieHint?
        get() = (detectionState as? SelfieDetectionState.Searching)?.hint

    val statusWarning: SelfieWarning?
        get() =
            when (val s = detectionState) {
                is SelfieDetectionState.Searching -> s.warning
                is SelfieDetectionState.Holding -> s.warning
                else -> null
            }

    val captureProgress: Float
        get() =
            when (val s = detectionState) {
                is SelfieDetectionState.Holding -> s.progress
                is SelfieDetectionState.ReadyToCapture -> 1f
                else -> 0f
            }

    /** Seconds left on the hold countdown, or `null` when not counting down. */
    val holdRemainingSec: Long?
        get() =
            if (detectionState is SelfieDetectionState.Holding) {
                val remainingMs = (SELFIE_HOLD_TARGET_MS * (1f - captureProgress)).toLong()
                ((remainingMs + SELFIE_PILL_ROUND_UP_MS) / 1_000L).coerceAtLeast(1L)
            } else {
                null
            }
}

/**
 * Status-pill copy for the selfie screen.
 *
 * A composable rather than a `val` on the state class: every branch below now
 * resolves through the content bundle, and `LocalContent` is only reachable
 * from the composition. The state object still decides *which* message applies
 * — it just no longer decides how that message is worded.
 */
@Composable
@ReadOnlyComposable
private fun selfieStatusText(
    state: SelfieCaptureUiState,
    kind: SelfieKind,
): String {
    val remainingSec = state.holdRemainingSec
    return when {
        state.isPreviewing -> content(CK.CAPTURE_REVIEW_LOOKS_GOOD)
        // `selfie.capture.holdSteady` always carries `{seconds}`, so the
        // countdown-free moment needs a different key — `liveness.hint.holdStill`
        // ("Hold still") is that string, already seeded. Borrowing across the
        // liveness/selfie boundary is sound here: both are the same camera
        // surface pointed at the same face, which is why the brightness pair is
        // already shared (see `SelfieWarning`).
        state.detectionState is SelfieDetectionState.ReadyToCapture ->
            content(CK.LIVENESS_HINT_HOLD_STILL)
        remainingSec != null ->
            content(CK.SELFIE_CAPTURE_HOLD_STEADY, PLACEHOLDER_SECONDS to remainingSec)
        state.statusHint != null -> selfieHintText(state.statusHint!!)
        // The idle prompt differs by kind — liveness asks the user to hold
        // still, face-match asks them to frame up — so it resolves against the
        // matching key family rather than borrowing the selfie one for both.
        kind == SelfieKind.Liveness -> content(CK.LIVENESS_CAPTURE_STATUS_DEFAULT)
        else -> content(CK.SELFIE_CAPTURE_STATUS_DEFAULT)
    }
}

/** `selfie.hint.*` for a live face-framing nudge; enum in, sentence out. */
@Composable
@ReadOnlyComposable
private fun selfieHintText(hint: SelfieHint): String = LocalContent.current.textOrNull(hint.key) ?: hint.text

/** `liveness.hint.tooDark` / `.tooBright` for the amber bubble. */
@Composable
@ReadOnlyComposable
private fun selfieWarningText(warning: SelfieWarning): String =
    LocalContent.current.textOrNull(warning.key) ?: warning.text

private const val PLACEHOLDER_SECONDS = "seconds"

private const val SELFIE_HOLD_TARGET_MS: Float = 1_400f
private const val SELFIE_PILL_ROUND_UP_MS: Long = 999L

internal data class SelfieCaptureCallbacks(
    val onShutter: () -> Unit,
    val onShowIntro: () -> Unit,
    val onTryAgain: () -> Unit,
    val onRetake: () -> Unit,
    val onConfirmCapture: () -> Unit,
    val onOpenAppSettings: () -> Unit,
)

@Composable
internal fun SelfieCaptureScreenContent(
    state: SelfieCaptureUiState,
    callbacks: SelfieCaptureCallbacks,
    kind: SelfieKind = SelfieKind.FaceMatch,
    previewSurface: @Composable () -> Unit = { Box(Modifier.fillMaxSize().background(Color.Black)) },
    capturedPreview: (@Composable () -> Unit)? = null,
) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        when {
            state.cameraReady == CameraReadyState.Loading -> SelfieCameraLoading()
            state.cameraReady == CameraReadyState.PermissionDenied ->
                SelfiePermissionError(
                    permanentlyDenied = false,
                    onTryAgain = callbacks.onTryAgain,
                    onOpenSettings = callbacks.onOpenAppSettings,
                )
            state.cameraReady == CameraReadyState.PermissionPermanentlyDenied ->
                SelfiePermissionError(
                    permanentlyDenied = true,
                    onTryAgain = callbacks.onTryAgain,
                    onOpenSettings = callbacks.onOpenAppSettings,
                )
            state.cameraReady == CameraReadyState.Unavailable -> SelfieCameraUnavailable(onTryAgain = callbacks.onTryAgain)
            state.timedOut -> SelfieTimeout(onTryAgain = callbacks.onRetake)
            state.isPreviewing && capturedPreview != null ->
                SelfiePreviewState(
                    capturedPreview = capturedPreview,
                    isValidating = state.validating,
                    warnings = state.previewWarnings,
                    onRetake = callbacks.onRetake,
                    onConfirm = callbacks.onConfirmCapture,
                )
            else ->
                SelfieActiveHud(
                    state = state,
                    callbacks = callbacks,
                    kind = kind,
                    previewSurface = previewSurface,
                )
        }
    }
}

// ──────────────────────────────────────── State composables ───────────────────────────────────────

@Composable
private fun SelfieCameraLoading() {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            KycLoader(size = KycLoaderSize.Lg)
            Spacer(Modifier.height(16.dp))
            Text(
                text = content(CK.CAPTURE_PREPARING_CAMERA),
                style = LocalOthentoTypography.current.body,
                color = Color.White,
            )
        }
    }
}

@Composable
private fun SelfiePermissionError(
    permanentlyDenied: Boolean,
    onTryAgain: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    SelfieErrorPanel(
        title = content(CK.CAPTURE_CAMERA_REQUIRED_TITLE),
        body = content(CK.SELFIE_CAMERA_REQUIRED_DENIED),
        primaryLabel =
            if (permanentlyDenied) {
                content(CK.CAPTURE_CAMERA_REQUIRED_OPEN_SETTINGS)
            } else {
                content(CK.CAPTURE_TIMEOUT_TRY_AGAIN)
            },
        onPrimary = if (permanentlyDenied) onOpenSettings else onTryAgain,
    )
}

@Composable
private fun SelfieCameraUnavailable(onTryAgain: () -> Unit) {
    SelfieErrorPanel(
        // Same two-key composition the document screen uses: the noCamera line
        // is the headline, `error.device.cameraNotAccessible` continues it.
        title = content(CK.CAPTURE_CAMERA_REQUIRED_NO_CAMERA),
        body = content(CK.ERROR_DEVICE_CAMERA_NOT_ACCESSIBLE),
        primaryLabel = content(CK.CAPTURE_TIMEOUT_TRY_AGAIN),
        onPrimary = onTryAgain,
    )
}

@Composable
private fun SelfieTimeout(onTryAgain: () -> Unit) {
    SelfieErrorPanel(
        title = content(CK.SELFIE_TIMEOUT_TITLE),
        body = content(CK.SELFIE_TIMEOUT_MESSAGE),
        primaryLabel = content(CK.CAPTURE_TIMEOUT_TRY_AGAIN),
        onPrimary = onTryAgain,
    )
}

@Composable
private fun SelfieErrorPanel(
    title: String,
    body: String,
    primaryLabel: String,
    onPrimary: () -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = title,
                style = LocalOthentoTypography.current.titleH3.copy(fontWeight = FontWeight.W700),
                color = Color.White,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = body,
                style = LocalOthentoTypography.current.body,
                color = Color.White.copy(alpha = 0.75f),
            )
            Spacer(Modifier.height(20.dp))
            KycButton(label = primaryLabel, onClick = onPrimary, variant = KycButtonVariant.Primary)
        }
    }
}

@Composable
private fun SelfieActiveHud(
    state: SelfieCaptureUiState,
    callbacks: SelfieCaptureCallbacks,
    kind: SelfieKind,
    previewSurface: @Composable () -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        previewSurface()
        OvalRoiOverlay(modifier = Modifier.fillMaxSize())

        val isHolding = state.detectionState is SelfieDetectionState.Holding
        if (isHolding) {
            SelfieScanLine(modifier = Modifier.fillMaxSize())
        }

        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars),
        ) {
            SelfieTopChrome(kind = kind, onTipsTap = callbacks.onShowIntro)
            Spacer(Modifier.height(8.dp))
            SelfieStatusPill(
                text = selfieStatusText(state, kind),
                isHolding =
                    state.detectionState is SelfieDetectionState.Holding ||
                        state.detectionState is SelfieDetectionState.ReadyToCapture,
            )
            Spacer(Modifier.weight(1f))
            state.statusWarning?.let { warning ->
                SelfieWarningBubble(
                    text = selfieWarningText(warning),
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
            }
            SelfieCaptureRow(
                progress = state.captureProgress,
                enabled =
                    state.captureReady &&
                        state.detectionState !is SelfieDetectionState.CaptureBlocked,
                visible = state.captureReady,
                onShutter = callbacks.onShutter,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SelfieScanLine(modifier: Modifier = Modifier) {
    val primary = LocalOthentoColors.current.primary
    val transition = rememberInfiniteTransition(label = "selfie-scan")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(durationMillis = SELFIE_SCAN_HALF_MS, easing = EaseInOut),
                repeatMode = RepeatMode.Reverse,
            ),
        label = "selfie-scan-progress",
    )
    val scanAlpha = 0.3f + 0.7f * progress

    Canvas(modifier = modifier) {
        val ovalW = size.width * SelfieConfig.ROI_WIDTH_RATIO
        val ovalH = ovalW * SelfieConfig.ROI_HEIGHT_TO_WIDTH_RATIO
        val ovalLeft = (size.width - ovalW) / 2f
        val ovalTop = (size.height - ovalH) / 2f
        val ovalRect = Rect(ovalLeft, ovalTop, ovalLeft + ovalW, ovalTop + ovalH)
        val ovalPath = Path().apply { addOval(ovalRect) }

        clipPath(ovalPath) {
            val scanTop = ovalTop + ovalH * 0.15f
            val scanBottom = ovalTop + ovalH * 0.75f
            val y = scanTop + (scanBottom - scanTop) * progress
            val lineLeft = ovalLeft + ovalW * 0.1f
            val lineW = ovalW * 0.8f
            val lineH = SELFIE_SCAN_LINE_H.toPx()
            val glowH = 8.dp.toPx()

            drawRect(
                brush =
                    Brush.horizontalGradient(
                        colors =
                            listOf(
                                Color.Transparent,
                                primary.copy(alpha = 0.3f),
                                primary.copy(alpha = 0.3f),
                                Color.Transparent,
                            ),
                        startX = lineLeft,
                        endX = lineLeft + lineW,
                    ),
                topLeft = Offset(lineLeft, y - glowH / 2f),
                size = Size(lineW, glowH),
                alpha = scanAlpha,
            )

            drawRect(
                brush =
                    Brush.horizontalGradient(
                        colors =
                            listOf(
                                Color.Transparent,
                                primary,
                                primary,
                                Color.Transparent,
                            ),
                        startX = lineLeft,
                        endX = lineLeft + lineW,
                    ),
                topLeft = Offset(lineLeft, y - lineH / 2f),
                size = Size(lineW, lineH),
                alpha = scanAlpha,
            )
        }
    }
}

private const val SELFIE_SCAN_HALF_MS: Int = 1_000
private val SELFIE_SCAN_LINE_H = 2.dp

@Composable
private fun SelfieTopChrome(
    kind: SelfieKind,
    onTipsTap: () -> Unit,
) {
    // `*.capture.chromePill` — the two kinds are separate key families, same as
    // the intro sheet above. The `when` now picks a *key*, not a sentence.
    val pillText =
        content(
            when (kind) {
                SelfieKind.FaceMatch -> CK.SELFIE_CAPTURE_CHROME_PILL
                SelfieKind.Liveness -> CK.LIVENESS_CAPTURE_CHROME_PILL
            },
        )
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 12.dp).height(36.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SelfieChromePill(text = pillText, modifier = Modifier.weight(1f))
        SelfieChromeButton(
            icon = OthentoIcons.Info,
            contentDescription = content(CK.A11Y_SHOW_TIPS),
            onClick = onTipsTap,
        )
    }
}

@Composable
private fun SelfieChromeButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
) {
    Box(
        modifier =
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f))
                .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        KycIcon(
            imageVector = icon,
            contentDescription = contentDescription,
            sizeDp = 16.dp,
            tint = Color.White,
        )
    }
}

@Composable
private fun SelfieChromePill(
    text: String,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier =
            modifier
                .height(36.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White.copy(alpha = 0.12f))
                .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            style = LocalOthentoTypography.current.caption.copy(fontWeight = FontWeight.W600),
            color = Color.White,
        )
    }
}

@Composable
private fun SelfieStatusPill(
    text: String,
    isHolding: Boolean,
) {
    val bg =
        if (isHolding) {
            LocalOthentoColors.current.primary.copy(alpha = 0.85f)
        } else {
            Color.White.copy(alpha = 0.15f)
        }
    val dotColor = if (isHolding) Color.White else AmberDot
    Box(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            modifier =
                Modifier
                    .wrapContentSize()
                    .clip(RoundedCornerShape(999.dp))
                    .background(bg)
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(dotColor))
            Text(
                text = text,
                style = LocalOthentoTypography.current.caption.copy(fontWeight = FontWeight.W600),
                color = Color.White,
            )
        }
    }
}

@Composable
private fun SelfieWarningBubble(
    text: String,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Row(
            modifier =
                Modifier
                    .wrapContentSize()
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(AmberDot))
            Text(
                text = text,
                style = LocalOthentoTypography.current.caption.copy(fontWeight = FontWeight.W600),
                color = AmberDot,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun SelfieCaptureRow(
    progress: Float,
    enabled: Boolean,
    visible: Boolean,
    onShutter: () -> Unit,
) {
    val ringColor = LocalOthentoColors.current.primary
    val targetProgress = progress.coerceIn(0f, 1f)
    val displayed by animateFloatAsState(
        targetValue = targetProgress,
        animationSpec =
            if (targetProgress == 0f) {
                snap()
            } else {
                tween(
                    durationMillis = 200,
                    easing = LinearEasing,
                )
            },
        label = "selfie-ring",
    )
    val appearAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(durationMillis = 350),
        label = "selfie-row-alpha",
    )
    val appearSlide by animateFloatAsState(
        targetValue = if (visible) 0f else 12f,
        animationSpec = tween(durationMillis = 350),
        label = "selfie-row-slide",
    )
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .graphicsLayer(alpha = appearAlpha, translationY = appearSlide),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier =
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f))
                    .clickable(enabled = enabled, onClick = onShutter),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val stroke = SELFIE_RING_STROKE.toPx()
                val inset = stroke / 2f
                val topLeft = Offset(inset, inset)
                val arcSize =
                    androidx.compose.ui.geometry.Size(
                        size.width - stroke,
                        size.height - stroke,
                    )
                drawArc(
                    color = ringColor.copy(alpha = 0.30f),
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
                if (displayed > 0f) {
                    drawArc(
                        color = ringColor.copy(alpha = 0.95f),
                        startAngle = -90f,
                        sweepAngle = 360f * displayed,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Round),
                    )
                }
            }
            KycIcon(
                imageVector = OthentoIcons.Camera,
                contentDescription = content(CK.A11Y_ALT_CAPTURED_SELFIE),
                sizeDp = 28.dp,
                tint = Color.White,
            )
        }
    }
}

private val SELFIE_RING_STROKE = 4.dp

@Composable
private fun SelfiePreviewState(
    capturedPreview: @Composable () -> Unit,
    isValidating: Boolean,
    warnings: List<ValidationWarning>,
    onRetake: () -> Unit,
    onConfirm: () -> Unit,
) {
    CaptureReviewSheet(
        // `selfie.review.*`, not `capture.review.ok*` — see the note on the
        // constants in ContentKeys.
        title = content(CK.SELFIE_REVIEW_TITLE),
        subtitle = content(CK.SELFIE_REVIEW_SUBTITLE),
        validationText = content(CK.SELFIE_PREVIEW_CHECKING),
        confirmLabel = content(CK.SELFIE_PREVIEW_USE),
        capturedPreview = capturedPreview,
        isValidating = isValidating,
        warnings = warnings,
        onRetake = onRetake,
        onConfirm = onConfirm,
    )
}

// ──────────────────────────────────────── Side-effect helpers ─────────────────────────────────────

private suspend fun fireCapture(
    videoBuffer: RollingVideoRecorder,
    onResult: (Uri?) -> Unit,
) {
    val trimmed =
        runCatching {
            withTimeoutOrNull(SELFIE_CAPTURE_WATCHDOG_MS) {
                videoBuffer.stopAndTrim()
            }
        }.getOrNull()
    onResult(trimmed?.let { Uri.fromFile(it) })
}

private fun openSelfieAppSettings(context: Context) {
    val intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    runCatching { context.startActivity(intent) }
}

private fun faceMatchIntroTipCards(): List<IntroTipCard> =
    listOf(
        IntroTipCard(
            label = "Face the camera",
            detail = "Look straight ahead",
            icon = OthentoIcons.Face,
        ),
        IntroTipCard(
            label = "Good lighting",
            detail = "Avoid strong backlight",
            icon = OthentoIcons.Sun,
        ),
        IntroTipCard(
            label = "Remove glasses",
            detail = "Hats and masks too",
            icon = OthentoIcons.Glasses,
        ),
        IntroTipCard(
            label = "Neutral expression",
            detail = "Keep still, don’t smile",
            icon = OthentoIcons.Neutral,
        ),
    )

private fun livenessIntroTipCards(): List<IntroTipCard> =
    listOf(
        IntroTipCard(
            label = "Look at the camera",
            detail = "Stay natural",
            icon = OthentoIcons.Face,
        ),
        IntroTipCard(
            label = "Stay in frame",
            detail = "Face centered in oval",
            icon = OthentoIcons.FourCorners,
        ),
        IntroTipCard(
            label = "Good lighting",
            detail = "Avoid strong backlight",
            icon = OthentoIcons.Sun,
        ),
        IntroTipCard(
            label = "Remove glasses",
            detail = "Hats and masks too",
            icon = OthentoIcons.Glasses,
        ),
    )

private val AmberDot: Color = Color(0xFFFBBF24)

// 2 s of buffered footage before the shutter unlocks. RollingVideoRecorder
// needs ≥ a second of scratch before the trim can produce a valid clip;
// tapping the shutter earlier gets a 0-byte trim → null → retake fallback
// fires instead of a real capture (the user perceives this as a missed
// click that requires tapping twice). Mirrors CAPTURE_READY_DELAY_MS on
// the ID capture screen — same buffer, same constraint.
private const val SELFIE_CAPTURE_READY_DELAY_MS: Long = 2_000L
private const val SELFIE_CAPTURE_WATCHDOG_MS: Long = 5_000L
private const val SELFIE_POST_CAPTURE_SAMPLES: Int = 5
