package com.othento.core.internal.content

import androidx.compose.runtime.Immutable

/**
 * The resolved copy bundle a screen reads through.
 *
 * Screens **never** touch the raw map — they call the nine accessors below,
 * which are the same nine on web and iOS so a key behaves identically on all
 * three platforms (plan §5).
 *
 * ### Resolution rules (plan §5)
 * 1. **Per-key overlay:** `fetched[key] ?: emergencyFallback[key]`. A partial
 *    response degrades key by key, never all-or-nothing.
 * 2. **Media:** every value is an HTTPS URL; [asset] rejects anything else.
 * 3. **Enums:** `tone` / `mode` parse with a safe fallback, never throw, so the
 *    backend can add a value later without breaking deployed builds.
 * 4. **Placeholders:** substituted by name; an *unmatched* placeholder is left
 *    literal so a contract mismatch is visible in QA rather than silently
 *    blanking a sentence.
 *
 * A missing key yields `""` — never the key name (plan §4.8).
 */
@Immutable
@Suppress(
    "TooManyFunctions",
    // Reason: this is the nine-accessor surface the plan defines, identical on
    // web, iOS and Android so a key behaves the same everywhere. Splitting it
    // would break that correspondence for a threshold.
)
internal class ContentBundle private constructor(
    private val fetched: Map<String, Any?>,
) {
    /** True when the backend actually returned something usable. */
    val isEmpty: Boolean get() = fetched.isEmpty()

    // ---- text ------------------------------------------------------------

    /**
     * Resolved string for [key], or `""` when neither the response nor the
     * emergency fallback carries it.
     *
     * Rendering the raw key name to a user is never acceptable in a regulated
     * KYC flow (plan §4.8), so there is deliberately no "echo the key" mode
     * outside the test stub.
     */
    fun text(key: String): String = textOrNull(key).orEmpty()

    /** Same as [text] but distinguishes "absent" from "present and empty". */
    fun textOrNull(key: String): String? =
        (fetched[key] as? String)?.takeIf { it.isNotEmpty() }
            ?: ContentFallback.MAP[key]

    /**
     * [text] with `{named}` placeholders substituted. **Numbers only** — the
     * contract never interpolates a translatable word into a sentence
     * (plan §3.1), so [args] values are formatted with [Any.toString] and are
     * expected to be numeric.
     */
    fun text(
        key: String,
        args: Map<String, Any>,
    ): String = substitute(text(key), args)

    /**
     * Resolves copy for a **backend-supplied identifier**, falling back to the
     * backend's own English and then to [generic].
     *
     * The backend sends stable keys (`declineReasonKey`, an error `code`, a
     * `documentTypeCode`) alongside a free-form English sentence. Our authored
     * copy always wins: the English is not localisable and, for inference
     * declines, can carry raw text passed through from the verification
     * provider. But an unknown key must degrade to that English rather than
     * blanking the screen, so a key the backend adds later still says
     * something.
     *
     * Shared by all three call sites deliberately — three hand-rolled elvis
     * chains would drift, and this is the one place to hang an unmapped-key
     * diagnostic if we ever want one.
     */
    fun resolveBackendCopy(
        prefix: String,
        key: String?,
        backendText: String?,
        generic: String = "",
    ): String {
        val authored = key?.takeIf { it.isNotBlank() }?.let { textOrNull(prefix + it) }
        if (!authored.isNullOrEmpty()) return authored
        return backendText?.trim()?.takeIf { it.isNotEmpty() } ?: generic
    }

    /**
     * Picks the `.one` / `.other` sibling of [key] by [count], substitutes
     * `{count}` plus any extra [args], and renders the count as a **digit**
     * (decision 27 — never a spelled-out word).
     */
    fun plural(
        key: String,
        count: Int,
        args: Map<String, Any> = emptyMap(),
    ): String {
        val suffix = if (count == 1) ContentKeys.SUFFIX_ONE else ContentKeys.SUFFIX_OTHER
        val resolved = textOrNull(key + suffix) ?: textOrNull(key) ?: return ""
        return substitute(resolved, args + (PLACEHOLDER_COUNT to count))
    }

    // ---- structured values --------------------------------------------------

    /** `[{ text, detail? }]`. Entries with a blank `text` are dropped. */
    fun tips(key: String): List<TipItem> =
        objectList(key).mapNotNull { row ->
            val text = row.string(FIELD_TEXT) ?: return@mapNotNull null
            TipItem(text = text, detail = row.string(FIELD_DETAIL))
        }

    /**
     * `[{ icon, label, detail }]`. An entry missing **either** field the
     * renderer dereferences is dropped rather than passed through — web
     * validated `label` but rendered `icon`, and a tenant card without an icon
     * crashed the intro sheet (plan §4.6).
     */
    fun tipCards(key: String): List<TipCard> =
        objectList(key).mapNotNull { row ->
            val icon = row.string(FIELD_ICON)?.takeIf(::isHttps) ?: return@mapNotNull null
            val label = row.string(FIELD_LABEL) ?: return@mapNotNull null
            TipCard(icon = icon, label = label, detail = row.string(FIELD_DETAIL))
        }

    /**
     * An HTTPS media URL, or `null`.
     *
     * Any HTTPS host is accepted — decision 7, no allow-list. Non-HTTPS is
     * rejected outright rather than upgraded, so a misconfigured tenant asset
     * falls back to the built-in drawing instead of leaking a cleartext fetch.
     */
    fun asset(key: String): String? = (fetched[key] as? String)?.takeIf(::isHttps)

    /** `result.*.tone`, parsed against the static built-in palette names. */
    fun tone(
        prefix: String,
        fallback: ResultTone,
    ): ResultTone = ResultTone.parse(fetched[prefix + ContentKeys.SUFFIX_TONE] as? String, fallback)

    /** `result.*.mode`, parsed with a safe fallback. */
    fun mode(
        prefix: String,
        fallback: ResultMode,
    ): ResultMode = ResultMode.parse(fetched[prefix + ContentKeys.SUFFIX_MODE] as? String, fallback)

    // ---- i18n -----------------------------------------------------------------

    /**
     * The picker list. Empty when the backend offers fewer than two languages,
     * which is also the signal to hide the picker entirely (plan §6 task 8).
     */
    fun languages(): List<LanguageOption> =
        objectList(ContentKeys.I18N_AVAILABLE).mapNotNull { row ->
            val code = row.string(FIELD_CODE) ?: return@mapNotNull null
            val label = row.string(FIELD_LABEL) ?: return@mapNotNull null
            LanguageOption(
                code = code,
                label = label,
                direction = row.string(FIELD_DIRECTION) ?: LanguageOption.DIRECTION_LTR,
            )
        }

    /**
     * The language the backend actually **resolved** — not the one requested.
     *
     * Asking for `?locale=ar` on a tenant with no Arabic returns English; a
     * picker that highlights the request would show Arabic active while the
     * screen renders English (plan §4.5).
     */
    fun currentLanguage(): String? = (fetched[ContentKeys.I18N_LANGUAGE] as? String)?.takeIf { it.isNotBlank() }

    /** Read and stored; deliberately not acted on — RTL is out of scope (plan §2). */
    fun direction(): String =
        (fetched[ContentKeys.I18N_DIRECTION] as? String)?.takeIf { it.isNotBlank() }
            ?: LanguageOption.DIRECTION_LTR

    // ---- internals ---------------------------------------------------------------

    private fun objectList(key: String): List<Map<*, *>> {
        val raw = fetched[key] as? List<*> ?: return emptyList()
        return raw.filterIsInstance<Map<*, *>>()
    }

    private fun Map<*, *>.string(field: String): String? = (this[field] as? String)?.takeIf { it.isNotBlank() }

    internal companion object {
        /** Nothing fetched yet — every lookup falls through to the emergency map. */
        val Empty: ContentBundle = ContentBundle(emptyMap())

        fun of(fetched: Map<String, Any?>): ContentBundle = ContentBundle(fetched)

        private const val PLACEHOLDER_COUNT = "count"
        private const val FIELD_TEXT = "text"
        private const val FIELD_DETAIL = "detail"
        private const val FIELD_ICON = "icon"
        private const val FIELD_LABEL = "label"
        private const val FIELD_CODE = "code"
        private const val FIELD_DIRECTION = "direction"
        private const val HTTPS_PREFIX = "https://"

        fun isHttps(value: String): Boolean = value.startsWith(HTTPS_PREFIX, ignoreCase = true)

        /**
         * Replaces `{name}` with `args["name"]`. A placeholder with no matching
         * arg is left exactly as written — see resolution rule 4.
         */
        fun substitute(
            template: String,
            args: Map<String, Any>,
        ): String {
            if (args.isEmpty() || !template.contains('{')) return template
            return args.entries.fold(template) { acc, (name, value) ->
                acc.replace("{$name}", value.toString())
            }
        }
    }
}
