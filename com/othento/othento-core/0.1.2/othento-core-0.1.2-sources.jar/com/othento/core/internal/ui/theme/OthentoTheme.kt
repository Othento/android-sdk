@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.theme

import android.provider.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

/**
 * The single Compose entry point for every SDK screen. Provides the design-token
 * CompositionLocals ([LocalOthentoColors], [LocalOthentoTypography], [LocalOthentoSpacing],
 * [LocalOthentoShapes], [LocalOthentoElevation], [LocalOthentoMotion]) and a thin
 * [MaterialTheme] beneath them so any incidental Material 3 surface (e.g.
 * indication ripple) inherits consistent tints.
 */
@Composable
internal fun OthentoTheme(
    reducedMotion: Boolean = rememberReducedMotion(),
    // Tenant overrides resolved from the backend content bundle
    // (`BrandingResolver`). Defaulted so every existing call site — the
    // Paparazzi snapshot harness in particular — keeps rendering the built-in
    // palette unchanged.
    colors: OthentoColors = OthentoColors.Light,
    shapes: OthentoShapes = OthentoShapes.Default,
    /**
     * Resolved from the content bundle's `i18n.direction`, **not** from the
     * device locale — see `ContentBundle.layoutDirection()`. Defaults to LTR so
     * every existing call site, including the snapshot harness, is unchanged.
     */
    layoutDirection: LayoutDirection = LayoutDirection.Ltr,
    content: @Composable () -> Unit,
) {
    val typography = remember { OthentoTypography.default() }
    val spacing = remember { OthentoSpacing.Default }
    val elevation = remember { OthentoElevation.Default }
    val motion =
        remember(reducedMotion) { OthentoMotion.Default.copy(reducedMotion = reducedMotion) }

    val materialColorScheme =
        remember(colors) {
            lightColorScheme(
                primary = colors.primary,
                onPrimary = Color.White,
                background = colors.bgBase,
                onBackground = colors.textPrimary,
                surface = colors.bgBase,
                onSurface = colors.textPrimary,
                error = colors.error,
                onError = Color.White,
            )
        }

    // Direction is driven by the session's resolved language, so it is pinned
    // here rather than inherited: an Arabic *device* running an English-only
    // tenant must still render LTR, and vice versa. The host Activity mirrors
    // the same value onto the View tree.
    //
    // Mirroring is otherwise free — the SDK uses `start`/`end` padding and
    // `Alignment.*Start/End` everywhere, and every animation translates on Y —
    // so only genuinely direction-invariant surfaces opt back out, via
    // `ForceLtr` (see `RtlSupport.kt`).
    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalOthentoColors provides colors,
        LocalOthentoTypography provides typography,
        LocalOthentoSpacing provides spacing,
        LocalOthentoShapes provides shapes,
        LocalOthentoElevation provides elevation,
        LocalOthentoMotion provides motion,
    ) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            content = content,
        )
    }
}

/**
 * Reads `Settings.Global.TRANSITION_ANIMATION_SCALE` and `ANIMATOR_DURATION_SCALE`
 * once per composition. Both at zero ⇒ user has reduced motion enabled.
 *
 * The flags are static for the lifetime of an Activity; if the user toggles them
 * the SDK Activity will be recreated, so the next composition picks up the
 * change automatically.
 */
@Composable
internal fun rememberReducedMotion(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        val resolver = context.contentResolver
        val transition =
            Settings.Global.getFloat(
                resolver,
                Settings.Global.TRANSITION_ANIMATION_SCALE,
                1f,
            )
        val animator =
            Settings.Global.getFloat(
                resolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1f,
            )
        transition == 0f && animator == 0f
    }
}
