@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens.common

import androidx.compose.runtime.Composable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.content.ResultMode
import com.othento.core.internal.content.ResultTone
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.components.StatusIconTone

/**
 * Renders one of the nine `result.*` states entirely from content.
 *
 * A result state is five keys — `title`, `description`, `icon`, `tone`,
 * `mode` — so every state is this one call with a different prefix. That is
 * deliberate: the alternative (nine screens each reaching for its own strings)
 * is how a screen ends up looking migrated while a literal elsewhere still
 * wins, which recurred four times on web (plan §4.2). Here there is exactly one
 * binding site per field, so "does content reach the screen?" has one answer.
 *
 * `tone` and `mode` parse with the supplied fallbacks and never throw, so the
 * backend can introduce `tone: "info"` without breaking deployed builds.
 * `icon` is a template PNG tinted at render, with [fallbackIcon] standing in
 * offline.
 *
 * **Nine states, not eight.** `result.unsupported` is phase 2 and not seeded
 * yet, but it is enumerated from the start — it is the one result state whose
 * whole purpose is to render on a client that is behind, so hard-coding its
 * copy would defeat it (plan §6).
 */
@Composable
@Suppress("LongParameterList")
internal fun ContentStatusScreen(
    prefix: String,
    fallbackIcon: StatusIconName,
    fallbackTone: ResultTone,
    fallbackMode: ResultMode,
    primaryAction: StatusAction? = null,
    secondaryAction: StatusAction? = null,
    extraContent: (@Composable () -> Unit)? = null,
    /** Overrides `result.*.description` — the error screen's mapped wire message. */
    descriptionOverride: String? = null,
) {
    val bundle = LocalContent.current
    val tone = bundle.tone(prefix, fallbackTone)
    StatusScreenScaffold(
        iconName = fallbackIcon,
        iconTone = tone.toStatusIconTone(),
        iconUrl = bundle.asset(prefix + ContentKeys.SUFFIX_ICON),
        title = bundle.text(prefix + ContentKeys.SUFFIX_TITLE),
        description = descriptionOverride ?: bundle.text(prefix + ContentKeys.SUFFIX_DESCRIPTION),
        mode = bundle.mode(prefix, fallbackMode).toStatusScreenMode(),
        primaryAction = primaryAction,
        secondaryAction = secondaryAction,
        extraContent = extraContent,
    )
}

/**
 * `tone` names *which* status; the colour itself is a static built-in that is
 * never transported (decision 5c).
 */
private fun ResultTone.toStatusIconTone(): StatusIconTone =
    when (this) {
        ResultTone.Neutral -> StatusIconTone.Neutral
        ResultTone.Success -> StatusIconTone.Success
        ResultTone.Warning -> StatusIconTone.Warning
        ResultTone.Error -> StatusIconTone.Error
    }

private fun ResultMode.toStatusScreenMode(): StatusScreenMode =
    when (this) {
        ResultMode.Terminal -> StatusScreenMode.Terminal
        ResultMode.InFlight -> StatusScreenMode.InFlight
    }
