package com.othento.core.internal.ui.components

import android.content.Context
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import com.othento.core.internal.content.ContentKeys as CK

/**
 * Phase 9 — wrapper around `libphonenumber-android` for the phone
 * destination input. The library bundles country metadata and is
 * thread-safe via its singleton; this object exposes only the two
 * operations the OTP screen actually performs (parse + validate).
 *
 * Spec [docs/spec/11-business-logic-and-validation.md] §10.4 — the
 * phone destination is invalid unless `isValidNumber(parsed)` returns
 * true. Length pre-check uses `validateLengthOf` to map per-state error
 * messages.
 */
internal class PhoneValidator(
    context: Context,
) {
    private val util: PhoneNumberUtil = PhoneNumberUtil.createInstance(context.applicationContext)

    @Suppress("ReturnCount")
    fun parseAndValidate(
        raw: String,
        regionCode: String,
    ): PhoneValidationResult {
        if (raw.isBlank()) return PhoneValidationResult.Empty
        return try {
            val parsed = util.parse(raw, regionCode)
            // Length pre-check first — gives more specific error copy than
            // bare isValid for too-short / too-long.
            val lengthIssue = util.isPossibleNumberWithReason(parsed)
            if (lengthIssue != PhoneNumberUtil.ValidationResult.IS_POSSIBLE) {
                return when (lengthIssue) {
                    PhoneNumberUtil.ValidationResult.TOO_SHORT ->
                        PhoneValidationResult.Invalid(PhoneInvalidReason.TooShort)
                    PhoneNumberUtil.ValidationResult.TOO_LONG ->
                        PhoneValidationResult.Invalid(PhoneInvalidReason.TooLong)
                    PhoneNumberUtil.ValidationResult.INVALID_LENGTH ->
                        PhoneValidationResult.Invalid(PhoneInvalidReason.InvalidLength)
                    PhoneNumberUtil.ValidationResult.INVALID_COUNTRY_CODE ->
                        PhoneValidationResult.Invalid(PhoneInvalidReason.InvalidCountry)
                    else ->
                        PhoneValidationResult.Invalid(PhoneInvalidReason.Malformed)
                }
            }
            if (!util.isValidNumber(parsed)) {
                PhoneValidationResult.Invalid(PhoneInvalidReason.NotValidForCountry)
            } else {
                val e164 = util.format(parsed, PhoneNumberUtil.PhoneNumberFormat.E164)
                PhoneValidationResult.Valid(e164 = e164)
            }
        } catch (_: Exception) {
            PhoneValidationResult.Invalid(PhoneInvalidReason.Malformed)
        }
    }
}

internal sealed interface PhoneValidationResult {
    object Empty : PhoneValidationResult

    data class Valid(
        val e164: String,
    ) : PhoneValidationResult

    data class Invalid(
        val reason: PhoneInvalidReason,
    ) : PhoneValidationResult
}

/** Why a number was rejected — enum in, sentence out. See [EmailInvalidReason]. */
internal enum class PhoneInvalidReason(
    val key: String,
    val fallback: String,
) {
    TooShort(CK.OTP_PHONE_ERROR_TOO_SHORT, "Number is too short for this country."),
    TooLong(CK.OTP_PHONE_ERROR_TOO_LONG, "Number is too long for this country."),
    InvalidLength(CK.OTP_PHONE_ERROR_INVALID_LENGTH, "Number length is invalid for this country."),
    InvalidCountry(CK.OTP_PHONE_ERROR_INVALID_COUNTRY, "Please select a valid country."),
    NotValidForCountry(
        CK.OTP_PHONE_ERROR_NOT_VALID_FOR_COUNTRY,
        "This doesn't look like a valid number for this country.",
    ),
    Malformed(CK.OTP_PHONE_ERROR_INVALID_NUMBER, "Please enter a valid phone number."),
}
