package com.othento.core.internal.flow

import com.othento.core.internal.data.SessionRepository
import com.othento.core.internal.data.model.ActiveStepStatus
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.data.model.SessionStatus
import kotlinx.coroutines.delay

/**
 * Coroutine-based session-polling loop. Mirrors the web SDK's
 * `TokenSessionPollingService.startPolling`
 * ([apps/sdk/.../services/token/token-session-polling.service.ts:29-75])
 * one-for-one, including the six-state outcome classification from spec §7.
 *
 * Configuration is pinned to [SessionConfig]. The default profile —
 * `pollIntervalMs = 2000`, `maxPolls = 8` — gives an effective wall-clock cap
 * ≈ 16 s. The [PollingProfile.Background] profile (AML / inference running
 * server-side, selected via [isBackgroundProcessing]) polls faster and for a
 * longer window — `backgroundPollIntervalMs = 1000`, `backgroundMaxPolls = 60`
 * (≈ 60 s) — and fires its first poll immediately.
 *
 * The driver does NOT own threading; the caller wraps the suspending entry
 * in its own scope (typically `viewModelScope`). Cancelling the scope
 * cancels the loop.
 */
internal class PollingDriver(
    private val sessionRepository: SessionRepository,
    private val config: SessionConfig = SessionConfig.Default,
) {
    /**
     * Suspends until the loop emits a non-`continue` outcome or hits
     * [SessionConfig.maxPolls]. The returned [PollingResult] always
     * carries the latest [Session] the loop saw — callers feed it into
     * [ScreenResolver] for the next screen.
     *
     * @param initialStepId snapshot of `currentStep.attemptStepId` at the
     *                      moment polling starts. Used to detect
     *                      `step_advanced` (the backend rotated to a new
     *                      step before the prior one's status flipped).
     */
    suspend fun startPolling(
        initialStepId: String?,
        profile: PollingProfile = PollingProfile.Default,
    ): PollingResult {
        val isBackground = profile == PollingProfile.Background
        val intervalMs = if (isBackground) config.backgroundPollIntervalMs else config.pollIntervalMs
        val maxPolls = if (isBackground) config.backgroundMaxPolls else config.maxPolls
        // Background (AML/inference): fire the first poll immediately so an
        // already-ready result surfaces with no upfront delay. Default keeps
        // the leading interval delay. Mirrors the web's `timer(0, ms)` vs
        // `timer(ms, ms)`.
        val firstPollDelayMs = if (isBackground) 0L else intervalMs

        var lastSession: Session? = null
        var pollCount = 0
        while (pollCount < maxPolls) {
            delay(if (pollCount == 0) firstPollDelayMs else intervalMs)
            val session = sessionRepository.pollSession()
            lastSession = session
            pollCount += 1
            val outcome = evaluate(session, initialStepId, pollCount, maxPolls)
            if (outcome != PollingOutcome.Continue) {
                return PollingResult(session = session, outcome = outcome)
            }
        }
        // Loop fell off the bottom — `pollCount >= maxPolls` and no
        // terminal outcome was emitted (the `evaluate` call above already
        // emits `TimedOut` in that case, so this branch is only reached
        // when `maxPolls == 0`). Defensive return.
        return PollingResult(
            session = requireNotNull(lastSession) { "Polling loop completed with no observed session." },
            outcome = PollingOutcome.TimedOut,
        )
    }

    @Suppress("ReturnCount")
    // Six classification branches (spec §7); collapsing into nested `when`
    // would hide the per-state contract.
    private fun evaluate(
        session: Session,
        initialStepId: String?,
        pollCount: Int,
        maxPolls: Int,
    ): PollingOutcome {
        val step = session.currentStep
        if (step?.status == ActiveStepStatus.Completed) return PollingOutcome.StepCompleted
        if (step?.status == ActiveStepStatus.Failed) return PollingOutcome.StepFailed
        val currentStepId = step?.attemptStepId
        if (currentStepId != initialStepId) return PollingOutcome.StepAdvanced
        if (session.status == SessionStatus.Completed) return PollingOutcome.SessionCompleted
        if (session.status == SessionStatus.Failed) return PollingOutcome.SessionFailed
        if (pollCount >= maxPolls) return PollingOutcome.TimedOut
        return PollingOutcome.Continue
    }
}

/** Six-state outcome of a polling loop, per spec §7. */
internal enum class PollingOutcome {
    Continue,
    StepCompleted,
    StepFailed,
    StepAdvanced,
    SessionCompleted,
    SessionFailed,
    TimedOut,
}

internal data class PollingResult(
    val session: Session,
    val outcome: PollingOutcome,
)

/**
 * Pinned constants matching the web's `session.config.ts`. Kept in a tight
 * data class so tests can substitute fast values without touching globals.
 */
internal data class SessionConfig(
    val pollIntervalMs: Long,
    /**
     * Max poll attempts for the default inference wait (~8 * 2 s = 16 s).
     *
     * Timing out here is not a soft prompt: it routes the user to
     * `result.processing.timedOut`, whose mode is terminal, so a decision that
     * was seconds away instead ends the session in "Verification under review".
     * The window is a count rather than a duration, so it only moves in
     * [pollIntervalMs] steps — 8 polls is the nearest step above 15 s.
     */
    val maxPolls: Int,
    val almostDoneDelayMs: Long,
    val takingLongerDelayMs: Long,
    // Background-processing profile: used when the session is `InProgress`
    // server-side with nothing left for the user to do (AML / inference after
    // all steps are submitted). The backend gives no dedicated AML signal, so
    // we poll faster and for a longer window (~60 * 1s = 60s) to surface the
    // result as soon as it lands. See [isBackgroundProcessing].
    val backgroundPollIntervalMs: Long,
    val backgroundMaxPolls: Int,
) {
    companion object {
        val Default: SessionConfig =
            SessionConfig(
                pollIntervalMs = 2_000L,
                maxPolls = 8,
                almostDoneDelayMs = 5_000L,
                takingLongerDelayMs = 12_000L,
                backgroundPollIntervalMs = 1_000L,
                backgroundMaxPolls = 60,
            )
    }
}
