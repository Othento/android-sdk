@file:Suppress(
    "MaxLineLength",
    // Reason: User-facing warning messages are intentionally verbatim from the web SDK
    // (document-validation.service.ts::WARNING_MESSAGES) for cross-platform UX parity.
)

package com.othento.core.internal.capture.detection

import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.data.model.DocumentType

/**
 * On-device validation issue catalogue. Mirrors the web SDK's
 * `document-validation.service.ts` ValidationIssue type.
 */
internal enum class ValidationIssue {
    TooDark,
    TooBright,
    Blurry,
    Glare,
    NoCard,

    /**
     * Android-only sibling of [NoCard] for the selfie review sheet.
     *
     * The selfie path used to raise `NoCard`, which routes the row to
     * `capture.quality.noCard` — "No document detected", shown after a selfie.
     * That was invisible in English only because the call site passed its own
     * message; once the copy resolves from the bundle the issue has to name the
     * right thing, so the two blocking cases are now distinct.
     */
    NoFace,
}

/** Doc-type discriminator for the static validator. */
internal enum class DocKind {
    Id,
    Passport,
}

internal data class ValidationWarning(
    val issue: ValidationIssue,
    val message: String,
)

internal data class ValidationResult(
    val valid: Boolean,
    val issues: List<ValidationIssue>,
    val warnings: List<ValidationWarning>,
) {
    companion object {
        val Clean: ValidationResult = ValidationResult(valid = true, issues = emptyList(), warnings = emptyList())
    }
}

/**
 * User-facing warning copy — verbatim from the web SDK's WARNING_MESSAGES.
 */
internal object ValidationMessages {
    fun forIssue(issue: ValidationIssue): String =
        when (issue) {
            ValidationIssue.TooDark ->
                "The image appears too dark. Please verify it is readable before continuing."
            ValidationIssue.TooBright ->
                "The image appears too bright. Please verify it is readable before continuing."
            ValidationIssue.Blurry ->
                "The image appears blurry. Please verify it is readable before continuing."
            ValidationIssue.Glare ->
                "Glare was detected on the document. Please verify all details are readable before continuing."
            ValidationIssue.NoCard ->
                "No document detected in this capture. Please retake ensuring the full document is clearly visible in the frame."
            ValidationIssue.NoFace ->
                "We could not detect a face in this capture. Please retake your selfie ensuring your face is clearly visible and centered in the frame."
        }
}

/**
 * MRZ-vs-card detection, selected by the document's stable
 * [com.othento.core.internal.data.model.DocumentType].
 *
 * This used to be a case-insensitive substring check on `typeName`. That
 * broke twice over: an admin renaming the display name silently disabled
 * passport MRZ detection, and a localised `typeName` stops containing the
 * English word "passport" at all. Anything that is not a passport takes the
 * card path, which is also the correct degrade for a code this build has
 * never seen.
 */
internal fun AcceptedDocument.docKind(): DocKind =
    if (documentType == DocumentType.Passport) DocKind.Passport else DocKind.Id
