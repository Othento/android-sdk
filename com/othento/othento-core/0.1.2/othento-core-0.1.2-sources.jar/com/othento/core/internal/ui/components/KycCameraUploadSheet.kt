@file:Suppress(
    "FunctionNaming",
    "TopLevelPropertyNaming",
    "MagicNumber",
    "LongParameterList",
    "LongMethod",
    "TooManyFunctions",
    // Reason: the bottom-sheet composable assembles a linear stack of
    // sections (drag handle + illustration + title + subtitle + tips +
    // primary CTA + cancel). Splitting fragments the visual hierarchy.
    // TooManyFunctions: DotStepper/Dot/UploadIllustration/UploadTipsList helpers
    // are all tightly coupled to this sheet's upload/preview state machine.
)

package com.othento.core.internal.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.content.content
import com.othento.core.internal.flow.PendingCapture
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Bottom-sheet overlay for the **camera-screen upload fallback**.
 *
 * Compose port of the web's
 * `apps/sdk/src/app/pages/verify/screens/camera-capture/upload-sheet/upload-sheet.ts`.
 *
 * Phase-6 reverses the V8/V11 deferral: tapping the upload glyph on the
 * camera HUD now opens this sheet instead of replacing the whole screen
 * with the Phase-5 [com.othento.core.internal.ui.screens.CaptureFallbackScreen].
 *
 * Phase-6 simplification: the sheet routes straight to
 * `ActivityResultContracts.PickVisualMedia` via [onPickFile]; the inline
 * preview / re-upload / image-quality validation steps from the web's
 * `'upload' | 'validating' | 'preview'` state machine are deferred to
 * Phase 11 (R4 + V2 territory).
 *
 * The full-screen Phase-5 fallback remains the path used by the
 * permission-denied / unavailable / timed-out error states' "Upload file
 * instead" CTAs (which sit on top of an inactive camera, where a slide-up
 * sheet would be visually awkward).
 *
 * Phase-9 extends the sheet with an optional preview state ([pendingCapture])
 * and an optional two-side dot stepper ([requireBothSides]).
 */
@Composable
internal fun KycCameraUploadSheet(
    side: SideKind,
    /**
     * Display label only — already localised by the caller. Never branched on:
     * see [isPassport], which the caller derives from `documentTypeCode`.
     */
    typeName: String?,
    /**
     * Whether the document is a passport, selecting the passport tip list and
     * page label. Passed in rather than sniffed out of [typeName], which stops
     * containing the English word "passport" the moment it is localised.
     */
    isPassport: Boolean = false,
    requireBothSides: Boolean = false,
    pendingCapture: PendingCapture? = null,
    onPickFile: () -> Unit,
    onRetake: () -> Unit = {},
    onConfirm: () -> Unit = {},
    onDismiss: () -> Unit,
) {
    val colors = LocalOthentoColors.current

    val backdropInteraction = remember { MutableInteractionSource() }

    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .background(BackdropColor)
                .clickable(
                    interactionSource = backdropInteraction,
                    indication = null,
                    onClick = onDismiss,
                ),
        contentAlignment = Alignment.BottomCenter,
    ) {
        // Inner panel — captures clicks so taps inside don't dismiss.
        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                    .background(colors.bgBase)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 20.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {},
                    ),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(8.dp))
            // Drag handle.
            Box(
                modifier =
                    Modifier
                        .size(width = 40.dp, height = 4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(colors.border),
            )
            Spacer(Modifier.height(20.dp))

            if (requireBothSides) {
                DotStepper(side = side)
                Spacer(Modifier.height(12.dp))
            }

            if (pendingCapture == null) {
                UploadStateBody(
                    side = side,
                    typeName = typeName,
                    isPassport = isPassport,
                    onPickFile = onPickFile,
                    onDismiss = onDismiss,
                )
            } else {
                PreviewStateBody(
                    side = side,
                    typeName = typeName,
                    requireBothSides = requireBothSides,
                    pendingCapture = pendingCapture,
                    onRetake = onRetake,
                    onConfirm = onConfirm,
                )
            }
        }
    }
}

internal enum class SideKind { Front, Back }

// ---------------------------------------------------------------------------
// Upload state (original content, extracted into a sub-composable)
// ---------------------------------------------------------------------------

@Composable
private fun UploadStateBody(
    side: SideKind,
    typeName: String?,
    isPassport: Boolean,
    onPickFile: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current

    UploadIllustration(side = side, isPassport = isPassport)
    Spacer(Modifier.height(16.dp))
    Text(
        text = uploadTitle(side = side, isPassport = isPassport),
        style = typography.titleH3.copy(fontWeight = FontWeight.W700),
        color = colors.textPrimary,
        textAlign = TextAlign.Center,
    )
    if (!typeName.isNullOrBlank()) {
        Spacer(Modifier.height(4.dp))
        Text(
            text = typeName,
            style = typography.bodySm,
            color = colors.textSecondary,
        )
    }
    Spacer(Modifier.height(20.dp))
    UploadTipsList(isPassport = isPassport)
    Spacer(Modifier.height(20.dp))
    KycButton(
        onClick = onPickFile,
        label = content(ContentKeys.IDV_UPLOAD_SELECT_PHOTO),
        variant = KycButtonVariant.Primary,
        size = KycButtonSize.Lg,
        fullWidth = true,
    )
    Spacer(Modifier.height(8.dp))
    KycButton(
        onClick = onDismiss,
        // `otp.cancel` is a bare "Cancel" — one word, one meaning, no OTP
        // semantics riding on it. Reusing it here is not the same move as
        // reusing a document sentence on a selfie screen.
        label = content(ContentKeys.OTP_CANCEL),
        variant = KycButtonVariant.Ghost,
        size = KycButtonSize.Md,
        fullWidth = true,
    )
    Spacer(Modifier.height(16.dp))
}

// ---------------------------------------------------------------------------
// Preview state
// ---------------------------------------------------------------------------

@Composable
private fun PreviewStateBody(
    side: SideKind,
    typeName: String?,
    requireBothSides: Boolean,
    pendingCapture: PendingCapture,
    onRetake: () -> Unit,
    onConfirm: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val context = LocalContext.current

    Text(
        text = previewTitle(side, requireBothSides = requireBothSides),
        style = typography.titleH3.copy(fontWeight = FontWeight.W700),
        color = colors.textPrimary,
        textAlign = TextAlign.Center,
    )
    if (!typeName.isNullOrBlank()) {
        Spacer(Modifier.height(4.dp))
        Text(
            text = typeName,
            style = typography.bodySm,
            color = colors.textSecondary,
        )
    }
    Spacer(Modifier.height(16.dp))

    PreviewImage(uri = pendingCapture.uri, context = context)

    Spacer(Modifier.height(12.dp))

    if (pendingCapture.isValidating) {
        ValidatingRow()
    } else if (pendingCapture.warnings.isNotEmpty()) {
        WarningsList(warnings = pendingCapture.warnings)
    }

    Spacer(Modifier.height(20.dp))

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        KycButton(
            onClick = onRetake,
            label = content(ContentKeys.IDV_CAPTURE_REUPLOAD),
            variant = KycButtonVariant.Ghost,
            size = KycButtonSize.Lg,
            modifier = Modifier.weight(1f),
        )
        KycButton(
            onClick = onConfirm,
            label = content(ContentKeys.IDV_CAPTURE_CONTINUE),
            variant = KycButtonVariant.Primary,
            size = KycButtonSize.Lg,
            enabled = !pendingCapture.isValidating,
            modifier = Modifier.weight(1f),
        )
    }
    Spacer(Modifier.height(16.dp))
}

// Supporting composables for preview state (PreviewImage, ValidatingRow,
// WarningsList, WarningRow) are defined in CapturePreviewState.kt and shared
// with CaptureFallbackScreen.

// ---------------------------------------------------------------------------
// Dot stepper
// ---------------------------------------------------------------------------

@Composable
private fun DotStepper(side: SideKind) {
    val colors = LocalOthentoColors.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        Dot(active = side == SideKind.Front, done = side == SideKind.Back, label = "1")
        Box(
            modifier =
                Modifier
                    .width(32.dp)
                    .height(2.dp)
                    .background(if (side == SideKind.Back) StepperDoneColor else colors.border),
        )
        Dot(active = side == SideKind.Back, done = false, label = "2")
    }
}

@Composable
private fun Dot(
    active: Boolean,
    done: Boolean,
    label: String,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val bg =
        when {
            done -> StepperDoneColor
            active -> colors.primary
            else -> colors.bgHover
        }
    val borderColor =
        when {
            done -> StepperDoneColor
            active -> colors.primary
            else -> colors.border
        }
    Box(
        modifier =
            Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(bg)
                .border(width = 2.dp, color = borderColor, shape = CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (done) {
            KycIcon(
                imageVector = OthentoIcons.Check,
                contentDescription = null,
                sizeDp = 14.dp,
                tint = Color.White,
            )
        } else {
            Text(
                text = label,
                style = typography.bodySm.copy(fontWeight = FontWeight.W600),
                color = if (active) Color.White else colors.textMuted,
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Upload state helpers (shared by UploadStateBody)
// ---------------------------------------------------------------------------

/**
 * A passport is one page, so it reads the `.single` key rather than a side —
 * the same split [previewTitle] and [UploadTipsList] make.
 */
@Composable
@ReadOnlyComposable
private fun uploadTitle(
    side: SideKind,
    isPassport: Boolean,
): String =
    content(
        when {
            isPassport -> ContentKeys.IDV_UPLOAD_TITLE_SINGLE
            side == SideKind.Front -> ContentKeys.IDV_UPLOAD_TITLE_FRONT
            else -> ContentKeys.IDV_UPLOAD_TITLE_BACK
        },
    )

@Composable
private fun UploadIllustration(
    side: SideKind,
    isPassport: Boolean,
) {
    val colors = LocalOthentoColors.current
    if (isPassport) {
        Box(
            modifier =
                Modifier
                    .size(width = 88.dp, height = 88.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(colors.bgHover),
            contentAlignment = Alignment.Center,
        ) {
            KycIcon(
                imageVector = OthentoIcons.Passport,
                contentDescription = null,
                sizeDp = 56.dp,
                tint = colors.textSecondary,
            )
        }
        return
    }
    Box(
        modifier =
            Modifier
                .fillMaxWidth(0.55f)
                .aspectRatio(85.6f / 54f)
                .clip(RoundedCornerShape(12.dp))
                .background(colors.bgHover),
        contentAlignment = Alignment.Center,
    ) {
        KycPlacementGuide(
            kind = if (side == SideKind.Front) PlacementGuideKind.IdCardFront else PlacementGuideKind.IdCardBack,
            visible = true,
            modifier = Modifier.fillMaxSize(),
        )
    }
}

@Composable
private fun UploadTipsList(isPassport: Boolean) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    // `tips` returns `[{ text, detail? }]`; this list renders one line per entry
    // and has no second line, so only `text` is read. An empty result means the
    // bundle carries no tips for this document kind — the block collapses rather
    // than falling back to English, matching the inclusion rule in
    // `ContentFallback` (optional copy is absent on purpose).
    val tips =
        LocalContent.current
            .tips(
                if (isPassport) {
                    ContentKeys.IDV_UPLOAD_TIPS_PASSPORT
                } else {
                    ContentKeys.IDV_UPLOAD_TIPS_DOCUMENT
                },
            ).map { it.text }
    if (tips.isEmpty()) return
    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(colors.bgHover)
                .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        tips.forEach { tip ->
            Row(verticalAlignment = Alignment.Top) {
                KycIcon(
                    imageVector = OthentoIcons.Check,
                    contentDescription = null,
                    sizeDp = 14.dp,
                    tint = colors.primary,
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = tip,
                    style = typography.bodySm,
                    color = colors.textSecondary,
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Preview state helpers
// ---------------------------------------------------------------------------

@Composable
@ReadOnlyComposable
private fun previewTitle(
    side: SideKind,
    requireBothSides: Boolean,
): String =
    content(
        if (!requireBothSides) {
            ContentKeys.IDV_UPLOAD_DOCUMENT_UPLOADED
        } else {
            when (side) {
                SideKind.Front -> ContentKeys.IDV_UPLOAD_SIDE_UPLOADED_FRONT
                SideKind.Back -> ContentKeys.IDV_UPLOAD_SIDE_UPLOADED_BACK
            }
        },
    )

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

private val BackdropColor = Color(0x99000000)
private val StepperDoneColor = Color(0xFF22C55E)
