package com.othento.core.internal.data.model

/**
 * Domain model for an entry in the documents-list response, used to render
 * the document-select screen (Phase 5).
 *
 * Per [docs/spec/09-data-models.md §2.4]. `widthMm` / `heightMm` may be
 * null when the backend doesn't know the physical dimensions; the camera
 * cutout (Phase 6) falls back to a default aspect ratio in that case.
 *
 * ### Identity vs display
 * [documentType] and [alpha2] are the identity fields — branch on those.
 * [typeName] and [countryName] are English display strings from the backend;
 * they are the *fallbacks* behind localised labels, never discriminators.
 */
internal data class AcceptedDocument(
    val documentId: String,
    /**
     * Raw backend code, kept verbatim so `documentType.<code>` can be looked
     * up. Defaulted for the same reason [canReinitiate] is on
     * [com.othento.core.internal.data.model.Session] — fixtures and tests
     * construct this type directly and should not all churn for an additive
     * field. The mapper always sets it explicitly, which
     * `SessionMapperTest` pins.
     */
    val documentTypeCode: String? = null,
    val countryCode: String? = null,
    val countryCodeAlpha2: String? = null,
    val countryCodeAlpha3: String? = null,
    val countryName: String,
    val countryIcon: String,
    val typeName: String,
    val widthMm: Double?,
    val heightMm: Double?,
    val requireBothSides: Boolean,
) {
    /** Behavioural identity. Never derive this from [typeName]. */
    val documentType: DocumentType get() = documentTypeOf(documentTypeCode)

    /**
     * ISO 3166-1 alpha-2, falling back to the legacy `countryCode` when it is
     * two characters — older responses put alpha-2 there. A three-letter
     * legacy value is ignored rather than passed on, because every consumer
     * (flag emoji, locale-based country names) expects alpha-2 and would
     * silently render nothing for an alpha-3 input.
     */
    val alpha2: String?
        get() =
            countryCodeAlpha2?.trim()?.takeIf { it.length == ALPHA2_LENGTH }
                ?: countryCode?.trim()?.takeIf { it.length == ALPHA2_LENGTH }

    /**
     * Grouping and selection identity for the country dropdown.
     *
     * Never the country *name*: that is now localised, and a translated string
     * cannot be an identity. Two countries whose localised names collide would
     * merge into one group, and switching language mid-screen would drop the
     * user's selection because the id it was stored under no longer exists.
     *
     * Rows with no alpha-2 fall back to a name-derived key rather than a
     * constant, so several code-less countries stay separate groups instead of
     * collapsing into one.
     */
    val countryGroupKey: String get() = alpha2?.uppercase() ?: "$NAME_KEY_PREFIX$countryName"

    private companion object {
        const val ALPHA2_LENGTH = 2
        const val NAME_KEY_PREFIX = "name:"
    }
}
