package com.othento.core.internal.capture.detection

import android.graphics.Bitmap
import android.graphics.Rect

/**
 * Helpers for the 2-stream capture path where detection runs over an upright
 * RGB [Bitmap] sampled from the GPU preview (`PreviewView.getBitmap()`) instead
 * of a CameraX `ImageProxy`. The bitmap is already upright (no rotation to
 * apply) and lives in the same view-pixel coordinate space as the on-screen
 * cutout, so detectors treat it as an image with `rotationDegrees = 0`.
 */
internal object BitmapFrames {
    /**
     * Crop [src] to [rect] (clamped to bounds). Returns [src] itself when the
     * rect is null, empty, or covers the whole bitmap — callers must therefore
     * recycle the result only when it is not the same instance as [src].
     */
    fun crop(
        src: Bitmap,
        rect: Rect?,
    ): Bitmap {
        if (rect == null || rect.isEmpty) return src
        val left = rect.left.coerceIn(0, src.width)
        val top = rect.top.coerceIn(0, src.height)
        val right = rect.right.coerceIn(left, src.width)
        val bottom = rect.bottom.coerceIn(top, src.height)
        val w = right - left
        val h = bottom - top
        if (w <= 0 || h <= 0) return src
        if (left == 0 && top == 0 && w == src.width && h == src.height) return src
        return Bitmap.createBitmap(src, left, top, w, h)
    }
}
