@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber", "MatchingDeclarationName", "LongMethod")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.internal.util.countrySearchKey
import com.othento.core.internal.util.countrySearchMatcher

/**
 * A single dropdown option. [leading] is rendered before the label (used for
 * country flags); [id] is the stable handle the parent receives on select.
 *
 * [searchKey] is the pre-folded haystack the search box matches against, built
 * with [countrySearchKey] where the caller has more to offer than the visible
 * label — the localised name, the English name and the ISO code, so an Arabic
 * session is still searchable from a Latin keyboard. It is built with the list
 * (which depends on the locale) rather than per keystroke. `null` falls back to
 * folding [label] on demand, which is correct but re-folds on every keystroke;
 * supply a key for any list long enough to have a search box.
 */
@Immutable
internal data class KycDropdownOption(
    val id: String,
    val label: String,
    val leading: (@Composable () -> Unit)? = null,
    val searchKey: String? = null,
)

/**
 * Enables the menu's search box. Passing `null` for [KycDropdown]'s `search`
 * leaves the menu exactly as it was before search existed — the caller decides
 * whether the list is long enough to be worth filtering.
 *
 * [noMatchLabel] takes the user's term and returns the empty-state sentence, so
 * the primitive interpolates no copy of its own: the term only exists in here,
 * but the wording belongs to the screen.
 */
@Immutable
internal data class KycDropdownSearch(
    val placeholder: String,
    val noMatchLabel: (String) -> String,
)

/**
 * Modal-style dropdown matching the web SDK's `.doc-select__dropdown-*`
 * pattern ([apps/sdk/.../document-select-screen.scss:91-99]). Trigger button
 * with optional leading + chevron; the menu renders as a [Popup] overlay
 * directly below the trigger so it floats over the rest of the screen
 * instead of pushing content down. Tapping outside the menu (popup's
 * built-in `dismissOnClickOutside`) or selecting an option closes it.
 *
 * Phase 5 only ships the country picker, but the primitive is internal so
 * Phase 11 can reuse it for the locale switcher (R5 in `99-open-questions.md`).
 *
 * Pass [search] to grow a filter box at the top of the menu; leave it `null`
 * and nothing about the menu changes.
 */
@Composable
@Suppress("LongParameterList")
internal fun KycDropdown(
    selectedId: String?,
    options: List<KycDropdownOption>,
    onSelect: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    search: KycDropdownSearch? = null,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val shapes = LocalOthentoShapes.current
    val motion = LocalOthentoMotion.current
    val density = LocalDensity.current
    var open by rememberSaveable { mutableStateOf(false) }
    // Cleared on every open and on every pick, never merely when the menu
    // closes: a term surviving into the next open would silently hide options
    // behind a box the user has forgotten they typed in.
    var term by rememberSaveable { mutableStateOf("") }
    var triggerWidthPx by remember { mutableStateOf(0) }
    var triggerHeightPx by remember { mutableStateOf(0) }
    val selected = remember(selectedId, options) { options.firstOrNull { it.id == selectedId } }
    val chevronRotation by animateFloatAsState(
        targetValue = if (open) 180f else 0f,
        animationSpec = tween(durationMillis = motion.durationFastMs, easing = motion.easeOut),
        label = "kyc-dropdown-chevron",
    )

    Box(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned {
                        triggerWidthPx = it.size.width
                        triggerHeightPx = it.size.height
                    }.clip(shapes.md)
                    .border(
                        width = TriggerBorderWidth,
                        color = if (open) colors.primary else colors.border,
                        shape = shapes.md,
                    ).background(colors.bgBase)
                    .clickable {
                        open = !open
                        if (open) term = ""
                    }.padding(horizontal = TriggerHorizontal, vertical = TriggerVertical),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    if (selected != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(LeadingGap),
                        ) {
                            selected.leading?.invoke()
                            Text(
                                text = selected.label,
                                style = typography.body,
                                color = colors.textPrimary,
                            )
                        }
                    } else {
                        Text(
                            text = placeholder,
                            style = typography.body,
                            color = colors.textMuted,
                        )
                    }
                }
                KycIcon(
                    imageVector = OthentoIcons.ChevronDown,
                    contentDescription = null,
                    sizeDp = ChevronSize,
                    tint = colors.textSecondary,
                    modifier = Modifier.rotate(chevronRotation),
                )
            }
        }
        if (open && triggerWidthPx > 0) {
            // Popup floats above the screen content so a long country list
            // can scroll inside the menu without pushing the rest of the
            // page off-screen. The offset positions the popup just below
            // the trigger; the menu width matches the trigger.
            val triggerWidthDp = with(density) { triggerWidthPx.toDp() }
            val offsetY = triggerHeightPx + with(density) { MenuTopGap.toPx().toInt() }
            Popup(
                offset = IntOffset(0, offsetY),
                onDismissRequest = { open = false },
                properties =
                    PopupProperties(
                        focusable = true,
                        dismissOnBackPress = true,
                        dismissOnClickOutside = true,
                    ),
            ) {
                DropdownMenu(
                    options = options,
                    selectedId = selectedId,
                    width = triggerWidthDp,
                    search = search,
                    term = term,
                    onTermChange = { term = it },
                    onDismiss = { open = false },
                    onSelect = {
                        open = false
                        term = ""
                        onSelect(it)
                    },
                )
            }
        }
    }
}

@Composable
@Suppress("LongParameterList")
private fun DropdownMenu(
    options: List<KycDropdownOption>,
    selectedId: String?,
    width: Dp,
    search: KycDropdownSearch?,
    term: String,
    onTermChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    val colors = LocalOthentoColors.current
    val shapes = LocalOthentoShapes.current
    // Keyed on `searchEnabled` rather than on `search` itself: the caller builds
    // that object inline, so a new identity every recomposition would re-filter
    // the whole list for nothing.
    val searchEnabled = search != null
    val visible =
        remember(options, term, searchEnabled) {
            if (searchEnabled) KycDropdownSearchLogic.filter(options, term) else options
        }
    // Index into `visible`, driven by the arrow keys. Reset whenever the term
    // changes: the old index points into the *previous* filtered list, and left
    // alone it can run past the end of the new one — so confirm would select
    // nothing, or a country the user never looked at.
    var highlighted by remember(term) { mutableIntStateOf(0) }
    val listState = rememberLazyListState()

    LaunchedEffect(highlighted, visible.size) {
        if (search != null && highlighted in visible.indices) {
            listState.scrollToItem(highlighted)
        }
    }

    Box(
        modifier =
            Modifier
                .width(width)
                .shadow(elevation = MenuElevation, shape = shapes.md)
                .clip(shapes.md)
                .background(colors.bgBase)
                .border(width = TriggerBorderWidth, color = colors.border, shape = shapes.md)
                .heightIn(max = MenuMaxHeight),
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            if (search != null) {
                // A column with only the list scrolling, so the box stays
                // pinned. Scrolling the whole menu would carry it out of view
                // on the first flick — exactly when the user still wants to
                // correct their term.
                SearchField(
                    search = search,
                    term = term,
                    onTermChange = onTermChange,
                    onMoveHighlight = { delta ->
                        highlighted = KycDropdownSearchLogic.moveHighlight(highlighted, visible.size, delta)
                    },
                    onConfirm = {
                        // Nothing matched, or a highlight stranded by a
                        // shrinking list: do nothing rather than guess an
                        // option on the user's behalf.
                        visible.getOrNull(highlighted)?.let { onSelect(it.id) }
                    },
                    onDismiss = onDismiss,
                )
                Box(modifier = Modifier.fillMaxWidth().height(DividerHeight).background(colors.border))
            }
            if (search != null && visible.isEmpty()) {
                NoMatchLabel(text = search.noMatchLabel(term))
            } else {
                LazyColumn(
                    state = listState,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .heightIn(max = if (search != null) MenuListMaxHeight else MenuMaxHeight)
                            .padding(MenuPadding),
                ) {
                    items(items = visible, key = { it.id }) { option ->
                        DropdownOptionRow(
                            option = option,
                            selected = option.id == selectedId,
                            // Autocomplete highlight only exists where a search
                            // box does — without one there is no way to move it.
                            highlighted = search != null && visible.getOrNull(highlighted)?.id == option.id,
                            onClick = { onSelect(option.id) },
                        )
                    }
                }
            }
        }
    }
}

/**
 * The filter box.
 *
 * Deliberately **not** autofocused: on a phone the soft keyboard would
 * immediately cover the list this box filters. The user taps it to type.
 */
@Composable
@Suppress("LongParameterList")
private fun SearchField(
    search: KycDropdownSearch,
    term: String,
    onTermChange: (String) -> Unit,
    onMoveHighlight: (Int) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(SearchHeight)
                .padding(horizontal = SearchHorizontal),
        contentAlignment = Alignment.CenterStart,
    ) {
        BasicTextField(
            value = term,
            onValueChange = onTermChange,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .onPreviewKeyEvent { event ->
                        if (event.type != KeyEventType.KeyDown) {
                            false
                        } else {
                            when (event.key) {
                                Key.DirectionDown -> {
                                    onMoveHighlight(1)
                                    true
                                }
                                Key.DirectionUp -> {
                                    onMoveHighlight(-1)
                                    true
                                }
                                Key.Enter, Key.NumPadEnter -> {
                                    onConfirm()
                                    true
                                }
                                Key.Escape -> {
                                    onDismiss()
                                    true
                                }
                                else -> false
                            }
                        }
                    },
            singleLine = true,
            textStyle = typography.body.copy(color = colors.textPrimary),
            cursorBrush = SolidColor(colors.primary),
            // A soft keyboard sends its action key rather than a KeyDown for
            // Enter, so confirm is wired to both.
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onConfirm() }),
            decorationBox = { inner ->
                if (term.isEmpty()) {
                    Text(text = search.placeholder, style = typography.body, color = colors.textMuted)
                }
                inner()
            },
        )
    }
}

@Composable
private fun NoMatchLabel(text: String) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Text(
        text = text,
        style = typography.caption,
        color = colors.textSecondary,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(horizontal = SearchHorizontal, vertical = NoMatchVertical),
    )
}

@Composable
private fun DropdownOptionRow(
    option: KycDropdownOption,
    selected: Boolean,
    highlighted: Boolean,
    onClick: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(OptionRadius))
                .background(if (selected) colors.primaryBg else Color.Transparent)
                .then(
                    if (highlighted) {
                        Modifier.border(
                            width = HighlightBorderWidth,
                            color = colors.primary,
                            shape = RoundedCornerShape(OptionRadius),
                        )
                    } else {
                        Modifier
                    },
                ).clickable(onClick = onClick)
                .padding(horizontal = OptionHorizontal, vertical = OptionVertical),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(LeadingGap),
    ) {
        option.leading?.invoke()
        Text(
            text = option.label,
            style = typography.body,
            color = if (selected) colors.primary else colors.textPrimary,
            modifier = Modifier.weight(1f),
        )
        if (selected) {
            KycIcon(
                imageVector = OthentoIcons.Check,
                contentDescription = null,
                sizeDp = CheckSize,
                tint = colors.primary,
            )
        }
    }
}

/**
 * The dropdown search rules, as plain functions so they can be tested without
 * a composition. The UI above owns only the state they operate on.
 */
internal object KycDropdownSearchLogic {
    /**
     * Options whose [KycDropdownOption.searchKey] matches [term], per the
     * shared country-picker rule: case-insensitive, trimmed, accent- and
     * diacritic-blind on both sides. A blank term matches everything.
     */
    fun filter(
        options: List<KycDropdownOption>,
        term: String,
    ): List<KycDropdownOption> {
        val matches = countrySearchMatcher(term)
        return options.filter { matches(it.searchKey ?: countrySearchKey(listOf(it.label))) }
    }

    /**
     * Moves the autocomplete highlight by [delta], wrapping at both ends so
     * holding one arrow key cycles the list rather than sticking at an edge.
     * An empty list has nothing to highlight and stays at 0.
     */
    fun moveHighlight(
        current: Int,
        size: Int,
        delta: Int,
    ): Int {
        if (size <= 0) return 0
        return ((current + delta) % size + size) % size
    }
}

private val TriggerHorizontal = 14.dp
private val TriggerVertical = 12.dp
private val TriggerBorderWidth: Dp = 1.5.dp
private val LeadingGap = 10.dp
private val ChevronSize = 16.dp
private val MenuTopGap = 4.dp
private val MenuMaxHeight = 280.dp
private val MenuListMaxHeight = 220.dp
private val SearchHeight = 40.dp
private val SearchHorizontal = 12.dp
private val DividerHeight = 1.dp
private val NoMatchVertical = 16.dp
private val HighlightBorderWidth: Dp = 2.dp
private val MenuPadding = 4.dp
private val MenuElevation = 12.dp
private val OptionRadius = 6.dp
private val OptionHorizontal = 12.dp
private val OptionVertical = 10.dp
private val CheckSize = 16.dp
