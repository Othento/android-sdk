@file:Suppress("FunctionNaming", "LongMethod", "TopLevelPropertyNaming", "LongParameterList")

package com.othento.core.internal.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.othento.core.internal.content.content
import com.othento.core.internal.content.contentLanguage
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.internal.util.countryDisplayName
import com.othento.core.internal.util.countryNameComparator
import com.othento.core.internal.util.countrySearchKey
import com.othento.core.internal.util.countrySearchMatcher
import com.othento.core.internal.content.ContentKeys as CK

/**
 * Phase 9 — phone-destination input. Faithful port of
 * `apps/sdk/.../phone-destination-input` per spec
 * [docs/spec/06-screens/09-otp-phone.md] §"Phone destination input".
 *
 * Layout: country picker trigger (flag emoji + dial code + chevron) on
 * the left, number input on the right. Tapping the trigger opens a
 * popover (search input + scrollable list) below. Selecting a country
 * closes the popover, clears the number input, and re-emits the value.
 *
 * The component owns its own popover-open state but pushes value /
 * selected country / validity changes back via callbacks so the OTP
 * screen can drive the "Send code" button.
 */
@Composable
internal fun PhoneDestinationInput(
    raw: String,
    countryCode: String,
    onRawChange: (String) -> Unit,
    onCountryChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    errorMessage: String? = null,
    disabled: Boolean = false,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val country =
        CountryList.byCode(countryCode)
            ?: CountryList.byCode(CountryList.DEFAULT_CODE)
            ?: CountryList.ALL.first()
    var popoverOpen by remember { mutableStateOf(false) }
    val isError = errorMessage != null
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // Pinned LTR: the dial-code trigger has to sit immediately before the
        // digits it prefixes, because together they are one E.164 number and
        // E.164 is left-to-right in every locale. Mirroring would read as
        // "number, then +962". The label above and the error below are prose
        // and still mirror.
        ForceLtr {
            Row(
                modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CountryTrigger(
                    country = country,
                    onClick = {
                        if (!disabled) {
                            focusManager.clearFocus(force = true)
                            keyboardController?.hide()
                            popoverOpen = !popoverOpen
                        }
                    },
                    disabled = disabled,
                    expanded = popoverOpen,
                    modifier = Modifier.widthIn(min = 104.dp).height(46.dp),
                )
                NumberField(
                    value = raw,
                    onValueChange = onRawChange,
                    disabled = disabled,
                    isError = isError,
                    modifier = Modifier.weight(1f).height(46.dp),
                )
            }
        }
        if (popoverOpen) {
            CountryPopover(
                onSelect = {
                    popoverOpen = false
                    onCountryChange(it.code)
                    onRawChange("")
                },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (isError) {
            Text(
                text = errorMessage.orEmpty(),
                style = typography.caption,
                color = colors.error,
            )
        }
    }
}

@Composable
private fun CountryTrigger(
    country: Country,
    expanded: Boolean,
    disabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val borderColor = if (expanded) colors.primary else colors.border
    val bg = if (disabled) colors.bgHover else colors.bgBase
    Row(
        modifier =
            modifier
                .clip(RoundedCornerShape(8.dp))
                .background(bg)
                .border(width = 1.dp, color = borderColor, shape = RoundedCornerShape(8.dp))
                .clickable(enabled = !disabled, onClick = onClick)
                .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = country.flagEmoji,
            style = typography.body.copy(fontWeight = FontWeight.W500),
            color = colors.textPrimary,
        )
        Text(
            text = country.dialCode,
            style = typography.body.copy(fontWeight = FontWeight.W600),
            color = if (disabled) colors.textMuted else colors.textPrimary,
        )
        Text(
            text = if (expanded) "▴" else "▾",
            style = typography.caption,
            color = colors.textSecondary,
        )
    }
}

@Composable
private fun NumberField(
    value: String,
    onValueChange: (String) -> Unit,
    disabled: Boolean,
    isError: Boolean,
    modifier: Modifier = Modifier,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val borderColor =
        when {
            isError -> colors.error
            else -> colors.border
        }
    Box(
        modifier =
            modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (disabled) colors.bgHover else colors.bgBase)
                .border(width = 1.dp, color = borderColor, shape = RoundedCornerShape(8.dp))
                .padding(horizontal = 14.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            enabled = !disabled,
            singleLine = true,
            textStyle = typography.body.copy(color = colors.textPrimary),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            cursorBrush = SolidColor(colors.primary),
            decorationBox = { inner ->
                if (value.isEmpty()) {
                    Text(text = content(CK.OTP_PHONE_PLACEHOLDER), style = typography.body, color = colors.textMuted)
                }
                inner()
            },
        )
    }
}

@Composable
private fun CountryPopover(
    onSelect: (Country) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    var query by remember { mutableStateOf("") }
    val language = contentLanguage()
    val localized = remember(language) { localizedCountries(language) }
    val filtered = remember(localized, query) { filterCountries(localized, query) }
    Column(
        modifier =
            modifier
                .clip(RoundedCornerShape(8.dp))
                .background(colors.bgBase)
                .border(width = 1.dp, color = colors.border, shape = RoundedCornerShape(8.dp)),
    ) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(40.dp)
                    .padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                textStyle = typography.body.copy(color = colors.textPrimary),
                cursorBrush = SolidColor(colors.primary),
                decorationBox = { inner ->
                    if (query.isEmpty()) {
                        Text(
                            text = content(CK.OTP_PHONE_COUNTRY_SEARCH_PLACEHOLDER),
                            style = typography.body,
                            color = colors.textMuted,
                        )
                    }
                    inner()
                },
            )
        }
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(colors.border),
        )
        if (filtered.isEmpty()) {
            Text(
                text = content(CK.OTP_PHONE_NO_COUNTRY_MATCH, PLACEHOLDER_SEARCH to query),
                style = typography.caption,
                color = colors.textSecondary,
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                textAlign = TextAlign.Center,
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp),
            ) {
                items(items = filtered, key = { it.country.code }) { row ->
                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(row.country) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = row.country.flagEmoji,
                            style = typography.body,
                            modifier = Modifier.width(24.dp),
                        )
                        Text(
                            text = row.name,
                            style = typography.body,
                            color = colors.textPrimary,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            text = row.country.dialCode,
                            style = typography.caption,
                            color = colors.textSecondary,
                        )
                    }
                }
            }
        }
        Spacer(Modifier.size(0.dp))
    }
}

/**
 * A country row as the picker renders it: the bundled record, its name in the
 * active language, and a haystack pre-folded by [countrySearchKey].
 */
private data class LocalizedCountry(
    val country: Country,
    val name: String,
    val searchKey: String,
)

/**
 * The bundled list, renamed into [language] and re-sorted for it.
 *
 * The bundled names are English, which left an Arabic session reading
 * "Jordan, Kuwait, Lebanon" inside otherwise-Arabic chrome. They stay as the
 * fallback for any code the platform has no name for, and — via [searchKey] —
 * as a second thing the user can type: someone with a Latin keyboard on an
 * Arabic device can still find "Jordan".
 *
 * Sorted with a collator, because a code-unit sort puts every Arabic name
 * after every Latin one and makes a translated list unnavigable.
 */
private fun localizedCountries(language: String): List<LocalizedCountry> {
    val comparator = countryNameComparator(language)
    return CountryList.ALL
        .map { country ->
            val name = countryDisplayName(country.code, language, country.name)
            LocalizedCountry(
                country = country,
                name = name,
                searchKey = countrySearchKey(listOf(name, country.name, country.code, country.dialCode)),
            )
        }.sortedWith { a, b -> comparator.compare(a.name, b.name) }
}

private fun filterCountries(
    rows: List<LocalizedCountry>,
    query: String,
): List<LocalizedCountry> {
    val matches = countrySearchMatcher(query)
    return rows.filter { matches(it.searchKey) }
}

/** `{search}` in `otp.phone.noCountryMatch` — the user's own query, echoed back. */
private const val PLACEHOLDER_SEARCH = "search"
