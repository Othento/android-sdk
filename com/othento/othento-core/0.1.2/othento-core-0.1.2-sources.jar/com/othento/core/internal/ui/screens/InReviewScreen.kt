@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.ResultMode
import com.othento.core.internal.content.ResultTone
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.screens.common.ContentStatusScreen
import com.othento.core.internal.ui.screens.common.returnToAppLabel
import com.othento.core.internal.ui.screens.common.StatusAction

/**
 * `result.inReview.*` — amber clock. The contract's `mode` is `in-flight`
 * despite this being a UI-terminal: the loop intent is conceptual, and the
 * clock glyph itself is static.
 */
@Composable
internal fun InReviewScreen(onReturnToApp: () -> Unit) {
    ContentStatusScreen(
        prefix = ContentKeys.RESULT_IN_REVIEW,
        fallbackIcon = StatusIconName.Clock,
        fallbackTone = ResultTone.Warning,
        fallbackMode = ResultMode.InFlight,
        primaryAction = StatusAction(label = returnToAppLabel(), onClick = onReturnToApp),
    )
}
