package com.othento.core.internal.data

import android.util.Log
import com.othento.core.internal.network.OthentoApi
import com.othento.core.internal.network.SessionMapper
import com.othento.core.internal.network.TokenStore
import com.othento.core.internal.network.dto.ApiErrorEnvelopeDto
import com.othento.core.internal.network.dto.OtpSendRequestDto
import com.othento.core.internal.network.dto.OtpVerifyRequestDto
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import kotlinx.coroutines.CancellationException
import okhttp3.ResponseBody
import retrofit2.HttpException

/**
 * Phase 9 — wraps `POST /api/v1/SessionToken/session/otp/send` and
 * `POST .../otp/verify`. Translates the spec's HTTP status table
 * ([docs/spec/11-business-logic-and-validation.md] §10.5) into the
 * typed [OtpSendResult] / [OtpVerifyResult] discriminants the
 * FlowCoordinator surfaces to the UI.
 *
 * The repository owns:
 * - Error-**code** → result discrimination (see [otpErrorFor]). HTTP status is
 *   consulted only as the fallback for responses that carry no code, because
 *   sibling cases share one: `OTP_EXPIRED` and `OTP_NOT_REQUESTED` are both
 *   410, and treating them alike told a user who had never requested a code
 *   that their code had expired.
 * - Skip-notice detection — when the response carries a `declineMessage`
 *   AND the active step rotated past `originalStepId`, the result is
 *   `SkipNotice` regardless of HTTP status.
 * - Token rotation — every response goes through [TokenStore.updateFromResponse]
 *   so X-ST / X-SRT rotations stay live for the next call.
 *
 * Body parsing for HTTP error responses uses the same envelope as
 * [com.othento.core.internal.network.ErrorMapper] consumers expect:
 * `{ error: { message?, title? } }`. A best-effort parse — if the
 * envelope is missing, we fall through to the spec's default copy.
 */
internal interface OtpRepository {
    suspend fun sendOtp(
        attemptStepId: String,
        contact: String,
    ): OtpSendResult

    suspend fun verifyOtp(
        attemptStepId: String,
        code: String,
    ): OtpVerifyResult
}

internal class OtpRepositoryImpl(
    private val api: OthentoApi,
    private val tokenStore: TokenStore,
    moshi: Moshi = Moshi.Builder().build(),
) : OtpRepository {
    private val errorEnvelopeAdapter: JsonAdapter<ApiErrorEnvelopeDto> =
        moshi.adapter(ApiErrorEnvelopeDto::class.java).lenient()

    @Suppress("TooGenericExceptionCaught")
    override suspend fun sendOtp(
        attemptStepId: String,
        contact: String,
    ): OtpSendResult =
        try {
            val response = api.sendOtp(OtpSendRequestDto(attemptStepId = attemptStepId, contact = contact))
            tokenStore.updateFromResponse(response)
            val session = SessionMapper.fromTokenSessionResponse(response)
            session.skipNoticeOrNull(attemptStepId)?.let {
                return OtpSendResult.SkipNotice(session, session.declineReasonKey, it)
            }
                ?: OtpSendResult.Sent(session)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: HttpException) {
            if (e.code() == HTTP_NOT_FOUND) {
                OtpSendResult.SessionNotFound
            } else {
                val parsed = parseError(e, fallback = SEND_FAIL_DEFAULT)
                OtpSendResult.Failure(displayMessage = parsed.message, code = parsed.code)
            }
        } catch (e: Exception) {
            OtpSendResult.Failure(displayMessage = e.message?.takeIf { it.isNotBlank() } ?: SEND_FAIL_DEFAULT)
        }

    @Suppress("TooGenericExceptionCaught", "ReturnCount")
    override suspend fun verifyOtp(
        attemptStepId: String,
        code: String,
    ): OtpVerifyResult =
        try {
            val response = api.verifyOtp(OtpVerifyRequestDto(attemptStepId = attemptStepId, code = code))
            tokenStore.updateFromResponse(response)
            val session = SessionMapper.fromTokenSessionResponse(response)
            session.skipNoticeOrNull(attemptStepId)?.let {
                return OtpVerifyResult.SkipNotice(session, session.declineReasonKey, it)
            }
            OtpVerifyResult.Advanced(session)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: HttpException) {
            if (e.code() == HTTP_NOT_FOUND) {
                OtpVerifyResult.SessionNotFound
            } else {
                verifyFailure(e)
            }
        } catch (e: Exception) {
            OtpVerifyResult.Failure(displayMessage = e.message?.takeIf { it.isNotBlank() } ?: VERIFY_FAIL_DEFAULT)
        }

    /**
     * Classifies a verify failure by the backend's error `code`, falling back
     * to the old status table only when the response carries none.
     *
     * The fallback is not legacy tolerance for its own sake — the backend
     * states `code` is absent on call sites it has not migrated yet, so a
     * status-blind implementation would regress those to a generic inline
     * error and lose both dialogs. It cannot, however, produce
     * [OtpVerifyErrorKind.NotRequested]: that case is *only* distinguishable
     * by code, which is the whole reason the code exists.
     */
    private fun verifyFailure(e: HttpException): OtpVerifyResult {
        val parsed = parseError(e, fallback = VERIFY_FAIL_DEFAULT)
        val kind =
            if (parsed.code != null) {
                // A code is authoritative. An unrecognised one is NOT forced
                // into a dialog by its status: the backend deliberately
                // reported something this build does not know, and guessing
                // "expired" for it is how the 410 conflation happened in the
                // first place. It degrades to an inline message instead.
                (otpErrorFor(parsed.code) as? OtpErrorMapping.Dialog)?.kind
            } else {
                dialogKindForStatus(e.code())
            }
        return kind
            ?.let { OtpVerifyResult.DialogError(it) }
            ?: OtpVerifyResult.Failure(displayMessage = parsed.message, code = parsed.code)
    }

    /**
     * The pre-code status table, consulted **only** when a response carries no
     * `code`. Cannot produce [OtpVerifyErrorKind.NotRequested]: that case
     * shares status 410 with Expired and is distinguishable by code alone,
     * which is exactly why the code exists.
     */
    private fun dialogKindForStatus(status: Int): OtpVerifyErrorKind? =
        when (status) {
            HTTP_GONE -> OtpVerifyErrorKind.Expired
            HTTP_UNPROCESSABLE_ENTITY -> OtpVerifyErrorKind.Invalid
            else -> null
        }

    /**
     * Spec §10.6: skip notice fires when the backend returns a
     * `declineMessage` AND `currentStep.attemptStepId` has rotated past
     * the step the user was working on. Returns the message string when
     * applicable, else null.
     */
    @Suppress("ReturnCount")
    private fun com.othento.core.internal.data.model.Session.skipNoticeOrNull(originalStepId: String): String? {
        val message = declineMessage?.takeIf { it.isNotBlank() } ?: return null
        if (currentStep == null) return message
        if (currentStep.attemptStepId == originalStepId) return null
        return message
    }

    /** A parsed error body: the stable [code] when present, plus English to render. */
    private data class ParsedError(
        val message: String,
        val code: String?,
    )

    /**
     * Best-effort body parse via Moshi. Tries every plausible message
     * field shape the dev backend might use:
     *
     * - `{"error":{"message":"…"}}` — RFC envelope
     * - `{"error":{"title":"…","detail":"…"}}` — portal envelope
     * - `{"message":"…"}` — flat shape
     * - `{"errors":{"request.Contact":["…"]}}` — RFC 9110 field-validation
     *   map (e.g. the corporate-email policy rejection), flattened and joined
     * - `{"title":"…","detail":"…"}` — RFC 7807 ProblemDetails
     *
     * Field-validation errors are preferred over the generic top-level
     * `title`/`detail` (which is often boilerplate like "The request could
     * not be processed"), mirroring the web SDK's
     * `ApiErrorHelper.getMessageOrFields`.
     *
     * If none match, falls through to a diagnostic string that includes
     * the HTTP status so the inline error in red text is more
     * actionable than the spec's generic copy. The raw body is also
     * logged to logcat so a debug build's HttpLoggingInterceptor isn't
     * the only source of truth.
     */
    private fun parseError(
        e: HttpException,
        fallback: String,
    ): ParsedError {
        val status = e.code()
        val body: ResponseBody? = e.response()?.errorBody()
        val raw = body?.let { runCatching { it.string() }.getOrNull() }
        if (raw != null && raw.isNotBlank()) {
            warnLog("OTP HTTP $status body: ${raw.take(BODY_LOG_PREVIEW)}")
        }
        if (raw.isNullOrBlank()) return ParsedError("$fallback (HTTP $status)", code = null)
        val parsed = runCatching { errorEnvelopeAdapter.fromJson(raw) }.getOrNull()
        val fieldErrors =
            parsed
                ?.errors
                ?.values
                ?.flatten()
                ?.filter { it.isNotBlank() }
                ?.joinToString(separator = "\n")
                ?.takeIf { it.isNotBlank() }
        val extracted =
            sequenceOf(
                parsed?.error?.message,
                parsed?.error?.detail,
                parsed?.error?.title,
                parsed?.message,
                fieldErrors,
                parsed?.detail,
                parsed?.title,
            ).firstOrNull { !it.isNullOrBlank() }
        // The nested `error.code` is read as a code, not as prose. It used to
        // sit in the message chain above, which meant a body carrying only a
        // code rendered the raw enum name — "OTP_INVALID" — to the user.
        val code =
            sequenceOf(parsed?.code, parsed?.error?.code)
                .firstOrNull { !it.isNullOrBlank() }
        return ParsedError(
            message = extracted ?: "$fallback (HTTP $status)",
            code = code,
        )
    }

    @Suppress("TooGenericExceptionCaught")
    private fun warnLog(message: String) {
        try {
            Log.w(LOG_TAG, message)
        } catch (_: LinkageError) {
            // Unit-test environment without android.util.Log — ignore.
        } catch (_: RuntimeException) {
            // Defensive against any platform stub that throws.
        }
    }

    private companion object {
        const val HTTP_NOT_FOUND: Int = 404
        const val HTTP_GONE: Int = 410
        const val HTTP_UNPROCESSABLE_ENTITY: Int = 422

        const val SEND_FAIL_DEFAULT: String = "Could not send code. Please try again."
        const val VERIFY_FAIL_DEFAULT: String = "Incorrect code. Please try again."

        const val LOG_TAG: String = "OthentoSDK-Otp"
        const val BODY_LOG_PREVIEW: Int = 500
    }
}
