package com.othento.core.internal.flow

import com.othento.core.internal.data.OtpVerifyErrorKind
import com.othento.core.internal.data.model.OtpChannel
import com.othento.core.internal.data.model.Session

/**
 * Screen-facing state for the OTP screens (phone + email). Owned by
 * [FlowCoordinator] and rebuilt on each tick of the cooldown timer.
 *
 * Fields mirror the visible elements of [docs/spec/06-screens/09-otp-phone.md]
 * §"States" — the screen is a thin renderer over this shape.
 */
internal data class OtpUiState(
    /** Phone vs email — drives the destination input + chrome copy. */
    val channel: OtpChannel,
    /**
     * `true` while the user is editing the destination contact (initial
     * state, or after tapping "Change phone/email"). `false` once a send
     * has succeeded — flips to the code-entry layout.
     */
    val editing: Boolean,
    val sendInFlight: Boolean = false,
    val verifyInFlight: Boolean = false,
    /**
     * Inline error below "Send code" (network, or an HTTP error whose code
     * does not open a dialog). Carries a content key plus the backend's
     * English, resolved at render — see [OtpNotice].
     */
    val sendError: OtpNotice? = null,
    /**
     * Inline error below "Verify". `null` when a dialog kind
     * ([verifyErrorKind]) is the active surface — the dialog supersedes the
     * inline notice.
     */
    val verifyError: OtpNotice? = null,
    /** Which blocking dialog to show, selected by the backend's error code. */
    val verifyErrorKind: OtpVerifyErrorKind? = null,
    /** Skip-notice sheet payload. Pending session committed on Continue. */
    val skipNotice: SkipNotice? = null,
    val cooldownRemainingSec: Int = 0,
    val isExpired: Boolean = false,
    val canResend: Boolean = true,
    /** Most recently sent contact — restores destination on edit-cancel. */
    val lastContact: String? = null,
    val codeLength: Int = DEFAULT_OTP_LENGTH,
    val alphanumeric: Boolean = false,
    /**
     * Email channel only: when `true` the destination input rejects public
     * / free email domains, accepting corporate addresses only. Driven by
     * the active challenge's `corporateEmailOnly` flag. Always `false` for
     * the phone channel.
     */
    val corporateEmailOnly: Boolean = false,
) {
    /**
     * The backend advanced past this OTP step after too many attempts.
     *
     * Stores the **key** plus the backend's English rather than a resolved
     * sentence — the same choice the capture hints and validators already
     * make. Resolving here would strand the notice in the previous language
     * if the user switched while it was on screen.
     */
    data class SkipNotice(
        val pendingSession: Session,
        val reasonKey: String?,
        val fallbackMessage: String,
    )

    companion object {
        const val DEFAULT_OTP_LENGTH: Int = 6
    }
}

/**
 * An inline OTP failure notice, held as *identity plus fallback* rather than
 * as a finished sentence.
 *
 * [contentKey] is set when the backend's error `code` mapped to copy we
 * author; [fallback] is always the backend's own English. The screen resolves
 * the pair at render time, which is what lets a mid-flow language switch
 * re-render the notice instead of leaving it frozen in the previous language —
 * and what keeps the repository, which runs off the composition and cannot
 * read content, out of the copy business entirely.
 */
internal data class OtpNotice(
    val fallback: String,
    val contentKey: String? = null,
)
