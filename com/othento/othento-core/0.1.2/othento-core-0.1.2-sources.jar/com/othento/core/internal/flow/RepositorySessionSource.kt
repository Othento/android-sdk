package com.othento.core.internal.flow

import com.othento.core.api.OthentoCallbackReceiver
import com.othento.core.api.OthentoConfig
import com.othento.core.api.OthentoError
import com.othento.core.api.OthentoExpectedDetails
import com.othento.core.api.OthentoMode
import com.othento.core.internal.data.SessionRepository
import com.othento.core.internal.data.model.CallbackReceiver
import com.othento.core.internal.network.OthentoNetworkException
import com.othento.core.internal.network.dto.CreateSessionRequestDto
import com.othento.core.internal.network.dto.ExpectedDetailsDto
import kotlinx.coroutines.CancellationException

/**
 * Default [SessionSource] for non-fixture launches. Calls
 * [SessionRepository.createSession] with the host-supplied
 * `workflowExternalId` / `clientData` and folds the response into a
 * [SessionResolveResult].
 *
 * The `Builder` validates that `OthentoMode.Create` is set before construction
 * (see [OthentoConfig.Builder.build]); if a future deeplink/token mode lands,
 * extend the `when` below rather than adding a new SessionSource.
 */
internal class RepositorySessionSource(
    private val sessionRepository: SessionRepository,
) : SessionSource {
    @Suppress("TooGenericExceptionCaught")
    override suspend fun resolveSession(config: OthentoConfig): SessionResolveResult =
        try {
            val session =
                when (val mode = config.mode) {
                    is OthentoMode.Create ->
                        sessionRepository.createSession(
                            CreateSessionRequestDto(
                                workflowExternalId = mode.workflowExternalId,
                                clientData = mode.clientData,
                                callbackUrl = config.callbackUrl,
                                callbackReceiver = config.callbackReceiver?.let(::callbackReceiverWire),
                                metadata = config.metadata,
                                expectedDetails = config.expectedDetails?.toDto(),
                                language = config.language,
                            ),
                        )
                    // Phase 10 — token mode skips create entirely. The
                    // SAT seeded by SessionRepositoryFactory drives the
                    // first poll-session call; the response carries the
                    // ST/SRT bundle that takes over from there.
                    is OthentoMode.Token -> sessionRepository.pollSession()
                }
            SessionResolveResult.Ok(session)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: OthentoNetworkException) {
            SessionResolveResult.Failure(
                error = e.error,
                displayMessage = e.displayMessage,
                httpStatus = (e.error as? OthentoError.CreateFailed)?.httpStatus,
            )
        }

    /**
     * Map the public [OthentoCallbackReceiver] enum to the internal DTO enum.
     * Both share the wire shape "Initiator | Completer | Both" (C2 in
     * `99-open-questions.md`); the indirection keeps the public SDK surface
     * decoupled from the internal DTO catalog.
     */
    private fun callbackReceiverWire(receiver: OthentoCallbackReceiver): CallbackReceiver =
        when (receiver) {
            OthentoCallbackReceiver.Initiator -> CallbackReceiver.Initiator
            OthentoCallbackReceiver.Completer -> CallbackReceiver.Completer
            OthentoCallbackReceiver.Both -> CallbackReceiver.Both
        }
}

private fun OthentoExpectedDetails.toDto(): ExpectedDetailsDto =
    ExpectedDetailsDto(
        firstName = firstName,
        lastName = lastName,
        dateOfBirth = dateOfBirth,
        gender = gender,
        nationality = nationality,
        country = country,
        address = address,
        documentNumber = documentNumber,
        ipAddress = ipAddress,
    )
