package com.othento.core.internal.ui.screens.common

import com.othento.core.internal.content.ContentBundle
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.data.model.ReinitStep
import com.othento.core.internal.data.model.Step
import com.othento.core.internal.ui.components.KycStepCardInput

/**
 * Maps a [Step] list to the [KycStepCardInput] list the Start /
 * FailedRetry hero block consumes.
 *
 * Mirrors `apps/sdk/.../shared/step-meta.ts` (`STEP_META`) per
 * [docs/spec/06-screens/20-shared.md] §"Step metadata helper". Step rows
 * Phase 4 doesn't recognise (e.g. future address-verification — open
 * question C1) fall back to a blank detail.
 *
 * `step_face_match` rows are filtered out when a `step_liveness_check`
 * exists, matching the web's `visibleSteps` rule
 * ([docs/spec/08-state-management.md] §2.4 `visibleSteps` row).
 *
 * ### Where each string comes from
 * - **name** — `steps.name.<stepCode>` wins, and the session's `stepName` is
 *   the fallback. This order is the reverse of what it was, and the reversal is
 *   the fix: `stepName` was assumed to be localised server-side, but the
 *   session is created once, before the user ever picks a language, so the
 *   field carries whatever language the *session* was created in and never
 *   changes again. Because it is virtually always non-blank, the old
 *   `stepName.ifBlank { … }` meant the content lookup below was dead code and
 *   the step list stayed English while every other string on the screen
 *   translated — visible only on the one screen that renders step names.
 *
 *   The lookup is by raw step code rather than through five constants, so a
 *   step type this build has never heard of still gets translated copy the
 *   moment the backend seeds it; an unseeded one still falls through to
 *   `stepName`, which is why demoting it costs nothing.
 * - **detail** — always content (`steps.detail.*`). There is no per-session
 *   variant of "SMS code", so nothing competes with the bundle here.
 * - **duration** — never content. `"~20s"` is a digit and a unit; translating
 *   it would only risk breaking it.
 */
internal object StepCardsBuilder {
    fun toCards(
        steps: List<Step>,
        content: ContentBundle = ContentBundle.Empty,
    ): List<KycStepCardInput> = build(steps.map { it.stepCode to it.stepName }, content)

    /**
     * Card list for the backend's `reinitInfo.stepsToRetry` (the FailedRetry
     * "What to redo" list). Mirrors the web's `toStepCards`, which accepts the
     * trimmed reinit-step shape interchangeably with the full step list.
     */
    fun fromReinitSteps(
        steps: List<ReinitStep>,
        content: ContentBundle = ContentBundle.Empty,
    ): List<KycStepCardInput> = build(steps.map { it.stepCode to it.stepName }, content)

    private fun build(
        steps: List<Pair<String, String>>,
        content: ContentBundle,
    ): List<KycStepCardInput> =
        filterVisible(steps).map { (stepCode, stepName) ->
            KycStepCardInput(
                name = nameFor(stepCode, stepName, content),
                detail = detailFor(stepCode, content),
                duration = STEP_DURATION[stepCode],
                stepCode = stepCode,
            )
        }

    private fun filterVisible(steps: List<Pair<String, String>>): List<Pair<String, String>> {
        val hasLiveness = steps.any { it.first == STEP_LIVENESS }
        return if (hasLiveness) steps.filterNot { it.first == STEP_FACE_MATCH } else steps
    }

    private fun nameFor(
        stepCode: String,
        stepName: String,
        content: ContentBundle,
    ): String =
        content.textOrNull(ContentKeys.STEPS_NAME_PREFIX + stepCode)
            ?: stepName.ifBlank { null }
            ?: BUILT_IN_NAME[stepCode]
            // Not a translation failure — an unrecognised step type the backend
            // also declined to name. Showing the raw code is the existing
            // behaviour and is the honest thing to show.
            ?: stepCode

    private fun detailFor(
        stepCode: String,
        content: ContentBundle,
    ): String? = STEP_DETAIL_KEY[stepCode]?.let { content.textOrNull(it) } ?: BUILT_IN_DETAIL[stepCode]

    private const val STEP_ID = "step_id_verification"
    private const val STEP_FACE_MATCH = "step_face_match"
    private const val STEP_LIVENESS = "step_liveness_check"
    private const val STEP_PHONE = "step_phone_verification"
    private const val STEP_EMAIL = "step_email_verification"

    private val STEP_DETAIL_KEY: Map<String, String> =
        mapOf(
            STEP_ID to ContentKeys.STEPS_DETAIL_ID_VERIFICATION,
            STEP_FACE_MATCH to ContentKeys.STEPS_DETAIL_FACE_MATCH,
            STEP_LIVENESS to ContentKeys.STEPS_DETAIL_LIVENESS_CHECK,
            STEP_PHONE to ContentKeys.STEPS_DETAIL_PHONE_VERIFICATION,
            STEP_EMAIL to ContentKeys.STEPS_DETAIL_EMAIL_VERIFICATION,
        )

    /** Offline copy only — the values the screens rendered before content. */
    private val BUILT_IN_NAME: Map<String, String> =
        mapOf(
            STEP_ID to "Document verification",
            STEP_FACE_MATCH to "Selfie",
            STEP_LIVENESS to "Selfie",
            STEP_PHONE to "Phone verification",
            STEP_EMAIL to "Email verification",
        )

    private val BUILT_IN_DETAIL: Map<String, String> =
        mapOf(
            STEP_ID to "Personal document",
            STEP_FACE_MATCH to "Selfie",
            STEP_LIVENESS to "Selfie",
            STEP_PHONE to "SMS code",
            STEP_EMAIL to "Email code",
        )

    private val STEP_DURATION: Map<String, String> =
        mapOf(
            STEP_ID to "~20s",
            STEP_FACE_MATCH to "~10s",
            STEP_LIVENESS to "~10s",
            STEP_PHONE to "~10s",
            STEP_EMAIL to "~10s",
        )
}
