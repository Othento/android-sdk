@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.ResultMode
import com.othento.core.internal.content.ResultTone
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.screens.common.ContentStatusScreen
import com.othento.core.internal.ui.screens.common.returnToAppLabel
import com.othento.core.internal.ui.screens.common.StatusAction

/**
 * `result.approved.*` — green check, success copy, plus the explicit
 * "Return to app" CTA so dismissal is user-driven (the SDK never auto-finishes
 * the flow).
 *
 * The CTA label is **not** content: it is an Android-only string with no key in
 * the shared contract. Adding one is part of the native copy sweep the plan
 * defers to §8.2.
 */
@Composable
internal fun ApprovedScreen(onReturnToApp: () -> Unit) {
    ContentStatusScreen(
        prefix = ContentKeys.RESULT_APPROVED,
        fallbackIcon = StatusIconName.Check,
        fallbackTone = ResultTone.Success,
        fallbackMode = ResultMode.Terminal,
        primaryAction = StatusAction(label = returnToAppLabel(), onClick = onReturnToApp),
    )
}
