@file:Suppress("FunctionNaming", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion

/** Spec §12 — `StatusIconTone`. Source: `apps/sdk/.../kyc-status-icon.scss:32-62`. */
@Immutable
internal enum class StatusIconTone { Neutral, Success, Warning, Error }

/** Spec §12 — `StatusIconName`. */
@Immutable
internal enum class StatusIconName { Check, Cross, Clock, Exclamation, Arc }

/**
 * 80-dp tone-tinted disc with a 10-dp solid same-color halo and a 36-dp glyph
 * inside. Faithful port of `apps/sdk/.../kyc-status-icon/`:
 *
 * - Disc: `width/height: 80px / border-radius: 50% / background: <tone-bg>`.
 * - Halo: `box-shadow: 0 0 0 10px <tone-bg>` (solid spread, no blur, same
 *   color as the disc bg) → rendered here as an outer 100-dp circle painted
 *   with the same tone-bg.
 * - Glyph: 36 dp (per `kyc-status-icon.scss:16-19` — the `<svg width=…>`
 *   attribute is 32 px but CSS's `36px` wins on the cascade).
 * - Entry animation: `motion-status-pop` — 320 ms slow duration with the
 *   `--motion-spring` cubic-bezier `(0.34, 1.56, 0.64, 1)`; runs here as a
 *   single tween whose spring curve overshoots past 1.0 before settling.
 *   Reduced motion: instant fade-in.
 *
 * The `Arc` glyph is rendered via [KycLoader] tinted to match the tone-text
 * color so spinners on success/warning/error discs blend in.
 *
 * [iconUrl] is the content bundle's `result.*.icon` — a 96 × 96
 * white-on-transparent **template** PNG. It is tinted with the tone's
 * foreground colour, exactly like the built-in vector it replaces; rendering it
 * untinted would produce an invisible white glyph on the tinted disc
 * (plan §4.1). [icon] stays alongside as the offline fallback.
 */
@Composable
@Suppress("LongMethod")
internal fun KycStatusIcon(
    icon: StatusIconName = StatusIconName.Check,
    tone: StatusIconTone = StatusIconTone.Neutral,
    modifier: Modifier = Modifier,
    iconUrl: String? = null,
) {
    val (bg, fg) = palette(tone)
    val motion = LocalOthentoMotion.current

    val scale = remember { Animatable(EntryStartScale) }
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (motion.reducedMotion) {
            scale.snapTo(1f)
            alpha.snapTo(1f)
            return@LaunchedEffect
        }
        // Spring easing's cubic-bezier(0.34, 1.56, 0.64, 1) overshoots past the
        // target (>1.0 mid-curve) before settling at 1.0 — this reproduces the
        // web's `kyc-status-pop` 0% / 60% / 100% keyframe shape in a single
        // tween. Opacity uses ease-out for a clean fade-in.
        alpha.animateTo(1f, tween(motion.durationSlowMs, easing = motion.easeOut))
    }
    LaunchedEffect(Unit) {
        if (!motion.reducedMotion) {
            scale.animateTo(1f, tween(motion.durationSlowMs, easing = motion.spring))
        }
    }

    Box(
        modifier =
            modifier
                .scale(scale.value)
                .alpha(alpha.value),
        contentAlignment = Alignment.Center,
    ) {
        // Halo: solid 10-dp spread of the same tone-bg, painted as an outer disc.
        Box(
            modifier =
                Modifier
                    .size(HaloSize)
                    .clip(CircleShape)
                    .background(bg),
        )
        // Disc: 80 dp, same tone-bg.
        Box(
            modifier =
                Modifier
                    .size(DiscSize)
                    .clip(CircleShape)
                    .background(bg),
            contentAlignment = Alignment.Center,
        ) {
            if (icon == StatusIconName.Arc) {
                // Spec §12: 28 dp arc, 3 dp stroke. The `Md` loader is 32 / 2.5 dp;
                // `Sm` is 20 / 2 — 28 isn't an enum value, so we keep `Md` and
                // accept a 4-dp visual difference (Lg is 48 — too large).
                KycLoader(
                    size = KycLoaderSize.Md,
                    tone =
                        when (tone) {
                            StatusIconTone.Neutral -> KycLoaderTone.Primary
                            StatusIconTone.Success, StatusIconTone.Warning, StatusIconTone.Error ->
                                KycLoaderTone.Neutral
                        },
                    contentDescription = "",
                )
            } else {
                val builtIn =
                    when (icon) {
                        StatusIconName.Check -> OthentoIcons.Check
                        StatusIconName.Cross -> OthentoIcons.Cross
                        StatusIconName.Clock -> OthentoIcons.Clock
                        StatusIconName.Exclamation -> OthentoIcons.Exclamation
                        StatusIconName.Arc -> OthentoIcons.Check // unreachable
                    }
                ContentTemplateImage(
                    url = iconUrl,
                    contentDescription = null,
                    tint = fg,
                    size = GlyphSize,
                    fallback = builtIn,
                )
            }
        }
    }
}

@Composable
private fun palette(tone: StatusIconTone): Pair<Color, Color> {
    val colors = LocalOthentoColors.current
    return when (tone) {
        StatusIconTone.Neutral -> colors.bgHover to colors.textSecondary
        StatusIconTone.Success -> colors.successBg to colors.successText
        StatusIconTone.Warning -> colors.warningBg to colors.warningText
        StatusIconTone.Error -> colors.errorBg to colors.errorText
    }
}

private val DiscSize = 80.dp
private val HaloSize = 100.dp // 80 + 10×2
private val GlyphSize = 36.dp
private const val EntryStartScale = 0.6f
