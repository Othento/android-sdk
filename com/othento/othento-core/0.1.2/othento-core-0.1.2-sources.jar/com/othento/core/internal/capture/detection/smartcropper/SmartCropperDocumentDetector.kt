@file:Suppress("ReturnCount")

package com.othento.core.internal.capture.detection.smartcropper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Point
import android.graphics.PointF
import android.graphics.Rect
import androidx.camera.core.ImageProxy
import com.othento.core.internal.capture.DetectionResult
import com.othento.core.internal.capture.DocumentDetector
import com.othento.core.internal.capture.detection.BitmapFrames
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import me.pqpo.smartcropperlib.SmartCropper
import kotlin.math.abs

/**
 * SmartCropper-backed [DocumentDetector] (V30).
 *
 * SmartCropper bundles a TFLite HED edge-detection model + tuned OpenCV
 * post-processing inside its AAR. We feed it an ARGB bitmap of the cutout
 * region (so HED runs over a smaller frame, faster); it returns 4 corner
 * points relative to that bitmap, which we map back to source-image
 * coordinates.
 *
 * Threading: [detect] is single-threaded by contract (FrameAnalyzer's
 * `STRATEGY_KEEP_ONLY_LATEST` guarantees no concurrent calls).
 */
internal class SmartCropperDocumentDetector(
    private val context: Context,
) : DocumentDetector {
    @Volatile private var initialized = false

    private val _initStatus = MutableStateFlow("not initialized")

    /** Debug flow: "not initialized" → "✓" on success, or "✗ <ClassName>: <msg>" on failure. */
    val initStatus: StateFlow<String> = _initStatus.asStateFlow()

    override suspend fun initialize() {
        if (initialized) return
        val outcome =
            runCatching {
                SmartCropper.buildImageDetector(context.applicationContext)
                initialized = true
            }
        _initStatus.value =
            if (outcome.isSuccess) {
                "✓"
            } else {
                val e = outcome.exceptionOrNull()
                "✗ ${e?.javaClass?.simpleName}: ${e?.message ?: "<no msg>"}"
            }
    }

    override fun detect(
        yuvImage: ImageProxy,
        cutoutInImageCoords: Rect,
    ): DetectionResult {
        if (!initialized) return DetectionResult.NONE
        // Fallback: if the screen couldn't map a sensor-space cutout (PreviewView's
        // outputTransform never became non-null on this device), run detection over
        // the full sensor frame. The pipeline relaxes its coverage thresholds when
        // it sees a full-frame cutout — see DetectionPipeline.process().
        val effectiveCutout = clampCutout(cutoutInImageCoords, yuvImage.width, yuvImage.height)
        val bmp = YuvToBitmap.convert(yuvImage, effectiveCutout) ?: return DetectionResult.NONE
        val corners = scanAndMap(bmp, effectiveCutout, recycle = true) ?: return DetectionResult.NONE
        return finishDetect(corners, effectiveCutout)
    }

    /**
     * 2-stream variant: SmartCropper over an already-upright RGB [bitmap]
     * (sampled from the GPU preview). The bitmap is cropped to
     * [cutoutInBitmapCoords] in-process — no YUV conversion — and the returned
     * corners are in the bitmap's pixel space. The source [bitmap] is never
     * recycled here (the caller owns it); only an internal crop is.
     */
    override fun detect(
        bitmap: Bitmap,
        cutoutInBitmapCoords: Rect,
    ): DetectionResult {
        if (!initialized) return DetectionResult.NONE
        val effectiveCutout = clampCutout(cutoutInBitmapCoords, bitmap.width, bitmap.height)
        val crop = BitmapFrames.crop(bitmap, effectiveCutout)
        val corners = scanAndMap(crop, effectiveCutout, recycle = crop !== bitmap) ?: return DetectionResult.NONE
        return finishDetect(corners, effectiveCutout)
    }

    private fun clampCutout(
        cutout: Rect,
        width: Int,
        height: Int,
    ): Rect =
        if (cutout.isEmpty || cutout.width() <= 0 || cutout.height() <= 0) {
            Rect(0, 0, width, height)
        } else {
            cutout
        }

    /**
     * Coverage gate shared by both detect paths. SmartCropper's HED sometimes
     * returns the bitmap rectangle itself when no real edges are found — reject
     * quads that fill ≥98% of the cutout.
     */
    private fun finishDetect(
        corners: List<PointF>,
        cutout: Rect,
    ): DetectionResult {
        val polyArea = PolygonGeometry.area(corners)
        val refArea = (cutout.width().toFloat() * cutout.height()).coerceAtLeast(1f)
        val coverage = polyArea / refArea
        return if (coverage > FULL_FRAME_REJECT) {
            DetectionResult.NONE
        } else {
            DetectionResult(detected = true, corners = corners, coverageRatio = coverage)
        }
    }

    /**
     * Runs SmartCropper over [scanBmp] (already cropped to [cutout]) and maps the
     * returned corners back to source-image coordinates. Returns `null` on any
     * failure, degenerate quad, or unexpected corner count. [recycle] frees
     * [scanBmp] when it is a throwaway (a YUV conversion or an internal crop),
     * never when it is a caller-owned source bitmap.
     */
    private fun scanAndMap(
        scanBmp: Bitmap,
        cutout: Rect,
        recycle: Boolean,
    ): List<PointF>? {
        val bmpW = scanBmp.width
        val bmpH = scanBmp.height

        val rawCorners =
            runCatching { SmartCropper.scan(scanBmp) }
                .onFailure { e ->
                    _initStatus.value = "scan failed: ${e.javaClass.simpleName}: ${e.message ?: "<no msg>"}"
                }.getOrNull()
        if (recycle) scanBmp.recycle()

        // SmartCropper.scan returns Point[4] with **null elements** when it
        // can't find a confident quad (undocumented v2.1.4 behavior). Filter
        // nulls before reading .x/.y, treat <4 valid corners as no detection.
        if (rawCorners == null) return null
        @Suppress("UNCHECKED_CAST")
        val nonNull: List<Point> = (rawCorners as Array<Point?>).filterNotNull()
        if (nonNull.size != EXPECTED_CORNER_COUNT) return null

        val scaleX = cutout.width().toFloat() / bmpW.coerceAtLeast(1)
        val scaleY = cutout.height().toFloat() / bmpH.coerceAtLeast(1)

        return nonNull
            .map { p ->
                PointF(
                    cutout.left + p.x * scaleX,
                    cutout.top + p.y * scaleY,
                )
            }.takeIf { !PolygonGeometry.isDegenerate(it) }
    }

    override fun release() {
        // SmartCropper has no explicit release API; native cleanup is GC-driven.
        initialized = false
    }

    private companion object {
        /** Expected number of corner points returned by SmartCropper.scan. */
        const val EXPECTED_CORNER_COUNT: Int = 4

        /** Reject quads that cover ≥98% of the cutout — SmartCropper's "no real edges" fallback. */
        const val FULL_FRAME_REJECT: Float = 0.98f
    }
}

/**
 * Pure-math polygon helpers used by [SmartCropperDocumentDetector]. Extracted
 * here so they're unit-testable without a SmartCropper or CameraX runtime.
 */
internal object PolygonGeometry {
    /** Minimum area below which a quad is treated as noise, in pixels squared. */
    const val MIN_AREA_PX: Float = 100f

    /** Expected number of vertices in a document quad. */
    private const val QUAD_VERTEX_COUNT: Int = 4

    /** Minimum polygon vertex count for area calculation (triangles and up). */
    private const val MIN_POLYGON_VERTEX_COUNT: Int = 3

    /** Shoelace-formula area of a closed polygon, in source pixels squared. */
    fun area(corners: List<PointF>): Float {
        if (corners.size < MIN_POLYGON_VERTEX_COUNT) return 0f
        var sum = 0f
        for (i in corners.indices) {
            val j = (i + 1) % corners.size
            sum += corners[i].x * corners[j].y
            sum -= corners[j].x * corners[i].y
        }
        return abs(sum) / 2f
    }

    /** A quad is degenerate if it has fewer than 4 points or near-zero area. */
    fun isDegenerate(corners: List<PointF>): Boolean {
        if (corners.size != QUAD_VERTEX_COUNT) return true
        return area(corners) < MIN_AREA_PX
    }
}
