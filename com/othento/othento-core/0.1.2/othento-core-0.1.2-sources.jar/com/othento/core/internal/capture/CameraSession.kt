package com.othento.core.internal.capture

import android.content.Context
import android.util.Log
import android.util.Size
import androidx.annotation.MainThread
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Thin wrapper around the CameraX use-case binding so the camera-capture
 * Compose screen stays declarative.
 *
 * Bound use cases:
 * - [Preview] — drives the [PreviewView] surface.
 * - [ImageAnalysis] — optional, hosts the V30 detection [FrameAnalyzer].
 * - Extra use case — optional, e.g. `VideoCapture` for the rolling buffer.
 *
 * `ImageAnalysis` is bound on capture screens that pass an analyzer; null
 * means the analyzer slot is skipped.
 *
 * Per spec §11 §6 / §12-permissions OQ #5 the back camera uses the
 * logical sensor ([CameraSelector.DEFAULT_BACK_CAMERA]); torch is wired
 * through `cameraInfo.hasFlashUnit()` + `cameraControl.enableTorch()`.
 *
 * Phase 7: [bind] takes a [CameraSelectorKind] — the selfie screen passes
 * [CameraSelectorKind.Front] to bind the user-facing sensor.
 */
internal class CameraSession(
    private val context: Context,
) {
    private var camera: Camera? = null
    private var cachedProvider: ProcessCameraProvider? = null
    private val analyzerExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    /**
     * Bind preview (+ optional analysis + optional extra use case) to the
     * host's lifecycle. [selector] picks back vs front camera; defaults to
     * back so existing call sites keep their behaviour. Pass an [extraUseCase]
     * to bind an additional CameraX use case (e.g. `VideoCapture` from the
     * rolling-buffer selfie flow).
     *
     * [analysisTargetResolution] overrides the resolution requested for the
     * ImageAnalysis stream only (preview/video keep the default 1080p target).
     * The selfie flow passes a lower 16:9 size so its 3-stream front-camera
     * combination has room to grant VideoCapture FHD; document screens leave it
     * null to keep the 1080p analysis frames their MRZ/SmartCropper gates need.
     *
     * [previewTargetResolution] does the same for the Preview stream. Left null
     * by all current callers — and it should stay that way: on CameraX 1.4 the
     * Preview and VideoCapture are stream-shared onto a single surface, so
     * pinning the preview low pins the recorded video to the same resolution. A
     * 720p preview override was observed producing a 720p recording on a back
     * camera whose Recorder advertised UHD/FHD support (boundPreview ==
     * boundVideo == 720x1280). Keep the preview at its 1080p default so the
     * shared stream — and therefore the recording — binds at FHD.
     */
    @MainThread
    suspend fun bind(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView?,
        analyzer: ImageAnalysis.Analyzer? = null,
        selector: CameraSelectorKind = CameraSelectorKind.Back,
        extraUseCase: androidx.camera.core.UseCase? = null,
        analysisTargetResolution: Size? = null,
        previewTargetResolution: Size? = null,
    ): BindResult =
        withContext(Dispatchers.Main.immediate) {
            // bindToLifecycle / unbindAll *must* run on the main thread.
            // The `@MainThread` annotation alone isn't a guarantee for a
            // suspend function — coerce explicitly.
            val provider = awaitCameraProvider()
            provider.unbindAll()

            val resolutionSelector =
                ResolutionSelector
                    .Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(TARGET_PREVIEW_WIDTH, TARGET_PREVIEW_HEIGHT),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER,
                        ),
                    )
                    // On constrained 3-stream combinations (Preview + ImageAnalysis +
                    // VideoCapture) CameraX defaults to PREFER_CAPTURE_RATE, which lets
                    // it drop the preview/analysis streams to a low resolution to keep
                    // the frame rate up — the soft 480p preview seen on mid-range
                    // devices (e.g. Samsung M-series). A document/selfie capture doesn't
                    // need 30fps; it needs pixels. Bias toward resolution instead.
                    .setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
                    .build()

            // A dedicated, lower-resolution selector for the analysis stream when
            // the caller asks for one — otherwise it shares the 1080p selector.
            // Keeping the analysis frames small frees surface-combination budget
            // so a sibling VideoCapture can hold FHD on constrained front cameras.
            val analysisResolutionSelector =
                if (analysisTargetResolution != null) {
                    ResolutionSelector
                        .Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                        .setResolutionStrategy(
                            ResolutionStrategy(
                                analysisTargetResolution,
                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER,
                            ),
                        ).build()
                } else {
                    resolutionSelector
                }

            // A dedicated, lower-resolution selector for the preview stream when
            // the caller asks for one. The preview's pixels only feed the
            // on-screen surface, never the upload, so dropping it below 1080p
            // frees surface-combination budget for a sibling VideoCapture to
            // hold FHD even while the analysis stream stays at 1080p.
            val previewResolutionSelector =
                if (previewTargetResolution != null) {
                    ResolutionSelector
                        .Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                        .setResolutionStrategy(
                            ResolutionStrategy(
                                previewTargetResolution,
                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER,
                            ),
                        ).build()
                } else {
                    resolutionSelector
                }

            // Preview is optional. The 2-stream capture path renders its own
            // preview from the ImageAnalysis frames (so VideoCapture can hold its
            // own FHD stream instead of being shared down to 720p with a Preview);
            // those call sites pass previewView = null and no Preview use case is
            // created.
            val previewUseCase =
                previewView?.let { pv ->
                    Preview
                        .Builder()
                        .setResolutionSelector(previewResolutionSelector)
                        .build()
                        .also { it.setSurfaceProvider(pv.surfaceProvider) }
                }

            val analysis =
                analyzer?.let {
                    ImageAnalysis
                        .Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setResolutionSelector(analysisResolutionSelector)
                        .build()
                        .also { ia -> ia.setAnalyzer(analyzerExecutor, it) }
                }

            // bindToLifecycle is a CameraX vararg API; listOfNotNull lets
            // us conditionally include the optional ImageAnalysis + extra
            // use cases, and the spread is the only way to pass a
            // runtime-determined set without code duplication.
            @Suppress("SpreadOperator")
            runCatching {
                val cameraSelector =
                    when (selector) {
                        CameraSelectorKind.Back -> CameraSelector.DEFAULT_BACK_CAMERA
                        CameraSelectorKind.Front -> CameraSelector.DEFAULT_FRONT_CAMERA
                    }
                val useCases =
                    listOfNotNull(previewUseCase, analysis, extraUseCase).toTypedArray()
                val boundCamera =
                    provider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        *useCases,
                    )
                camera = boundCamera
                // TEMP (remove after FHD verification): the actual bound video
                // resolution. `[vfhd]` marks a fresh build in logcat.
                Log.i(
                    "CameraSession",
                    "[vfhd] $selector boundVideo=${extraUseCase?.attachedSurfaceResolution} " +
                        "boundAnalysis=${analysis?.resolutionInfo?.resolution}",
                )
                BindResult.Bound(
                    hasFlashUnit = boundCamera.cameraInfo.hasFlashUnit(),
                    previewSize = previewUseCase?.resolutionInfo?.resolution,
                    analysisSize = analysis?.resolutionInfo?.resolution,
                    // CW degrees to rotate the raw camera buffer to upright. The
                    // 2-stream capture path renders its preview from the analysis
                    // frames, which arrive in sensor orientation; the analyzer
                    // rotates by this to display + detect upright.
                    sensorRotationDegrees = boundCamera.cameraInfo.sensorRotationDegrees,
                )
            }.getOrElse { err ->
                unbind()
                BindResult.Failed(cause = err)
            }
        }

    fun setTorch(on: Boolean) {
        val cam = camera ?: return
        if (!cam.cameraInfo.hasFlashUnit()) return
        cam.cameraControl.enableTorch(on)
    }

    /** Tear down all use cases. Safe to call multiple times. */
    @MainThread
    fun unbind() {
        camera = null
        cachedProvider?.runCatching { unbindAll() }
    }

    fun shutdown() {
        unbind()
        analyzerExecutor.shutdownNow()
    }

    private suspend fun awaitCameraProvider(): ProcessCameraProvider {
        cachedProvider?.let { return it }
        val future: ListenableFuture<ProcessCameraProvider> =
            ProcessCameraProvider.getInstance(context)
        return suspendCancellableCoroutine { cont ->
            future.addListener(
                {
                    runCatching { future.get() }
                        .onSuccess { provider ->
                            cachedProvider = provider
                            if (cont.isActive) cont.resume(provider)
                        }.onFailure { if (cont.isActive) cont.resumeWithException(it) }
                },
                ContextCompat.getMainExecutor(context),
            )
        }
    }

    sealed class BindResult {
        data class Bound(
            val hasFlashUnit: Boolean,
            val previewSize: Size? = null,
            val analysisSize: Size? = null,
            val sensorRotationDegrees: Int = 0,
        ) : BindResult()

        data class Failed(
            val cause: Throwable,
        ) : BindResult()
    }

    private companion object {
        // Spec §12-permissions §3.1 ideal preview resolution. Native
        // always runs the mobile branch (1920×1080 portrait-friendly).
        const val TARGET_PREVIEW_WIDTH = 1_920
        const val TARGET_PREVIEW_HEIGHT = 1_080
    }
}
