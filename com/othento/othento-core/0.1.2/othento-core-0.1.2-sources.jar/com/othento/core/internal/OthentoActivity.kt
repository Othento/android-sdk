package com.othento.core.internal

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.ViewModelProvider
import com.othento.core.api.OthentoCancelReason
import com.othento.core.internal.content.BrandingResolver
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.content.layoutDirection
import com.othento.core.internal.flow.OthentoFlowViewModel
import com.othento.core.internal.ui.screens.OthentoFlowHost
import com.othento.core.internal.ui.theme.OthentoTheme

/**
 * Compose-driven host Activity. Reads the [SdkBus] token from its Intent,
 * constructs an [OthentoFlowViewModel], and renders [OthentoFlowHost].
 *
 * Two cancel paths route here:
 * 1. **Hardware back / gesture** — the back-press callback signals the
 *    ViewModel which fires `onCancelled(BackButton)` on the host listener.
 * 2. **Host destroy** — `OthentoSDK.destroy()` is forwarded through
 *    [SdkBus.signalCancel]; the registered canceller below fires
 *    `onCancelled(HostDestroy)` and finishes the Activity.
 */
internal class OthentoActivity : ComponentActivity() {
    private var token: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val incomingToken = intent.getStringExtra(SdkBus.EXTRA_TOKEN)
        val busSession = incomingToken?.let { SdkBus.get(it) }
        if (incomingToken == null || busSession == null) {
            // Either the Intent was hand-constructed (no token) or the host
            // process was restored from death and the bus map was wiped.
            // There's no recovery — finish quietly so the host's launcher
            // Activity stays in a sane state.
            finish()
            return
        }
        token = incomingToken

        val viewModel =
            ViewModelProvider(
                this,
                OthentoFlowViewModel.Factory(
                    config = busSession.config,
                    listener = busSession.listener,
                    fixture = busSession.fixture,
                    contentResolver = applicationContext.contentResolver,
                    appContext = applicationContext,
                ),
            )[OthentoFlowViewModel::class.java]

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    viewModel.onUserCancel(OthentoCancelReason.BackButton)
                    finish()
                }
            },
        )

        SdkBus.registerCanceller(incomingToken) { reason ->
            viewModel.onUserCancel(reason)
            finish()
        }

        setContent {
            // Tenant theme and copy both come from the same backend bundle, so
            // they are resolved together here — above OthentoFlowHost, because
            // the scaffold chrome (brand name, logo, page background) needs
            // them too. Backend tenant theme wins over any host-app branding
            // (content decision 23).
            val contentState by viewModel.contentState.collectAsState()
            val branding =
                remember(contentState.bundle) { BrandingResolver.resolve(contentState.bundle) }
            val direction = remember(contentState.bundle) { contentState.bundle.layoutDirection() }

            // The View tree has to be told separately: Compose's
            // LocalLayoutDirection does not reach Views hosted through
            // AndroidView, and the Amplify liveness component brings its own.
            // This runs on every direction change rather than once in onCreate,
            // because the direction arrives with the content — after the first
            // frame, and again on a language switch.
            //
            // Deliberately NOT read from the device locale: the session's
            // resolved language decides, so an Arabic phone on an English-only
            // tenant still renders LTR.
            SideEffect {
                window.decorView.layoutDirection =
                    if (direction == LayoutDirection.Rtl) {
                        View.LAYOUT_DIRECTION_RTL
                    } else {
                        View.LAYOUT_DIRECTION_LTR
                    }
            }

            OthentoTheme(
                colors = branding.colors,
                shapes = branding.shapes,
                layoutDirection = direction,
            ) {
                CompositionLocalProvider(LocalContent provides contentState.bundle) {
                    OthentoFlowHost(
                        viewModel = viewModel,
                        branding = branding,
                        contentGateOpen = contentState.gateOpen,
                        languageSwitching = contentState.switching,
                        onReturnToApp = { finish() },
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Burn the bus entry only on real teardown — `isFinishing` distinguishes
        // user dismissal / terminal exit from a configuration-change recreation.
        if (isFinishing) {
            token?.let { SdkBus.remove(it) }
        }
    }
}
