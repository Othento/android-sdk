package com.othento.core.internal.data.model

/**
 * Type of evidence the active step's challenge expects from the client.
 *
 * Mirrors [docs/spec/09-data-models.md §1.6]. `Selfie` and `LivenessVideo`
 * are alternatives — whichever the backend marks `AwaitingUpload` is the
 * one the selfie/liveness uploader uses (Phase 7+).
 */
internal enum class ChallengeType {
    DocumentFront,
    DocumentBack,
    Selfie,
    LivenessVideo,

    /**
     * AWS Rekognition Face Liveness. Session-based: there is no upload, so the
     * backend parks this challenge in [ChallengeStatus.Queued] while it waits
     * for the user to perform the check.
     */
    RekognitionLivenessSession,
    EmailOtp,
    PhoneOtp,

    /**
     * Sentinel for a challenge type this SDK build does not know about. Set by
     * [com.othento.core.internal.network.TolerantEnumJsonAdapter] so a backend
     * that ships a new evidence type before the SDK does routes the user to
     * the "Update required" screen rather than being mis-routed.
     *
     * The previous fallback was [DocumentFront], chosen when only document
     * challenges existed. It sent users into ID capture for challenges that
     * had nothing to do with documents.
     */
    Unknown,
}
