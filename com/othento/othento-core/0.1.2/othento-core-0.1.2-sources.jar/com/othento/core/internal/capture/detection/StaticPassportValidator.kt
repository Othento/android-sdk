package com.othento.core.internal.capture.detection

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.othento.core.internal.capture.detection.face.FaceDetectorClient
import com.othento.core.internal.capture.detection.passport.MrzMatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

internal class StaticPassportValidator(
    private val recognizer: TextRecognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
    private val faceClient: FaceDetectorClient =
        FaceDetectorClient(minFaceSize = MIN_FACE_SIZE),
) {
    suspend fun validate(bitmap: Bitmap): ValidationResult =
        coroutineScope {
            val input = InputImage.fromBitmap(bitmap, 0)
            val mrzDeferred = async { checkMrz(input) }
            val faceDeferred = async { checkFace(input) }

            val mrzFound = mrzDeferred.await()
            val faceFound = faceDeferred.await()

            if (mrzFound || faceFound) {
                ValidationResult.Clean
            } else {
                val warning =
                    ValidationWarning(
                        ValidationIssue.NoCard,
                        ValidationMessages.forIssue(ValidationIssue.NoCard),
                    )
                ValidationResult(
                    valid = false,
                    issues = listOf(ValidationIssue.NoCard),
                    warnings = listOf(warning),
                )
            }
        }

    @Suppress("TooGenericExceptionCaught")
    private suspend fun checkMrz(input: InputImage): Boolean =
        suspendCancellableCoroutine { cont ->
            recognizer
                .process(input)
                .addOnSuccessListener { text ->
                    val perLine = text.textBlocks.flatMap { it.lines }.map { it.text }
                    val perBlock =
                        text.textBlocks.map { b ->
                            b.lines.joinToString(" ") { it.text }
                        }
                    val candidates = (perLine + perBlock).distinct()
                    val lineBounds =
                        text.textBlocks
                            .flatMap { it.lines }
                            .mapNotNull { it.boundingBox }
                    val matched =
                        MrzMatcher.matches(candidates) || MrzMatcher.matchesLayout(lineBounds)
                    if (cont.isActive) cont.resume(matched)
                }.addOnFailureListener {
                    if (cont.isActive) cont.resume(false)
                }
        }

    @Suppress("TooGenericExceptionCaught")
    private suspend fun checkFace(input: InputImage): Boolean =
        try {
            faceClient.detectOnce(input).isNotEmpty()
        } catch (_: Exception) {
            false
        }

    fun release() {
        runCatching { recognizer.close() }
        faceClient.release()
    }

    private companion object {
        const val MIN_FACE_SIZE: Float = 0.15f
    }
}
