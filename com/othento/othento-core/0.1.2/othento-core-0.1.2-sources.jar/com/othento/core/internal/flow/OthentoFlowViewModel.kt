package com.othento.core.internal.flow

import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.othento.core.api.OthentoCancelReason
import com.othento.core.api.OthentoConfig
import com.othento.core.api.OthentoFixtureScenario
import com.othento.core.api.OthentoSDKListener
import com.othento.core.internal.capture.detection.DocKind
import com.othento.core.internal.capture.detection.SmartCropperStaticDetector
import com.othento.core.internal.capture.detection.StaticDocumentValidator
import com.othento.core.internal.capture.detection.docKind
import com.othento.core.internal.content.ContentRepository
import com.othento.core.internal.content.ContentState
import com.othento.core.internal.data.RekognitionLivenessRepository
import com.othento.core.internal.data.SessionRepositoryFactory
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.fixtures.FixtureSessionSource
import com.othento.core.internal.ui.screens.Side
import com.othento.core.internal.util.ImageInfo
import com.othento.core.internal.util.UriBitmapDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Component-scoped ViewModel that wires a [FlowCoordinator] into the
 * Activity's lifecycle ([docs/spec/08-state-management.md] §1.2).
 *
 * Survives configuration changes — the coordinator's resolve / upload /
 * polling work runs on `viewModelScope` so cancellation flows through on
 * Activity finish but **not** on rotation.
 *
 * Phase 5 changes:
 * - The factory accepts a [ContentResolver] so the upload pipeline can
 *   stream from a `Uri`.
 * - When [Factory.fixture] is `null`, the factory builds a
 *   [RepositorySessionSource] (real network) instead of a fixture-driven
 *   one. The fixture path remains as a regression hook (R1).
 * - The ViewModel owns Job tracking for upload + polling so the user's
 *   "back press" + "poll retry" cancel cleanly without races.
 */
@Suppress(
    "TooManyFunctions",
    // Reason: each public action method (begin, retry, country, doc, confirm,
    // change, retake, poll-retry, file, cancel) is a single line that
    // delegates to the coordinator. Splitting them up to satisfy the threshold
    // would obscure the 1:1 mapping the Compose host depends on.
    "LongParameterList",
    // Reason: the extra two parameters are the content repository and the
    // host's requested language. Both are nullable so the existing coordinator
    // unit tests construct this without a network stack; folding them into a
    // holder would make that opt-out less obvious, not more.
)
internal class OthentoFlowViewModel(
    private val coordinator: FlowCoordinator,
    private val contentResolver: ContentResolver,
    private val staticDocumentValidator: StaticDocumentValidator,
    // OthentoConfig.closeOnComplete — when true the host wants the SDK to
    // auto-dismiss on any terminal screen rather than leaving it up. Read by
    // OthentoFlowHost; the listener's terminal event still fires first.
    val closeOnComplete: Boolean = false,
    // Phase 10 — handed straight to the Rekognition screen, which owns its own
    // state machine and drives start/complete/credentials itself. Nullable so
    // fixture-mode construction and unit tests can omit it.
    val rekognitionRepository: RekognitionLivenessRepository? = null,
    // SDK content (copy + tenant theme). Nullable so the existing
    // FlowCoordinator unit tests can construct the ViewModel without a
    // network stack; when absent every screen renders the emergency fallback.
    private val contentRepository: ContentRepository? = null,
    // OthentoConfig.language — the host's requested locale. Only a fallback:
    // the session's own language wins when the backend reports one (plan §4.5).
    private val configLanguage: String? = null,
) : ViewModel() {
    val state: StateFlow<FlowUiState> = coordinator.state

    /** Copy bundle + the `gateOpen` / `errored` / `switching` flags. */
    val contentState: StateFlow<ContentState> =
        contentRepository?.state ?: MutableStateFlow(ContentState(gateOpen = true))

    private var inflightJob: Job? = null
    private var validationJob: Job? = null

    init {
        // Tracking the resolve job lets `onUserCancel` actively cancel an
        // in-flight `createSession` round-trip rather than waiting for
        // viewModelScope to wind down on Activity finish — the latter
        // could let `applyResolved` / `applyFailure` fire listener events
        // *after* `onCancelled`, breaking the spec §16 ordering invariant.
        inflightJob = viewModelScope.launch { coordinator.resolve() }
        startContentLoad()
    }

    /**
     * Content bootstrap.
     *
     * Not tracked by [inflightJob]: `startInflight` cancels whatever it finds
     * there, and a user tapping "Begin" mid-fetch must not kill the copy load.
     *
     * The load waits for the resolved session because `/SdkContent` is
     * authenticated by `X-SAT`, which does not exist until the session lands
     * (create mode) or is seeded (token mode, but there the language is only
     * knowable from the session anyway).
     *
     * There is no longer a companion gate timer. If the session never resolves
     * this coroutine parks on [first] forever and the gate stays shut — which
     * is correct, because that same failure drives the flow to
     * [com.othento.core.internal.flow.ScreenState.Error], and the host exempts
     * the error screen from the gate. The user sees the error, not a spinner.
     */
    private fun startContentLoad() {
        val repository = contentRepository ?: return
        viewModelScope.launch {
            val session =
                coordinator.state
                    .map { it.session }
                    .filterNotNull()
                    .first()
            repository.load(session.language ?: configLanguage)
        }
    }

    /**
     * Language picked from the welcome-screen dropdown. Re-entrant taps are
     * dropped inside the repository (plan §4.4), so this is safe to call on
     * every click.
     */
    fun onUserSelectLanguage(code: String) {
        val repository = contentRepository ?: return
        viewModelScope.launch { repository.setLocale(code) }
    }

    /**
     * Cancels the running flow with the supplied [reason]. Triggered by the
     * hardware back press (`BackButton`), by `OthentoSDK.destroy()`
     * (`HostDestroy`), or by an in-flow SDK-side cancel CTA (`SdkInternal`).
     *
     * Order matters: cancel any in-flight resolve / upload / poll first,
     * then fire the coordinator's cancel which emits `onCancelled`. Without
     * the cancel-then-emit order, a network resolve completing in the same
     * millisecond as the back-press could fire `onSessionCreated` AFTER
     * `onCancelled`.
     */
    fun onUserCancel(reason: OthentoCancelReason) {
        validationJob?.cancel()
        inflightJob?.cancel()
        coordinator.cancel(reason)
    }

    fun onUserBeginVerification() {
        startInflight { coordinator.beginVerification() }
    }

    fun onUserRetryFailed() {
        startInflight { coordinator.retryFailed() }
    }

    fun onUserCountrySelected(countryName: String) = coordinator.onUserCountrySelected(countryName)

    fun onUserDocumentSelected(documentId: String) = coordinator.onUserDocumentSelected(documentId)

    fun onUserConfirmDocument() = coordinator.onUserConfirmDocument()

    fun onUserChangeDocument() = coordinator.onUserChangeDocument()

    fun onUserRetake() = coordinator.onUserRetake()

    fun onUserSwitchToFallback() = coordinator.onUserSwitchToFallback()

    fun onUserStayOnCamera() = coordinator.onUserStayOnCamera()

    fun onUserPollRetry() {
        startInflight { coordinator.pollRetry() }
    }

    // ---- Phase 9 OTP --------------------------------------------------

    fun onUserSendOtp(contact: String) {
        startInflight { coordinator.sendOtp(contact) }
    }

    fun onUserVerifyOtp(code: String) {
        startInflight { coordinator.verifyOtp(code) }
    }

    fun onUserEditOtpDestination() = coordinator.onUserEditOtpDestination()

    fun onUserCancelOtpEdit() = coordinator.onUserCancelOtpEdit()

    fun onUserDismissOtpDialog() = coordinator.onUserDismissOtpDialog()

    fun onUserOtpDialogPrimary() {
        startInflight { coordinator.onUserOtpDialogPrimary() }
    }

    fun onUserAcknowledgeOtpSkipNotice() {
        startInflight { coordinator.onUserAcknowledgeOtpSkipNotice() }
    }

    fun onUserTickOtpCooldown() = coordinator.tickOtpCooldown()

    // ---- Rekognition liveness (Phase 10) --------------------------------

    /** `/complete` returned a session — route it exactly like a finished upload. */
    fun onRekognitionCompleted(session: Session) {
        startInflight { coordinator.onRekognitionCompleted(session) }
    }

    /** The challenge failed past the attempt cap, or failed fatally. */
    fun onRekognitionFailed() = coordinator.onRekognitionFailed()

    /**
     * The Compose `CaptureFallbackScreen` calls this when the user selects a
     * media item. The ViewModel resolves the [Uri] into [ImageInfo.Resolved]
     * (size, MIME, file name) here so the coordinator stays
     * Android-Context-free and easier to test.
     *
     * Rather than uploading immediately, this sets the pending-capture slot
     * and kicks off background validation. The user then confirms or retakes
     * on the preview screen before the upload is actually initiated.
     */
    @Suppress(
        "ReturnCount",
        // Reason: three returns are the three distinct guard conditions
        // (unresolvable URI, oversized file, wrong screen state) before the
        // happy-path. Collapsing them into a single nested-if tree would hurt
        // readability. The labeled return@launch inside the coroutine is a
        // fourth exit that detekt also counts; extracting the lambda body to a
        // named function would obscure the single-file flow.
    )
    fun onUserFileCaptured(
        uri: Uri,
        isManualCapture: Boolean = false,
    ) {
        val info = ImageInfo.resolve(uri, contentResolver)
        if (info == null) {
            coordinator.onFileUnreadable()
            return
        }
        if (info.sizeBytes > ImageInfo.MAX_UPLOAD_SIZE_BYTES) {
            coordinator.onOversizedFile()
            return
        }
        if (coordinator.state.value.screenState == ScreenState.SelfieCapture ||
            info.mimeType == VIDEO_MP4_MIME
        ) {
            startInflight { coordinator.uploadAndAdvance(uri, info, isManualCapture) }
            return
        }

        val side = currentSide() ?: return
        val docKind =
            coordinator.state.value.pendingDocument
                ?.docKind() ?: DocKind.Id

        coordinator.setPendingCapture(uri, info, side, docKind, isManualCapture)

        validationJob?.cancel()
        validationJob =
            viewModelScope.launch(Dispatchers.Default) {
                val bitmap = UriBitmapDecoder.decode(uri, contentResolver)
                if (bitmap == null) {
                    // Decode failed after metadata succeeded — treat as unreadable.
                    withContext(Dispatchers.Main) {
                        coordinator.clearPendingCapture()
                        coordinator.onFileUnreadable()
                    }
                    return@launch
                }
                val result =
                    try {
                        staticDocumentValidator.validate(bitmap, docKind)
                    } finally {
                        bitmap.recycle()
                    }
                withContext(Dispatchers.Main) {
                    coordinator.updatePendingCaptureWarnings(result.warnings)
                }
            }
    }

    fun onUserConfirmCapture() {
        val pc = coordinator.state.value.pendingCapture ?: return
        validationJob?.cancel()
        coordinator.clearPendingCapture()
        startInflight { coordinator.uploadAndAdvance(pc.uri, pc.imageInfo, pc.isManualCapture) }
    }

    fun onUserRetakeCapture() {
        validationJob?.cancel()
        coordinator.clearPendingCapture()
    }

    /**
     * Launches a long-running coordinator action under [viewModelScope] and
     * cancels any prior in-flight job — guards against e.g. a user
     * double-tapping Begin during a slow document fetch, or tapping Try
     * Again on Processing while polling is still running.
     */
    private fun startInflight(block: suspend () -> Unit) {
        inflightJob?.cancel()
        inflightJob = viewModelScope.launch { block() }
    }

    private fun currentSide(): Side? =
        when (coordinator.state.value.screenState) {
            ScreenState.CaptureFront -> Side.Front
            ScreenState.CaptureBack -> Side.Back
            else -> null
        }

    companion object {
        private const val VIDEO_MP4_MIME = "video/mp4"
    }

    class Factory(
        private val config: OthentoConfig,
        private val listener: OthentoSDKListener,
        private val fixture: OthentoFixtureScenario?,
        private val contentResolver: ContentResolver,
        private val appContext: android.content.Context? = null,
    ) : androidx.lifecycle.ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            require(modelClass.isAssignableFrom(OthentoFlowViewModel::class.java)) {
                "Unknown ViewModel: ${modelClass.name}"
            }
            val stack = SessionRepositoryFactory.create(config, contentResolver, appContext)
            val sessionSource =
                if (fixture != null) {
                    FixtureSessionSource(fixture)
                } else {
                    RepositorySessionSource(stack.sessionRepository)
                }
            val coordinator =
                FlowCoordinator(
                    config = config,
                    listener = listener,
                    sessionSource = sessionSource,
                    // Main.immediate keeps listener-callback ordering deterministic
                    // (matches Phase-1's MockFlowController choice and avoids the
                    // cancel-vs-terminal race the Phase-1 code-review caught).
                    stepDispatcher = Dispatchers.Main.immediate,
                    documentRepository = stack.documentRepository,
                    uploadRepository = stack.uploadRepository,
                    pollingDriver = PollingDriver(stack.sessionRepository),
                    otpRepository = stack.otpRepository,
                    sessionRepository = stack.sessionRepository,
                )
            val staticValidator =
                StaticDocumentValidator(
                    detector = SmartCropperStaticDetector(),
                )
            return OthentoFlowViewModel(
                coordinator,
                contentResolver,
                staticValidator,
                closeOnComplete = config.closeOnComplete,
                rekognitionRepository = stack.rekognitionRepository,
                contentRepository = stack.contentRepository,
                configLanguage = config.language,
            ) as T
        }
    }
}
