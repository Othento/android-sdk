package com.othento.core.internal.content

import android.util.Log
import androidx.compose.runtime.Immutable
import com.othento.core.internal.network.OthentoApi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Indirection over the HTTP call so the store is unit-testable without Retrofit. */
internal fun interface ContentSource {
    suspend fun fetch(locale: String?): Map<String, Any?>
}

/** Production [ContentSource] — one Retrofit call, no mapping. */
internal class ApiContentSource(
    private val api: OthentoApi,
) : ContentSource {
    override suspend fun fetch(locale: String?): Map<String, Any?> = api.getSdkContent(locale)
}

/**
 * Observable content state.
 *
 * [gateOpen] and [errored] are **deliberately separate flags** (plan §4.3).
 * Web collapsed them and shipped a bug where a slow network ended the session
 * on the error screen against a working backend, because "no bundle yet" was
 * read as "failed".
 *
 * - [gateOpen] — the UI may paint. Set **only** by the request settling,
 *   either with a bundle or with a failure.
 * - [errored]  — the request genuinely failed, or returned an empty body.
 *
 * ### The gate has no timer
 * It used to open after 2 s so first paint was never delayed. That guaranteed
 * a visible flash: the chrome painted with the compiled-in brand name and
 * "SECURED BY", then swapped to the tenant's the moment content landed. The
 * SDK now waits for the bundle, so the first frame a user sees is already the
 * tenant's.
 *
 * The wait is bounded without a timer of its own: the HTTP client's 20 s
 * timeout settles the request either way, and a session that never resolves
 * routes to the error screen, which is exempt from the gate.
 */
@Immutable
internal data class ContentState(
    val bundle: ContentBundle = ContentBundle.Empty,
    val gateOpen: Boolean = false,
    val errored: Boolean = false,
    /** A language switch is in flight — the picker shows a spinner and is disabled. */
    val switching: Boolean = false,
)

/**
 * Fetches, holds and re-fetches the SDK content bundle.
 *
 * ### Ordering (plan §3.3, adapted for Android auth)
 * The plan calls for create-mode to fetch content **in parallel** with session
 * creation. That holds on web, where the content endpoint is reachable before
 * the SDK has a session token. On Android it is not: `/api/v1/SdkContent`
 * lives on the SDK host, so `TokenInterceptor` is the only thing that can
 * authenticate it, and the `TokenStore` is empty until the create response
 * lands. Both modes therefore learn the language from the resolved session and
 * fetch afterwards, which is the same two-hop shape the plan prescribes for
 * token mode. The 2 s gate and the emergency fallback cover the slow case.
 *
 * ### Idempotence
 * [load] runs at most once per launch regardless of how many callers race it,
 * so whichever bootstrap path fires first wins and the other is a no-op.
 */
internal class ContentRepository(
    private val source: ContentSource,
) {
    private val internalState = MutableStateFlow(ContentState())
    val state: StateFlow<ContentState> = internalState.asStateFlow()

    private var loadStarted = false
    private var switchInFlight = false

    /**
     * First load. [locale] is the language the session resolved to, or `null`
     * to let the backend pick. Subsequent calls are no-ops.
     */
    suspend fun load(locale: String?) {
        if (loadStarted) return
        loadStarted = true
        fetch(locale, isSwitch = false)
    }

    /**
     * Switches language mid-session. The GET *is* the persistence — this call
     * records the choice server-side (decisions 31/34), so there is no separate
     * update endpoint.
     *
     * Two guards, both from plan §4.4:
     * - **Never re-arms the gate.** Re-gating on a switch blanks a screen the
     *   user is already looking at; the previous language stays visible until
     *   the new one lands.
     * - **Ignores re-entrant switches.** Three quick taps fire three overlapping
     *   requests and whichever *responds* last wins, not whichever the user
     *   picked last.
     */
    suspend fun setLocale(code: String) {
        if (switchInFlight) return
        if (code.isBlank() || code == state.value.bundle.currentLanguage()) return
        switchInFlight = true
        internalState.update { it.copy(switching = true) }
        try {
            fetch(code, isSwitch = true)
        } finally {
            switchInFlight = false
            internalState.update { it.copy(switching = false) }
        }
    }

    @Suppress("TooGenericExceptionCaught")
    // Reason: content is non-essential to session correctness — the emergency
    // fallback covers every screen-critical string. Anything the transport or
    // the JSON decoder can throw must degrade to that fallback, never surface
    // as a crash inside a KYC flow. CancellationException is rethrown so
    // structured concurrency still works.
    private suspend fun fetch(
        locale: String?,
        isSwitch: Boolean,
    ) {
        try {
            val fetched = source.fetch(locale)
            if (fetched.isEmpty()) {
                markFailed(isSwitch, "empty content body")
                return
            }
            internalState.update {
                it.copy(bundle = ContentBundle.of(fetched), gateOpen = true, errored = false)
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (failure: Exception) {
            markFailed(isSwitch, failure.message ?: failure.javaClass.simpleName)
        }
    }

    /**
     * A failed **switch** leaves the current bundle and `errored` untouched —
     * the user is looking at a working screen in the previous language and
     * blanking it would be strictly worse. Only the first load can set
     * [ContentState.errored].
     */
    private fun markFailed(
        isSwitch: Boolean,
        reason: String,
    ) {
        warnLogcat("SdkContent fetch failed ($reason); falling back to the built-in bundle")
        if (isSwitch) return
        internalState.update { it.copy(gateOpen = true, errored = true) }
    }

    /**
     * Wraps `Log.w` so the same code compiles and runs in JVM unit tests —
     * `android.util.Log` is a native stub there and throws
     * `UnsatisfiedLinkError`. Same pattern as
     * [com.othento.core.internal.network.ErrorMapper].
     */
    @Suppress("TooGenericExceptionCaught")
    private fun warnLogcat(message: String) {
        try {
            Log.w(TAG, message)
        } catch (_: LinkageError) {
            // Unit-test environment without android.util.Log — ignore.
        } catch (_: RuntimeException) {
            // Defensive: a platform stub that throws must not fail the fetch path.
        }
    }

    internal companion object {
        private const val TAG = "OthentoSDK-Content"
    }
}
