package com.othento.core.internal.liveness

import com.amplifyframework.ui.liveness.model.FaceLivenessDetectionException

/**
 * What the screen should do about a failure reported by the AWS component.
 *
 * [Cancelled] is separate from [Retry] on purpose: a user who backs out has
 * not failed a check, so cancelling must not burn one of the three attempts.
 */
internal enum class LivenessOutcome {
    Cancelled,
    Retry,
    PermissionDenied,
    UnsupportedUpdate,
    Fatal,
}

/**
 * Maps `FaceLivenessDetector`'s single error channel onto [LivenessOutcome].
 *
 * Two Android-specific notes, both confirmed against
 * `com.amplifyframework.ui:liveness:1.5.0` itself rather than the docs:
 *
 * 1. **`FaceLivenessDetectionException` is not a `Throwable`.** It extends
 *    `Object` and carries `message` / `recoverySuggestion` / `throwable`, so
 *    it arrives by value rather than being thrown — hence a mapper rather
 *    than a `catch`.
 * 2. **Cancel arrives through `onError`, not a dedicated callback.** Web has
 *    an explicit `onUserCancel`; Android delivers
 *    [FaceLivenessDetectionException.UserCancelledException] on the same
 *    channel as real failures. Misclassifying it would consume an attempt
 *    and, worse, could finalize a challenge the user abandoned.
 *
 * The web mapping (`liveness-error-mapper.ts`) is preserved wherever the
 * concepts line up: permission → permission_denied, server-side → fatal,
 * everything else → retry.
 */
internal object LivenessErrorMapper {
    fun map(error: FaceLivenessDetectionException): LivenessOutcome =
        when (error) {
            is FaceLivenessDetectionException.UserCancelledException -> LivenessOutcome.Cancelled
            is FaceLivenessDetectionException.CameraPermissionDeniedException ->
                LivenessOutcome.PermissionDenied
            // The component cannot render the challenge this session asks for —
            // the same user-facing story as an unknown challenge type from our
            // own backend, so it lands on the same screen.
            is FaceLivenessDetectionException.UnsupportedChallengeTypeException ->
                LivenessOutcome.UnsupportedUpdate
            // Credentials rejected / session gone: retrying re-mints a session
            // and hits the same wall. Web's SERVER_ERROR → fatal.
            is FaceLivenessDetectionException.AccessDeniedException -> LivenessOutcome.Fatal
            is FaceLivenessDetectionException.SessionNotFoundException -> LivenessOutcome.Fatal
            is FaceLivenessDetectionException.SessionTimedOutException -> LivenessOutcome.Retry
            // Web's default arm: an unrecognised failure is assumed transient.
            //
            // `FaceInOvalMatchExceededTimeLimitException` is deliberately not
            // matched by name — Amplify declares it `internal`, so it is
            // unreachable from Kotlin even though it is public in the bytecode.
            // It lands here, which is the outcome it would have been given
            // anyway.
            else -> LivenessOutcome.Retry
        }
}
