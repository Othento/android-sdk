package com.othento.core.internal.content

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import com.othento.core.internal.network.ErrorMapper

/**
 * Resolves an SDK-authored error message through the content bundle, leaving
 * genuine wire errors alone.
 *
 * ### Why this is not "just another content lookup"
 * Every other string in the SDK is fetched by a key the *screen* knows. An
 * error message is different: it arrives at the screen as a finished English
 * sentence, produced by [ErrorMapper] deep in the network layer, which runs off
 * the composition and cannot read content. The same `displayMessage` field also
 * carries text the SDK did **not** write — a server-supplied message, or
 * `throwable.message` — and that text has no key, cannot be translated, and is
 * often the only detail the screen has about what actually failed.
 *
 * So the question this answers is not "what does this key say" but "did we
 * write this sentence?". [SDK_AUTHORED] is keyed by the [ErrorMapper] constants
 * **by reference**. That matters: nothing here retypes an English string, so
 * changing a message in [ErrorMapper] moves the map entry with it, and deleting
 * one is a compile error rather than a lookup that silently stops matching.
 *
 * Anything absent from the map is passed through untouched. Replacing an
 * unrecognised message with generic translated copy would trade a specific
 * English clue for a vague localized one — worse for the user *and* for whoever
 * reads the bug report.
 *
 * ### Deliberately unmapped
 * The contract also serves `error.session.loadFailed` and
 * `error.session.restartFailed`. Neither is bound, because no [ErrorMapper]
 * message means quite the same thing: `INITIATE_FAIL_BODY` is "failed to
 * *start*", which is a different event from the backend's "failed to
 * *restart*". Binding them on the strength of similar wording would render
 * confidently wrong copy in every language at once — the same trap
 * `SELFIE_REVIEW_TITLE` documents. They stay declared and unread until there is
 * a message that genuinely matches.
 */
private val SDK_AUTHORED: Map<String, String> =
    mapOf(
        ErrorMapper.CREATE_FAIL_BODY to ContentKeys.ERROR_SESSION_CREATE_FAILED,
        ErrorMapper.DOCUMENTS_FAIL_BODY to ContentKeys.DOCUMENT_SELECT_LOAD_ERROR,
        ErrorMapper.DEFAULT_ERROR_MESSAGE to ContentKeys.ERROR_GENERIC_RETRY_HINT,
    )

/**
 * [message] translated when the SDK wrote it, or returned verbatim when it came
 * off the wire. `null` in, `null` out — the caller decides what an absent
 * description means.
 */
@Composable
@ReadOnlyComposable
internal fun errorCopy(message: String?): String? {
    // A null message and an unrecognised one take the same exit: hand back
    // exactly what came in.
    val key = message?.let { SDK_AUTHORED[it] } ?: return message
    // `textOrNull` rather than `text`: an unseeded key must fall back to the
    // English sentence we already have, never blank the description.
    return LocalContent.current.textOrNull(key) ?: message
}
