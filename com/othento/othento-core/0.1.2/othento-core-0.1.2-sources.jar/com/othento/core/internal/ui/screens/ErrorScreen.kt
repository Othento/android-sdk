@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.othento.core.api.OthentoError
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.ResultMode
import com.othento.core.internal.content.ResultTone
import com.othento.core.internal.content.content
import com.othento.core.internal.content.errorCopy
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.screens.common.ContentStatusScreen
import com.othento.core.internal.ui.screens.common.returnToAppLabel
import com.othento.core.internal.ui.screens.common.StatusAction
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * `result.error.*` — red cross, description = the SDK's mapped display
 * message, optional "error code NNN" chip in the extra slot.
 *
 * ### The title now comes from content
 * Previously this screen chose between two hard-coded titles ("Session not
 * found" for 404, "Something went wrong" otherwise) while the orchestrator's
 * copy won over the bundle. That is precisely the defect in plan §4.2 — a
 * screen looks migrated because the right string still renders, just from the
 * old path. The contract has one title key for this state, so both cases now
 * resolve `result.error.title`.
 *
 * The 404-specific wording belongs to the phase-2 `error.*` group, which is
 * entirely unseeded (plan §1). Until it lands, the HTTP status still
 * distinguishes the two cases visibly, via the code chip.
 *
 * [displayMessage] remains the description, but it now passes through
 * [errorCopy] first. The field mixes two kinds of text: sentences the SDK's own
 * `ErrorMapper` wrote, which the contract *does* have keys for, and messages
 * that came off the wire, which it does not. `errorCopy` translates the former
 * and leaves the latter untouched — see its docs for why the distinction is
 * drawn by constant identity rather than by the error type.
 *
 * This is separate from the machine-readable `error.code` the host receives,
 * which is API and must never be localized (plan §4.12).
 *
 * The web SDK's retry CTA is deliberately not wired: the host receives the
 * `onError` callback and can relaunch the SDK if it wants to retry.
 */
@Composable
internal fun ErrorScreen(
    error: OthentoError?,
    displayMessage: String?,
    httpStatus: Int?,
    onReturnToApp: () -> Unit,
) {
    val codeText =
        if (error == OthentoError.SessionNotFound) NOT_FOUND_CODE else httpStatus?.toString()
    ContentStatusScreen(
        prefix = ContentKeys.RESULT_ERROR,
        fallbackIcon = StatusIconName.Cross,
        fallbackTone = ResultTone.Error,
        fallbackMode = ResultMode.Terminal,
        descriptionOverride = errorCopy(displayMessage),
        primaryAction = StatusAction(label = returnToAppLabel(), onClick = onReturnToApp),
        extraContent =
            if (codeText != null) {
                {
                    ErrorCodeChip(codeText)
                }
            } else {
                null
            },
    )
}

@Composable
private fun ErrorCodeChip(code: String) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier =
            Modifier
                .clip(RoundedCornerShape(percent = 50))
                .background(colors.bgLayout)
                .border(width = 1.dp, color = colors.border, shape = RoundedCornerShape(percent = 50))
                .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(
            text = content(ContentKeys.RESULT_ERROR_CODE_LABEL).uppercase(),
            style = typography.microEyebrow.copy(fontSize = 10.sp),
            color = colors.textMuted,
        )
        Text(
            text = code,
            style = typography.numericBadge.copy(fontSize = 12.sp),
            color = colors.textPrimary,
        )
    }
}

private const val NOT_FOUND_CODE = "404"
