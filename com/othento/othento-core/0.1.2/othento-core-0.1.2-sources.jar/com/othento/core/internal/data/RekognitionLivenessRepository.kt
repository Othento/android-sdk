package com.othento.core.internal.data

import com.othento.core.internal.data.model.LivenessChallengeMode
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.network.ErrorMapper
import com.othento.core.internal.network.OthentoApi
import com.othento.core.internal.network.SessionMapper
import com.othento.core.internal.network.TokenStore
import com.othento.core.internal.network.dto.RekognitionStartRequestDto
import kotlinx.coroutines.CancellationException

/**
 * The three Rekognition endpoints, mirroring web's
 * `RekognitionTokenSessionService`.
 *
 * Failures surface as
 * [com.othento.core.internal.network.OthentoNetworkException] via the shared
 * [ErrorMapper], tagged [ErrorMapper.Flow.Poll] for its generic copy. That tag
 * is diagnostic only: the screen routes every repository failure to
 * `FailedRetry` rather than the host error screen, so the `OthentoError`
 * subtype never reaches a host callback on this path.
 */
internal interface RekognitionLivenessRepository {
    /**
     * `POST …/start` — mints a single-use AWS session. Called once per
     * attempt; a retry must call this again rather than reusing a sessionId.
     */
    suspend fun start(attemptStepId: String): RekognitionStartResult

    /**
     * `POST …/complete` — finalises the challenge and returns the rotated
     * session. **Only** called after the component reports success; a user
     * cancel must never reach here.
     */
    suspend fun complete(attemptStepId: String): Session

    /** `GET …/credentials` — short-lived STS credentials for streaming. */
    suspend fun credentials(): RekognitionCredentials
}

internal data class RekognitionStartResult(
    val sessionId: String,
    val challengeMode: LivenessChallengeMode?,
    val photosensitivity: Boolean,
)

/**
 * [expirationEpochSeconds] is epoch **seconds**, which is what
 * `AWSCredentials.createAWSCredentials` expects (it feeds
 * `Instant.fromEpochSeconds`). Null when the backend omits `expiration`.
 */
internal data class RekognitionCredentials(
    val accessKeyId: String,
    val secretAccessKey: String,
    val sessionToken: String?,
    val expirationEpochSeconds: Long?,
)

internal class RekognitionLivenessRepositoryImpl(
    private val api: OthentoApi,
    private val errorMapper: ErrorMapper,
    private val tokenStore: TokenStore,
) : RekognitionLivenessRepository {
    override suspend fun start(attemptStepId: String): RekognitionStartResult =
        mapErrors {
            val response =
                api.startRekognitionLiveness(RekognitionStartRequestDto(attemptStepId = attemptStepId))
            RekognitionStartResult(
                sessionId = response.sessionId,
                challengeMode = response.challengeMode,
                photosensitivity = response.photosensitivity,
            )
        }

    override suspend fun complete(attemptStepId: String): Session =
        mapErrors {
            val response =
                api.completeRekognitionLiveness(RekognitionStartRequestDto(attemptStepId = attemptStepId))
            // Same contract as every other session-returning call: absorb the
            // rotated ST/SRT before the next request goes out.
            tokenStore.updateFromResponse(response)
            SessionMapper.fromTokenSessionResponse(response)
        }

    override suspend fun credentials(): RekognitionCredentials =
        mapErrors {
            val response = api.getRekognitionCredentials()
            RekognitionCredentials(
                accessKeyId = response.accessKeyId,
                secretAccessKey = response.secretAccessKey,
                sessionToken = response.sessionToken,
                expirationEpochSeconds =
                    response.expiration
                        ?.let { TokenStore.parseIso8601Utc(it) }
                        ?.let { millis -> millis / MILLIS_PER_SECOND },
            )
        }

    private inline fun <T> mapErrors(block: () -> T): T =
        try {
            block()
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (
            // Reason: ErrorMapper is the single funnel for every wire failure
            // shape (HttpException / IOException / JsonDataException);
            // enumerating them here would duplicate its dispatch table.
            @Suppress("TooGenericExceptionCaught") e: Exception,
        ) {
            throw errorMapper.toException(e, ErrorMapper.Flow.Poll)
        }

    private companion object {
        const val MILLIS_PER_SECOND = 1_000L
    }
}
