package com.othento.core.internal.network

import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.data.model.ActiveStep
import com.othento.core.internal.data.model.Challenge
import com.othento.core.internal.data.model.LivenessHint
import com.othento.core.internal.data.model.ReinitInfo
import com.othento.core.internal.data.model.ReinitStep
import com.othento.core.internal.data.model.SelectedDocument
import com.othento.core.internal.data.model.Session
import com.othento.core.internal.data.model.Step
import com.othento.core.internal.network.dto.AcceptedDocumentDto
import com.othento.core.internal.network.dto.ActiveStepDto
import com.othento.core.internal.network.dto.ChallengeDto
import com.othento.core.internal.network.dto.ReinitInfoDto
import com.othento.core.internal.network.dto.ReinitStepDto
import com.othento.core.internal.network.dto.SelectedDocumentDto
import com.othento.core.internal.network.dto.StepDto
import com.othento.core.internal.network.dto.TokenSessionResponseDto

/**
 * Pure functions that map wire DTOs into the SDK's domain models.
 *
 * The Android SDK uses a single response shape ([TokenSessionResponseDto])
 * for every wire call; see P9 in `docs/spec/99-open-questions.md`. The
 * mapper folds it straight into the domain [Session], carrying the
 * SAT/ST/SRT bundle through unchanged so the flow layer can hand them to
 * the token interceptor in later phases.
 */
internal object SessionMapper {
    fun fromTokenSessionResponse(dto: TokenSessionResponseDto): Session =
        Session(
            externalId = dto.externalId,
            desktopAccess = dto.desktopAccess,
            sessionUrl = dto.sessionUrl,
            status = dto.status,
            isSandbox = dto.isSandbox,
            maxAttempts = dto.maxAttempts,
            attemptNumber = dto.attemptNumber,
            estimatedPrice = dto.estimatedPrice,
            expiresAt = dto.expiresAt,
            currentStep = dto.currentStep?.let(::mapActiveStep),
            selectedDocument = dto.selectedDocument?.let(::mapSelectedDocument),
            steps = dto.steps.map(::mapStep),
            canInitiate = dto.canInitiate,
            canReinitiate = dto.canReinitiate,
            reinitInfo = dto.reinitInfo?.let(::mapReinitInfo),
            decision = dto.decision,
            sessionToken = dto.sessionToken,
            sessionRetryToken = dto.sessionRetryToken,
            stExpiresAt = dto.stExpiresAt,
            srtExpiresAt = dto.srtExpiresAt,
            declineMessage = dto.declineMessage,
            declineReasonKey = dto.declineReasonKey,
            language = dto.language,
        )

    fun mapAcceptedDocuments(list: List<AcceptedDocumentDto>): List<AcceptedDocument> = list.map(::mapAcceptedDocument)

    private fun mapReinitInfo(dto: ReinitInfoDto): ReinitInfo =
        ReinitInfo(
            attemptsRemaining = dto.attemptsRemaining,
            failureReason = dto.failureReason,
            stepsToRetry = dto.stepsToRetry.map(::mapReinitStep),
        )

    private fun mapReinitStep(dto: ReinitStepDto): ReinitStep =
        ReinitStep(
            stepCode = dto.stepCode,
            stepName = dto.stepName,
            order = dto.order,
        )

    private fun mapStep(dto: StepDto): Step =
        Step(
            attemptStepId = dto.attemptStepId,
            configuration = dto.configuration,
            stepCode = dto.stepCode,
            stepName = dto.stepName,
            order = dto.order,
            status = dto.status,
        )

    private fun mapActiveStep(dto: ActiveStepDto): ActiveStep =
        ActiveStep(
            attemptStepId = dto.attemptStepId,
            configuration = dto.configuration,
            stepCode = dto.stepCode,
            stepName = dto.stepName,
            order = dto.order,
            status = dto.status,
            challenges = dto.challenges.map(::mapChallenge),
        )

    private fun mapChallenge(dto: ChallengeDto): Challenge =
        Challenge(
            challengeType = dto.challengeType,
            challengeStatus = dto.challengeStatus,
            otpExpiresAt = dto.otpExpiresAt,
            otpSize = dto.otpSize,
            otpAlphanumeric = dto.otpAlphanumeric,
            corporateEmailOnly = dto.corporateEmailOnly,
            liveness =
                dto.liveness?.let { hint ->
                    LivenessHint(
                        provider = hint.provider,
                        challengeMode = hint.challengeMode,
                        photosensitivity = hint.photosensitivity,
                        region = hint.region,
                    )
                },
        )

    private fun mapSelectedDocument(dto: SelectedDocumentDto): SelectedDocument =
        SelectedDocument(
            id = dto.id,
            widthMm = dto.widthMm,
            heightMm = dto.heightMm,
            requireBothSides = dto.requireBothSides,
        )

    private fun mapAcceptedDocument(dto: AcceptedDocumentDto): AcceptedDocument =
        AcceptedDocument(
            documentId = dto.documentId,
            documentTypeCode = dto.documentTypeCode,
            countryCode = dto.countryCode,
            countryCodeAlpha2 = dto.countryCodeAlpha2,
            countryCodeAlpha3 = dto.countryCodeAlpha3,
            countryName = dto.countryName,
            countryIcon = dto.countryIcon,
            typeName = dto.typeName,
            widthMm = dto.widthMm,
            heightMm = dto.heightMm,
            requireBothSides = dto.requireBothSides,
        )
}
