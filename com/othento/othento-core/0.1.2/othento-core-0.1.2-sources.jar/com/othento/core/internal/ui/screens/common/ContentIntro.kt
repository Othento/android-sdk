package com.othento.core.internal.ui.screens.common

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.ui.components.ContentIconRegistry
import com.othento.core.internal.ui.components.IntroTipCard

/**
 * Resolves an intro sheet's tip grid from content, falling back to the
 * compiled-in cards when the bundle carries none.
 *
 * The bundle's `icon` is an HTTPS template PNG. Its **filename** also names the
 * built-in that stands in offline (`…/icons/tips/light.png` → the `light`
 * glyph), so a card keeps a sensible icon even when the image cannot load —
 * falling back on the raw value instead would render a generic placeholder,
 * because the value is a URL, not a name (plan §4.7).
 *
 * Malformed entries are already dropped by
 * [com.othento.core.internal.content.ContentBundle.tipCards]: it validates
 * every field the renderer dereferences, not just the ones that happen to be
 * checked (plan §4.6).
 */
@Composable
@ReadOnlyComposable
internal fun contentTipCards(
    key: String,
    fallback: List<IntroTipCard>,
): List<IntroTipCard> {
    val cards = LocalContent.current.tipCards(key)
    if (cards.isEmpty()) return fallback
    return cards.map { card ->
        IntroTipCard(
            label = card.label,
            detail = card.detail.orEmpty(),
            icon = ContentIconRegistry.resolve(card.icon) ?: FALLBACK_GLYPH,
            iconUrl = card.icon,
        )
    }
}

private val FALLBACK_GLYPH = com.othento.core.internal.ui.icons.OthentoIcons.Info
