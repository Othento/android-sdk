@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.othento.core.api.OthentoError
import com.othento.core.internal.capture.SelfieKind
import com.othento.core.internal.capture.selfieKind
import com.othento.core.internal.content.BrandingResolver
import com.othento.core.internal.content.ContentBundle
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.content.OthentoBranding
import com.othento.core.internal.content.errorCopy
import com.othento.core.internal.data.model.ChallengeType
import com.othento.core.internal.flow.FlowUiState
import com.othento.core.internal.flow.OthentoFlowViewModel
import com.othento.core.internal.flow.ScreenState
import com.othento.core.internal.network.ErrorMapper
import com.othento.core.internal.ui.screens.common.OthentoSdkScaffold
import com.othento.core.internal.ui.screens.common.StepProgress
import com.othento.core.internal.ui.theme.LocalOthentoColors

/**
 * Compose root that observes [OthentoFlowViewModel.state] and renders the
 * matching screen wrapped in [OthentoSdkScaffold] (sandbox banner + trust
 * footer chrome). The [UploadProgressSheet] overlay layers on top of the
 * capture screens when an upload is in flight.
 */
@Composable
@Suppress(
    "CyclomaticComplexMethod",
    "LongMethod",
    // Reason: the per-ScreenState switch has 13 branches; extracting individual
    // branches to helpers doesn't improve readability — the switch is the single
    // decision table the reader expects to scan.
)
internal fun OthentoFlowHost(
    viewModel: OthentoFlowViewModel,
    onReturnToApp: () -> Unit,
    branding: OthentoBranding = BrandingResolver.resolve(ContentBundle.Empty),
    contentGateOpen: Boolean = true,
    languageSwitching: Boolean = false,
) {
    val state: FlowUiState by viewModel.state.collectAsState()
    // Brand name comes from `theme.brand.name` in the content bundle, falling
    // back to the compiled-in default. Reading a compiled-in constant while the
    // API value sits in a dead variable is exactly the defect in plan §4.2, so
    // this is the only place the name is resolved and every consumer takes it
    // from here.
    val brandName = branding.brandName.ifBlank { DEFAULT_BRAND_NAME }
    val isSandbox = state.session?.isSandbox == true

    // Decision 3 — first paint blocks until the content bundle lands. Error is
    // exempt: a flow that already failed must not be held behind a copy fetch
    // that will never arrive.
    val waitingForContent = !contentGateOpen && state.screenState != ScreenState.Error
    if (waitingForContent) {
        // Deliberately *not* wrapped in OthentoSdkScaffold. The scaffold's
        // trust footer renders the brand name and "SECURED BY", and before the
        // bundle lands both can only come from the compiled-in fallback — so
        // wrapping here would paint Othento's own chrome to a tenant's user
        // and then swap it. A bare themed surface has nothing to correct.
        UnbrandedLoadingSurface()
        return
    }
    if (state.screenState == ScreenState.Loading) {
        OthentoSdkScaffold(isSandbox = isSandbox, brandName = brandName, logoUrl = branding.logoUrl) {
            LoadingScreen()
        }
        return
    }

    // OthentoConfig.closeOnComplete — auto-hand control back to the host the
    // moment the flow lands on a terminal screen (the terminal listener event
    // has already fired). FailedRetry is recoverable, so it is NOT terminal.
    if (viewModel.closeOnComplete) {
        LaunchedEffect(state.screenState) {
            if (state.screenState in TERMINAL_SCREEN_STATES) onReturnToApp()
        }
    }
    // The `PickVisualMedia` launcher must be remembered at this level —
    // CaptureFallbackScreen takes a `() -> Unit` so it stays Paparazzi-friendly.
    val pickFile =
        rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
            if (uri != null) viewModel.onUserFileCaptured(uri, isManualCapture = true)
        }
    val onPickFileClick: () -> Unit = {
        pickFile.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    val stepProgress = StepProgress.of(state.session)

    val isImmersive =
        when {
            state.screenState == ScreenState.SelfieCapture -> true
            // The AWS Face Liveness component draws its own full-screen
            // surface; wrapping it in the SDK card chrome would nest a
            // camera view inside a scrollable scaffold.
            state.screenState == ScreenState.RekognitionLiveness -> true
            !state.useFallback &&
                (
                    state.screenState == ScreenState.CaptureFront ||
                        state.screenState == ScreenState.CaptureBack
                ) -> true
            else -> false
        }

    if (isImmersive) {
        // Spec §05-capture line 17 + §08-selfie-capture line 14 — the
        // camera + selfie screens are immersive: full-bleed black, no SDK
        // card chrome, no sandbox banner, no trust footer.
        Box(modifier = Modifier.fillMaxSize()) {
            when (state.screenState) {
                ScreenState.SelfieCapture ->
                    SelfieCaptureScreen(
                        kind = state.session?.selfieKind ?: SelfieKind.FaceMatch,
                        onCapturedFile = { uri, manual -> viewModel.onUserFileCaptured(uri, manual) },
                    )
                ScreenState.RekognitionLiveness -> {
                    val repository = viewModel.rekognitionRepository
                    val step = state.session?.currentStep
                    // The advisory hint rides on the Rekognition challenge
                    // itself; absent hint means "mode unknown", which the
                    // screen reads as "suppress the photosensitivity warning".
                    val hint =
                        step
                            ?.challenges
                            ?.firstOrNull {
                                it.challengeType == ChallengeType.RekognitionLivenessSession
                            }?.liveness
                    if (repository == null || step == null) {
                        missingSessionError("RekognitionLiveness", onReturnToApp = onReturnToApp)
                    } else {
                        RekognitionLivenessScreen(
                            attemptStepId = step.attemptStepId,
                            photosensitivity = hint?.photosensitivity == true,
                            challengeMode = hint?.challengeMode,
                            repository = repository,
                            onCompleted = { session -> viewModel.onRekognitionCompleted(session) },
                            onFailed = { viewModel.onRekognitionFailed() },
                        )
                    }
                }
                else ->
                    CaptureFrontOrBack(
                        side = if (state.screenState == ScreenState.CaptureFront) Side.Front else Side.Back,
                        state = state,
                        stepProgress = stepProgress,
                        onChangeDocument = { viewModel.onUserChangeDocument() },
                        onPickFileClick = onPickFileClick,
                        onCapturedFile = { uri, manual -> viewModel.onUserFileCaptured(uri, manual) },
                        onSwitchToFallback = { viewModel.onUserSwitchToFallback() },
                        onRetake = { viewModel.onUserRetakeCapture() },
                        onConfirm = { viewModel.onUserConfirmCapture() },
                    )
            }
            if (state.uploadProgress != null) {
                // Dark variant — mirrors web's `.sdk-upload-sheet--dark`
                // applied on capture_front/capture_back/selfie_capture for
                // visual continuity with the dark camera viewport behind it.
                UploadProgressSheet(hint = state.uploadHint, dark = true)
            }
        }
        return
    }

    OthentoSdkScaffold(isSandbox = isSandbox, brandName = brandName) {
        Box(modifier = Modifier.fillMaxSize()) {
            when (state.screenState) {
                // Intercepted by the loading/gate branch above; kept for exhaustiveness.
                ScreenState.Loading -> LoadingScreen()
                ScreenState.Start ->
                    state.session?.let { session ->
                        StartScreen(
                            session = session,
                            brandName = brandName,
                            logoUrl = branding.logoUrl,
                            // Task 8 — the picker lives on the welcome screen only.
                            // Switching mid-flow would swap copy under a user
                            // part-way through a capture or an OTP entry.
                            languages = LocalContent.current.languages(),
                            currentLanguage = LocalContent.current.currentLanguage(),
                            languageSwitching = languageSwitching,
                            onLanguageSelected = { viewModel.onUserSelectLanguage(it) },
                            onBeginClick = { viewModel.onUserBeginVerification() },
                        )
                    } ?: missingSessionError("Start", onReturnToApp = onReturnToApp)
                ScreenState.DocumentSelect ->
                    DocumentSelectScreen(
                        documents = state.documents,
                        selectedCountryKey = state.selectedCountryKey,
                        selectedDocumentId = state.selectedDocumentId,
                        loading = state.documentsLoading,
                        errorMessage = errorCopy(state.documentsError),
                        stepProgress = stepProgress,
                        onCountrySelected = { viewModel.onUserCountrySelected(it) },
                        onDocumentSelected = { viewModel.onUserDocumentSelected(it) },
                        onConfirmClick = { viewModel.onUserConfirmDocument() },
                    )
                ScreenState.CaptureFront ->
                    CaptureFrontOrBack(
                        side = Side.Front,
                        state = state,
                        stepProgress = stepProgress,
                        onChangeDocument = { viewModel.onUserChangeDocument() },
                        onPickFileClick = onPickFileClick,
                        onCapturedFile = { uri, manual -> viewModel.onUserFileCaptured(uri, manual) },
                        onSwitchToFallback = { viewModel.onUserSwitchToFallback() },
                        onRetake = { viewModel.onUserRetakeCapture() },
                        onConfirm = { viewModel.onUserConfirmCapture() },
                    )
                ScreenState.CaptureBack ->
                    CaptureFrontOrBack(
                        side = Side.Back,
                        state = state,
                        stepProgress = stepProgress,
                        onChangeDocument = { viewModel.onUserChangeDocument() },
                        onPickFileClick = onPickFileClick,
                        onCapturedFile = { uri, manual -> viewModel.onUserFileCaptured(uri, manual) },
                        onSwitchToFallback = { viewModel.onUserSwitchToFallback() },
                        onRetake = { viewModel.onUserRetakeCapture() },
                        onConfirm = { viewModel.onUserConfirmCapture() },
                    )
                ScreenState.SelfieCapture, ScreenState.RekognitionLiveness -> {
                    // Unreachable — the immersive branch above intercepts both
                    // before this `when` runs. Kept here so the exhaustiveness
                    // check covers every enum value.
                }
                ScreenState.UnsupportedUpdate -> UnsupportedUpdateScreen(onReturnToApp = onReturnToApp)
                ScreenState.OtpPhone, ScreenState.OtpEmail ->
                    state.otp?.let { otp ->
                        OtpScreen(viewModel = viewModel, otp = otp, stepProgress = stepProgress)
                    } ?: missingSessionError("OTP", onReturnToApp = onReturnToApp)
                ScreenState.Processing ->
                    ProcessingScreen(
                        timedOut = state.pollTimedOut,
                        onTryAgainClick = { viewModel.onUserPollRetry() },
                    )
                ScreenState.Approved -> ApprovedScreen(onReturnToApp = onReturnToApp)
                ScreenState.Declined -> DeclinedScreen(onReturnToApp = onReturnToApp)
                ScreenState.InReview -> InReviewScreen(onReturnToApp = onReturnToApp)
                ScreenState.Expired -> ExpiredScreen(onReturnToApp = onReturnToApp)
                ScreenState.FailedTerminal -> FailedTerminalScreen(onReturnToApp = onReturnToApp)
                ScreenState.FailedRetry ->
                    state.session?.let { session ->
                        FailedRetryScreen(
                            session = session,
                            brandName = brandName,
                            onTryAgainClick = { viewModel.onUserRetryFailed() },
                            onReturnToApp = onReturnToApp,
                        )
                    } ?: missingSessionError("FailedRetry", onReturnToApp = onReturnToApp)
                ScreenState.Error ->
                    ErrorScreen(
                        error = state.error,
                        displayMessage = state.displayMessage,
                        httpStatus = state.errorHttpStatus,
                        onReturnToApp = onReturnToApp,
                    )
            }
            // Upload-progress overlay: layers above the capture screens
            // when bytes are flowing. Spec [11-uploading.md] §B.
            if (state.uploadProgress != null) {
                UploadProgressSheet(hint = state.uploadHint)
            }
        }
    }
}

/**
 * Phase 6 — single entry point for `CaptureFront` / `CaptureBack` that
 * picks the camera HUD or the upload-only fallback depending on
 * [FlowUiState.useFallback].
 *
 * The fallback path is exactly the Phase-5 [CaptureFallbackScreen] (zero
 * regression). The camera path is the new [CameraCaptureScreen] running
 * the CameraX preview + analyzer + auto-capture pipeline.
 */
@Composable
@Suppress("LongParameterList")
private fun CaptureFrontOrBack(
    side: Side,
    state: FlowUiState,
    stepProgress: StepProgress,
    onChangeDocument: () -> Unit,
    onPickFileClick: () -> Unit,
    onCapturedFile: (Uri, Boolean) -> Unit,
    onSwitchToFallback: () -> Unit,
    onRetake: () -> Unit,
    onConfirm: () -> Unit,
) {
    if (state.useFallback) {
        CaptureFallbackScreen(
            side = side,
            pendingDocument = state.pendingDocument,
            pendingCapture = state.pendingCapture,
            oversizedFile = state.oversizedFile,
            fileUnreadable = state.fileUnreadable,
            stepProgress = stepProgress,
            onChangeDocument = onChangeDocument,
            onPickFileClick = onPickFileClick,
            onRetake = onRetake,
            onConfirm = onConfirm,
        )
    } else {
        CameraCaptureScreen(
            side = side,
            pendingDocument = state.pendingDocument,
            enableFallback = true,
            pendingCapture = state.pendingCapture,
            onChangeDocument = onChangeDocument,
            onCapturedFile = onCapturedFile,
            onSwitchToFallback = onSwitchToFallback,
            onPickFile = onPickFileClick,
            onRetakePickedFile = onRetake,
            onConfirmPickedFile = onConfirm,
        )
    }
}

/**
 * First paint, before the content bundle has landed.
 *
 * The skeleton is deliberately the *only* thing on screen. Every other surface
 * in the SDK carries at least one tenant-owned string — the trust footer's
 * brand name, the sandbox banner, a screen title — and rendering any of them
 * now would mean rendering the compiled-in fallback and correcting it a moment
 * later. [LoadingScreen] is pure geometry (it uses `KycScreenZone.Result`, so
 * not even a header), which is what makes it safe to show this early.
 *
 * The palette is still the built-in one here, since `theme.*` arrives in the
 * same response. That is unavoidable — something has to be painted — but a
 * neutral background changing tint reads as a theme settling in, where swapped
 * brand *text* reads as the wrong company's SDK.
 */
@Composable
private fun UnbrandedLoadingSurface() {
    val colors = LocalOthentoColors.current
    val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .background(colors.bgBase)
                .padding(top = statusBarPadding),
    ) {
        LoadingScreen()
    }
}

/**
 * Renders the generic error screen for the (unreachable in well-behaved
 * code) case where [OthentoFlowHost] sees `screenState=Start | FailedRetry`
 * without a resolved [Session]. Emits a typed [OthentoError.Unknown] so the bug
 * surfaces visibly rather than masquerading as another `Loading` flicker.
 */
@Composable
private fun missingSessionError(
    screenName: String,
    onReturnToApp: () -> Unit,
) {
    ErrorScreen(
        error = OthentoError.Unknown("Resolved $screenName screen without a session payload."),
        // Routed through the ErrorMapper constant rather than a literal so
        // `errorCopy` recognises it as SDK-authored and resolves
        // `error.generic.retryHint`. A bespoke sentence here would be the one
        // untranslatable string on an otherwise fully-bound screen.
        displayMessage = ErrorMapper.DEFAULT_ERROR_MESSAGE,
        httpStatus = null,
        onReturnToApp = onReturnToApp,
    )
}

private const val DEFAULT_BRAND_NAME = "Othento"

/**
 * Terminal screens for `closeOnComplete`: a terminal listener event
 * (`onCompleted` / `onError`) has fired and the flow is over. `FailedRetry`
 * is intentionally excluded — the user can still retry from it.
 */
private val TERMINAL_SCREEN_STATES =
    setOf(
        ScreenState.Approved,
        ScreenState.Declined,
        ScreenState.InReview,
        ScreenState.Expired,
        ScreenState.FailedTerminal,
        ScreenState.Error,
    )
