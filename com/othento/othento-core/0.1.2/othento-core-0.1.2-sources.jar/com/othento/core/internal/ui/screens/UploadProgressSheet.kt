@file:Suppress("FunctionNaming", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.content
import com.othento.core.internal.flow.UploadHint
import com.othento.core.internal.ui.components.KycLoader
import com.othento.core.internal.ui.components.KycLoaderSize
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Bottom-sheet overlay rendered over the capture screens while an upload is
 * in flight. Mirrors the web SDK's `.sdk-upload-sheet`
 * (`apps/sdk/.../verify.html:255-275`, `verify.scss:158-221`):
 *
 * - Translucent backdrop (dims the host capture screen).
 * - Sheet at the bottom with a centered, vertically stacked spinner + label
 *   + delayed hints (web's `flex-direction: column`, `align-items: center`).
 * - Hints appear progressively: 5 s ⇒ "We're almost finished", 12 s ⇒
 *   "Thanks for your patience".
 *
 * No percentage is shown — the web sheet doesn't surface one and we now
 * match that. Upload progress is still tracked upstream and drives the
 * sheet's visibility (a non-null value means bytes are flowing).
 *
 * The [dark] variant matches the web's `.sdk-upload-sheet--dark` modifier
 * applied on `capture_front`/`capture_back`/`selfie_capture` — visual
 * continuity with the camera viewport behind the sheet. Colors are
 * hardcoded (web SCSS hardcodes them too, on top of any host brand).
 *
 * Non-interactive — the user can't dismiss the sheet mid-upload, only
 * cancel-via-back-press flushes the in-flight job (which the FlowCoordinator
 * cancels gracefully).
 */
@Composable
internal fun UploadProgressSheet(
    hint: UploadHint,
    modifier: Modifier = Modifier,
    dark: Boolean = false,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val tapInteractionSource = remember { MutableInteractionSource() }
    val sheetBackground = if (dark) DarkSheetBackground else colors.bgBase
    val labelColor = if (dark) DarkSheetLabel else colors.textPrimary
    val hintColor = if (dark) DarkSheetHint else colors.textSecondary
    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(BackdropColor)
                // Soak up any taps on the dimmed area.
                .clickable(interactionSource = tapInteractionSource, indication = null) { },
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = SheetCornerRadius, topEnd = SheetCornerRadius))
                    .background(sheetBackground)
                    .padding(SheetPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(SheetIconTextGap),
        ) {
            KycLoader(size = KycLoaderSize.Lg)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(SheetTextGap),
            ) {
                Text(
                    // `uploading.label`. The two hint lines below have no
                    // contract key — they belong to the native-only copy sweep
                    // (plan §8.2) and stay compiled in until that lands.
                    text = content(ContentKeys.UPLOADING_LABEL).ifBlank { PROCESSING_FALLBACK },
                    style = typography.bodyLg.copy(fontWeight = FontWeight.W600),
                    color = labelColor,
                    textAlign = TextAlign.Center,
                )
                if (hint != UploadHint.None) {
                    Text(
                        text = content(ContentKeys.UPLOADING_ALMOST_DONE),
                        style = typography.body,
                        color = hintColor,
                        textAlign = TextAlign.Center,
                    )
                }
                if (hint == UploadHint.TakingLonger) {
                    Text(
                        text = content(ContentKeys.UPLOADING_TAKING_LONGER),
                        style = typography.body,
                        color = hintColor,
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

private const val PROCESSING_FALLBACK = "Processing…"

private val BackdropColor: Color = Color.Black.copy(alpha = 0.4f)
private val SheetCornerRadius: Dp = 20.dp
private val SheetPadding: Dp = 24.dp
private val SheetIconTextGap: Dp = 14.dp
private val SheetTextGap: Dp = 6.dp

// Web `.sdk-upload-sheet--dark` (verify.scss:209-220).
private val DarkSheetBackground: Color = Color(0xFF1A1A1A)
private val DarkSheetLabel: Color = Color(0xFFF0F0F0)
private val DarkSheetHint: Color = Color(0xFF9CA3AF)
