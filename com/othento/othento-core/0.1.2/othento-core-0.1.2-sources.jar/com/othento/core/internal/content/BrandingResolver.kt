@file:Suppress("MagicNumber")

package com.othento.core.internal.content

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.OthentoColors
import com.othento.core.internal.ui.theme.OthentoShapes
import com.othento.core.internal.ui.theme.colorMix
import com.othento.core.internal.content.ContentKeys as CK

/**
 * Everything `theme.*` resolves to: a token override set plus the brand
 * identity the chrome renders.
 */
@Immutable
internal data class OthentoBranding(
    val colors: OthentoColors,
    val shapes: OthentoShapes,
    val brandName: String,
    /** Full-colour PNG — **never** tinted, unlike every other remote asset (plan §4.1). */
    val logoUrl: String?,
)

/**
 * Folds the bundle's `theme.*` keys into the design-token layer.
 *
 * ### Only base colours are transported (plan §3.2)
 * `primary` is the tenant's brand colour; `primaryHover` / `primaryActive` /
 * `primaryBg` are **derived here** with [colorMix], the same helper the web
 * SDK uses, so a derived token can never drift from its base. The derivation
 * factors reproduce the built-in palette from the built-in primary, which is
 * what keeps a default-theme render identical to the pre-content build.
 *
 * ### Status colours are static built-ins (decision 5c)
 * `success` / `warning` / `error` and their `*Bg` / `*Border` / `*Text`
 * variants are never read from the bundle. `result.*.tone` names *which*
 * status; this file resolves it against the fixed palette.
 *
 * ### Tenant input is untrusted
 * Every value is validated and **dropped** if malformed — this is
 * tenant-editable input, and a bad hex string must not blank a screen.
 *
 * ### Known-inert keys
 * - `theme.color.secondary` — no component in this SDK consumes a secondary
 *   brand colour. Deliberately not written anywhere: writing a token nothing
 *   reads is exactly the failure in plan §4.11, and it looks like it works.
 * - `theme.font.family` — a CSS font stack. Bundling an Arabic-capable font is
 *   a prerequisite of the RTL phase (plan §8.4), not of this one.
 * - `theme.brand.logoUrlOnDark` — no dark surface renders a logo today
 *   (plan §8.5).
 */
internal object BrandingResolver {
    fun resolve(
        bundle: ContentBundle,
        baseColors: OthentoColors = OthentoColors.Light,
        baseShapes: OthentoShapes = OthentoShapes.Default,
    ): OthentoBranding =
        OthentoBranding(
            colors = resolveColors(bundle, baseColors),
            shapes = resolveShapes(bundle, baseShapes),
            brandName = bundle.text(CK.THEME_BRAND_NAME),
            logoUrl = bundle.asset(CK.THEME_BRAND_LOGO_URL),
        )

    @Suppress(
        "CyclomaticComplexMethod",
        // Reason: the complexity is one `?:` per token, in a flat copy() call.
        // It is a mapping table, not a branchy algorithm, and reading it top to
        // bottom is exactly how you check that no token was missed.
    )
    private fun resolveColors(
        bundle: ContentBundle,
        base: OthentoColors,
    ): OthentoColors {
        val primary = bundle.hex(CK.THEME_COLOR_PRIMARY)
        val bgBase = bundle.hex(CK.THEME_COLOR_BG_BASE) ?: base.bgBase
        return base.copy(
            primary = primary ?: base.primary,
            // Derived, never transported. Factors chosen so the built-in
            // primary reproduces the built-in hover/active/bg triple.
            primaryHover = primary?.let { colorMix(it, HOVER_MIX, Color.Black) } ?: base.primaryHover,
            primaryActive = primary?.let { colorMix(it, ACTIVE_MIX, Color.Black) } ?: base.primaryActive,
            primaryBg = primary?.let { colorMix(it, BG_TINT_MIX, bgBase) } ?: base.primaryBg,
            textHeading = bundle.hex(CK.THEME_COLOR_TEXT_HEADING) ?: base.textHeading,
            textPrimary = bundle.hex(CK.THEME_COLOR_TEXT_PRIMARY) ?: base.textPrimary,
            textSecondary = bundle.hex(CK.THEME_COLOR_TEXT_SECONDARY) ?: base.textSecondary,
            textMuted = bundle.hex(CK.THEME_COLOR_TEXT_MUTED) ?: base.textMuted,
            textDisabled = bundle.hex(CK.THEME_COLOR_TEXT_DISABLED) ?: base.textDisabled,
            border = bundle.hex(CK.THEME_COLOR_BORDER) ?: base.border,
            borderHover = bundle.hex(CK.THEME_COLOR_BORDER_HOVER) ?: base.borderHover,
            bgBase = bgBase,
            bgLayout = bundle.hex(CK.THEME_COLOR_BG_LAYOUT) ?: base.bgLayout,
            bgContainer = bundle.hex(CK.THEME_COLOR_BG_CONTAINER) ?: base.bgContainer,
            bgElevated = bundle.hex(CK.THEME_COLOR_BG_ELEVATED) ?: base.bgElevated,
            bgHover = bundle.hex(CK.THEME_COLOR_BG_HOVER) ?: base.bgHover,
        )
    }

    /**
     * `theme.shape.borderRadius` is a single base radius (`"10px"`), while the
     * SDK ships a four-step ramp. The tenant value anchors the `md` step and
     * the rest of the ramp scales with it, so the visual relationship between
     * a button and a card survives the override.
     *
     * The scale is clamped: a tenant typo of `"200px"` should look wrong, not
     * destroy the layout.
     */
    private fun resolveShapes(
        bundle: ContentBundle,
        base: OthentoShapes,
    ): OthentoShapes {
        val radiusPx = bundle.pixels(CK.THEME_SHAPE_BORDER_RADIUS) ?: return base
        val scale = (radiusPx / BASE_RADIUS_DP).coerceIn(MIN_RADIUS_SCALE, MAX_RADIUS_SCALE)
        return base.copy(
            sm = RoundedCornerShape((4f * scale).dp),
            md = RoundedCornerShape((BASE_RADIUS_DP * scale).dp),
            lg = RoundedCornerShape((12f * scale).dp),
            xl = RoundedCornerShape((16f * scale).dp),
        )
    }

    /**
     * `#RRGGBB` or `#RRGGBBAA`. Anything else — a named colour, an `rgb()`
     * function, a truncated string — returns `null` and the built-in survives.
     */
    @Suppress(
        "ReturnCount",
        // Reason: each early return is one distinct way a tenant value can be
        // malformed (absent, wrong length, not hex). Collapsing them would hide
        // which validation rejected the value.
    )
    private fun ContentBundle.hex(key: String): Color? {
        val raw = textOrNull(key)?.trim()?.removePrefix("#") ?: return null
        if (raw.length != RGB_LENGTH && raw.length != RGBA_LENGTH) return null
        val value = raw.toLongOrNull(radix = 16) ?: return null
        return if (raw.length == RGB_LENGTH) {
            Color(value or OPAQUE_ALPHA)
        } else {
            // Wire order is RRGGBBAA; Compose's Long constructor wants AARRGGBB.
            val alpha = value and 0xFF
            Color((alpha shl 24) or (value ushr 8))
        }
    }

    /** Accepts `"10px"` or a bare `"10"`. */
    private fun ContentBundle.pixels(key: String): Float? =
        textOrNull(key)
            ?.trim()
            ?.removeSuffix("px")
            ?.toFloatOrNull()
            ?.takeIf { it >= 0f }

    private const val HOVER_MIX = 0.91f
    private const val ACTIVE_MIX = 0.83f
    private const val BG_TINT_MIX = 0.08f
    private const val BASE_RADIUS_DP = 8f
    private const val MIN_RADIUS_SCALE = 0.25f
    private const val MAX_RADIUS_SCALE = 3f
    private const val RGB_LENGTH = 6
    private const val RGBA_LENGTH = 8
    private const val OPAQUE_ALPHA = 0xFF000000L
}
