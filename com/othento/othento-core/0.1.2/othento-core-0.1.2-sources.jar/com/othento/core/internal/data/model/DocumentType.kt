package com.othento.core.internal.data.model

/**
 * A document's behavioural identity, normalised from the backend's
 * `documentTypeCode`.
 *
 * This exists because `typeName` cannot carry identity. It is an
 * admin-editable display string, and once the backend localises it — or an
 * admin simply renames it — it stops containing the English word the old
 * heuristics matched on. Every behavioural branch (MRZ-vs-card detection,
 * capture guide, intro copy, icon) therefore keys off the type, leaving
 * `typeName` to do the only thing it can do honestly: render as text.
 *
 * [Other] is load-bearing, not a leftover. Document types are admin-managed,
 * so production holds codes this build has never seen; they must degrade to
 * the generic card path exactly as an unrecognised name did before.
 */
internal enum class DocumentType {
    Passport,
    IdCard,
    DriversLicense,
    ResidencePermit,
    Other,
}

/**
 * The backend's `documentTypeCode` → our vocabulary.
 *
 * ⚠️ The ID card is seeded under **both** `id` and `id_card`. The written API
 * spec lists `id_card`; the live `/document-types` rows use `id`, and the live
 * SDK-content bundle carries `documentType.id` *and* `documentType.id_card`.
 * Mapping only one of them would be silent: an unmatched code falls to [Other],
 * which renders the generic icon and — because `documentType.<code>` then
 * resolves to nothing — quietly falls back to the backend's English `typeName`.
 * Nothing throws; the screen just speaks English inside an Arabic session.
 *
 * Keys are the backend's CODES, values our [DocumentType]. They are not
 * required to correspond one-to-one, and for `id` they deliberately do not.
 */
private val TYPE_BY_CODE: Map<String, DocumentType> =
    mapOf(
        "passport" to DocumentType.Passport,
        "id" to DocumentType.IdCard,
        "id_card" to DocumentType.IdCard,
        "drivers_license" to DocumentType.DriversLicense,
        "residence_permit" to DocumentType.ResidencePermit,
    )

/** Normalise a backend `documentTypeCode`. Case-insensitive per the API contract. */
internal fun documentTypeOf(code: String?): DocumentType =
    TYPE_BY_CODE[code.orEmpty().trim().lowercase()] ?: DocumentType.Other
