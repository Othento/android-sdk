package com.othento.core.internal.ui.screens.common

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.content

/**
 * Shared label for the explicit "close the SDK" CTA on every terminal /
 * error screen. The SDK never auto-finishes the host Activity — the user
 * tapping this is the one and only path back to the host app.
 *
 * Was a `const val` until `layout.returnToApp` was seeded. It stays a single
 * shared definition rather than eight `content(...)` calls: the point of the
 * constant was that every terminal screen says the same thing, and that is
 * still worth enforcing in one place now that the string is fetched.
 */
@Composable
@ReadOnlyComposable
internal fun returnToAppLabel(): String = content(ContentKeys.LAYOUT_RETURN_TO_APP)
