package com.othento.core.internal.network.dto

import com.othento.core.internal.data.model.LivenessChallengeMode
import com.squareup.moshi.JsonClass

/**
 * Body for both `POST …/liveness/rekognition/start` and `…/complete`.
 *
 * `attemptStepId` is sent by the client (sourced from
 * `session.currentStep.attemptStepId`) — the backend does not mint it. The
 * same value goes on both calls.
 */
@JsonClass(generateAdapter = true)
internal data class RekognitionStartRequestDto(
    val attemptStepId: String,
)

/**
 * `POST …/liveness/rekognition/start` response. Only [sessionId] is
 * load-bearing for the client; the rest is echoed context.
 */
@JsonClass(generateAdapter = true)
internal data class RekognitionStartResponseDto(
    val sessionId: String,
    val challengeMode: LivenessChallengeMode? = null,
    val photosensitivity: Boolean = false,
    val attemptStepId: String? = null,
)

/**
 * `GET …/liveness/rekognition/credentials` — short-lived STS credentials
 * scoped to `rekognition:StartFaceLivenessSession` (see
 * `ekyc-frontend/docs/face-liveness-backend-credentials-spec.md`).
 *
 * [expiration] is an ISO-8601 UTC string. Unlike web — which strips it because
 * the JS signer wants a `Date` and treats a string as invalid — Android parses
 * it: the typed credential factory takes an expiry and the streaming client
 * uses it.
 */
@JsonClass(generateAdapter = true)
internal data class RekognitionCredentialsDto(
    val accessKeyId: String,
    val secretAccessKey: String,
    val sessionToken: String? = null,
    val expiration: String? = null,
)

/**
 * Advisory `liveness` object on a Rekognition challenge. Present only on that
 * challenge type, and not guaranteed even there.
 */
@JsonClass(generateAdapter = true)
internal data class LivenessHintDto(
    val provider: String? = null,
    val challengeMode: LivenessChallengeMode? = null,
    val region: String? = null,
    val photosensitivity: Boolean = false,
)
