package com.othento.core.internal.capture

import com.othento.core.internal.content.ContentKeys as CK

/**
 * The positioning nudges the detection pipeline can raise, as an enum rather
 * than the sentence itself.
 *
 * [DetectionPipeline] runs on the CameraX analyzer thread, which is not the
 * composition — it cannot read `LocalContent`, so it cannot produce translated
 * copy. Emitting the enum and resolving it at render time (`captureHintText`)
 * is what lets the same nudge be Arabic on an Arabic session, and it is the
 * pattern `capture.quality.*` already uses through
 * [com.othento.core.internal.ui.components.qualityWarningText].
 *
 * [fallbackText] is the offline value only — the string the pill showed before
 * the bundle reached it, kept byte-identical so a no-backend render is
 * unchanged.
 */
internal enum class CaptureHint(
    val key: String,
    val fallbackText: String,
) {
    MoveCloser(CK.CAPTURE_HINT_MOVE_CLOSER, "Move the document closer"),
    MoveFurther(CK.CAPTURE_HINT_MOVE_FURTHER, "Move the document further away"),
    PassportAlign(CK.CAPTURE_HINT_PASSPORT_ALIGN, "Align the passport inside the frame"),
    PassportMoveFurther(CK.CAPTURE_HINT_PASSPORT_MOVE_FURTHER, "Move the passport farther away"),
    PassportMoveLeft(CK.CAPTURE_HINT_PASSPORT_MOVE_LEFT, "Move the passport left"),
    PassportMoveRight(CK.CAPTURE_HINT_PASSPORT_MOVE_RIGHT, "Move the passport right"),

    /**
     * Android-only: the web pipeline has no "passport too far" state, so the
     * contract carries no `capture.hint.passport.moveCloser`. It resolves
     * against the generic document key instead — a passport *is* the document
     * on that screen, so the sentence reads correctly and, more to the point,
     * it is translated. Swap the key if the contract ever grows the specific
     * one.
     */
    PassportMoveCloser(CK.CAPTURE_HINT_MOVE_CLOSER, "Move the passport closer"),
}
