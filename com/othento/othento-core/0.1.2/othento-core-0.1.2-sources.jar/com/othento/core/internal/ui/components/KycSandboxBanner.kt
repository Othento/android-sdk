@file:Suppress("FunctionNaming", "MagicNumber")

package com.othento.core.internal.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.content
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/**
 * Top sandbox-mode warning strip. Faithful port of `sdk-sandbox-banner` in
 * `apps/sdk/.../sdk-layout.scss:43-60`:
 *
 * - `display: flex / align-items: center / justify-content: center / gap: 6px`
 * - `background: var(--color-warning-bg)`
 * - `border-radius: var(--radius-sm) var(--radius-sm) 0 0`
 * - `padding: 4px 12px`
 * - `font-size: 11 / weight: 500 / color: #92400e`
 * - inner `svg { width: 12px; height: 12px }` with `stroke="#F59E0B"`
 *
 * The full SdkLayout shell that ordinarily hosts this banner is Phase-4
 * territory; the banner ships in Phase 2 as a standalone primitive. The
 * web banner sits *between the screen body and the footer* — production
 * callers should anchor the banner directly above the footer container so
 * the rounded-top / flat-bottom corners hide flush against the footer.
 */
@Composable
internal fun KycSandboxBanner(
    modifier: Modifier = Modifier,
    text: String = content(ContentKeys.LAYOUT_SANDBOX_BADGE),
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val topRadius = 4.dp // matches `--radius-sm` per spec design-system §4
    Row(
        modifier =
            modifier
                .fillMaxWidth()
                .background(
                    color = colors.warningBg,
                    shape =
                        RoundedCornerShape(
                            topStart = topRadius,
                            topEnd = topRadius,
                            bottomStart = 0.dp,
                            bottomEnd = 0.dp,
                        ),
                ).padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        KycIcon(
            imageVector = OthentoIcons.WarningTriangle,
            contentDescription = null,
            sizeDp = 12.dp,
            tint = SandboxStrokeColor,
        )
        Text(
            text = text,
            style = typography.sandboxBanner,
            color = SandboxTextColor,
        )
    }
}

private val SandboxStrokeColor = Color(0xFFF59E0B)
private val SandboxTextColor = Color(0xFF92400E)
