package com.othento.core.internal.data.model

/**
 * Which Rekognition challenge the backend configured for this session.
 *
 * [Unknown] is the tolerant-decoding sentinel and is **not** the same as
 * "no mode": both suppress the photosensitivity warning, because that warning
 * is only correct for [FaceMovementAndLight] (the mode that flashes coloured
 * lights). Guessing it on is worse than omitting it.
 */
internal enum class LivenessChallengeMode {
    FaceMovementAndLight,
    FaceMovement,
    Unknown,
}

/**
 * Advisory hint the backend attaches to a Rekognition challenge. Every field
 * may be absent — the screen must behave sensibly without it.
 *
 * [region] is parsed but deliberately ignored: the streaming region is a
 * build-time constant
 * ([com.othento.core.internal.liveness.RekognitionConfig.REGION]), matching
 * web. The backend's `CreateFaceLivenessSession` call and the client's
 * streaming connection must target the same region, and the client has no way
 * to verify a server-supplied one.
 */
internal data class LivenessHint(
    val provider: String?,
    val challengeMode: LivenessChallengeMode?,
    val photosensitivity: Boolean,
    val region: String?,
)
