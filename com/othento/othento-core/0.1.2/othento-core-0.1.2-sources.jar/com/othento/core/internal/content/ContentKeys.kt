@file:Suppress("TooManyFunctions")

package com.othento.core.internal.content

/**
 * Every key name in the `GET /api/v1/SdkContent` phase-1 contract
 * (`docs/sdk-copy-bundle.json`, 206 keys), plus the three server-computed
 * `i18n.*` keys that ride along in the same response.
 *
 * Screens reference keys through these constants so a rename is a compile
 * error rather than a silently-blank string. A constant existing here is
 * **not** a claim that something reads it — see plan §4.10; the reachability
 * audit is a separate exercise.
 *
 * Phase 2 (86 further keys, `docs/sdk-copy-bundle-phase2.json`) is not seeded
 * on the backend yet. Keys marked `// P2` below are declared so the readers
 * can be written once and light up when the backend serves them; until then
 * they resolve through the normal `fetched ?: fallback ?: ""` chain.
 */
@Suppress("TopLevelPropertyNaming")
internal object ContentKeys {
    // ---- i18n (computed server-side, not in the bundle files) ------------

    const val I18N_LANGUAGE = "i18n.language"
    const val I18N_DIRECTION = "i18n.direction"
    const val I18N_AVAILABLE = "i18n.available"

    // ---- theme -----------------------------------------------------------

    const val THEME_COLOR_PRIMARY = "theme.color.primary"
    const val THEME_COLOR_SECONDARY = "theme.color.secondary"
    const val THEME_COLOR_TEXT_HEADING = "theme.color.textHeading"
    const val THEME_COLOR_TEXT_PRIMARY = "theme.color.textPrimary"
    const val THEME_COLOR_TEXT_SECONDARY = "theme.color.textSecondary"
    const val THEME_COLOR_TEXT_MUTED = "theme.color.textMuted"
    const val THEME_COLOR_TEXT_DISABLED = "theme.color.textDisabled"
    const val THEME_COLOR_BORDER = "theme.color.border"
    const val THEME_COLOR_BORDER_HOVER = "theme.color.borderHover"
    const val THEME_COLOR_BG_BASE = "theme.color.bgBase"
    const val THEME_COLOR_BG_LAYOUT = "theme.color.bgLayout"
    const val THEME_COLOR_BG_CONTAINER = "theme.color.bgContainer"
    const val THEME_COLOR_BG_ELEVATED = "theme.color.bgElevated"
    const val THEME_COLOR_BG_HOVER = "theme.color.bgHover"
    const val THEME_BRAND_NAME = "theme.brand.name"
    const val THEME_BRAND_LOGO_URL = "theme.brand.logoUrl"

    /** No dark-surface consumer in any SDK today — plan §8.5. Declared, inert. */
    const val THEME_BRAND_LOGO_URL_ON_DARK = "theme.brand.logoUrlOnDark"

    /** A CSS font stack. Inert on Android — custom tenant fonts are out of scope (plan §8.4). */
    const val THEME_FONT_FAMILY = "theme.font.family"
    const val THEME_SHAPE_BORDER_RADIUS = "theme.shape.borderRadius"

    // ---- layout / trust chrome -------------------------------------------

    const val LAYOUT_SECURED_BY = "layout.securedBy"
    const val LAYOUT_ENCRYPTED = "layout.encrypted"
    const val LAYOUT_SANDBOX_BADGE = "layout.sandboxBadge"

    /**
     * The "close the SDK" CTA on every terminal screen. Android-only: web closes
     * a tab, so this had no key until the native sweep. The SDK never
     * auto-finishes the host Activity, which makes this the last string most
     * sessions render.
     */
    const val LAYOUT_RETURN_TO_APP = "layout.returnToApp"

    // ---- step list ---------------------------------------------------------
    //
    // `steps.name.*` is keyed by the backend's `stepCode`, so the lookup is
    // `STEPS_NAME_PREFIX + stepCode` rather than five constants the compiler
    // could check. A step code this build does not recognise therefore still
    // resolves if the backend seeds copy for it — which is the point, since new
    // step types ship on the backend first.

    const val STEPS_NAME_PREFIX = "steps.name."
    const val STEPS_DETAIL_ID_VERIFICATION = "steps.detail.idVerification"
    const val STEPS_DETAIL_FACE_MATCH = "steps.detail.faceMatch"
    const val STEPS_DETAIL_LIVENESS_CHECK = "steps.detail.livenessCheck"
    const val STEPS_DETAIL_PHONE_VERIFICATION = "steps.detail.phoneVerification"
    const val STEPS_DETAIL_EMAIL_VERIFICATION = "steps.detail.emailVerification"
    const val STEPS_INDEX_LABEL = "steps.indexLabel"

    /** "Step 2 of 3" in the guided header — carries **both** `{index}` and `{total}`. */
    const val STEPS_PROGRESS_LABEL = "steps.progressLabel"

    /**
     * NOT SEEDED YET — the "3 steps" half of the start screen's meta pill.
     *
     * The contract has no key for it and the web hard-codes the English word
     * (`kyc-step-list.html`: `{{ steps().length }} steps`), so this is the one
     * pill on the screen that could not translate on either platform. Android
     * previously pointed it at [STEPS_PROGRESS_LABEL], whose value is
     * "Step {index} of {total}" — with only `{total}` bound, users read a
     * literal "Step {index} of 5".
     *
     * Declared with `.one` / `.other` siblings so it resolves through the normal
     * fallback chain until the backend seeds it.
     */
    const val STEPS_COUNT_LABEL = "steps.countLabel"

    // ---- accessibility -----------------------------------------------------
    //
    // Content descriptions are read aloud, never drawn. They are the one string
    // family whose omission is invisible in a screenshot and in every Paparazzi
    // snapshot, which is why they went unwired longest.

    const val A11Y_SHOW_TIPS = "a11y.showTips"
    const val A11Y_STEPS_TO_REDO = "a11y.stepsToRedo"
    const val A11Y_CONTINUE_ON_PHONE = "a11y.continueOnPhone"
    const val A11Y_DISMISS_UPLOAD_SHEET = "a11y.dismissUploadSheet"
    const val A11Y_ALT_CAPTURED_SELFIE = "a11y.alt.capturedSelfie"
    const val A11Y_ALT_CAPTURED_DOCUMENT = "a11y.alt.capturedDocument"
    const val A11Y_ALT_DOCUMENT_PREVIEW = "a11y.alt.documentPreview"
    const val A11Y_BACK = "a11y.back"

    /**
     * NOT SEEDED YET — the loading screen's TalkBack announcement.
     *
     * Android-only: web has no equivalent because the screen is a live region
     * there, announced from the visible text. Ours has no visible text to
     * announce, so the string exists solely to be read aloud — which is exactly
     * why it survived every screenshot review.
     */
    const val A11Y_LOADING = "a11y.loading"

    // ---- start -----------------------------------------------------------

    const val START_TITLE = "start.title"
    const val START_SUBTITLE_STEPS = "start.subtitle.steps"
    const val START_SUBTITLE_MOBILE_REQUIRED = "start.subtitle.mobileRequired"
    const val START_QR_TITLE = "start.qr.title"
    const val START_QR_HELP = "start.qr.help"
    const val START_QR_ASIDE_TITLE = "start.qrAside.title"
    const val START_QR_ASIDE_SUBTITLE = "start.qrAside.subtitle"

    /**
     * The start CTA label. Seeded as `start.cta.begin`, **not** `start.cta` —
     * the leaf names the action, leaving room for a second CTA later. Reading
     * the prefix instead resolved nothing and fell through to the built-in in
     * every language, which is invisible precisely because the fallback works.
     */
    const val START_CTA = "start.cta.begin"

    // ---- backend-identifier prefixes ---------------------------------------
    //
    // Three families are keyed by a value the BACKEND chooses, not by a
    // constant this build can spell out: a document's `documentTypeCode`, a
    // session's `declineReasonKey`, and an error response's `code`. Each is
    // looked up as `PREFIX + identifier` through `ContentBundle.resolveBackendCopy`,
    // which falls back to the backend's English so a key we have not authored
    // yet degrades to a sentence rather than to blank.
    //
    // They are prefixes precisely because the value set is open: document
    // types are admin-managed and the error enum grows server-side, so
    // enumerating them here would turn every backend addition into an app
    // release.

    /** `documentType.<code>` — e.g. `documentType.passport`, `documentType.id`. */
    const val DOCUMENT_TYPE_PREFIX = "documentType."

    /** `decline.<reasonKey>` — e.g. `decline.otp_max_send_attempts`. */
    const val DECLINE_PREFIX = "decline."

    // ---- document select --------------------------------------------------

    const val DOCUMENT_SELECT_TITLE = "documentSelect.title"
    const val DOCUMENT_SELECT_SUBTITLE = "documentSelect.subtitle"
    const val DOCUMENT_SELECT_COUNTRY_LABEL = "documentSelect.countryLabel"
    const val DOCUMENT_SELECT_COUNTRY_PLACEHOLDER = "documentSelect.countryPlaceholder"
    const val DOCUMENT_SELECT_TYPE_LABEL = "documentSelect.typeLabel"
    const val DOCUMENT_SELECT_LOAD_ERROR = "documentSelect.loadError"
    const val DOCUMENT_SELECT_CTA_CONTINUE = "documentSelect.cta.continue"

    // ---- idv intro sheets -------------------------------------------------

    /**
     * Document-kind prefixes. The three kinds are separate whole key families
     * rather than one family plus an interpolated document noun — inserting a
     * translated word into a sentence is what the contract forbids (plan §3.1).
     * Compose them with the `SUFFIX_INTRO_*` constants below.
     */
    const val IDV_ID_CARD = "idv.idCard"
    const val IDV_ID_CARD_BACK = "idv.idCardBack"
    const val IDV_PASSPORT = "idv.passport"
    const val SELFIE = "selfie"
    const val LIVENESS = "liveness"

    const val SUFFIX_INTRO_EYEBROW = ".intro.eyebrow"
    const val SUFFIX_INTRO_TITLE = ".intro.title"
    const val SUFFIX_INTRO_SUBTITLE = ".intro.subtitle"
    const val SUFFIX_INTRO_TIPS = ".intro.tips"
    const val SUFFIX_INTRO_TIP_CARDS = ".intro.tipCards"

    const val IDV_ID_CARD_INTRO_EYEBROW = "idv.idCard.intro.eyebrow"
    const val IDV_ID_CARD_INTRO_TITLE = "idv.idCard.intro.title"
    const val IDV_ID_CARD_INTRO_SUBTITLE = "idv.idCard.intro.subtitle"
    const val IDV_ID_CARD_INTRO_TIPS = "idv.idCard.intro.tips"
    const val IDV_ID_CARD_INTRO_TIP_CARDS = "idv.idCard.intro.tipCards"

    const val IDV_ID_CARD_BACK_INTRO_EYEBROW = "idv.idCardBack.intro.eyebrow"
    const val IDV_ID_CARD_BACK_INTRO_TITLE = "idv.idCardBack.intro.title"
    const val IDV_ID_CARD_BACK_INTRO_SUBTITLE = "idv.idCardBack.intro.subtitle"
    const val IDV_ID_CARD_BACK_INTRO_TIPS = "idv.idCardBack.intro.tips"
    const val IDV_ID_CARD_BACK_INTRO_TIP_CARDS = "idv.idCardBack.intro.tipCards"

    const val IDV_PASSPORT_INTRO_EYEBROW = "idv.passport.intro.eyebrow"
    const val IDV_PASSPORT_INTRO_TITLE = "idv.passport.intro.title"
    const val IDV_PASSPORT_INTRO_SUBTITLE = "idv.passport.intro.subtitle"
    const val IDV_PASSPORT_INTRO_TIPS = "idv.passport.intro.tips"
    const val IDV_PASSPORT_INTRO_TIP_CARDS = "idv.passport.intro.tipCards"

    // ---- idv capture chrome ------------------------------------------------

    const val IDV_CAPTURE_CHANGE_DOCUMENT = "idv.capture.changeDocument"
    const val IDV_CAPTURE_SIDE_FRONT = "idv.capture.side.front"
    const val IDV_CAPTURE_SIDE_BACK = "idv.capture.side.back"
    const val IDV_CAPTURE_TITLE_FRONT = "idv.capture.title.front"
    const val IDV_CAPTURE_TITLE_BACK = "idv.capture.title.back"
    const val IDV_CAPTURE_UPLOAD_FILE = "idv.capture.uploadFile"
    const val IDV_CAPTURE_CHECKING_QUALITY = "idv.capture.checkingQuality"
    const val IDV_CAPTURE_REUPLOAD = "idv.capture.reupload"
    const val IDV_CAPTURE_CONTINUE = "idv.capture.continue"
    const val IDV_CAPTURE_UPLOAD_TITLE = "idv.capture.upload.title"
    const val IDV_CAPTURE_UPLOAD_SUBTITLE = "idv.capture.upload.subtitle"

    /**
     * The capture chrome-pill label used when the session carries no document
     * (upload-only tenants, or a pill rendered before the document lands).
     * Previously a hard-coded `"Document"`, which was the last English word on
     * an otherwise-translated capture screen.
     */
    const val IDV_CAPTURE_PILL_FALLBACK_FRONT = "idv.capture.pillFallback.front"
    const val IDV_CAPTURE_PILL_FALLBACK_BACK = "idv.capture.pillFallback.back"

    // ---- idv upload sheet ---------------------------------------------------

    const val IDV_UPLOAD_TITLE_FRONT = "idv.upload.title.front"
    const val IDV_UPLOAD_TITLE_BACK = "idv.upload.title.back"
    const val IDV_UPLOAD_TITLE_SINGLE = "idv.upload.title.single"
    const val IDV_UPLOAD_SELECT_PHOTO = "idv.upload.selectPhoto"
    const val IDV_UPLOAD_FORMATS_HINT = "idv.upload.formatsHint"
    const val IDV_UPLOAD_SIDE_UPLOADED_FRONT = "idv.upload.sideUploaded.front"
    const val IDV_UPLOAD_SIDE_UPLOADED_BACK = "idv.upload.sideUploaded.back"
    const val IDV_UPLOAD_DOCUMENT_UPLOADED = "idv.upload.documentUploaded"

    /**
     * Both carry a `{maxMb}` placeholder. The size ceiling is a client policy
     * constant, so it is substituted here rather than baked into the sentence —
     * the previous literal hard-coded "10 MB" and would have gone stale
     * silently the first time the limit moved.
     */
    const val IDV_UPLOAD_FILE_TOO_LARGE = "idv.upload.fileTooLarge"
    const val IDV_UPLOAD_MAX_SIZE_HINT = "idv.upload.maxSizeHint"
    const val IDV_UPLOAD_INVALID_FORMAT = "idv.upload.invalidFormat"

    /** A passport has one page, so `idv.capture.side.*` does not describe it. */
    const val IDV_UPLOAD_PASSPORT_PAGE_LABEL = "idv.upload.passportPageLabel"

    /**
     * The manual-upload sheet's bullet list, read with `ContentBundle.tips`.
     * Two families rather than one interpolated document noun, for the same
     * reason the intro sheets split by kind (plan §3.1).
     */
    const val IDV_UPLOAD_TIPS_DOCUMENT = "idv.upload.tips.document"
    const val IDV_UPLOAD_TIPS_PASSPORT = "idv.upload.tips.passport"

    // ---- capture guides (overlay PNGs) --------------------------------------

    const val CAPTURE_GUIDE_PASSPORT_IMAGE = "captureGuide.passport.image"
    const val CAPTURE_GUIDE_ID_CARD_IMAGE = "captureGuide.idCard.image"
    const val CAPTURE_GUIDE_ID_CARD_BACK_IMAGE = "captureGuide.idCardBack.image"
    const val CAPTURE_GUIDE_DOCUMENT_IMAGE = "captureGuide.document.image"

    // ---- intro illustration captions ----------------------------------------
    //
    // The words drawn *inside* the animated intro illustration, not the sheet's
    // own title. They sit on top of a hand-drawn Compose vector rather than a
    // fetched PNG, which is exactly why they were missed: nothing about the
    // drawing looks like copy until it renders in Arabic and stays English.

    const val INTRO_ILLUSTRATION_ID_CARD_CAPTION = "intro.illustration.idCard.caption"
    const val INTRO_ILLUSTRATION_ID_CARD_BACK_CAPTION = "intro.illustration.idCardBack.caption"
    const val INTRO_ILLUSTRATION_SELFIE_CAPTION = "intro.illustration.selfie.caption"
    const val INTRO_ILLUSTRATION_LIVENESS_CAPTION = "intro.illustration.liveness.caption"
    const val INTRO_ILLUSTRATION_PASSPORT_RIGHT = "intro.illustration.passport.right"
    const val INTRO_ILLUSTRATION_PASSPORT_WRONG = "intro.illustration.passport.wrong"

    // ---- runtime capture prompts / quality ----------------------------------

    const val CAPTURE_PROMPT_HOLD_STEADY = "capture.prompt.holdSteady"
    const val CAPTURE_PROMPT_POSITION_PASSPORT = "capture.prompt.positionPassport"
    const val CAPTURE_PROMPT_POSITION_DOCUMENT_FRONT = "capture.prompt.positionDocument.front"
    const val CAPTURE_PROMPT_POSITION_DOCUMENT_BACK = "capture.prompt.positionDocument.back"
    const val CAPTURE_NOTICE_DETECTION_UNAVAILABLE = "capture.notice.detectionUnavailable"
    const val CAPTURE_NOTICE_MANUAL_NUDGE = "capture.notice.manualNudge"
    const val CAPTURE_QUALITY_TOO_DARK = "capture.quality.tooDark"
    const val CAPTURE_QUALITY_TOO_BRIGHT = "capture.quality.tooBright"
    const val CAPTURE_QUALITY_BLURRY = "capture.quality.blurry"
    const val CAPTURE_QUALITY_GLARE = "capture.quality.glare"
    const val CAPTURE_QUALITY_NO_CARD = "capture.quality.noCard"
    const val CAPTURE_REVIEW_ISSUES_TITLE = "capture.review.issuesTitle"
    const val CAPTURE_REVIEW_RETAKE_ADVICE = "capture.review.retakeAdvice"
    const val CAPTURE_REVIEW_OK_TITLE = "capture.review.okTitle"
    const val CAPTURE_REVIEW_OK_SUBTITLE = "capture.review.okSubtitle"
    const val CAPTURE_REVIEW_LOOKS_GOOD = "capture.review.looksGood"
    const val CAPTURE_REVIEW_RETAKE = "capture.review.retake"
    const val CAPTURE_TIMEOUT_TITLE = "capture.timeout.title"
    const val CAPTURE_TIMEOUT_MESSAGE = "capture.timeout.message"
    const val CAPTURE_TIMEOUT_TRY_AGAIN = "capture.timeout.tryAgain"
    const val CAPTURE_TIMEOUT_UPLOAD_INSTEAD = "capture.timeout.uploadInstead"
    const val CAPTURE_SCAN_BUTTON = "capture.scanButton"
    const val CAPTURE_PREPARING_CAMERA = "capture.preparingCamera"
    const val CAPTURE_CAMERA_REQUIRED_TITLE = "capture.cameraRequired.title"
    /**
     * Body for **both** Android denial states. The first denial can re-prompt
     * and the permanent one cannot, but the difference is carried by the button
     * ([CAPTURE_CAMERA_REQUIRED_OPEN_SETTINGS] vs a retry) rather than by two
     * bodies — the value no longer names a mechanism, so one sentence covers it.
     */
    const val CAPTURE_CAMERA_REQUIRED_DENIED = "capture.cameraRequired.denied"
    const val CAPTURE_CAMERA_REQUIRED_OPEN_SETTINGS = "capture.cameraRequired.openSettings"
    const val CAPTURE_CAMERA_REQUIRED_NO_CAMERA = "capture.cameraRequired.noCamera"

    /**
     * Reads "Or not accessible on this device" — a **continuation**, not a
     * standalone sentence. The leading "Or" is the tell: web renders it directly
     * under [CAPTURE_CAMERA_REQUIRED_NO_CAMERA], so the two are one message split
     * across a title and a subtitle, and this key is meaningless on its own.
     */
    const val ERROR_DEVICE_CAMERA_NOT_ACCESSIBLE = "error.device.cameraNotAccessible"
    const val CAPTURE_FLASH_LABEL = "capture.flashLabel"
    const val CAPTURE_DETECT_PASSPORT_FAILED = "capture.detect.passportFailed"

    // ---- live framing hints (document) --------------------------------------
    //
    // These are the per-frame nudges the detection pipeline emits. They are
    // bound by **enum**, not by the pipeline's English `message`, for the same
    // reason `capture.quality.*` is: the analyzer runs off the Compose tree and
    // cannot read content, so its string is demoted to the offline fallback and
    // the enum selects the copy at render time (see `DetectionHintText`).

    const val CAPTURE_HINT_MOVE_CLOSER = "capture.hint.moveCloser"
    const val CAPTURE_HINT_MOVE_FURTHER = "capture.hint.moveFurther"
    const val CAPTURE_HINT_ADJUST_POSITION = "capture.hint.adjustPosition"
    const val CAPTURE_HINT_IMPROVE_LIGHTING = "capture.hint.improveLighting"
    const val CAPTURE_HINT_POSITION_IN_FRAME = "capture.hint.positionInFrame"
    const val CAPTURE_HINT_PASSPORT_ALIGN = "capture.hint.passport.align"
    const val CAPTURE_HINT_PASSPORT_MOVE_LEFT = "capture.hint.passport.moveLeft"
    const val CAPTURE_HINT_PASSPORT_MOVE_RIGHT = "capture.hint.passport.moveRight"
    const val CAPTURE_HINT_PASSPORT_MOVE_FURTHER = "capture.hint.passport.moveFurther"

    // ---- selfie ---------------------------------------------------------------

    const val SELFIE_INTRO_EYEBROW = "selfie.intro.eyebrow"
    const val SELFIE_INTRO_TITLE = "selfie.intro.title"
    const val SELFIE_INTRO_SUBTITLE = "selfie.intro.subtitle"
    const val SELFIE_INTRO_TIPS = "selfie.intro.tips"
    const val SELFIE_INTRO_TIP_CARDS = "selfie.intro.tipCards"
    const val SELFIE_INTRO_BUTTON = "selfie.intro.button"
    const val SELFIE_INTRO_HEADER_TITLE = "selfie.intro.headerTitle"
    const val SELFIE_INTRO_HEADER_SUBTITLE = "selfie.intro.headerSubtitle"
    const val SELFIE_CAPTURE_CHROME_PILL = "selfie.capture.chromePill"
    const val SELFIE_CAPTURE_TITLE = "selfie.capture.title"
    const val SELFIE_CAPTURE_STATUS_DEFAULT = "selfie.capture.statusDefault"
    const val SELFIE_CAPTURE_HOLD_STEADY = "selfie.capture.holdSteady"
    const val SELFIE_PREVIEW_USE = "selfie.preview.use"

    /**
     * The selfie review sheet's own heading. Deliberately **not**
     * `capture.review.okTitle` / `.okSubtitle`, whose values name a document
     * ("Make sure the document is clear and readable") and would read as
     * confidently wrong here in every language at once.
     */
    const val SELFIE_REVIEW_TITLE = "selfie.review.title"
    const val SELFIE_REVIEW_SUBTITLE = "selfie.review.subtitle"
    const val SELFIE_PREVIEW_CHECKING = "selfie.preview.checking"
    const val SELFIE_VALIDATION_NO_FACE = "selfie.validation.noFace"
    const val SELFIE_VALIDATION_MULTIPLE_FACES = "selfie.validation.multipleFaces"
    const val SELFIE_TIMEOUT_TITLE = "selfie.timeout.title"
    const val SELFIE_TIMEOUT_MESSAGE = "selfie.timeout.message"
    const val SELFIE_CAMERA_REQUIRED_DENIED = "selfie.cameraRequired.denied"

    /** Live face-framing nudges, bound by enum — see the `capture.hint.*` note. */
    const val SELFIE_HINT_CENTER_FACE = "selfie.hint.centerFace"
    const val SELFIE_HINT_MOVE_CLOSER = "selfie.hint.moveCloser"
    const val SELFIE_HINT_MOVE_FURTHER = "selfie.hint.moveFurther"
    const val SELFIE_HINT_MULTIPLE_FACES = "selfie.hint.multipleFaces"

    // ---- liveness ---------------------------------------------------------------

    const val LIVENESS_INTRO_EYEBROW = "liveness.intro.eyebrow"
    const val LIVENESS_INTRO_TITLE = "liveness.intro.title"
    const val LIVENESS_INTRO_SUBTITLE = "liveness.intro.subtitle"
    const val LIVENESS_INTRO_TIPS = "liveness.intro.tips"
    const val LIVENESS_INTRO_TIP_CARDS = "liveness.intro.tipCards"
    const val LIVENESS_INTRO_BUTTON = "liveness.intro.button"
    const val LIVENESS_CAPTURE_CHROME_PILL = "liveness.capture.chromePill"
    const val LIVENESS_CAPTURE_TITLE = "liveness.capture.title"
    const val LIVENESS_CAPTURE_STATUS_DEFAULT = "liveness.capture.statusDefault"
    const val LIVENESS_CONNECTING = "liveness.connecting"
    const val LIVENESS_TRY_AGAIN = "liveness.tryAgain"

    /**
     * The photosensitivity gate. Whether it is reachable is
     * `RekognitionLivenessStateHolder`'s decision; these are only its copy.
     */
    /**
     * The Rekognition challenge's own guidance strings. Most are rendered by
     * the AWS component and are not ours to set; the brightness pair is reused
     * by the passive selfie warning bubble, which is the only reason this
     * family is declared rather than left to the vendor.
     */
    const val LIVENESS_HINT_CENTER_FACE = "liveness.hint.centerFace"
    const val LIVENESS_HINT_FACE_OFF_CENTER = "liveness.hint.faceOffCenter"
    const val LIVENESS_HINT_GOOD_FIT = "liveness.hint.goodFit"
    const val LIVENESS_HINT_HOLD_STILL = "liveness.hint.holdStill"
    const val LIVENESS_HINT_LIGHTING_NORMAL = "liveness.hint.lightingNormal"
    const val LIVENESS_HINT_MOVE_BACK = "liveness.hint.moveBack"
    const val LIVENESS_HINT_MOVE_CLOSER = "liveness.hint.moveCloser"
    const val LIVENESS_HINT_MOVE_FACE_IN_FRONT = "liveness.hint.moveFaceInFrontOfCamera"
    const val LIVENESS_HINT_TOO_BRIGHT = "liveness.hint.tooBright"
    const val LIVENESS_HINT_TOO_DARK = "liveness.hint.tooDark"
    const val LIVENESS_HINT_TOO_MANY_FACES = "liveness.hint.tooManyFaces"
    const val LIVENESS_HINT_VERIFYING = "liveness.hint.verifying"

    const val LIVENESS_WARNING_TITLE = "liveness.warning.title"
    const val LIVENESS_WARNING_BODY = "liveness.warning.body"
    const val LIVENESS_WARNING_CONTINUE_BUTTON = "liveness.warning.continueButton"

    // ---- otp -----------------------------------------------------------------

    const val OTP_PHONE_TITLE = "otp.phone.title"
    const val OTP_PHONE_SUBTITLE = "otp.phone.subtitle"
    const val OTP_PHONE_EDITING_SUBTITLE = "otp.phone.editingSubtitle"
    const val OTP_PHONE_LABEL = "otp.phone.label"
    const val OTP_PHONE_STEP_TITLE = "otp.phone.stepTitle"
    const val OTP_PHONE_STEP_SUBTITLE = "otp.phone.stepSubtitle"
    const val OTP_PHONE_CODE_TITLE = "otp.phone.codeTitle"
    const val OTP_PHONE_CHANGE_BUTTON = "otp.phone.changeButton"
    const val OTP_PHONE_TIP = "otp.phone.tip"

    const val OTP_EMAIL_TITLE = "otp.email.title"
    const val OTP_EMAIL_SUBTITLE = "otp.email.subtitle"
    const val OTP_EMAIL_EDITING_SUBTITLE = "otp.email.editingSubtitle"
    const val OTP_EMAIL_LABEL = "otp.email.label"
    const val OTP_EMAIL_STEP_TITLE = "otp.email.stepTitle"
    const val OTP_EMAIL_STEP_SUBTITLE = "otp.email.stepSubtitle"
    const val OTP_EMAIL_CODE_TITLE = "otp.email.codeTitle"
    const val OTP_EMAIL_CHANGE_BUTTON = "otp.email.changeButton"
    const val OTP_EMAIL_TIP = "otp.email.tip"

    const val OTP_CODE_SUBTITLE = "otp.code.subtitle"
    const val OTP_SEND_INITIAL = "otp.send.initial"
    const val OTP_SEND_RESEND = "otp.send.resend"
    const val OTP_SEND_LOADING = "otp.send.loading"
    const val OTP_VERIFY = "otp.verify"
    const val OTP_VERIFY_LOADING = "otp.verify.loading"
    const val OTP_RESEND_PROMPT = "otp.resendPrompt"
    const val OTP_CANCEL = "otp.cancel"
    const val OTP_SECURITY = "otp.security"
    const val OTP_ERROR_EXPIRED_TITLE = "otp.error.expired.title"
    const val OTP_ERROR_EXPIRED_BODY = "otp.error.expired.body"
    const val OTP_ERROR_EXPIRED_BUTTON = "otp.error.expired.button"
    const val OTP_ERROR_INVALID_TITLE = "otp.error.invalid.title"
    const val OTP_ERROR_INVALID_BODY = "otp.error.invalid.body"
    const val OTP_ERROR_INVALID_BUTTON = "otp.error.invalid.button"

    const val OTP_SEND_RESEND_IN = "otp.send.resendIn"
    const val OTP_SKIP_TITLE = "otp.skip.title"
    const val OTP_SKIP_BUTTON = "otp.skip.button"

    /**
     * The third verify dialog. `OTP_NOT_REQUESTED` used to be indistinguishable
     * from `OTP_EXPIRED` because both are HTTP 410 — so a user who had never
     * requested a code was told their code had expired, and the dialog's
     * primary button pointed at a resend with a null contact, which did
     * nothing at all when tapped.
     */
    const val OTP_ERROR_NOT_REQUESTED_TITLE = "otp.error.notRequested.title"
    const val OTP_ERROR_NOT_REQUESTED_BODY = "otp.error.notRequested.body"
    const val OTP_ERROR_NOT_REQUESTED_BUTTON = "otp.error.notRequested.button"

    const val OTP_ERROR_INVALID_INLINE = "otp.error.invalidInline"
    const val OTP_ERROR_SEND_FAILED_INLINE = "otp.error.sendFailedInline"
    const val OTP_ERROR_DISMISS = "otp.error.dismiss"
    const val OTP_ERROR_CORPORATE_EMAIL_REQUIRED = "otp.error.corporateEmailRequired"
    const val OTP_ERROR_INVALID_EMAIL_FORMAT = "otp.error.invalidEmailFormat"
    const val OTP_ERROR_SESSION_NOT_FOUND = "otp.error.sessionNotFound"

    /**
     * Resend-cooldown rejection. The countdown-free [OTP_ERROR_COOLDOWN_ACTIVE]
     * is what we render: the backend embeds the remaining seconds in its
     * English prose only, and parsing a number back out of a sentence is
     * exactly the pattern this whole change removes. The `{seconds}` variant is
     * declared for the day the backend returns the value as its own field.
     */
    const val OTP_ERROR_COOLDOWN_ACTIVE = "otp.error.cooldownActive"
    const val OTP_ERROR_COOLDOWN_ACTIVE_SECONDS = "otp.error.cooldownActiveSeconds"

    // ---- otp destination inputs ------------------------------------------------

    const val OTP_PHONE_PLACEHOLDER = "otp.phone.placeholder"
    const val OTP_PHONE_COUNTRY_CODE_LABEL = "otp.phone.countryCodeLabel"
    const val OTP_PHONE_COUNTRY_SEARCH_PLACEHOLDER = "otp.phone.countrySearchPlaceholder"
    const val OTP_PHONE_NO_COUNTRY_MATCH = "otp.phone.noCountryMatch"

    /**
     * Validation messages, bound by the validator's result enum rather than by
     * the message it carries — same rule as the capture hints. `PhoneValidator`
     * and `EmailValidator` are plain Kotlin, callable off the composition, so
     * their English strings stay as the offline fallback.
     */
    const val OTP_PHONE_ERROR_TOO_SHORT = "otp.phone.error.tooShort"
    const val OTP_PHONE_ERROR_TOO_LONG = "otp.phone.error.tooLong"
    const val OTP_PHONE_ERROR_INVALID_LENGTH = "otp.phone.error.invalidLength"
    const val OTP_PHONE_ERROR_INVALID_COUNTRY = "otp.phone.error.invalidCountry"
    const val OTP_PHONE_ERROR_INVALID_NUMBER = "otp.phone.error.invalidNumber"
    const val OTP_PHONE_ERROR_NOT_VALID_FOR_COUNTRY = "otp.phone.error.notValidForCountry"

    const val OTP_EMAIL_ERROR_MISSING_AT = "otp.email.error.missingAt"
    const val OTP_EMAIL_ERROR_MISSING_LOCAL = "otp.email.error.missingLocal"
    const val OTP_EMAIL_ERROR_MISSING_DOMAIN = "otp.email.error.missingDomain"
    const val OTP_EMAIL_ERROR_MISSING_DOT = "otp.email.error.missingDot"
    const val OTP_EMAIL_ERROR_INVALID = "otp.email.error.invalid"

    // `otp.code.stepSubtitle` is deliberately NOT declared. The backend serves
    // it, nothing reads it, and the phase-2 hand-off asks for it to be deleted
    // (plan §8.3). Declaring a constant would invite a reader.

    // ---- uploading / failed retry --------------------------------------------

    const val UPLOADING_LABEL = "uploading.label"
    const val UPLOADING_ALMOST_DONE = "uploading.almostDone"
    const val UPLOADING_TAKING_LONGER = "uploading.takingLonger"
    const val FAILED_RETRY_CTA_TRY_AGAIN = "failedRetry.cta.tryAgain"
    const val FAILED_RETRY_TITLE = "failedRetry.title"
    const val FAILED_RETRY_SUBTITLE = "failedRetry.subtitle"
    const val FAILED_RETRY_ATTEMPTS = "failedRetry.attempts"
    const val FAILED_RETRY_MOBILE_REQUIRED = "failedRetry.mobileRequired"
    const val FAILED_RETRY_QR_TITLE = "failedRetry.qr.title"
    const val FAILED_RETRY_QR_HELP = "failedRetry.qr.help"
    const val FAILED_RETRY_STEPS_LABEL = "failedRetry.steps.label"

    // ---- result states --------------------------------------------------------

    /**
     * The nine result states. Eight are live today; `unsupported` is phase 2 —
     * enumerated from the start because it is the one state whose whole purpose
     * is to render on a client that is behind, so hard-coding its copy defeats
     * it (plan §6).
     */
    const val RESULT_APPROVED = "result.approved"
    const val RESULT_IN_REVIEW = "result.inReview"
    const val RESULT_FAILED = "result.failed"
    const val RESULT_DECLINED = "result.declined"
    const val RESULT_EXPIRED = "result.expired"
    const val RESULT_ERROR = "result.error"
    const val RESULT_PROCESSING = "result.processing"
    const val RESULT_PROCESSING_TIMED_OUT = "result.processing.timedOut"

    /** P2 — the "update required" screen for an unrecognised challenge type. */
    const val RESULT_UNSUPPORTED = "result.unsupported"

    const val RESULT_ERROR_CODE_LABEL = "result.error.codeLabel"

    // ---- end-user error copy --------------------------------------------------
    //
    // Only the errors a *verifying user* can actually hit are declared here. The
    // `error.config.*` family the backend also serves (missing API key, missing
    // workflow, missing client data) is deliberately absent: those fire when the
    // host app is wired up wrong, they are read by an integrator reading a
    // logcat trace, and translating them would make a stack-trace-adjacent
    // message harder to search for, not easier to read.
    //
    // These bind through `OthentoError`'s shape rather than by matching the
    // English `displayMessage`, the same rule the capture hints follow: the
    // mapper runs off the composition and cannot read content, so its string
    // stays as the offline fallback and the *kind* selects copy at render time.

    const val ERROR_SESSION_LOAD_FAILED = "error.session.loadFailed"
    const val ERROR_SESSION_CREATE_FAILED = "error.session.createFailed"
    const val ERROR_SESSION_RESTART_FAILED = "error.session.restartFailed"
    const val ERROR_CONTENT_UNAVAILABLE = "error.content.unavailable"
    const val ERROR_GENERIC_RETRY_HINT = "error.generic.retryHint"

    /** Suffixes appended to a `result.*` prefix above. */
    const val SUFFIX_TITLE = ".title"
    const val SUFFIX_DESCRIPTION = ".description"

    /**
     * Suffixes appended to an `otp.error.<kind>` prefix. The three verify
     * dialogs share one shape, so the kind selects the prefix and these name
     * the parts — see [com.othento.core.internal.data.contentPrefix].
     */
    const val SUFFIX_BODY = ".body"
    const val SUFFIX_BUTTON = ".button"

    const val SUFFIX_ICON = ".icon"
    const val SUFFIX_TONE = ".tone"
    const val SUFFIX_MODE = ".mode"

    /** Sibling plural suffixes for `plural(key, count)` (plan §3.1 / decision 6). */
    const val SUFFIX_ONE = ".one"
    const val SUFFIX_OTHER = ".other"
}
