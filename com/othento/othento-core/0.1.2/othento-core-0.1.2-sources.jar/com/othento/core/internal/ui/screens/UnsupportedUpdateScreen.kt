@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.ResultMode
import com.othento.core.internal.content.ResultTone
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.screens.common.ContentStatusScreen
import com.othento.core.internal.ui.screens.common.returnToAppLabel
import com.othento.core.internal.ui.screens.common.StatusAction

/**
 * `result.unsupported.*` — the ninth result state. Shown when the active
 * challenge needs something this SDK build cannot do: an unrecognised
 * `ChallengeType`, or a Rekognition challenge the bundled AWS component
 * reports as unsupported.
 *
 * This screen exists so that case is an explained dead end rather than a crash
 * or a silent mis-route into an unrelated capture screen.
 *
 * Warning rather than error tone: nothing has failed and the user has done
 * nothing wrong; their app is simply behind the backend.
 *
 * The keys are **phase 2 and not seeded yet**, so today this renders from
 * [com.othento.core.internal.content.ContentFallback]. That is by design — an
 * old build is exactly the audience for this screen, and it can only ever show
 * copy it already has. Once the backend serves the keys, a newer message
 * reaches older installs without a release.
 */
@Composable
internal fun UnsupportedUpdateScreen(onReturnToApp: () -> Unit) {
    ContentStatusScreen(
        prefix = ContentKeys.RESULT_UNSUPPORTED,
        fallbackIcon = StatusIconName.Exclamation,
        fallbackTone = ResultTone.Warning,
        fallbackMode = ResultMode.Terminal,
        primaryAction = StatusAction(label = returnToAppLabel(), onClick = onReturnToApp),
    )
}
