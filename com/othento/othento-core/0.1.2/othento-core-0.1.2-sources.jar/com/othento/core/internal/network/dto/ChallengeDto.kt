package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass
import com.othento.core.internal.data.model.ChallengeStatus
import com.othento.core.internal.data.model.ChallengeType

/**
 * Wire shape for a single evidence challenge inside the active step.
 *
 * Mirrors [docs/spec/09-data-models.md §2.2]. The OTP fields
 * (`otpExpiresAt`, `otpSize`, `otpAlphanumeric`) are present only on OTP
 * challenges and absent on document/selfie/liveness — declared nullable
 * here so Moshi accepts both shapes.
 *
 * [corporateEmailOnly] is an email-OTP policy flag the backend sends
 * alongside the OTP fields: when `true` the email step rejects public /
 * free email domains, matching the web portal register form's
 * "work email only" rule. Absent on every other challenge and defaulted
 * to `false`, so older backends (which never send it) keep the prior
 * "any valid email" behaviour.
 */
@JsonClass(generateAdapter = true)
internal data class ChallengeDto(
    val challengeType: ChallengeType,
    val challengeStatus: ChallengeStatus,
    val otpExpiresAt: String? = null,
    val otpSize: Int? = null,
    val otpAlphanumeric: Boolean? = null,
    val corporateEmailOnly: Boolean = false,
    /**
     * Advisory Rekognition hint. Absent on every other challenge type, and
     * optional even on a Rekognition challenge — nothing downstream may
     * require it.
     */
    val liveness: LivenessHintDto? = null,
)
