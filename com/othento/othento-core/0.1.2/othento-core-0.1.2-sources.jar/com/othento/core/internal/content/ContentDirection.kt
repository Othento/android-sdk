package com.othento.core.internal.content

import androidx.compose.ui.unit.LayoutDirection

/**
 * `i18n.direction` → the Compose layout direction the whole SDK renders in.
 *
 * The contract carries exactly two values, `"ltr"` and `"rtl"`. Anything else
 * resolves to [LayoutDirection.Ltr] rather than throwing — same safe-fallback
 * rule the `tone` / `mode` enums follow, so a backend that starts sending a
 * third value cannot brick a deployed build.
 *
 * The direction comes from the **backend's resolved language**, never from the
 * device locale. An Arabic phone running an English-only tenant must render
 * LTR, and an English phone on an Arabic session must render RTL; keying off
 * `Locale.getDefault()` would get both cases backwards.
 */
internal fun ContentBundle.layoutDirection(): LayoutDirection =
    if (direction().equals(DIRECTION_RTL, ignoreCase = true)) {
        LayoutDirection.Rtl
    } else {
        LayoutDirection.Ltr
    }

private const val DIRECTION_RTL = "rtl"
