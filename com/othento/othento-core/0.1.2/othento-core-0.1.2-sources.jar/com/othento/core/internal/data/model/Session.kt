package com.othento.core.internal.data.model

/**
 * Single normalized session shape consumed by the SDK's flow layer.
 *
 * The Android SDK does not split apiKey/token modes (see P9 in
 * `docs/spec/99-open-questions.md`) — every wire response is a
 * `TokenSessionResponseDto`, and this domain type mirrors it directly.
 * The `sessionToken` field carries a SAT on the create response and an
 * ST on later token-mode responses (distinguishable by the wire prefix
 * `sat:` vs `st:`).
 */
internal data class Session(
    val externalId: String,
    val desktopAccess: Boolean,
    val sessionUrl: String,
    val status: SessionStatus,
    val isSandbox: Boolean,
    val maxAttempts: Int,
    val attemptNumber: Int,
    val estimatedPrice: Double?,
    val expiresAt: String,
    val currentStep: ActiveStep?,
    val selectedDocument: SelectedDocument?,
    val steps: List<Step>,
    val canInitiate: Boolean,
    // Backend-driven retry contract (web parity). `canReinitiate` is the
    // token-mode retry gate (`Failed -> FailedRetry`); `reinitInfo` carries
    // the authoritative attempts-remaining + steps-to-retry metadata. Both
    // are optional additions, so they default — the mapper always sets them
    // explicitly from the wire response.
    val canReinitiate: Boolean = false,
    val reinitInfo: ReinitInfo? = null,
    val decision: Decision?,
    val sessionToken: String?,
    val sessionRetryToken: String?,
    val stExpiresAt: String?,
    val srtExpiresAt: String?,
    /**
     * Free-form English from the backend. Never render this when a key is
     * available — for inference declines it can carry raw text passed through
     * from the verification provider.
     */
    val declineMessage: String?,
    /** Stable decline-reason identifier; render `decline.<key>`, fall back to [declineMessage]. */
    val declineReasonKey: String? = null,
    /**
     * Language recorded on the session, used as the `?locale=` for the
     * SDK-content fetch. Defaults so existing construction sites (fixtures,
     * tests) compile unchanged.
     */
    val language: String? = null,
)
