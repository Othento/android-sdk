package com.othento.core.internal.data

import com.othento.core.internal.content.ContentKeys as CK

/**
 * Maps the backend's stable OTP error `code` onto our copy **and** our UI
 * treatment.
 *
 * Replaces two mechanisms that could not survive localisation:
 *
 *  1. **Branching on HTTP status.** Sibling cases share one — `OTP_EXPIRED`
 *     and `OTP_NOT_REQUESTED` are both 410 — so "410 means expired" told a
 *     user who had never requested a code that their code had expired, and
 *     pointed the dialog's primary button at a resend whose contact was null.
 *     That button did nothing at all when tapped.
 *  2. **A regex over the backend's English message**
 *     (`corporate|business|organization|company`) to detect the corporate-email
 *     policy. Matching prose stops working the moment the prose is not English.
 *
 * The table survives even though a key could be derived mechanically from the
 * code (`error.OTP_INVALID`), because a code also selects **behaviour** —
 * blocking dialog vs inline notice, and whether the primary action resends.
 * That is not derivable from a string. Given a table is needed regardless, the
 * keys stay in the bundle's existing dot-case house style rather than
 * introducing a second naming convention.
 */
internal sealed interface OtpErrorMapping {
    /** Opens the blocking result dialog. */
    data class Dialog(
        val kind: OtpVerifyErrorKind,
    ) : OtpErrorMapping

    /** Rendered inline under the field, from a single content key. */
    data class Inline(
        val contentKey: String,
    ) : OtpErrorMapping
}

/** The verify dialogs, keyed by error code rather than by status. */
internal enum class OtpVerifyErrorKind {
    /** Code expired; a resend is available. Primary action re-sends. */
    Expired,

    /** Wrong code, attempts remain. Primary action clears and retries. */
    Invalid,

    /**
     * Verify was called before any code was sent. Primary action sends the
     * first code — the same act as [Expired]'s resend, since in both cases the
     * user needs a code they do not have. Its button reads "Send code" rather
     * than "Send new code", which is the honest difference.
     */
    NotRequested,
}

/** `otp.error.*` key prefix for a dialog kind's `.title` / `.body` / `.button`. */
internal fun OtpVerifyErrorKind.contentPrefix(): String =
    when (this) {
        OtpVerifyErrorKind.Expired -> "otp.error.expired"
        OtpVerifyErrorKind.Invalid -> "otp.error.invalid"
        OtpVerifyErrorKind.NotRequested -> "otp.error.notRequested"
    }

private val MAPPING_BY_CODE: Map<String, OtpErrorMapping> =
    mapOf(
        "OTP_INVALID" to OtpErrorMapping.Dialog(OtpVerifyErrorKind.Invalid),
        "OTP_EXPIRED" to OtpErrorMapping.Dialog(OtpVerifyErrorKind.Expired),
        "OTP_NOT_REQUESTED" to OtpErrorMapping.Dialog(OtpVerifyErrorKind.NotRequested),
        "CORPORATE_EMAIL_REQUIRED" to OtpErrorMapping.Inline(CK.OTP_ERROR_CORPORATE_EMAIL_REQUIRED),
        "INVALID_EMAIL_FORMAT" to OtpErrorMapping.Inline(CK.OTP_ERROR_INVALID_EMAIL_FORMAT),
        "OTP_SEND_FAILED" to OtpErrorMapping.Inline(CK.OTP_ERROR_SEND_FAILED_INLINE),
        "COOLDOWN_ACTIVE" to OtpErrorMapping.Inline(CK.OTP_ERROR_COOLDOWN_ACTIVE),
        "NOT_FOUND" to OtpErrorMapping.Inline(CK.OTP_ERROR_SESSION_NOT_FOUND),
        // VALIDATION_ERROR is deliberately absent: the backend states it
        // signals an integration mistake, not something an end user can act
        // on. It falls through to the generic inline message rather than
        // surfacing diagnostics to a verifying user.
    )

/**
 * Look up an error code.
 *
 * Returns `null` for an absent or unrecognised code so the caller degrades to
 * the backend's English message — a code the backend adds later must read as
 * English, never as a blank screen.
 */
internal fun otpErrorFor(code: String?): OtpErrorMapping? =
    code?.trim()?.takeIf { it.isNotEmpty() }?.let { MAPPING_BY_CODE[it.uppercase()] }
