package com.othento.core.internal.flow

import com.othento.core.internal.data.model.Session
import com.othento.core.internal.data.model.SessionStatus

/**
 * Polling cadence selector. [Background] — AML / inference running server-side
 * with no user action left — polls faster and for a longer window than the
 * [Default] inference wait. See [SessionConfig] `background*` fields and
 * [isBackgroundProcessing]. Mirrors the web SDK's `PollingProfile`
 * ([apps/sdk/.../services/session/session-adapter.ts]).
 */
internal enum class PollingProfile {
    Default,
    Background,
}

/**
 * True when the session is in progress server-side with nothing left for the
 * user to do — e.g. AML / inference running in the background after all steps
 * are submitted. Mirrors the web SDK's `isBackgroundProcessing`
 * ([apps/sdk/.../services/session/background-processing.util.ts]).
 *
 * The backend gives no dedicated AML signal: it keeps `status = InProgress`
 * and either drops `currentStep` to null or leaves a step with no challenges.
 * A normal mid-flow `InProgress` session always carries a `currentStep` with
 * challenges (an awaiting upload or OTP), so this only fires for the background
 * case. When true, the SDK polls faster and for a longer window instead of
 * timing out on the 10 s default window and stranding the user on the
 * "taking longer" retry state.
 *
 * Note the screen half of the web fix is already covered on Android: an
 * `InProgress` session with no `currentStep` resolves to
 * [ScreenState.Processing] via `ScreenResolver.resolveByStatus`, unlike the
 * web whose `mapStatusToScreen` returned a `loading` skeleton. This predicate
 * is therefore used only to pick the polling profile.
 */
internal fun isBackgroundProcessing(session: Session): Boolean {
    if (session.status != SessionStatus.InProgress) return false
    val step = session.currentStep
    return step == null || step.challenges.isEmpty()
}
