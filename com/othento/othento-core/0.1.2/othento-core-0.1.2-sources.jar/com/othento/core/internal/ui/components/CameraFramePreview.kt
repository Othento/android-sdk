package com.othento.core.internal.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale

/**
 * Renders an already-upright camera frame [bitmap] as the live preview for the
 * 2-stream capture path. The analyzer feeds frames here instead of the screen
 * binding a CameraX `PreviewView`, so `VideoCapture` keeps its own FHD stream
 * rather than being stream-shared down to 720p with a Preview use case.
 *
 * Uses [ContentScale.Crop] so the on-screen geometry matches the old
 * `PreviewView.ScaleType.FILL_CENTER` (scale-to-fill, center-crop) exactly —
 * that keeps the detection overlay's image-fraction → full-screen-fraction
 * projection (and the cutout-fraction math) unchanged. [mirror] horizontally
 * flips the frame for the user-facing (selfie) camera.
 *
 * Before the first frame arrives, [bitmap] is null and a black box is shown
 * (matching the snapshot default and the brief pre-bind gap).
 */
@Composable
internal fun CameraFramePreview(
    bitmap: Bitmap?,
    modifier: Modifier = Modifier,
    mirror: Boolean = false,
) {
    if (bitmap == null) {
        Box(modifier = modifier.background(Color.Black))
        return
    }
    Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = null,
        modifier = if (mirror) modifier.scale(scaleX = -1f, scaleY = 1f) else modifier,
        contentScale = ContentScale.Crop,
    )
}
