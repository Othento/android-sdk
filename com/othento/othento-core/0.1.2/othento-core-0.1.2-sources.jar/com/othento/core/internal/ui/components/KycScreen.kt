@file:Suppress("FunctionNaming", "TopLevelPropertyNaming")

package com.othento.core.internal.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoMotion
import com.othento.core.internal.ui.theme.LocalOthentoTypography

/** Spec §10 — `KycScreenZone`. */
@Immutable
internal enum class KycScreenZone { Guided, Immersive, Result }

/** Spec §10 — `KycScreenTone`. */
@Immutable
internal enum class KycScreenTone { Neutral, Success, Warning, Error }

/**
 * Screen-level slot-layout primitive. Faithful port of `apps/sdk/.../kyc-screen/`:
 *
 * - Guided header padding `20px 24px 24px` (top / horizontal / bottom).
 * - Brand row: 10 dp gap, 14 dp `margin-bottom`.
 * - Step label: 4 dp `margin-bottom`.
 * - Title: 26 sp / W700 / `letter-spacing -0.3 sp`; subtitle 15 sp / 1.4 lh /
 *   6 dp `margin-top` only.
 * - Body padding 16 dp (or 16 / 24 ≥480 dp).
 * - Footer padding 12 / 16 (or 12 / 24 ≥480 dp), with safe-area inset bottom.
 * - Tone shifts: header bg + title color + progress fill.
 * - Animation: `motion-screen-enter` — translateY 8 → 0 + opacity 0 → 1 over
 *   180 ms ease-out (`motion-keyframes` `kyc-screen-enter`).
 */
@Composable
@Suppress("LongParameterList", "LongMethod", "CyclomaticComplexMethod")
internal fun KycScreen(
    modifier: Modifier = Modifier,
    tone: KycScreenTone = KycScreenTone.Neutral,
    zone: KycScreenZone = KycScreenZone.Guided,
    title: String = "",
    subtitle: String = "",
    stepLabel: String = "",
    logoName: String = "",
    headerBorder: Boolean = true,
    bodyFill: Boolean = false,
    totalSegments: Int = 0,
    activeSegment: Int = -1,
    animate: Boolean = true,
    headerExtra: (@Composable () -> Unit)? = null,
    /** `theme.brand.logoUrl`; falls back to the initials chip when absent. */
    logoUrl: String? = null,
    /** Rendered at the far end of the brand row, opposite the logo. */
    headerTrailing: (@Composable () -> Unit)? = null,
    body: @Composable () -> Unit,
    footer: (@Composable () -> Unit)? = null,
) {
    val colors = LocalOthentoColors.current
    val motion = LocalOthentoMotion.current

    val translationDp = remember { Animatable(if (animate) ScreenEnterTranslateDp.value else 0f) }
    val alpha = remember { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(animate) {
        if (!animate || motion.reducedMotion) {
            translationDp.snapTo(0f)
            alpha.snapTo(1f)
            return@LaunchedEffect
        }
        alpha.animateTo(1f, tween(motion.durationBaseMs, easing = motion.easeOut))
        translationDp.animateTo(0f, tween(motion.durationBaseMs, easing = motion.easeOut))
    }
    val translationPx = with(LocalDensity.current) { translationDp.value.dp.toPx() }

    Column(
        modifier =
            modifier
                .fillMaxSize()
                .background(colors.bgBase)
                .alpha(alpha.value)
                .graphicsLayer { translationY = translationPx },
    ) {
        if (zone == KycScreenZone.Guided && shouldShowHeader(title, logoName, stepLabel, totalSegments)) {
            ScreenHeader(
                tone = tone,
                title = title,
                subtitle = subtitle,
                stepLabel = stepLabel,
                logoName = logoName,
                headerBorder = headerBorder,
                totalSegments = totalSegments,
                activeSegment = activeSegment,
                headerExtra = headerExtra,
                logoUrl = logoUrl,
                headerTrailing = headerTrailing,
            )
        }

        Box(
            modifier = Modifier.fillMaxWidth().weight(1f),
        ) {
            ScreenBody(
                zone = zone,
                bodyFill = bodyFill,
                content = body,
            )
        }

        if (zone == KycScreenZone.Guided && footer != null) {
            ScreenFooter(footer)
        }
    }
}

// ---- Header -------------------------------------------------------------

@Composable
@Suppress("LongMethod", "LongParameterList")
private fun ScreenHeader(
    tone: KycScreenTone,
    title: String,
    subtitle: String,
    stepLabel: String,
    logoName: String,
    headerBorder: Boolean,
    totalSegments: Int,
    activeSegment: Int,
    headerExtra: (@Composable () -> Unit)?,
    logoUrl: String?,
    headerTrailing: (@Composable () -> Unit)?,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val palette = headerPalette(tone)
    val finalBorderColor = if (headerBorder) palette.borderColor else Color.Transparent

    Column(modifier = Modifier.fillMaxWidth().background(palette.background)) {
        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(top = HeaderPaddingTop, bottom = HeaderPaddingBottom)
                    .padding(horizontal = HeaderPaddingHorizontal),
        ) {
            if (totalSegments >= 1) {
                Row(
                    modifier = Modifier.padding(bottom = ProgressBottomGap),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    repeat(totalSegments) { index ->
                        Box(
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (index <= activeSegment) palette.segmentFill else colors.border),
                        )
                    }
                }
            }
            if (logoName.isNotBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = BrandBottomGap),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(BrandRowGap),
                ) {
                    if (logoUrl != null) {
                        // `theme.brand.logoUrl` — a full-colour brand asset, so it is
                        // rendered untinted (plan §4.1) unlike every other remote PNG.
                        ContentBrandImage(
                            url = logoUrl,
                            contentDescription = null,
                            width = LogoSize,
                            height = LogoSize,
                        )
                    } else {
                        // Initials chip — the offline stand-in for the brand logo.
                        Box(
                            modifier =
                                Modifier
                                    .size(LogoSize)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(colors.primaryBg),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = logoName.take(1).uppercase(),
                                style = typography.body.copy(fontWeight = FontWeight.W700),
                                color = colors.primary,
                            )
                        }
                    }
                    Text(
                        text = logoName,
                        style = typography.body.copy(fontWeight = FontWeight.W600),
                        color = colors.textPrimary,
                        modifier = Modifier.weight(1f),
                    )
                    // Opposite the logo — today only the welcome screen's
                    // language picker lives here.
                    headerTrailing?.invoke()
                }
            }
            if (stepLabel.isNotBlank()) {
                Text(
                    modifier = Modifier.padding(bottom = StepLabelBottomGap),
                    text = stepLabel.uppercase(),
                    style = typography.microEyebrow,
                    color = colors.primary,
                )
            }
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    if (title.isNotBlank()) {
                        Text(text = title, style = typography.titleH1, color = palette.titleColor)
                    }
                    if (subtitle.isNotBlank()) {
                        Text(
                            modifier = Modifier.padding(top = SubtitleTopGap),
                            text = subtitle,
                            style = typography.subtitle,
                            color = colors.textSecondary,
                        )
                    }
                }
                if (headerExtra != null) headerExtra()
            }
        }
        // Border sits flush against the header bottom (outside the padding).
        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(finalBorderColor))
    }
}

// ---- Body ---------------------------------------------------------------

@Composable
private fun ScreenBody(
    zone: KycScreenZone,
    bodyFill: Boolean,
    content: @Composable () -> Unit,
) {
    val padding = bodyPadding(zone)
    when {
        zone == KycScreenZone.Result ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) { content() }
        bodyFill ->
            Box(modifier = Modifier.fillMaxSize().padding(padding)) { content() }
        else -> {
            val scrollState = rememberScrollState()
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(scrollState).padding(padding),
            ) { content() }
        }
    }
}

@Composable
private fun bodyPadding(zone: KycScreenZone): PaddingValues =
    when (zone) {
        KycScreenZone.Immersive -> PaddingValues(0.dp)
        KycScreenZone.Guided, KycScreenZone.Result -> {
            val w = LocalConfiguration.current.screenWidthDp
            val horizontal = if (w >= TabletBreakpointDp) BodyPaddingHorizontalLg else BodyPaddingHorizontal
            PaddingValues(horizontal = horizontal, vertical = BodyPaddingVertical)
        }
    }

// ---- Footer -------------------------------------------------------------

@Composable
private fun ScreenFooter(footer: @Composable () -> Unit) {
    val safeBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val w = LocalConfiguration.current.screenWidthDp
    val horizontal = if (w >= TabletBreakpointDp) FooterPaddingHorizontalLg else FooterPaddingHorizontal
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(horizontal = horizontal, vertical = FooterPaddingVertical)
                .padding(bottom = safeBottom),
    ) {
        footer()
    }
}

// ---- Palette ------------------------------------------------------------

private data class HeaderPalette(
    val background: Color,
    val titleColor: Color,
    val segmentFill: Color,
    val borderColor: Color,
)

@Composable
private fun headerPalette(tone: KycScreenTone): HeaderPalette {
    val colors = LocalOthentoColors.current
    return when (tone) {
        KycScreenTone.Neutral ->
            HeaderPalette(Color.Transparent, colors.textHeading, colors.primary, colors.border)
        KycScreenTone.Success ->
            HeaderPalette(colors.successBg, colors.successText, colors.success, colors.successBorder)
        KycScreenTone.Warning ->
            HeaderPalette(colors.warningBg, colors.warningText, colors.warning, colors.warningBorder)
        KycScreenTone.Error ->
            HeaderPalette(colors.errorBg, colors.errorText, colors.error, colors.errorBorder)
    }
}

private fun shouldShowHeader(
    title: String,
    logoName: String,
    stepLabel: String,
    totalSegments: Int,
): Boolean = title.isNotBlank() || logoName.isNotBlank() || stepLabel.isNotBlank() || totalSegments >= 1

private val HeaderPaddingTop = 20.dp
private val HeaderPaddingBottom = 24.dp
private val HeaderPaddingHorizontal = 24.dp
private val ProgressBottomGap = 16.dp
private val BrandRowGap = 10.dp
private val BrandBottomGap = 14.dp
private val LogoSize = 32.dp
private val StepLabelBottomGap = 4.dp
private val SubtitleTopGap = 6.dp
private val BodyPaddingHorizontal = 16.dp
private val BodyPaddingHorizontalLg = 24.dp
private val BodyPaddingVertical = 16.dp
private val FooterPaddingHorizontal = 16.dp
private val FooterPaddingHorizontalLg = 24.dp
private val FooterPaddingVertical = 12.dp
private val ScreenEnterTranslateDp = 8.dp
private const val TabletBreakpointDp = 480
