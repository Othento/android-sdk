package com.othento.core.internal.util

import java.text.Normalizer
import java.util.Locale

/**
 * Substring matching for country pickers. Port of the web SDK's
 * `apps/sdk/.../utils/country-search.utils.ts`.
 *
 * Shared by the OTP phone country popover ([PhoneDestinationInput]) and the
 * document-select country dropdown. The two render differently enough that one
 * component would have to be parameterised into uselessness, but the *matching
 * rule* is the subtle part and belongs in one place: it decides whether an
 * Arabic user can find a country by typing "Jordan", and whether "cote" finds
 * "Côte d'Ivoire".
 *
 * Normalisation is split across the two functions on purpose. [countrySearchKey]
 * folds once, when the (locale-dependent) list is built; [countrySearchMatcher]
 * folds the term once per keystroke and returns a predicate. The obvious
 * `matches(key, term)` shape would instead re-fold the term for every country on
 * every keystroke — ~240 redundant passes per character in the phone picker.
 */

private val COMBINING_MARKS = Regex("[\\u0300-\\u036F\\u0653-\\u0655]")

/**
 * Lowercases and strips diacritics.
 *
 * NFD splits a precomposed letter into base + combining marks, and
 * [COMBINING_MARKS] then drops them: `ô` → `o`, and — because `أ` decomposes to
 * `ا` plus a combining hamza — `أ` → `ا`. That second case matters as much as
 * the first: Arabic speakers routinely type `الاردن` for `الأردن`. Hence the
 * two ranges: Latin diacriticals (U+0300–U+036F) and the Arabic hamza marks
 * (U+0653–U+0655) that NFD splits off an alef.
 *
 * [Locale.ROOT] rather than the default locale, because a Turkish device would
 * otherwise lowercase "I" to "ı" and stop "Iraq" matching "iraq".
 */
private fun fold(value: String): String =
    COMBINING_MARKS.replace(Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD), "")

/**
 * Builds the haystack a country is matched against.
 *
 * Pass every string a user might plausibly type: the localised name, the
 * English name, the ISO code, and — for the phone picker — the dial code.
 * Blank and null parts are dropped rather than joined, because a code-less
 * backend row would otherwise leave a double space in the key.
 */
internal fun countrySearchKey(parts: List<String?>): String =
    fold(parts.filterNotNull().filter { it.isNotBlank() }.joinToString(separator = " "))

/**
 * Returns a predicate over keys built by [countrySearchKey].
 *
 * A blank term yields a predicate that accepts everything, so callers never
 * need to special-case "nothing typed yet".
 */
internal fun countrySearchMatcher(term: String): (String) -> Boolean {
    val needle = fold(term.trim())
    if (needle.isEmpty()) return { true }
    return { searchKey -> searchKey.contains(needle) }
}
