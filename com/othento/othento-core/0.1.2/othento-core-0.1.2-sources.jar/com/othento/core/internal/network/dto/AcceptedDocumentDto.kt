package com.othento.core.internal.network.dto

import com.squareup.moshi.JsonClass

/**
 * Wire shape for an entry in the documents-list response.
 *
 * Mirrors [docs/spec/09-data-models.md §2.4]. Used by the document-select
 * screen in Phase 5; defined now so DTO+mapper layers don't need a Phase-5
 * patch.
 */
@JsonClass(generateAdapter = true)
internal data class AcceptedDocumentDto(
    val documentId: String,
    /**
     * Stable, admin-managed document-type identifier (`passport`, `id`,
     * `drivers_license`, …). **This** is the behavioural discriminator; see
     * [com.othento.core.internal.data.model.DocumentType].
     *
     * Defaulted because it is an additive field — a backend that has not
     * shipped it yet must still parse, degrading to the generic card path
     * rather than failing the whole documents call.
     */
    val documentTypeCode: String? = null,
    /**
     * Legacy country code. Superseded by [countryCodeAlpha2] / [countryCodeAlpha3],
     * which name their ISO form explicitly — this API uses alpha-3 elsewhere
     * (expected-details nationality), so a bare `countryCode` was ambiguous.
     * Kept as a fallback for responses predating the split.
     */
    val countryCode: String? = null,
    /** ISO 3166-1 alpha-2. Feeds country-name localisation and flag rendering. */
    val countryCodeAlpha2: String? = null,
    /** ISO 3166-1 alpha-3. Carried for parity with the rest of the API. */
    val countryCodeAlpha3: String? = null,
    /** English display name. Localised at render via `documentType.<code>`. */
    val countryName: String,
    val countryIcon: String,
    val typeName: String,
    val widthMm: Double?,
    val heightMm: Double?,
    val requireBothSides: Boolean,
)
