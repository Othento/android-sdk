package com.othento.core.internal.network

/**
 * Path constants for the SDK's HTTP surface.
 *
 * The Android SDK is a single-mode flow (P9 in `99-open-questions.md`):
 * one apiKey-authenticated `POST /api/v1/SessionToken/session` per launch
 * to mint a SAT, then every subsequent call hits a token-mode endpoint
 * with `X-SAT` / `X-ST` / `X-SRT` headers.
 *
 * Leading slashes are required: Retrofit treats relative paths as resolved
 * against the *last segment* of the base URL, while absolute paths reset
 * to the host root. Anchoring at the host root keeps the wire path stable
 * regardless of the resolved base URL.
 */
internal object OthentoApiPaths {
    /**
     * API version segment. Hard-coded to `v1` (P2). The user's prompt used
     * `{version}` as a placeholder — exposing it as a host-configurable
     * Builder setter is deferred until a host asks.
     */
    const val API_VERSION: String = "v1"

    /**
     * `POST /api/v1/SessionToken/session` — create session (P1, apiKey).
     *
     * The response carries a SAT in `sessionToken`; the
     * [com.othento.core.internal.network.TokenStore] absorbs it.
     * Subsequent token-mode endpoints below send `X-SAT` / `X-ST` /
     * `X-SRT` instead of `X-API-KEY`.
     */
    const val CREATE_SESSION: String = "/api/$API_VERSION/SessionToken/session"

    /** `GET /api/v1/SessionToken/session` — load + poll the current session. */
    const val POLL_SESSION: String = "/api/$API_VERSION/SessionToken/session"

    /** `GET /api/v1/SessionToken/session/documents` — accepted documents list. */
    const val DOCUMENTS: String = "/api/$API_VERSION/SessionToken/session/documents"

    /**
     * `GET /api/v1/SdkContent?locale=…` — the tenant's copy + theme bundle.
     *
     * Not under `SessionToken/`, but still on the SDK host, so
     * [TokenInterceptor] attaches `X-SAT` by its host gate. That auth
     * dependency is why the fetch cannot actually run in parallel with
     * create-session on Android — see `ContentRepository`.
     *
     * The GET **is** the persistence: requesting `?locale=ar` records the
     * session's language server-side (plan decisions 31/34). There is no
     * separate update endpoint and none is needed.
     */
    const val SDK_CONTENT: String = "/api/$API_VERSION/SdkContent"

    /**
     * `POST /api/v1/SessionToken/session/initiate` — pick the document for the
     * id-verification step. `documentId` is a query param (web spec §5.2).
     */
    const val INITIATE: String = "/api/$API_VERSION/SessionToken/session/initiate"

    /**
     * `POST /api/v1/SessionToken/session/reinitiate` — re-attempt the document
     * step on a `Failed` + `canInitiate` session. Same params as [INITIATE].
     */
    const val REINITIATE: String = "/api/$API_VERSION/SessionToken/session/reinitiate"

    /**
     * `GET /api/v1/SessionToken/session/upload-url` — presigned S3 URL for the
     * next upload. Query params: `AttemptStepId`, `ChallengeType`, `FileName`.
     */
    const val UPLOAD_URL: String = "/api/$API_VERSION/SessionToken/session/upload-url"

    /** `POST /api/v1/SessionToken/session/confirm-upload` — confirm an S3 PUT. */
    const val CONFIRM_UPLOAD: String = "/api/$API_VERSION/SessionToken/session/confirm-upload"

    /**
     * `POST /api/v1/SessionToken/session/otp/send` — Phase 9. Sends an OTP
     * code to the user's phone or email. Body: `OtpSendRequestDto`.
     */
    const val OTP_SEND: String = "/api/$API_VERSION/SessionToken/session/otp/send"

    /**
     * `POST /api/v1/SessionToken/session/otp/verify` — Phase 9. Verifies
     * the user's typed code. Body: `OtpVerifyRequestDto`. Returns `410` for
     * expired codes and `422` for invalid codes per spec §10.5.
     */
    const val OTP_VERIFY: String = "/api/$API_VERSION/SessionToken/session/otp/verify"

    /**
     * `POST /api/v1/SessionToken/session/liveness/rekognition/start` — mints an
     * AWS Face Liveness session. Body: `RekognitionStartRequestDto`. Called
     * once per attempt; Rekognition sessions are single-use, so a retry starts
     * a new one.
     */
    const val REKOGNITION_START: String =
        "/api/$API_VERSION/SessionToken/session/liveness/rekognition/start"

    /**
     * `GET /api/v1/SessionToken/session/liveness/rekognition/credentials` —
     * short-lived STS credentials for streaming to Rekognition, scoped to
     * `rekognition:StartFaceLivenessSession` alone.
     */
    const val REKOGNITION_CREDENTIALS: String =
        "/api/$API_VERSION/SessionToken/session/liveness/rekognition/credentials"

    /**
     * `POST /api/v1/SessionToken/session/liveness/rekognition/complete` —
     * finalises the challenge and returns the standard session response.
     * **Never called on user cancel** — that would finalize a challenge the
     * user abandoned.
     */
    const val REKOGNITION_COMPLETE: String =
        "/api/$API_VERSION/SessionToken/session/liveness/rekognition/complete"
}
