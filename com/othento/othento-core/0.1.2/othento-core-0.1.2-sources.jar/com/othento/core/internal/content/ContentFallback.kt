package com.othento.core.internal.content

import com.othento.core.internal.content.ContentKeys as CK

/**
 * The emergency fallback bundle — the **only** copy compiled into the AAR.
 *
 * Decision 8: the backend is the sole content source; clients ship an
 * emergency set so a total content outage still produces a coherent screen
 * instead of blanks.
 *
 * ### The inclusion rule
 * A key belongs here when a **user cannot proceed without reading it**: a
 * screen title, a button label, an input label, a runtime capture prompt, an
 * error dialog. Plan §4.8 forbids rendering a raw key name; the twin failure is
 * rendering *nothing* where a primary button's label belongs, and a Paparazzi
 * run of this integration caught exactly that on the capture-fallback and OTP
 * screens before it shipped.
 *
 * Everything genuinely optional is deliberately **absent** so it collapses
 * instead (plan §4.8 rule 2): tip bullets, tip cards, detail lines, eyebrows,
 * intro subtitles, and any string whose call site already supplies an inline
 * `ifBlank { … }` default.
 *
 * ### Values are byte-identical to the pre-integration screens
 * That is load-bearing (plan §7): a screen rendered with no backend produces
 * the same pixels as the pre-content build, so any snapshot that moves, moved
 * for a reason you can name. Where a value here differs from
 * `docs/sdk-copy-bundle.json`, the Android string wins — the bundle is what the
 * backend serves, this is what the screen used to render.
 *
 * ### Not the full bundle
 * All 206 keys live in the web repo as the canonical fixture. If that file is
 * ever imported from `src/main` it ships to end users and contradicts decision
 * 8 (plan §4.9). This map is hand-maintained and covers roughly a third of the
 * contract.
 */
internal object ContentFallback {
    val MAP: Map<String, String> =
        mapOf(
            // --- brand / chrome -------------------------------------------
            CK.THEME_BRAND_NAME to "Othento",
            CK.LAYOUT_SECURED_BY to "SECURED BY",
            CK.LAYOUT_ENCRYPTED to "Encrypted & secure",
            CK.LAYOUT_SANDBOX_BADGE to "Sandbox Mode",
            // The only route out of the SDK. A blank here strands the user on a
            // terminal screen with no way back to the host app, which is the
            // single worst thing a missing string can do in this flow.
            CK.LAYOUT_RETURN_TO_APP to "Return to app",
            // --- failed retry ----------------------------------------------
            CK.FAILED_RETRY_CTA_TRY_AGAIN to "Try Again",
            // --- otp ---------------------------------------------------------
            CK.OTP_SKIP_TITLE to "Verification skipped",
            CK.OTP_SKIP_BUTTON to "Continue",
            CK.OTP_SEND_RESEND_IN to "Resend in {seconds}s",
            CK.OTP_PHONE_PLACEHOLDER to "Phone number",
            CK.OTP_PHONE_COUNTRY_SEARCH_PLACEHOLDER to "Search country",
            CK.OTP_PHONE_NO_COUNTRY_MATCH to "No countries match \"{search}\"",
            // --- liveness ------------------------------------------------------
            CK.LIVENESS_INTRO_BUTTON to "Continue",
            CK.LIVENESS_WARNING_CONTINUE_BUTTON to "I understand, continue",
            CK.LIVENESS_CONNECTING to "Connecting to the secure liveness check…",
            // --- selfie ---------------------------------------------------------
            CK.SELFIE_PREVIEW_CHECKING to "Checking face quality…",
            CK.SELFIE_REVIEW_TITLE to "Review your selfie",
            CK.SELFIE_REVIEW_SUBTITLE to "Make sure your face is clearly visible",
            CK.SELFIE_PREVIEW_USE to "Use this selfie",
            CK.SELFIE_TIMEOUT_TITLE to "No face detected",
            CK.SELFIE_CAPTURE_STATUS_DEFAULT to "Position your face in the oval",
            // The camera chrome pill is the only label on a full-screen camera
            // surface; collapsing it would leave a visibly empty pill rather
            // than nothing, so it earns a fallback despite reading like an
            // eyebrow.
            CK.SELFIE_CAPTURE_CHROME_PILL to "Face match · Selfie",
            CK.LIVENESS_CAPTURE_CHROME_PILL to "Liveness",
            // Liveness previously borrowed the selfie idle prompt; it now has
            // its own, so this value is the contract's rather than the old
            // screen's. The liveness idle snapshot moves by exactly this string.
            CK.LIVENESS_CAPTURE_STATUS_DEFAULT to "Look at the camera and hold still",
            // --- upload sheet ------------------------------------------------------
            CK.IDV_UPLOAD_SELECT_PHOTO to "Choose photo",
            // --- start ----------------------------------------------------
            CK.START_TITLE to "Let's confirm it's you.",
            CK.START_SUBTITLE_STEPS + CK.SUFFIX_ONE to "{count} short step.",
            CK.START_SUBTITLE_STEPS + CK.SUFFIX_OTHER to "{count} short steps.",
            CK.START_CTA to "Begin verification →",
            // --- document select -------------------------------------------
            CK.DOCUMENT_SELECT_TITLE to "Select your document",
            CK.DOCUMENT_SELECT_SUBTITLE to "Choose your country and document type",
            CK.DOCUMENT_SELECT_COUNTRY_LABEL to "Issuing country",
            CK.DOCUMENT_SELECT_COUNTRY_PLACEHOLDER to "Select a country",
            CK.DOCUMENT_SELECT_TYPE_LABEL to "Choose document type",
            CK.DOCUMENT_SELECT_CTA_CONTINUE to "Continue",
            CK.UPLOADING_LABEL to "Processing…",
            // --- document capture chrome ------------------------------------
            CK.IDV_CAPTURE_CONTINUE to "Continue",
            CK.IDV_CAPTURE_REUPLOAD to "Re-upload",
            CK.IDV_CAPTURE_UPLOAD_FILE to "Upload file",
            CK.IDV_CAPTURE_CHANGE_DOCUMENT to "Change document",
            CK.IDV_CAPTURE_CHECKING_QUALITY to "Checking document quality…",
            CK.IDV_CAPTURE_SIDE_FRONT to "Front side",
            CK.IDV_CAPTURE_SIDE_BACK to "Back side",
            // The chrome pill when no document is selected. Essential because
            // it is the pill's ONLY text in that state — a blank leaves an
            // empty capsule floating over the camera.
            CK.IDV_CAPTURE_PILL_FALLBACK_FRONT to "Front of your document",
            CK.IDV_CAPTURE_PILL_FALLBACK_BACK to "Back of your document",
            // The expired-code dialog's secondary action. A dialog with a
            // blank button is worse than an untranslated one.
            CK.OTP_ERROR_DISMISS to "Dismiss",
            CK.IDV_CAPTURE_UPLOAD_TITLE to "Upload your document",
            CK.IDV_CAPTURE_UPLOAD_SUBTITLE to "Take a clear photo of your document",
            CK.IDV_UPLOAD_SIDE_UPLOADED_FRONT to "Front side uploaded",
            CK.IDV_UPLOAD_SIDE_UPLOADED_BACK to "Back side uploaded",
            // The manual-upload sheet's own headings. Present because they are
            // the sheet's primary heading and its confirmation — a user cannot
            // tell which side they are uploading without them. The sheet's tip
            // bullets are deliberately absent: optional copy collapses.
            CK.IDV_UPLOAD_TITLE_FRONT to "Upload front side",
            CK.IDV_UPLOAD_TITLE_BACK to "Upload back side",
            CK.IDV_UPLOAD_TITLE_SINGLE to "Upload your document",
            CK.IDV_UPLOAD_DOCUMENT_UPLOADED to "Document uploaded",
            // --- camera runtime ----------------------------------------------
            CK.CAPTURE_SCAN_BUTTON to "Scan Document",
            CK.CAPTURE_PREPARING_CAMERA to "Preparing camera…",
            CK.CAPTURE_CAMERA_REQUIRED_TITLE to "Camera access required",
            CK.CAPTURE_CAMERA_REQUIRED_NO_CAMERA to "No camera detected on this device.",
            CK.CAPTURE_PROMPT_HOLD_STEADY to "Hold steady... {seconds}s",
            CK.CAPTURE_PROMPT_POSITION_PASSPORT to "Position your passport in the frame",
            CK.CAPTURE_PROMPT_POSITION_DOCUMENT_FRONT to
                "Position the front of your document in the frame",
            CK.CAPTURE_PROMPT_POSITION_DOCUMENT_BACK to
                "Position the back of your document in the frame",
            CK.CAPTURE_REVIEW_OK_TITLE to "Review your capture",
            CK.CAPTURE_REVIEW_OK_SUBTITLE to "Make sure the document is clear and readable",
            CK.CAPTURE_REVIEW_RETAKE to "Retake",
            CK.CAPTURE_REVIEW_LOOKS_GOOD to "Looks good",
            CK.CAPTURE_TIMEOUT_TITLE to "We couldn't detect your document in time",
            CK.CAPTURE_TIMEOUT_MESSAGE to
                "Make sure the document is well-lit and inside the frame, then try again.",
            CK.CAPTURE_TIMEOUT_TRY_AGAIN to "Try again",
            CK.CAPTURE_CAMERA_REQUIRED_OPEN_SETTINGS to "Open settings",
            CK.CAPTURE_CAMERA_REQUIRED_DENIED to "Allow camera access to scan your document.",
            CK.SELFIE_CAMERA_REQUIRED_DENIED to
                "Allow camera access to verify your identity with a selfie.",
            CK.CAPTURE_TIMEOUT_UPLOAD_INSTEAD to "Upload file instead",
            // --- OTP: every string on the send + verify path -----------------
            CK.OTP_PHONE_STEP_TITLE to "Phone verification",
            CK.OTP_PHONE_STEP_SUBTITLE to "We'll text you a verification code",
            CK.OTP_PHONE_TITLE to "Verify your phone number",
            CK.OTP_PHONE_SUBTITLE to "We'll send a one-time code via SMS to verify your number.",
            CK.OTP_PHONE_EDITING_SUBTITLE to "Enter the new number you want the code sent to.",
            CK.OTP_PHONE_LABEL to "Phone number",
            CK.OTP_PHONE_CODE_TITLE to "Check your messages",
            CK.OTP_PHONE_CHANGE_BUTTON to "Change phone number",
            CK.OTP_PHONE_TIP to
                "Standard message rates may apply. Make sure the number can receive SMS.",
            CK.OTP_EMAIL_STEP_TITLE to "Email verification",
            CK.OTP_EMAIL_STEP_SUBTITLE to "We'll email you a verification code",
            CK.OTP_EMAIL_TITLE to "Verify your email address",
            CK.OTP_EMAIL_SUBTITLE to "We'll send a one-time code to verify your email address.",
            CK.OTP_EMAIL_EDITING_SUBTITLE to "Enter the new email you want the code sent to.",
            CK.OTP_EMAIL_LABEL to "Email address",
            CK.OTP_EMAIL_CODE_TITLE to "Check your inbox",
            CK.OTP_EMAIL_CHANGE_BUTTON to "Change email",
            CK.OTP_EMAIL_TIP to "Check your spam or junk folder if you don't see the email.",
            CK.OTP_CODE_SUBTITLE to "We sent a {digits}-digit code to",
            CK.OTP_SEND_INITIAL to "Send code",
            CK.OTP_SEND_RESEND to "Resend code",
            CK.OTP_SEND_LOADING to "Sending...",
            CK.OTP_VERIFY to "Verify",
            CK.OTP_VERIFY_LOADING to "Verifying...",
            CK.OTP_RESEND_PROMPT to "Didn't receive it?",
            CK.OTP_CANCEL to "Cancel",
            CK.OTP_SECURITY to "Your information is encrypted and secure",
            CK.OTP_ERROR_EXPIRED_TITLE to "Code expired",
            CK.OTP_ERROR_EXPIRED_BODY to
                "The verification code is no longer valid. Send a new one and we'll deliver it again.",
            CK.OTP_ERROR_EXPIRED_BUTTON to "Send new code",
            CK.OTP_ERROR_INVALID_TITLE to "Incorrect code",
            CK.OTP_ERROR_INVALID_BODY to "That code doesn't match. Double-check and try again.",
            CK.OTP_ERROR_INVALID_BUTTON to "Try again",
            // The third verify dialog. It is here for the same reason the other
            // two are: it is a blocking sheet whose primary button is the only
            // way forward, so a blank title and an unlabelled button would
            // strand the user completely.
            CK.OTP_ERROR_NOT_REQUESTED_TITLE to "No code sent yet",
            CK.OTP_ERROR_NOT_REQUESTED_BODY to
                "We haven't sent you a verification code yet. Request one to continue.",
            CK.OTP_ERROR_NOT_REQUESTED_BUTTON to "Send code",
            // --- failed-retry (recoverable, so its copy is essential) -----
            CK.FAILED_RETRY_TITLE to "That attempt didn't pass",
            CK.FAILED_RETRY_SUBTITLE to
                "We couldn't complete your verification. Review the steps below and try again.",
            CK.FAILED_RETRY_STEPS_LABEL to "What to redo",
            // --- step chrome --------------------------------------------------
            // Both are structural: they tell the user where they are in the
            // flow, and a blank leaves the guided header with a bare title.
            // `progressLabel` keeps both placeholders so an unbound one stays
            // visible in QA rather than silently collapsing the sentence.
            CK.STEPS_PROGRESS_LABEL to "Step {index} of {total}",
            CK.STEPS_COUNT_LABEL + CK.SUFFIX_ONE to "{count} step",
            CK.STEPS_COUNT_LABEL + CK.SUFFIX_OTHER to "{count} steps",
            // --- intro illustration captions ----------------------------------
            // Present despite being decorative: they are drawn *inside* the
            // animated illustration, so an empty value leaves a visible gap in
            // the layout rather than collapsing it. Values are byte-identical
            // to the literals they replaced, which is what keeps the intro
            // snapshots stable.
            CK.INTRO_ILLUSTRATION_ID_CARD_CAPTION to "Align inside frame",
            CK.INTRO_ILLUSTRATION_ID_CARD_BACK_CAPTION to "Flip to the back",
            CK.INTRO_ILLUSTRATION_SELFIE_CAPTION to "Center your face",
            CK.INTRO_ILLUSTRATION_LIVENESS_CAPTION to "Just look at the camera",
            CK.A11Y_LOADING to "Loading verification",
            CK.FAILED_RETRY_ATTEMPTS + CK.SUFFIX_ONE to "{count} try left",
            CK.FAILED_RETRY_ATTEMPTS + CK.SUFFIX_OTHER to "{count} tries left",
            // --- result: approved -----------------------------------------
            CK.RESULT_APPROVED + CK.SUFFIX_TITLE to "Identity Verified",
            CK.RESULT_APPROVED + CK.SUFFIX_DESCRIPTION to
                "Your identity has been successfully verified.",
            // --- result: in review ----------------------------------------
            CK.RESULT_IN_REVIEW + CK.SUFFIX_TITLE to "Verification Under Review",
            CK.RESULT_IN_REVIEW + CK.SUFFIX_DESCRIPTION to
                "Your submission is being reviewed. This may take a little longer than usual. " +
                "You'll be notified once the review is complete.",
            // --- result: failed (terminal) --------------------------------
            CK.RESULT_FAILED + CK.SUFFIX_TITLE to "Verification Failed",
            CK.RESULT_FAILED + CK.SUFFIX_DESCRIPTION to
                "Something went wrong during verification. " +
                "Please contact your service provider for further assistance.",
            // --- result: declined -----------------------------------------
            CK.RESULT_DECLINED + CK.SUFFIX_TITLE to "Verification Declined",
            CK.RESULT_DECLINED + CK.SUFFIX_DESCRIPTION to
                "Your identity could not be verified. " +
                "Please contact your service provider for further assistance.",
            // --- result: expired ------------------------------------------
            CK.RESULT_EXPIRED + CK.SUFFIX_TITLE to "Session Expired",
            CK.RESULT_EXPIRED + CK.SUFFIX_DESCRIPTION to
                "This verification session has expired. " +
                "Please request a new session from your provider.",
            // --- result: error --------------------------------------------
            CK.RESULT_ERROR + CK.SUFFIX_TITLE to "Something went wrong",
            CK.RESULT_ERROR + CK.SUFFIX_DESCRIPTION to
                "The verification session could not be found. " +
                "It may have expired or the link is invalid.",
            CK.RESULT_ERROR_CODE_LABEL to "ERROR CODE",
            // --- result: processing ---------------------------------------
            CK.RESULT_PROCESSING + CK.SUFFIX_TITLE to "Verifying your identity",
            CK.RESULT_PROCESSING + CK.SUFFIX_DESCRIPTION to
                "We're running the final checks. This usually takes a few moments.",
            CK.RESULT_PROCESSING_TIMED_OUT + CK.SUFFIX_TITLE to "Verification under review",
            CK.RESULT_PROCESSING_TIMED_OUT + CK.SUFFIX_DESCRIPTION to
                "Your submission is being reviewed. This may take a little longer than usual.",
            // --- result: unsupported (phase 2, not yet seeded) ------------
            // Enumerated here precisely because this state renders on a build
            // that is behind the backend — the fallback is the only copy an old
            // client has for it (plan §6).
            CK.RESULT_UNSUPPORTED + CK.SUFFIX_TITLE to "Update Required",
            CK.RESULT_UNSUPPORTED + CK.SUFFIX_DESCRIPTION to
                "This verification needs a newer version of this app. " +
                "Please update to the latest version and try again.",
        )
}
