@file:Suppress("FunctionNaming", "TopLevelPropertyNaming", "MagicNumber")

package com.othento.core.internal.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.LocalContent
import com.othento.core.internal.content.content
import com.othento.core.internal.content.contentFor
import com.othento.core.internal.content.contentLanguage
import com.othento.core.internal.data.model.AcceptedDocument
import com.othento.core.internal.data.model.DocumentType
import com.othento.core.internal.ui.components.CountryFlagImage
import com.othento.core.internal.ui.components.DropdownFlagHeight
import com.othento.core.internal.ui.components.DropdownFlagWidth
import com.othento.core.internal.ui.components.KycButton
import com.othento.core.internal.ui.components.KycButtonSize
import com.othento.core.internal.ui.components.KycButtonVariant
import com.othento.core.internal.ui.components.KycDropdown
import com.othento.core.internal.ui.components.KycDropdownOption
import com.othento.core.internal.ui.components.KycDropdownSearch
import com.othento.core.internal.ui.components.KycIcon
import com.othento.core.internal.ui.components.KycLoader
import com.othento.core.internal.ui.components.KycLoaderSize
import com.othento.core.internal.ui.components.KycScreen
import com.othento.core.internal.ui.components.KycScreenZone
import com.othento.core.internal.ui.icons.OthentoIcons
import com.othento.core.internal.ui.screens.common.StepProgress
import com.othento.core.internal.ui.screens.common.progressLabel
import com.othento.core.internal.ui.theme.LocalOthentoColors
import com.othento.core.internal.ui.theme.LocalOthentoShapes
import com.othento.core.internal.ui.theme.LocalOthentoTypography
import com.othento.core.internal.util.countryDisplayName
import com.othento.core.internal.util.countryNameComparator
import com.othento.core.internal.util.countrySearchKey

/**
 * Spec [docs/spec/06-screens/03-document-select.md]: country dropdown +
 * document cards, footer Continue.
 *
 * State surface (all from [com.othento.core.internal.flow.FlowUiState]):
 * - [documents] — fully loaded list, grouped by country.
 * - [selectedCountryKey] — the country's ISO group key, auto-set when docs
 *   land; the user can switch via the dropdown. Never a display name: those
 *   are localised, and a translated string cannot be an identity.
 * - [selectedDocumentId] — null until the user taps a card.
 * - [loading] / [errorMessage] — loading + error states.
 *
 * The Continue CTA fires `onConfirmClick` only when [selectedDocumentId] is
 * non-null — disabled otherwise (matches the web's `[disabled]` binding).
 */
@Composable
@Suppress("LongParameterList", "LongMethod")
internal fun DocumentSelectScreen(
    documents: List<AcceptedDocument>?,
    selectedCountryKey: String?,
    selectedDocumentId: String?,
    loading: Boolean,
    errorMessage: String?,
    stepProgress: StepProgress,
    onCountrySelected: (String) -> Unit,
    onDocumentSelected: (String) -> Unit,
    onConfirmClick: () -> Unit,
) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current

    // Grouped by ISO code and labelled in the active language. Both the
    // labels and the sort depend on the language, so the whole computation is
    // keyed on it — a language switch rebuilds the list rather than leaving
    // the previous locale's names on screen.
    val language = contentLanguage()
    val countryGroups: List<CountryGroup> =
        remember(documents, language) {
            val comparator = countryNameComparator(language)
            documents
                ?.groupBy { it.countryGroupKey }
                ?.map { (key, docs) ->
                    val first = docs.first()
                    val name = countryDisplayName(first.alpha2, language, first.countryName)
                    CountryGroup(
                        key = key,
                        name = name,
                        // The English name and the ISO code sit alongside the
                        // localised one so an Arabic session is still findable
                        // from a Latin keyboard, and vice versa. Folded here,
                        // with the (locale-dependent) list, not per keystroke.
                        searchKey =
                            countrySearchKey(
                                listOf(name, countryDisplayName(first.alpha2, "en", first.countryName), first.alpha2),
                            ),
                        countryIcon = docs.firstNotNullOfOrNull { it.countryIcon.takeIf(String::isNotBlank) },
                        documents = docs,
                    )
                }?.sortedWith { a, b -> comparator.compare(a.name, b.name) }
                .orEmpty()
        }
    val selectedGroup =
        remember(countryGroups, selectedCountryKey) {
            countryGroups.firstOrNull { it.key == selectedCountryKey }
        }
    val visibleDocuments = selectedGroup?.documents.orEmpty()
    val canConfirm = selectedDocumentId != null && !loading

    KycScreen(
        zone = KycScreenZone.Guided,
        title = content(ContentKeys.DOCUMENT_SELECT_TITLE),
        subtitle = content(ContentKeys.DOCUMENT_SELECT_SUBTITLE),
        stepLabel = stepProgress.progressLabel(),
        // Brand row is intentionally omitted on inner screens — the brand
        // already lives in the trust footer underneath the screen body.
        logoName = "",
        totalSegments = stepProgress.total,
        activeSegment = stepProgress.currentIndex,
        body = {
            when {
                loading ->
                    Column(
                        modifier = Modifier.fillMaxSize().padding(top = LoadingTopGap),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        KycLoader(size = KycLoaderSize.Md)
                    }
                errorMessage != null -> ErrorBlock(errorMessage)
                documents == null -> Unit
                else ->
                    DocumentSelectBody(
                        countryGroups = countryGroups,
                        selectedCountryKey = selectedCountryKey,
                        selectedDocumentId = selectedDocumentId,
                        visibleDocuments = visibleDocuments,
                        onCountrySelected = onCountrySelected,
                        onDocumentSelected = onDocumentSelected,
                        colors = colors,
                        typography = typography,
                    )
            }
        },
        footer = {
            KycButton(
                onClick = onConfirmClick,
                label = content(ContentKeys.DOCUMENT_SELECT_CTA_CONTINUE),
                variant = KycButtonVariant.Primary,
                size = KycButtonSize.Lg,
                enabled = canConfirm,
                fullWidth = true,
            )
        },
    )
}

@Composable
@Suppress("LongParameterList", "LongMethod")
private fun DocumentSelectBody(
    countryGroups: List<CountryGroup>,
    selectedCountryKey: String?,
    selectedDocumentId: String?,
    visibleDocuments: List<AcceptedDocument>,
    onCountrySelected: (String) -> Unit,
    onDocumentSelected: (String) -> Unit,
    colors: com.othento.core.internal.ui.theme.OthentoColors,
    typography: com.othento.core.internal.ui.theme.OthentoTypography,
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = SectionTopGap),
        verticalArrangement = Arrangement.spacedBy(SectionGap),
    ) {
        Section(label = content(ContentKeys.DOCUMENT_SELECT_COUNTRY_LABEL)) {
            // Country flags are rendered from `AcceptedDocument.countryIcon`
            // (a remote URL) via Coil's AsyncImage — same pipeline the web
            // SDK uses (`<img [src]="country.countryIcon" width="20"
            // height="14">`, spec docs/spec/04-design-system.md §"Country
            // flag"). The slot collapses if the URL is blank.
            // Search appears only past COUNTRY_SEARCH_THRESHOLD countries; at or
            // below it the picker is byte-for-byte what it was before. The copy
            // is the phone picker's — one "Search country" placeholder and one
            // no-match sentence serve both, so there is nothing extra to
            // translate.
            val bundle = LocalContent.current
            val noMatchTemplate = { term: String ->
                bundle.text(ContentKeys.OTP_PHONE_NO_COUNTRY_MATCH, mapOf(PLACEHOLDER_SEARCH to term))
            }
            KycDropdown(
                selectedId = selectedCountryKey,
                placeholder = content(ContentKeys.DOCUMENT_SELECT_COUNTRY_PLACEHOLDER),
                options =
                    countryGroups.map { group ->
                        KycDropdownOption(
                            id = group.key,
                            label = group.name,
                            searchKey = group.searchKey,
                            leading =
                                group.countryIcon?.let { url ->
                                    {
                                        CountryFlagImage(
                                            url = url,
                                            width = DropdownFlagWidth,
                                            height = DropdownFlagHeight,
                                            contentDescription = group.name,
                                        )
                                    }
                                },
                        )
                    },
                onSelect = onCountrySelected,
                search =
                    if (shouldShowCountrySearch(countryGroups.size)) {
                        KycDropdownSearch(
                            placeholder = content(ContentKeys.OTP_PHONE_COUNTRY_SEARCH_PLACEHOLDER),
                            noMatchLabel = noMatchTemplate,
                        )
                    } else {
                        null
                    },
            )
        }
        if (selectedCountryKey != null) {
            Section(label = content(ContentKeys.DOCUMENT_SELECT_TYPE_LABEL)) {
                Column(verticalArrangement = Arrangement.spacedBy(CardGap)) {
                    visibleDocuments.forEach { doc ->
                        DocumentCard(
                            document = doc,
                            selected = doc.documentId == selectedDocumentId,
                            onClick = { onDocumentSelected(doc.documentId) },
                            colors = colors,
                            typography = typography,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Section(
    label: String,
    body: @Composable () -> Unit,
) {
    val typography = LocalOthentoTypography.current
    val colors = LocalOthentoColors.current
    Column {
        Text(
            text = label,
            style = typography.inputLabel.copy(fontWeight = FontWeight.W600),
            color = colors.textPrimary,
        )
        Spacer(modifier = Modifier.height(LabelGap))
        body()
    }
}

@Composable
private fun DocumentCard(
    document: AcceptedDocument,
    selected: Boolean,
    onClick: () -> Unit,
    colors: com.othento.core.internal.ui.theme.OthentoColors,
    typography: com.othento.core.internal.ui.theme.OthentoTypography,
) {
    val shapes = LocalOthentoShapes.current
    val borderColor = if (selected) colors.primary else colors.border
    val backgroundColor = if (selected) colors.primaryBg else colors.bgBase
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(shapes.md)
                .border(width = CardBorderWidth, color = borderColor, shape = shapes.md)
                .background(backgroundColor)
                .clickable(onClick = onClick)
                .padding(horizontal = CardHorizontal, vertical = CardVertical),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(CardInnerGap),
    ) {
        DocumentIcon(documentType = document.documentType, selected = selected, colors = colors)
        Text(
            // Localised at render, falling back to the backend's English for a
            // document type nobody has authored a label for yet.
            text = contentFor(ContentKeys.DOCUMENT_TYPE_PREFIX, document.documentTypeCode, document.typeName),
            style = typography.body.copy(fontWeight = FontWeight.W500),
            color = colors.textPrimary,
            modifier = Modifier.weight(1f),
        )
        RadioMark(selected = selected, colors = colors)
    }
}

@Composable
private fun DocumentIcon(
    documentType: DocumentType,
    selected: Boolean,
    colors: com.othento.core.internal.ui.theme.OthentoColors,
) {
    val iconBg = if (selected) colors.primary else colors.bgLayout
    val iconTint = if (selected) Color.White else colors.textSecondary
    Box(
        modifier =
            Modifier
                .size(DocIconSize)
                .clip(RoundedCornerShape(8.dp))
                .background(iconBg),
        contentAlignment = Alignment.Center,
    ) {
        KycIcon(
            imageVector = iconImageVectorFor(documentType),
            contentDescription = null,
            sizeDp = DocIconGlyphSize,
            tint = iconTint,
        )
    }
}

/**
 * Keyed by [DocumentType] rather than written as a chain of substring tests, so
 * the compiler rejects a new type nobody gave an icon.
 *
 * Only two icons exist today, and every non-passport type deliberately maps to
 * the card glyph — including the unknown [DocumentType.Other]. That is the same
 * output the old English substring matching produced, so this is a change of
 * mechanism, not of pixels.
 */
private fun iconImageVectorFor(documentType: DocumentType) =
    when (documentType) {
        DocumentType.Passport -> OthentoIcons.Passport
        DocumentType.IdCard,
        DocumentType.DriversLicense,
        DocumentType.ResidencePermit,
        DocumentType.Other,
        -> OthentoIcons.IdCard
    }

@Composable
private fun RadioMark(
    selected: Boolean,
    colors: com.othento.core.internal.ui.theme.OthentoColors,
) {
    Box(
        modifier =
            Modifier
                .size(RadioOuter)
                .clip(CircleShape)
                .border(
                    width = CardBorderWidth,
                    color = if (selected) colors.primary else colors.border,
                    shape = CircleShape,
                ),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Box(
                modifier =
                    Modifier
                        .size(RadioInner)
                        .clip(CircleShape)
                        .background(colors.primary),
            )
        }
    }
}

@Composable
private fun ErrorBlock(message: String) {
    val colors = LocalOthentoColors.current
    val typography = LocalOthentoTypography.current
    val shapes = LocalOthentoShapes.current
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(top = ErrorTopGap)
                .clip(shapes.md)
                .background(colors.errorBg)
                .padding(horizontal = ErrorHorizontal, vertical = ErrorVertical),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = message,
            style = typography.body,
            color = colors.error,
        )
    }
}

/**
 * One country's documents, as the list renders them.
 *
 * [key] is the identity (an ISO alpha-2 code, or a name-derived fallback for
 * rows without one) and [name] is its localised label. They are separate
 * fields precisely because the label changes with the language while the
 * identity must not.
 */
private data class CountryGroup(
    val key: String,
    val name: String,
    val searchKey: String,
    val countryIcon: String?,
    val documents: List<AcceptedDocument>,
)

/**
 * Country count above which the dropdown grows a search box.
 *
 * Below it the box is noise: a list this short is fully visible without
 * scrolling, and the box would only push the options themselves further down.
 */
internal const val COUNTRY_SEARCH_THRESHOLD = 4

/** Whether a country list of [count] entries is long enough to be worth filtering. */
internal fun shouldShowCountrySearch(count: Int): Boolean = count > COUNTRY_SEARCH_THRESHOLD

/** `{search}` in `otp.phone.noCountryMatch` — the user's own term, echoed back. */
private const val PLACEHOLDER_SEARCH = "search"

private val SectionTopGap = 16.dp
private val SectionGap = 24.dp
private val LabelGap = 10.dp
private val CardGap = 12.dp
private val CardHorizontal = 16.dp
private val CardVertical = 12.dp
private val CardInnerGap = 14.dp
private val CardBorderWidth: Dp = 1.5.dp
private val DocIconSize = 40.dp
private val DocIconGlyphSize = 22.dp
private val RadioOuter = 20.dp
private val RadioInner = 10.dp
private val LoadingTopGap = 48.dp
private val ErrorTopGap = 32.dp
private val ErrorHorizontal = 24.dp
private val ErrorVertical = 32.dp
