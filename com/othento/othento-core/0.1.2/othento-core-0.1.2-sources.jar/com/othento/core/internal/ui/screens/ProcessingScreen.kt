@file:Suppress("FunctionNaming")

package com.othento.core.internal.ui.screens

import androidx.compose.runtime.Composable
import com.othento.core.internal.content.ContentKeys
import com.othento.core.internal.content.content
import com.othento.core.internal.content.ResultMode
import com.othento.core.internal.content.ResultTone
import com.othento.core.internal.ui.components.StatusIconName
import com.othento.core.internal.ui.screens.common.ContentStatusScreen
import com.othento.core.internal.ui.screens.common.StatusAction

/**
 * Two variants, two content prefixes:
 *
 * - **In-flight** (`result.processing.*`): neutral arc loader, no buttons,
 *   polling active. The contract carries no `.icon` for this state — the glyph
 *   is a spinner, not an asset — so [StatusIconName.Arc] always wins.
 * - **Timed-out** (`result.processing.timedOut.*`): warning clock, "Try again"
 *   CTA, polling stopped.
 *
 * The "Try again" label has no key in the shared contract — it is part of the
 * native copy sweep deferred to plan §8.2.
 */
@Composable
internal fun ProcessingScreen(
    timedOut: Boolean = false,
    onTryAgainClick: () -> Unit = { },
) {
    if (timedOut) {
        ContentStatusScreen(
            prefix = ContentKeys.RESULT_PROCESSING_TIMED_OUT,
            fallbackIcon = StatusIconName.Clock,
            fallbackTone = ResultTone.Warning,
            fallbackMode = ResultMode.Terminal,
            primaryAction = StatusAction(label = content(ContentKeys.CAPTURE_TIMEOUT_TRY_AGAIN), onClick = onTryAgainClick),
        )
    } else {
        ContentStatusScreen(
            prefix = ContentKeys.RESULT_PROCESSING,
            fallbackIcon = StatusIconName.Arc,
            fallbackTone = ResultTone.Neutral,
            fallbackMode = ResultMode.InFlight,
        )
    }
}

