package com.othento.core.internal.util

import java.text.Collator
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Localised country names, derived on-device rather than fetched.
 *
 * The backend deliberately does **not** translate `countryName` — it sends ISO
 * codes instead, because every platform already ships CLDR region names. On
 * Android that is [Locale.getDisplayCountry]. The result: correct names in
 * every language we ever add, with no backend data entry, no content keys for
 * ~250 countries per locale, and nothing to keep in sync.
 *
 * Resolutions are memoised per `(language, alpha-2)`. The document list is
 * small, but the phone-OTP country picker resolves ~240 countries on every
 * rebuild and again on every language switch, and each uncached call is an ICU
 * lookup.
 */
private val NAMES_BY_LANGUAGE: MutableMap<String, MutableMap<String, String>> = ConcurrentHashMap()

private const val ALPHA2_LENGTH = 2

private fun localeFor(language: String): Locale = Locale.forLanguageTag(language.ifBlank { "en" })

/**
 * Resolves an ISO 3166-1 alpha-2 code to a country name in [language].
 *
 * [fallback] is used whenever we cannot do better: a blank or malformed code,
 * or one the platform does not recognise. It should be the backend's English
 * name — returning the bare code is never right, because a user shown "AE"
 * learns strictly less than one shown "United Arab Emirates".
 *
 * Note [Locale.getDisplayCountry] echoes the input code back when it has no
 * name for it, so that case is detected and routed to [fallback] too.
 */
internal fun countryDisplayName(
    alpha2: String?,
    language: String,
    fallback: String,
): String {
    val code = alpha2?.trim()?.uppercase().orEmpty()
    if (code.length != ALPHA2_LENGTH) return fallback
    val cache = NAMES_BY_LANGUAGE.getOrPut(language) { ConcurrentHashMap() }
    // Only successful resolutions are cached. A miss falls through to the
    // caller's own English, which differs per document row — caching that
    // under the country code would leak one row's fallback onto another's.
    val resolved = cache[code] ?: resolveRegionName(code, language)?.also { cache[code] = it }
    return resolved ?: fallback
}

/**
 * The raw ICU lookup, or `null` when it cannot do better than the code.
 *
 * [Locale.getDisplayCountry] echoes its input back for a region it has no name
 * for — "QQ" in, "QQ" out, no exception — so that case is filtered here rather
 * than allowed to reach a screen looking like data.
 */
private fun resolveRegionName(
    code: String,
    language: String,
): String? =
    runCatching {
        Locale.Builder().setRegion(code).build().getDisplayCountry(localeFor(language))
    }.getOrNull()
        ?.takeIf { it.isNotBlank() && !it.equals(code, ignoreCase = true) }

/**
 * Locale-aware comparator for country lists.
 *
 * `String.compareTo` orders by UTF-16 code unit, which puts every Arabic name
 * after every Latin one and ignores diacritics entirely — so a translated list
 * sorted that way is not merely differently ordered, it is unordered.
 *
 * A fresh [Collator] per call: it is stateful and not thread-safe, and a sort
 * happens once per list rather than once per row.
 */
internal fun countryNameComparator(language: String): Comparator<String> {
    val collator =
        runCatching { Collator.getInstance(localeFor(language)) }.getOrNull()
            ?: return naturalOrder()
    return Comparator { a, b -> collator.compare(a, b) }
}
