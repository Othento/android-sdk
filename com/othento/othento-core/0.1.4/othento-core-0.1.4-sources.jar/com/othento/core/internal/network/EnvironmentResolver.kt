package com.othento.core.internal.network

/**
 * Internal-only resolver for the backend base URL.
 *
 * There is a single Othento backend. Whether an account is sandbox or live is
 * decided server-side by the API key the session was created with, and is
 * reflected in the flow UI — the client never routes on it. This matches the
 * web SDK, whose verification UI calls one hardcoded host.
 *
 * The SDK previously routed on the apiKey prefix. Token mode carries no
 * apiKey (the host's server creates the session), so it fell through to the
 * development host and every production SAT failed.
 *
 * [BASE_URL_OVERRIDE_PROPERTY] is read first so the sample app can point at a
 * non-production backend. It is a JVM system property, not a public API, and
 * is never surfaced through `OthentoConfig`.
 */
internal object EnvironmentResolver {
    const val PRODUCTION_BASE_URL: String = "https://sdk-api.othento.com"
    const val BASE_URL_OVERRIDE_PROPERTY: String = "othento.internal.baseUrl"

    fun resolveBaseUrl(): String =
        System
            .getProperty(BASE_URL_OVERRIDE_PROPERTY)
            ?.takeIf { it.isNotBlank() }
            ?: PRODUCTION_BASE_URL
}
