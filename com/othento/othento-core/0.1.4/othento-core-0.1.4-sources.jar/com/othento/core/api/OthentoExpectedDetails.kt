package com.othento.core.api

/**
 * Typed identity hints forwarded into the create-session call so the
 * backend can compare them against the data extracted from the document
 * and selfie.
 *
 * Mirrors the cross-platform contract's `ExpectedDetails` shape (Web / iOS
 * share the same 9 fields and the same JSON keys). All fields are optional;
 * send only what the host already knows about the user.
 *
 * Wire format: each field serializes to a JSON property with the literal
 * camelCase name shown here.
 *
 * @property firstName The user's first (given) name.
 * @property lastName The user's last (family) name.
 * @property dateOfBirth Must be `yyyy-MM-dd`, e.g. `1988-01-01`.
 * @property gender `"M"` or `"F"`.
 * @property nationality ISO 3166-1 alpha-3 country code, e.g. `JOR`.
 * @property country ISO 3166-1 alpha-3 country code, e.g. `JOR`.
 * @property address The user's address as free text.
 * @property documentNumber The ID document number.
 * @property ipAddress The IPv4 address the end user is expected to connect from.
 */
public data class OthentoExpectedDetails(
    val firstName: String? = null,
    val lastName: String? = null,
    val dateOfBirth: String? = null,
    val gender: String? = null,
    val nationality: String? = null,
    val country: String? = null,
    val address: String? = null,
    val documentNumber: String? = null,
    val ipAddress: String? = null,
)
